TEXT-ONLY review. All complete material is inline below. Do not call tools, edit files, run tests, shell or repository inspection. Every permission request terminates this attempt. Return concrete findings with call path/evidence; no implementation.

# Reviewer Prompt Template

Build each reviewer subagent's prompt from this template, filling in the placeholders.

---

You are an adversarial code reviewer. Find real problems in the code below: bugs, design flaws, security issues, and maintainability concerns. You are not here to be helpful or encouraging. You are here to stress-test.

## Intent

The author's stated intent for this change:

> Implement only C07: core-issued immutable expiring command windows, final per-write claim, complete/partial/failed attempt evidence independent of feedback, bounded refresh, clock monotonicity. Stop/expiry/fault/replacement must not lose an in-flight receipt or revive motion. Owner tokens and limits start C08 onward, do not flag those planned fields as C07 defects. All hardware remains blocked. Bench defaults stay unchanged; fixture evidence establishes software only. Parent has checked code and cheap regressions, but adversarial review must find gaps independently.

You are reviewing whether the code achieves this intent well. Do NOT question the intent itself. Assume the goal is correct and challenge the execution.

## Code Under Review


### joint_contract.py
```
"""Frozen domain records and status types for joint control.

All records are immutable (frozen) data contracts with no transport or clock ownership.
"""

from dataclasses import dataclass
from enum import Enum
import math
from typing import Literal

from joint_mapping import JointMap, JointSample, JointTarget


class State(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    CHECKING = "checking"
    READY = "ready"
    ARMED = "armed"
    MOVING = "moving"
    STOPPED = "stopped"
    FAULT = "fault"


class DecisionCode(str, Enum):
    ACCEPTED = "accepted"
    INVALID_STATE = "invalid_state"
    INVALID_ARGUMENT = "invalid_argument"
    INVALID_SOURCE = "invalid_source"
    UNKNOWN_JOINT = "unknown_joint"
    INVALID_OBSERVATION = "invalid_observation"
    FAULT_ACK_REQUIRED = "fault_ack_required"
    FAULT_LATCHED = "fault_latched"
    OBSERVATIONS_INCOMPLETE = "observations_incomplete"
    STALE_FEEDBACK = "stale_feedback"
    UNHEALTHY = "unhealthy"
    NOT_STOPPED = "not_stopped"
    DUPLICATE_OR_OLDER = "duplicate_or_older"
    EXPIRED = "expired"


class CommunicationFailure(str, Enum):
    TIMEOUT = "timeout"
    INVALID_FEEDBACK = "invalid_feedback"
    DRIVER_FAILURE = "driver_failure"


class WriteResult(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"


@dataclass(frozen=True)
class Decision:
    accepted: bool
    code: DecisionCode

    def __post_init__(self) -> None:
        if type(self.accepted) is not bool:
            raise ValueError("accepted must be a bool")
        if not isinstance(self.code, DecisionCode):
            raise ValueError("code must be a DecisionCode")
        if self.accepted != (self.code is DecisionCode.ACCEPTED):
            raise ValueError("accepted must match the decision code")

    def __bool__(self) -> bool:
        return self.accepted


@dataclass(frozen=True)
class JointSpec:
    name: str
    motor_id: int
    mapping: JointMap

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if not isinstance(self.mapping, JointMap):
            raise ValueError("mapping must be a JointMap")


@dataclass(frozen=True)
class JointFault:
    name: str
    motor_id: int
    errors: int = 0
    warnings: int = 0
    timeout: bool = False
    communication_error: CommunicationFailure | None = None
    stale: bool = False
    communication_errors: tuple[CommunicationFailure, ...] = ()

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if type(self.stale) is not bool:
            raise ValueError("stale must be a bool")
        if type(self.communication_errors) is not tuple or any(
            not isinstance(c, CommunicationFailure) for c in self.communication_errors
        ):
            raise ValueError("communication_errors must be a tuple of CommunicationFailure")

        if len(self.communication_errors) != len(set(self.communication_errors)):
            raise ValueError("communication_errors must contain unique codes")
        if self.communication_error is not None and self.communication_errors and (
            self.communication_error not in self.communication_errors
        ):
            raise ValueError("communication_error must belong to communication_errors")

        if self.communication_error is not None and not self.communication_errors:
            object.__setattr__(self, "communication_errors", (self.communication_error,))
        elif self.communication_errors and self.communication_error is None:
            object.__setattr__(self, "communication_error", self.communication_errors[-1])


@dataclass(frozen=True)
class MotorHealth:
    mode: int
    errors: int
    warnings: int
    timeout: bool

    def __post_init__(self) -> None:
        if type(self.mode) is not int or self.mode not in (0, 1):
            raise ValueError("mode must be the integer 0 or 1")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")

    @property
    def healthy(self) -> bool:
        return self.errors == 0 and self.warnings == 0 and not self.timeout


@dataclass(frozen=True)
class SourceIdentity:
    backend: Literal["physical", "demo", "fixture"]
    identity: str
    connection: int

    def __post_init__(self) -> None:
        if type(self.backend) is not str or self.backend not in ("physical", "demo", "fixture"):
            raise ValueError("backend must be physical, demo, or fixture")
        if type(self.identity) is not str or not self.identity.strip():
            raise ValueError("identity must be a non-empty string")
        if type(self.connection) is not int or self.connection < 0:
            raise ValueError("connection must be a nonnegative integer")


@dataclass(frozen=True)
class JointStatus:
    sample: JointSample | None = None
    health: MotorHealth | None = None
    received_at: float | None = None
    communication_error: CommunicationFailure | None = None

    def __post_init__(self) -> None:
        if (self.sample is None) != (self.health is None):
            raise ValueError("sample and health must both be present or both be absent")
        if self.sample is not None and not isinstance(self.sample, JointSample):
            raise ValueError("sample must be a JointSample")
        if self.health is not None and not isinstance(self.health, MotorHealth):
            raise ValueError("health must be MotorHealth")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if self.valid and self.received_at is None:
            raise ValueError("a valid observation requires received_at")
        if self.received_at is not None:
            if isinstance(self.received_at, bool) or not isinstance(self.received_at, (int, float)):
                raise ValueError("received_at must be a finite real number or None")
            try:
                received_at = float(self.received_at)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("received_at must be finite") from exc
            if not math.isfinite(received_at):
                raise ValueError("received_at must be finite")
            if not self.valid:
                raise ValueError("received_at requires a valid observation")
            object.__setattr__(self, "received_at", received_at)

    @property
    def valid(self) -> bool:
        return self.sample is not None and self.health is not None

    @property
    def healthy(self) -> bool:
        return self.valid and self.health.healthy and self.communication_error is None

    @property
    def errors(self) -> int:
        return self.health.errors if self.health is not None else 0

    @property
    def warnings(self) -> int:
        return self.health.warnings if self.health is not None else 0

    @property
    def timeout(self) -> bool:
        return self.health.timeout if self.health is not None else False


@dataclass(frozen=True)
class IntentWindow:
    id: int
    created_at_s: float
    expires_at_s: float

    def __post_init__(self) -> None:
        if type(self.id) is not int or not (0 <= self.id <= (1 << 64) - 1):
            raise ValueError("window ID must be an integer from 0 to 2**64 - 1")
        if isinstance(self.created_at_s, bool) or not isinstance(self.created_at_s, (int, float)):
            raise ValueError("created_at_s must be a finite real number")
        if isinstance(self.expires_at_s, bool) or not isinstance(self.expires_at_s, (int, float)):
            raise ValueError("expires_at_s must be a finite real number")
        try:
            created = float(self.created_at_s)
            expires = float(self.expires_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("window timestamps must be finite") from exc
        if not math.isfinite(created) or not math.isfinite(expires):
            raise ValueError("window timestamps must be finite")
        if expires <= created:
            raise ValueError("expires_at_s must be strictly greater than created_at_s")
        object.__setattr__(self, "created_at_s", created)
        object.__setattr__(self, "expires_at_s", expires)


@dataclass(frozen=True)
class Target:
    sequence: int
    joints: tuple[JointTarget, ...]
    window: IntentWindow

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if type(self.joints) is not tuple:
            raise ValueError("joints must be a tuple of JointTarget")
        if not self.joints:
            raise ValueError("joints must be a non-empty tuple")
        if any(not isinstance(joint, JointTarget) for joint in self.joints):
            raise ValueError("every joint target must be a JointTarget")
        if not isinstance(self.window, IntentWindow):
            raise ValueError("window must be an IntentWindow")


@dataclass(frozen=True)
class RefreshPlan:
    plan_id: int
    target: Target
    prepared_at_s: float
    joint_targets: tuple[JointTarget, ...]

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, Target):
            raise ValueError("target must be a Target")
        if isinstance(self.prepared_at_s, bool) or not isinstance(self.prepared_at_s, (int, float)):
            raise ValueError("prepared_at_s must be a finite real number")
        try:
            prepared = float(self.prepared_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("prepared_at_s must be finite") from exc
        if not math.isfinite(prepared):
            raise ValueError("prepared_at_s must be finite")
        object.__setattr__(self, "prepared_at_s", prepared)
        if type(self.joint_targets) is not tuple or not self.joint_targets:
            raise ValueError("joint_targets must be a non-empty tuple")
        if any(not isinstance(jt, JointTarget) for jt in self.joint_targets):
            raise ValueError("every joint target must be a JointTarget")

    @property
    def window(self) -> IntentWindow:
        return self.target.window


@dataclass(frozen=True)
class JointDispatchedRecord:
    sequence: int
    target: JointTarget
    dispatched_at_s: float

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if isinstance(self.dispatched_at_s, bool) or not isinstance(self.dispatched_at_s, (int, float)):
            raise ValueError("dispatched_at_s must be a finite real number")
        try:
            dispatched = float(self.dispatched_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("dispatched_at_s must be finite") from exc
        if not math.isfinite(dispatched):
            raise ValueError("dispatched_at_s must be finite")
        object.__setattr__(self, "dispatched_at_s", dispatched)


@dataclass(frozen=True)
class JointDispatchAttempt:
    plan_id: int
    sequence: int
    target: JointTarget
    result: WriteResult
    started_at_s: float

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if not isinstance(self.result, WriteResult):
            raise ValueError("result must be a WriteResult")
        if isinstance(self.started_at_s, bool) or not isinstance(self.started_at_s, (int, float)):
            raise ValueError("started_at_s must be a finite real number")
        try:
            started = float(self.started_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("started_at_s must be finite") from exc
        if not math.isfinite(started):
            raise ValueError("started_at_s must be finite")
        object.__setattr__(self, "started_at_s", started)


@dataclass(frozen=True)
class Snapshot:
    state: State
    joint_names: tuple[str, ...]
    joints: tuple[JointStatus, ...]
    source: SourceIdentity | None
    fault_latched: bool
    feedback_ages_s: tuple[float | None, ...]
    faults: tuple[JointFault, ...] = ()
    admitted_target: Target | None = None
    prepared_plan: RefreshPlan | None = None
    dispatched_records: tuple[JointDispatchedRecord | None, ...] = ()
    last_sequence: int = -1
    dispatch_attempts: tuple[JointDispatchAttempt | None, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.state, State):
            raise ValueError("state must be a State")
        if type(self.joint_names) is not tuple or any(type(name) is not str for name in self.joint_names):
            raise ValueError("joint_names must be a tuple of strings")
        if type(self.joints) is not tuple or any(not isinstance(joint, JointStatus) for joint in self.joints):
            raise ValueError("joints must be a tuple of JointStatus")
        if type(self.feedback_ages_s) is not tuple:
            raise ValueError("feedback_ages_s must be a tuple")
        if len(self.joint_names) != len(self.joints):
            raise ValueError("joint names and statuses must have equal lengths")
        if len(self.feedback_ages_s) != len(self.joints):
            raise ValueError("feedback ages and joint statuses must have equal lengths")
        normalized_ages: list[float | None] = []
        for joint, age in zip(self.joints, self.feedback_ages_s):
            if joint.received_at is None:
                if age is not None:
                    raise ValueError("feedback age must be None before a joint is received")
                normalized_ages.append(None)
                continue
            if isinstance(age, bool) or not isinstance(age, (int, float)):
                raise ValueError("feedback age must be a finite nonnegative number")
            try:
                age_value = float(age)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("feedback age must be finite") from exc
            if not math.isfinite(age_value) or age_value < 0.0:
                raise ValueError("feedback age must be finite and nonnegative")
            normalized_ages.append(age_value)
        object.__setattr__(self, "feedback_ages_s", tuple(normalized_ages))
        if self.source is not None and not isinstance(self.source, SourceIdentity):
            raise ValueError("source must be a SourceIdentity or None")
        if type(self.fault_latched) is not bool:
            raise ValueError("fault_latched must be a bool")
        if type(self.faults) is not tuple or any(not isinstance(f, JointFault) for f in self.faults):
            raise ValueError("faults must be a tuple of JointFault")
        if self.admitted_target is not None and not isinstance(self.admitted_target, Target):
            raise ValueError("admitted_target must be a Target or None")
        if self.prepared_plan is not None and not isinstance(self.prepared_plan, RefreshPlan):
            raise ValueError("prepared_plan must be a RefreshPlan or None")
        if not self.dispatched_records:
            object.__setattr__(self, "dispatched_records", tuple(None for _ in self.joints))
        else:
            if type(self.dispatched_records) is not tuple or len(self.dispatched_records) != len(self.joints):
                raise ValueError("dispatched_records must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchedRecord) for r in self.dispatched_records):
                raise ValueError("every dispatched record must be a JointDispatchedRecord or None")
        if not self.dispatch_attempts:
            object.__setattr__(self, "dispatch_attempts", tuple(None for _ in self.joints))
        else:
            if type(self.dispatch_attempts) is not tuple or len(self.dispatch_attempts) != len(self.joints):
                raise ValueError("dispatch_attempts must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchAttempt) for r in self.dispatch_attempts):
                raise ValueError("every dispatch attempt must be a JointDispatchAttempt or None")
        if type(self.last_sequence) is not int or not (-1 <= self.last_sequence <= (1 << 64) - 1):
            raise ValueError("last_sequence must be an integer from -1 to 2**64 - 1")

    @property
    def affected_joints(self) -> tuple[str, ...]:
        return tuple(fault.name for fault in self.faults)

```

### joint_controller.py
```
"""Transport-free lifecycle and health state for an ordered joint set.

All methods on a JointCore belong to one calling thread. The core owns no
transport and all externally visible records are immutable snapshots.
"""

from collections.abc import Iterable
from dataclasses import dataclass
import math
import time

from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    Decision,
    DecisionCode,
    IntentWindow,
    JointDispatchAttempt,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    MotorHealth,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_mapping import JointSample

__all__ = ("JointCore",)


@dataclass(frozen=True)
class _DispatchClaim:
    plan: RefreshPlan
    index: int
    started_at_s: float


class JointCore:
    """Thread-confined state machine for one fixed, ordered set of joints."""

    def __init__(
        self,
        joints: Iterable[JointSpec],
        *,
        feedback_max_age_s: float = 0.5,
        max_window_s: float = 1.0,
        clock=None,
    ):
        if isinstance(feedback_max_age_s, bool) or not isinstance(feedback_max_age_s, (int, float)):
            raise ValueError("feedback_max_age_s must be a finite positive real number")
        try:
            feedback_max_age_s = float(feedback_max_age_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("feedback_max_age_s must be finite") from exc
        if not math.isfinite(feedback_max_age_s) or feedback_max_age_s <= 0.0:
            raise ValueError("feedback_max_age_s must be finite and positive")

        if isinstance(max_window_s, bool) or not isinstance(max_window_s, (int, float)):
            raise ValueError("max_window_s must be a finite positive real number")
        try:
            max_window_s = float(max_window_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_window_s must be finite") from exc
        if not math.isfinite(max_window_s) or max_window_s <= 0.0:
            raise ValueError("max_window_s must be finite and positive")

        if clock is None:
            clock = time.monotonic
        if not callable(clock):
            raise ValueError("clock must be callable")

        try:
            specs = tuple(joints)
        except TypeError as exc:
            raise ValueError("joints must be an iterable of JointSpec") from exc
        if not specs:
            raise ValueError("at least one active joint is required")
        if any(not isinstance(spec, JointSpec) for spec in specs):
            raise ValueError("every joint must be a JointSpec")
        if len({spec.name for spec in specs}) != len(specs):
            raise ValueError("joint names must be unique")
        if len({spec.motor_id for spec in specs}) != len(specs):
            raise ValueError("motor IDs must be unique")

        self._specs: tuple[JointSpec, ...] = specs
        self._id_to_index: dict[int, int] = {
            spec.motor_id: index for index, spec in enumerate(specs)
        }
        self._state: State = State.DISCONNECTED
        self._observations: list[JointStatus] = [JointStatus() for _ in specs]
        self._source: SourceIdentity | None = None
        self._feedback_max_age_s = feedback_max_age_s
        self._max_window_s = max_window_s
        self._clock = clock
        self._now_high_water_s: float | None = None
        self._next_window_id: int = 0
        self._offered_window: IntentWindow | None = None
        self._admitted_target: Target | None = None
        self._prepared_plan: RefreshPlan | None = None
        self._next_plan_id: int = 0
        self._next_dispatch_index: int = 0
        self._dispatch_claim: _DispatchClaim | None = None
        self._dispatched_records: list[JointDispatchedRecord | None] = [None for _ in specs]
        self._dispatch_attempts: list[JointDispatchAttempt | None] = [None for _ in specs]
        self._faults: dict[str, JointFault] = {}
        self._last_sequence: int = -1

    @property
    def joint_specs(self) -> tuple[JointSpec, ...]:
        return self._specs

    @property
    def admitted_target(self) -> Target | None:
        return self._admitted_target

    @staticmethod
    def _accepted() -> Decision:
        return Decision(True, DecisionCode.ACCEPTED)

    @staticmethod
    def _rejected(code: DecisionCode) -> Decision:
        return Decision(False, code)

    def _clear_observations(self) -> None:
        self._observations = [JointStatus() for _ in self._specs]

    def _invalidate_plan(self) -> None:
        self._prepared_plan = None
        self._next_dispatch_index = 0

    def _withdraw_motion(self) -> None:
        self._admitted_target = None
        self._invalidate_plan()

    def _record_dispatch_failure(self, index: int) -> None:
        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            spec.motor_id,
            communication_error=CommunicationFailure.DRIVER_FAILURE,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample,
            joint.health,
            joint.received_at,
            CommunicationFailure.DRIVER_FAILURE,
        )

    def _latch_joint_fault(
        self,
        name: str,
        motor_id: int,
        *,
        errors: int = 0,
        warnings: int = 0,
        timeout: bool = False,
        communication_error: CommunicationFailure | None = None,
        stale: bool = False,
    ) -> None:
        existing = self._faults.get(name) or JointFault(name, motor_id)
        communication_errors = existing.communication_errors
        if communication_error is not None and communication_error not in communication_errors:
            communication_errors += (communication_error,)
        fault = JointFault(
            name, motor_id,
            errors=existing.errors | errors,
            warnings=existing.warnings | warnings,
            timeout=existing.timeout or timeout,
            stale=existing.stale or stale,
            communication_error=communication_error or existing.communication_error,
            communication_errors=communication_errors,
        )
        self._faults[name] = fault
        self._state = State.FAULT
        self._withdraw_motion()

    def _withdraw_expired_goal(self) -> None:
        self._withdraw_motion()
        if self._faults:
            self._state = State.FAULT
        elif self._state in (State.ARMED, State.MOVING):
            self._state = State.STOPPED

    def _now(self) -> float:
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("clock must return a finite real number")
        try:
            result = float(value)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("clock must return a finite real number") from exc
        if not math.isfinite(result):
            raise ValueError("clock must return a finite real number")
        if self._now_high_water_s is not None and result < self._now_high_water_s:
            raise ValueError(
                f"clock regressed from {self._now_high_water_s} to {result}"
            )
        self._now_high_water_s = result
        return result

    @staticmethod
    def _age(received_at: float, now: float) -> float:
        age = now - received_at
        if not math.isfinite(age) or age < 0.0:
            raise ValueError("clock must be monotonic and feedback age finite")
        return age

    def _all_fresh(self, now: float) -> bool:
        return all(
            joint.valid
            and joint.received_at is not None
            and self._age(joint.received_at, now) <= self._feedback_max_age_s
            for joint in self._observations
        )

    def _housekeeping(self, now: float) -> DecisionCode | None:
        if self._state in (State.READY, State.ARMED, State.MOVING):
            stale_specs = [
                spec
                for spec, joint in zip(self._specs, self._observations)
                if (
                    not joint.valid
                    or joint.received_at is None
                    or self._age(joint.received_at, now) > self._feedback_max_age_s
                )
            ]
            if stale_specs:
                for spec in stale_specs:
                    self._latch_joint_fault(spec.name, spec.motor_id, stale=True)
                return DecisionCode.STALE_FEEDBACK
        if (
            self._admitted_target is not None
            and now >= self._admitted_target.window.expires_at_s
        ):
            self._withdraw_expired_goal()
            return DecisionCode.EXPIRED
        return None

    def issue_window(self, valid_for_s: float) -> IntentWindow:
        if isinstance(valid_for_s, bool) or not isinstance(valid_for_s, (int, float)):
            raise ValueError("valid_for_s must be a finite positive real number")
        try:
            valid_for_s = float(valid_for_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("valid_for_s must be finite") from exc
        if not math.isfinite(valid_for_s) or valid_for_s <= 0.0:
            raise ValueError("valid_for_s must be finite and positive")
        if valid_for_s > self._max_window_s:
            raise ValueError(
                f"valid_for_s ({valid_for_s}) exceeds configured maximum window ({self._max_window_s})"
            )
        now = self._now()
        window_id = self._next_window_id
        if window_id > (1 << 64) - 1:
            raise OverflowError("window ID sequence exhausted")
        self._next_window_id += 1
        window = IntentWindow(
            id=window_id,
            created_at_s=now,
            expires_at_s=now + valid_for_s,
        )
        self._offered_window = window
        return window

    def begin_connect(self) -> Decision:
        if self._state is not State.DISCONNECTED or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        self._state = State.CONNECTING
        return self._accepted()

    def connected(self, source: SourceIdentity) -> Decision:
        if self._state is not State.CONNECTING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not isinstance(source, SourceIdentity):
            return self._rejected(DecisionCode.INVALID_SOURCE)
        self._clear_observations()
        self._source = source
        self._state = State.CONNECTED
        return self._accepted()

    def begin_check(self, *, acknowledge_fault: bool = False) -> Decision:
        if type(acknowledge_fault) is not bool:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._state not in (State.CONNECTED, State.STOPPED, State.FAULT) or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        if bool(self._faults) and not acknowledge_fault:
            return self._rejected(DecisionCode.FAULT_ACK_REQUIRED)
        self._clear_observations()
        self._withdraw_motion()
        self._state = State.CHECKING
        return self._accepted()

    def receive(
        self, motor_id: int, sample: JointSample, status: MotorHealth
    ) -> Decision:
        if self._state not in (
            State.CONNECTED,
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
            State.STOPPED,
            State.FAULT,
        ):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)
        if not isinstance(sample, JointSample) or not isinstance(status, MotorHealth):
            return self._rejected(DecisionCode.INVALID_OBSERVATION)

        now = self._now()
        self._observations[index] = JointStatus(sample, status, now)
        if not status.healthy:
            self._latch_joint_fault(
                self._specs[index].name,
                motor_id,
                errors=status.errors,
                warnings=status.warnings,
                timeout=status.timeout,
            )
        return self._accepted()

    def communication_failed(
        self, motor_id: int, code: CommunicationFailure
    ) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)

        if not isinstance(code, CommunicationFailure):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        failure_code = code

        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            motor_id,
            communication_error=failure_code,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample, joint.health, joint.received_at, failure_code
        )
        return self._accepted()

    def checked(self) -> Decision:
        if self._state is not State.CHECKING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)
        self._state = State.READY
        self._faults.clear()
        return self._accepted()

    def arm(self) -> Decision:
        if self._state is not State.READY:
            return self._rejected(DecisionCode.INVALID_STATE)
        if bool(self._faults):
            return self._rejected(DecisionCode.FAULT_LATCHED)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)
        self._state = State.ARMED
        return self._accepted()

    def tick(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        self._housekeeping(now)
        return self._accepted()

    def submit_target(self, target: Target) -> Decision:
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        housekeeping = self._housekeeping(now)
        if housekeeping is not None:
            return self._rejected(housekeeping)
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)

        if not isinstance(target, Target) or len(target.joints) != len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        if not isinstance(target.window, IntentWindow):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._offered_window is None:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if target.window.id < self._offered_window.id:
            return self._rejected(DecisionCode.EXPIRED)
        if target.window.id != self._offered_window.id:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if (
            target.window.created_at_s != self._offered_window.created_at_s
            or target.window.expires_at_s != self._offered_window.expires_at_s
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if now >= target.window.expires_at_s:
            return self._rejected(DecisionCode.EXPIRED)

        try:
            for spec, joint_target in zip(self._specs, target.joints):
                output = spec.mapping.to_output(joint_target)
                command(
                    spec.motor_id,
                    mode=1,
                    rpm=output.rpm,
                    kd=output.kd,
                    torque=output.tau_nm,
                    watchdog=True,
                    position=output.q_rad,
                    kp=output.kp,
                )
        except ValueError:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        if target.sequence <= self._last_sequence:
            return self._rejected(DecisionCode.DUPLICATE_OR_OLDER)

        self._admitted_target = target
        self._last_sequence = target.sequence
        self._invalidate_plan()
        return self._accepted()

    def prepare_refresh(self) -> RefreshPlan | None:
        if self._dispatch_claim is not None:
            return None
        if self._state not in (State.ARMED, State.MOVING):
            return None
        if self._state is State.FAULT or bool(self._faults):
            return None
        now = self._now()
        if self._housekeeping(now) is not None:
            return None
        if any(not joint.healthy for joint in self._observations):
            return None
        if self._admitted_target is None:
            return None

        try:
            for spec, joint_target in zip(self._specs, self._admitted_target.joints):
                output = spec.mapping.to_output(joint_target)
                command(
                    spec.motor_id,
                    mode=1,
                    rpm=output.rpm,
                    kd=output.kd,
                    torque=output.tau_nm,
                    watchdog=True,
                    position=output.q_rad,
                    kp=output.kp,
                )
        except ValueError:
            return None

        plan_id = self._next_plan_id
        if plan_id > (1 << 64) - 1:
            raise OverflowError("plan ID sequence exhausted")
        self._next_plan_id += 1

        plan = RefreshPlan(
            plan_id=plan_id,
            target=self._admitted_target,
            prepared_at_s=now,
            joint_targets=self._admitted_target.joints,
        )
        self._prepared_plan = plan
        self._next_dispatch_index = 0
        return plan

    def claim_dispatch(self, plan_id: int, index: int) -> bool:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return False
        if self._dispatch_claim is not None:
            return False
        if self._prepared_plan is None or self._prepared_plan.plan_id != plan_id:
            return False
        if self._state not in (State.ARMED, State.MOVING):
            return False
        if self._state is State.FAULT or bool(self._faults):
            return False
        if index < 0 or index >= len(self._specs):
            return False
        if index != self._next_dispatch_index:
            return False

        now = self._now()
        if self._housekeeping(now) is not None:
            return False
        if self._admitted_target is None or self._prepared_plan is None:
            return False
        if any(not joint.healthy for joint in self._observations):
            return False

        self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
        return True

    def dispatch_result(
        self, plan_id: int, index: int, result: WriteResult
    ) -> Decision:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if not isinstance(result, WriteResult):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        claim = self._dispatch_claim
        if claim is None or claim.plan.plan_id != plan_id or claim.index != index:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if index < 0 or index >= len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        self._dispatch_claim = None
        plan = claim.plan
        joint_target = plan.joint_targets[index]
        self._dispatch_attempts[index] = JointDispatchAttempt(
            plan_id=plan.plan_id,
            sequence=plan.target.sequence,
            target=joint_target,
            result=result,
            started_at_s=claim.started_at_s,
        )
        if result is WriteResult.COMPLETE:
            record = JointDispatchedRecord(
                sequence=plan.target.sequence,
                target=joint_target,
                dispatched_at_s=claim.started_at_s,
            )
            self._dispatched_records[index] = record
            try:
                now = self._now()
            except Exception:
                self._record_dispatch_failure(index)
                return self._rejected(DecisionCode.FAULT_LATCHED)

            housekeeping = self._housekeeping(now)
            still_current = (
                self._prepared_plan is plan
                and self._admitted_target is plan.target
                and self._state in (State.ARMED, State.MOVING)
                and not self._faults
            )
            if still_current and housekeeping is None:
                self._next_dispatch_index = index + 1
                self._state = State.MOVING
            return self._accepted()

        self._record_dispatch_failure(index)
        return self._rejected(DecisionCode.FAULT_LATCHED)

    def stop(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        self._withdraw_motion()
        if self._state is State.FAULT or bool(self._faults):
            self._state = State.FAULT
        else:
            self._state = State.STOPPED
        return self._accepted()

    def disconnect(self) -> Decision:
        self._state = State.DISCONNECTED
        self._source = None
        self._clear_observations()
        self._withdraw_motion()
        return self._accepted()

    def snapshot(self) -> Snapshot:
        received = [joint.received_at for joint in self._observations]
        now = self._now() if any(value is not None for value in received) else None
        ages = tuple(
            None if value is None else self._age(value, now)
            for value in received
        )
        faults = tuple(self._faults[spec.name] for spec in self._specs
                       if spec.name in self._faults)
        return Snapshot(
            state=self._state,
            joint_names=tuple(spec.name for spec in self._specs),
            joints=tuple(self._observations),
            source=self._source,
            fault_latched=bool(self._faults),
            feedback_ages_s=ages,
            faults=faults,
            admitted_target=self._admitted_target,
            prepared_plan=self._prepared_plan,
            dispatched_records=tuple(self._dispatched_records),
            dispatch_attempts=tuple(self._dispatch_attempts),
            last_sequence=self._last_sequence,
        )

```

### im6014_serial.py
```
from collections import deque
from dataclasses import dataclass
import math
import threading
import time

from im6014_codec import feedback
from joint_contract import WriteResult

_monotonic = time.monotonic

_REQUEST_BYTES = 20
_REPLY_BYTES = 26
_CAPTURE_CAPACITY = 256
_IDENTITY_CHARS = 96
_PORT_CHARS = 160
_TAIL_BYTES = 25
_OUTCOMES = frozenset(('OK', 'TIMEOUT', 'INVALID_FEEDBACK', 'DRIVER_FAILURE'))
_DECODED_INTEGER_LIMITS = {
    'id': (0, 14), 'mode': (0, 1), 'timeout': (0, 1),
    'driver_c': (-128, 127), 'winding_c': (0, 255),
    'errors': (0, 0xFFFFFFFF), 'warnings': (0, 7),
}
_DECODED_FLOAT_FIELDS = ('voltage', 'torque_nm', 'rpm', 'position_rad')


def _bounded_count(value):
    if type(value) is not int or value < 0:
        return 0
    return min(value, 0x7FFFFFFF)


def _bounded_tail(value):
    if isinstance(value, bytes):
        return value[-_TAIL_BYTES:]
    if isinstance(value, bytearray):
        return bytes(value[-_TAIL_BYTES:])
    if isinstance(value, memoryview):
        try:
            return value.cast('B')[-_TAIL_BYTES:].tobytes()
        except (TypeError, ValueError):
            return b''
    return b''


class TransactionTimeoutError(RuntimeError):
    """The bounded transaction expired; diagnostics contain no exception text."""

    def __init__(self, message, *, rejected=0, crc_rejected=0, tail=b''):
        super().__init__(message)
        self.rejected_frames = _bounded_count(rejected)
        self.crc_rejected_frames = min(_bounded_count(crc_rejected), self.rejected_frames)
        self.tail = _bounded_tail(tail)


class InvalidFeedbackError(TransactionTimeoutError):
    """The transaction expired after rejecting one or more candidate frames."""


class WriteCancelledError(RuntimeError):
    """The serial write was cancelled before transmission by the pre-write hook."""


@dataclass(frozen=True)
class _PacketRecord:
    source: str
    identity: str
    connection: int
    port: str
    baud: int
    requested_motor_id: int
    started_s: float
    ended_s: float | None
    request_hex: str
    reply_hex: str
    decoded_fields: tuple
    outcome: str
    rejected_frames: int
    crc_rejected_frames: int
    tail_hex: str


class PacketCapture:
    """A copy-out, fixed-capacity ring of allowlisted packet diagnostics."""

    def __init__(self, capacity=_CAPTURE_CAPACITY, *, clock=None):
        if type(capacity) is not int or not 1 <= capacity <= _CAPTURE_CAPACITY:
            raise ValueError('Capture capacity must be an integer from 1 to 256')
        if clock is not None and not callable(clock):
            raise ValueError('Capture clock must be callable')
        self.capacity = capacity
        self._clock = time.monotonic if clock is None else clock
        self._records = deque(maxlen=capacity)
        self._dropped = 0
        self._lock = threading.Lock()

    def _now(self):
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError('Capture clock must return a finite monotonic number')
        try:
            value = float(value)
        except (OverflowError, TypeError, ValueError) as error:
            raise ValueError('Capture clock must return a finite monotonic number') from error
        if not math.isfinite(value) or not 0 <= value <= 1e12:
            raise ValueError('Capture clock must return a finite monotonic number')
        return value

    def _append(self, record):
        with self._lock:
            if len(self._records) == self.capacity:
                self._dropped = min(self._dropped + 1, 0x7FFFFFFFFFFFFFFF)
            self._records.append(record)

    def snapshot(self):
        with self._lock:
            records = self._records.copy()
            dropped = self._dropped
        return {
            'capacity': self.capacity,
            'dropped': dropped,
            'records': [
                {
                    'source': item.source,
                    'identity': item.identity,
                    'connection': item.connection,
                    'port': item.port,
                    'baud': item.baud,
                    'requested_motor_id': item.requested_motor_id,
                    'started_s': item.started_s,
                    'ended_s': item.ended_s,
                    'request_hex': item.request_hex,
                    'reply_hex': item.reply_hex,
                    'decoded_fields': dict(item.decoded_fields),
                    'outcome': item.outcome,
                    'rejected_frames': item.rejected_frames,
                    'crc_rejected_frames': item.crc_rejected_frames,
                    'tail_hex': item.tail_hex,
                }
                for item in records
            ],
        }


def _capture_metadata(source, identity, connection, port, baud, motor_id):
    if type(source) is not str or source not in ('physical', 'demo', 'fixture'):
        raise ValueError('Capture source must be physical, demo, or fixture')
    if type(identity) is not str or not identity:
        raise ValueError('Capture identity must be a nonempty string')
    if type(port) is not str:
        raise ValueError('Capture port must be a string')
    if source == 'physical' and not port:
        raise ValueError('Physical capture requires an explicit port')
    if type(connection) is not int or not 0 <= connection <= 0x7FFFFFFF:
        raise ValueError('Capture connection must be a nonnegative integer')
    if type(baud) is not int or baud not in (4000000, 6000000):
        raise ValueError('Capture baud must be 4000000 or 6000000')
    if type(motor_id) is not int or not 0 <= motor_id <= 14:
        raise ValueError('Capture motor ID must be an integer from 0 to 14')
    return source, identity[:_IDENTITY_CHARS], connection, port[:_PORT_CHARS], baud, motor_id


def _packet_prefix(value, limit):
    if isinstance(value, bytes):
        return value[:limit]
    if isinstance(value, bytearray):
        return bytes(value[:limit])
    if isinstance(value, memoryview):
        try:
            return value.cast('B')[:limit].tobytes()
        except (TypeError, ValueError):
            return b''
    return b''


def _reply_prefix(result):
    if type(result) is not dict:
        return b''
    raw = result.get('raw')
    if isinstance(raw, bytes):
        return raw[:_REPLY_BYTES]
    if isinstance(raw, bytearray):
        return bytes(raw[:_REPLY_BYTES])
    if isinstance(raw, memoryview):
        try:
            return raw.cast('B')[:_REPLY_BYTES].tobytes()
        except (TypeError, ValueError):
            return b''
    if type(raw) is str:
        raw = raw[:_REPLY_BYTES * 2]
        raw = raw[:len(raw) - len(raw) % 2]
        try:
            return bytes.fromhex(raw)[:_REPLY_BYTES]
        except ValueError:
            return b''
    return b''


def _decoded_fields(result):
    if type(result) is not dict:
        return ()
    fields = []
    for name, (minimum, maximum) in _DECODED_INTEGER_LIMITS.items():
        value = result.get(name)
        if type(value) is int and minimum <= value <= maximum:
            fields.append((name, value))
    for name in _DECODED_FLOAT_FIELDS:
        value = result.get(name)
        if type(value) in (int, float):
            try:
                value = float(value)
            except (OverflowError, TypeError, ValueError):
                continue
            if math.isfinite(value) and abs(value) <= 1e6:
                fields.append((name, value))
    return tuple(fields)


def _outcome(error):
    if isinstance(error, InvalidFeedbackError):
        return 'INVALID_FEEDBACK'
    if isinstance(error, (TransactionTimeoutError, TimeoutError)):
        return 'TIMEOUT'
    return 'DRIVER_FAILURE'


def capture_exchange(capture, exchange_fn, bus, packet, motor_id, *,
                     source, identity, connection, port, baud,
                     before_write=None, on_write=None):
    """Call the current caller's three-argument exchange and retain one safe record."""
    if not isinstance(capture, PacketCapture):
        raise ValueError('Capture must be a PacketCapture')
    if not callable(exchange_fn):
        raise ValueError('Capture exchange function must be callable')
    context = _capture_metadata(source, identity, connection, port, baud, motor_id)
    source, identity, connection, port, baud, motor_id = context
    request = _packet_prefix(packet, _REQUEST_BYTES)
    started = capture._now()
    reply = b''
    decoded = ()
    outcome = 'DRIVER_FAILURE'
    rejected = 0
    crc_rejected = 0
    tail = b''
    kwargs = {}
    if before_write is not None:
        kwargs['before_write'] = before_write
    if on_write is not None:
        kwargs['on_write'] = on_write
    try:
        if kwargs:
            result = exchange_fn(bus, packet, motor_id, **kwargs)
        else:
            result = exchange_fn(bus, packet, motor_id)
        reply = _reply_prefix(result)
        decoded = _decoded_fields(result)
        outcome = 'OK'
        return result
    except Exception as error:
        outcome = _outcome(error)
        if isinstance(error, TransactionTimeoutError):
            rejected = _bounded_count(error.rejected_frames)
            crc_rejected = min(_bounded_count(error.crc_rejected_frames), rejected)
            tail = _bounded_tail(error.tail)
        raise
    finally:
        try:
            ended = capture._now()
        except Exception:
            ended = None
        if ended is not None and ended < started:
            ended = None
        if outcome not in _OUTCOMES:
            outcome = 'DRIVER_FAILURE'
        capture._append(_PacketRecord(
            source, identity, connection, port, baud, motor_id, started, ended,
            request.hex(), reply.hex(), decoded, outcome, rejected, crc_rejected, tail.hex(),
        ))


def _remaining(deadline):
    remaining = deadline - _monotonic()
    if remaining <= 0:
        raise TransactionTimeoutError('No validated motor feedback within deadline')
    return remaining


def _bounded_timeout(original, remaining, writing=False):
    if original is None or writing and original == 0:
        return remaining
    return min(original, remaining)


def _receive(bus, motor_id, deadline, original_timeout):
    data = bytearray()
    rejected = 0
    crc_rejected = 0
    last_error = ''
    try:
        while True:
            bus.timeout = _bounded_timeout(original_timeout, _remaining(deadline))
            _remaining(deadline)
            size = min(26, max(1, bus.in_waiting))
            _remaining(deadline)
            data.extend(bus.read(size))
            _remaining(deadline)
            while True:
                _remaining(deadline)
                start = data.find(b'\xfc\xee')
                if start < 0:
                    data[:] = b'\xfc' if data.endswith(b'\xfc') else b''
                    break
                del data[:start]
                if len(data) < 26:
                    break
                try:
                    result = feedback(bytes(data[:26]), motor_id)
                except RuntimeError as error:
                    rejected += 1
                    last_error = str(error)
                    crc_rejected += int("CRC" in last_error)
                    del data[:1]
                else:
                    _remaining(deadline)
                    return result
    except TransactionTimeoutError as error:
        crc_detail = f'CRC rejected {crc_rejected}; ' if crc_rejected else ''
        message = (f'No validated motor feedback within deadline; rejected {rejected}; '
                   f'{crc_detail}{last_error}; tail {data[-25:].hex()}')
        error_type = InvalidFeedbackError if rejected else TransactionTimeoutError
        raise error_type(message, rejected=rejected, crc_rejected=crc_rejected,
                         tail=data[-25:]) from error


def exchange(bus, packet, motor_id, deadline_s=0.05, *, before_write=None, on_write=None):
    """Reset once, write once, and return requested feedback before expiry.

    The bus has one owner. Its timeout setters, reset and I/O must obey their
    driver contract. Objects without write_timeout must write immediately.
    Synchronous driver calls and cleanup cannot be forcibly interrupted.
    Read/write settings are restored before any validated result is returned.
    If the final deadline check expires after before_write allows dispatch,
    on_write receives FAILED even though bus.write was never called.
    """
    if type(motor_id) is not int or not 0 <= motor_id <= 14:
        raise ValueError('Expected motor ID must be an integer from 0 to 14')
    if isinstance(deadline_s, bool) or not isinstance(deadline_s, (int, float)):
        raise ValueError('Transaction deadline must be a finite positive int or float')
    try:
        deadline_s = float(deadline_s)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError('Transaction deadline must be finite and positive') from error
    if not math.isfinite(deadline_s) or deadline_s <= 0:
        raise ValueError('Transaction deadline must be finite and positive')
    if before_write is not None and not callable(before_write):
        raise ValueError('before_write hook must be callable')
    if on_write is not None and not callable(on_write):
        raise ValueError('on_write hook must be callable')
    deadline = _monotonic() + deadline_s
    if not math.isfinite(deadline):
        raise ValueError('Transaction deadline is not representable')
    original_timeout = bus.timeout
    has_write_timeout = hasattr(bus, 'write_timeout')
    original_write_timeout = bus.write_timeout if has_write_timeout else None
    failure = None
    try:
        _remaining(deadline)
        bus.reset_input_buffer()
        _remaining(deadline)
        if has_write_timeout:
            bus.write_timeout = _bounded_timeout(original_write_timeout, _remaining(deadline), writing=True)
        _remaining(deadline)
        if before_write is not None:
            allowed = before_write()
            if not allowed:
                raise WriteCancelledError('Serial write cancelled by pre-write hook')
        try:
            _remaining(deadline)
        except Exception:
            if on_write is not None:
                on_write(WriteResult.FAILED)
            raise
        try:
            written = bus.write(packet)
        except Exception:
            if on_write is not None:
                try:
                    on_write(WriteResult.FAILED)
                except Exception:
                    pass
            raise
        if type(written) is int and written == len(packet):
            write_result = WriteResult.COMPLETE
        elif type(written) is int and 0 < written < len(packet):
            write_result = WriteResult.PARTIAL
        else:
            write_result = WriteResult.FAILED
        if on_write is not None:
            on_write(write_result)
        _remaining(deadline)
        if write_result is not WriteResult.COMPLETE:
            raise RuntimeError('Incomplete serial write')
        result = _receive(bus, motor_id, deadline, original_timeout)
    except ValueError as error:
        failure = error
        raise RuntimeError('Serial timeout configuration failed') from error
    except Exception as error:
        failure = error
        raise
    finally:
        restore_errors = []
        for name, value in [('timeout', original_timeout), *(
                [('write_timeout', original_write_timeout)] if has_write_timeout else [])]:
            try:
                setattr(bus, name, value)
            except Exception as error:
                restore_errors.append((name, error))
        if restore_errors:
            names = ', '.join(name for name, _ in restore_errors)
            detail = f'; transaction also failed: {failure}' if failure else ''
            raise RuntimeError(f'Cannot restore serial timeout settings: {names}{detail}') from restore_errors[0][1]
    _remaining(deadline)
    return result

```

### joint_mapping.py
```
from dataclasses import dataclass
import math


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a real int or float")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def _result(value, name, nonzero_inputs=None):
    if not math.isfinite(value):
        raise ValueError(f"{name} result must be finite")
    if nonzero_inputs and value == 0.0 and all(item != 0.0 for item in nonzero_inputs):
        raise ValueError(f"{name} result underflowed")
    return value


def _multiply(name, *values):
    result = 1.0
    for index, value in enumerate(values):
        result *= value
        _result(result, name, values[:index + 1])
    return result


def _divide(numerator, denominator, name):
    try:
        result = numerator / denominator
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError(f"{name} result is not representable") from exc
    return _result(result, name, (numerator,))


def _add(left, right, name):
    return _result(left + right, name)


def _subtract(left, right, name):
    return _result(left - right, name)


@dataclass(frozen=True)
class JointMap:
    reduction: float
    direction: int
    zero_output_rad: float

    def __post_init__(self):
        reduction = _finite(self.reduction, "reduction")
        if reduction <= 0.0:
            raise ValueError("reduction must be positive")
        if type(self.direction) is not int or self.direction not in (-1, 1):
            raise ValueError("direction must be the integer -1 or 1")
        object.__setattr__(self, "reduction", reduction)
        object.__setattr__(self, "zero_output_rad", _finite(self.zero_output_rad, "zero_output_rad"))

    def to_output(self, target: "JointTarget") -> "OutputTarget":
        if not isinstance(target, JointTarget):
            raise ValueError("target must be a JointTarget")

        signed_reduction = _multiply("signed reduction", float(self.direction), self.reduction)
        q_rad = _add(
            self.zero_output_rad,
            _multiply("output position", signed_reduction, target.q_rad),
            "output position",
        )
        output_rad_s = _multiply("output velocity", signed_reduction, target.dq_rad_s)
        rpm = _divide(_multiply("output speed", output_rad_s, 60.0), math.tau, "output speed")
        tau_nm = _divide(
            _multiply("output torque", float(self.direction), target.tau_nm),
            self.reduction,
            "output torque",
        )
        kp = _divide(_divide(target.kp, self.reduction, "output kp"), self.reduction, "output kp")
        kd = _divide(_divide(target.kd, self.reduction, "output kd"), self.reduction, "output kd")
        return OutputTarget(q_rad=q_rad, rpm=rpm, tau_nm=tau_nm, kp=kp, kd=kd)

    def from_output(self, sample: "OutputSample") -> "JointSample":
        if not isinstance(sample, OutputSample):
            raise ValueError("sample must be an OutputSample")

        q_delta = _subtract(sample.q_rad, self.zero_output_rad, "joint position")
        q_rad = _divide(
            _multiply("joint position", float(self.direction), q_delta),
            self.reduction,
            "joint position",
        )
        output_rad_s = _divide(
            _multiply("joint velocity", sample.rpm, math.tau),
            60.0,
            "joint velocity",
        )
        dq_rad_s = _divide(
            _multiply("joint velocity", float(self.direction), output_rad_s),
            self.reduction,
            "joint velocity",
        )
        tau_nm = _multiply("joint torque", float(self.direction), self.reduction, sample.tau_nm)
        return JointSample(q_rad=q_rad, dq_rad_s=dq_rad_s, tau_nm=tau_nm)


@dataclass(frozen=True)
class JointTarget:
    q_rad: float
    dq_rad_s: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputTarget:
    q_rad: float
    rpm: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputSample:
    q_rad: float
    rpm: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))


@dataclass(frozen=True)
class JointSample:
    q_rad: float
    dq_rad_s: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))

```

### im6014_codec.py
```
import math
import struct

RATIO = 38 / 3
RPM_MIN = -32768 / 64 / RATIO * 60
RPM_MAX = 32767 / 64 / RATIO * 60
POSITION_MIN = -2147483648 / 32768 / RATIO * math.tau
POSITION_MAX = 2147483647 / 32768 / RATIO * math.tau


def _motor_id(value, name='Individual ID'):
    if type(value) is not int or not 0 <= value <= 14:
        raise ValueError(f'{name} must be an integer from 0 to 14')
    return value


def _finite_control(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f'{name} must be a finite int or float')
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError(f'{name} must be finite') from error
    if not math.isfinite(result):
        raise ValueError(f'{name} must be finite')
    return result


def _signed_raw(value, minimum, maximum, name):
    raw = round(value)
    if not minimum <= raw <= maximum:
        raise ValueError(f'{name} cannot be represented by the motor protocol')
    return raw


def crc32(data):
    if len(data) % 4:
        raise ValueError('CRC input must contain complete four-byte words')
    crc = 0xFFFFFFFF
    for start in range(0, len(data), 4):
        for byte in data[start:start + 4][::-1]:
            crc ^= byte << 24
            for _ in range(8):
                crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    return crc


def command(motor_id, mode=0, rpm=0, kd=0, torque=0, watchdog=True, position=0, kp=0):
    motor_id = _motor_id(motor_id)
    if type(mode) is not int or mode not in (0, 1):
        raise ValueError('Individual ID 0–14 and Stop/FOC modes only')
    if type(watchdog) is not bool:
        raise ValueError('Watchdog must be a bool')
    rpm, kd, torque, position, kp = (
        _finite_control(value, name) for value, name in
        ((rpm, 'Speed'), (kd, 'Kd'), (torque, 'Feedforward torque'),
         (position, 'Position'), (kp, 'Kp'))
    )
    if not RPM_MIN <= rpm <= RPM_MAX:
        raise ValueError('Speed cannot be encoded in the motor protocol; this is not a rated-speed limit')
    if not 0 <= kd <= 6 or not 0 <= kp <= 30 or not -3.5 <= torque <= 3.5:
        raise ValueError('Bench limits: Kd 0–6, Kp 0–30, feedforward torque ±3.5 Nm')
    if not POSITION_MIN <= position <= POSITION_MAX:
        raise ValueError('Position cannot be encoded in the motor protocol')
    torque_raw = _signed_raw(torque / RATIO * 2560, -32768, 32767, 'Feedforward torque')
    rpm_raw = _signed_raw(rpm / 60 * RATIO * 64, -32768, 32767, 'Speed')
    position_raw = _signed_raw(position / math.tau * RATIO * 32768,
                               -2147483648, 2147483647, 'Position')
    kp_raw = _signed_raw(kp / RATIO ** 2 * 12800, -32768, 32767, 'Kp')
    kd_raw = _signed_raw(kd / RATIO ** 2 * 51200, -32768, 32767, 'Kd')
    if mode == 0 and (rpm or kd or torque or position or kp) or mode == 1 and not watchdog:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    raw = b'\xfe\xee' + bytes([motor_id | mode << 4 | int(watchdog) << 7, 0])
    raw += struct.pack('<hhihh', torque_raw, rpm_raw, position_raw, kp_raw, kd_raw)
    return raw + struct.pack('<I', crc32(raw))


def feedback(raw, motor_id):
    motor_id = _motor_id(motor_id, 'Expected motor ID')
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Feedback frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Feedback frame must be a bytes-like buffer') from error
    if len(raw) != 26 or raw[:2] != b'\xfc\xee':
        raise RuntimeError('Invalid feedback length/header')
    if struct.unpack('<I', raw[22:])[0] != crc32(raw[2:22]):
        raise RuntimeError('Feedback CRC mismatch')
    m, td, tw, v, tq, sp, pos, err, flags, _, _ = struct.unpack('<BbBBhhiIHBB', raw[2:22])
    if m & 15 != motor_id or (m >> 4) & 7 not in (0, 1):
        raise RuntimeError('Feedback ID/mode mismatch')
    return dict(id=m & 15, mode=(m >> 4) & 7, timeout=m >> 7,
                driver_c=td, winding_c=tw, voltage=v / 2,
                torque_nm=tq / 2560 * RATIO, rpm=sp / 64 / RATIO * 60,
                position_rad=pos / 32768 / RATIO * math.tau,
                errors=err, warnings=(flags >> 13) & 7, raw=raw.hex())

```

### test_controller.py
```
import unittest
from dataclasses import FrozenInstanceError
import math

from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    IntentWindow,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    MotorHealth,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget


SAMPLE = JointSample(0.1, 0.0, 0.0)
HEALTHY_STOP = MotorHealth(mode=0, errors=0, warnings=0, timeout=False)
SOURCE = SourceIdentity("fixture", "controller-test", 1)


class FakeStation:
    def __init__(self, core):
        self.core = core
        self.writes = []

    def _write_stops(self):
        self.writes.extend(command(spec.motor_id, mode=0) for spec in self.core.joint_specs)

    def connect(self):
        decision = self.core.begin_connect()
        if not decision.accepted:
            return decision
        decision = self.core.connected(SOURCE)
        if decision.accepted:
            self._write_stops()
        return decision

    def check(self, *, acknowledge_fault=False):
        decision = self.core.begin_check(acknowledge_fault=acknowledge_fault)
        if not decision.accepted:
            return decision
        self._write_stops()
        for spec in self.core.joint_specs:
            decision = self.core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP)
            if not decision.accepted:
                return decision
        return self.core.checked()

    def arm(self):
        return self.core.arm()

    def issue_window(self, valid_for_s=0.2):
        return self.core.issue_window(valid_for_s)

    def submit(self, target):
        return self.core.submit_target(target)

    def refresh(self):
        plan = self.core.prepare_refresh()
        if plan is None:
            return None
        packets = []
        for spec, joint_target in zip(self.core.joint_specs, plan.joint_targets):
            output = spec.mapping.to_output(joint_target)
            packets.append(
                command(
                    spec.motor_id,
                    mode=1,
                    rpm=output.rpm,
                    kd=output.kd,
                    torque=output.tau_nm,
                    watchdog=True,
                    position=output.q_rad,
                    kp=output.kp,
                )
            )
        for index, packet in enumerate(packets):
            if not self.core.claim_dispatch(plan.plan_id, index):
                break
            self.writes.append(packet)
            self.core.dispatch_result(plan.plan_id, index, WriteResult.COMPLETE)
        return plan

    def stop(self):
        decision = self.core.stop()
        if decision.accepted:
            self._write_stops()
        return decision

    def disconnect(self):
        return self.core.disconnect()


class DeterministicClock:
    def __init__(self, value=0.0):
        self.value = value
        self.calls = 0

    def __call__(self):
        self.calls += 1
        return self.value


class FeedbackAgeTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0)),
            JointSpec("J2", 1, JointMap(1, 1, 0.0)),
        )

    def _ready_station(self, clock, *, feedback_max_age_s=1.0):
        core = JointCore(
            self.specs,
            clock=clock,
            feedback_max_age_s=feedback_max_age_s,
        )
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        return core, station

    def test_feedback_age_configuration_is_finite_positive_and_typed(self):
        for value in (True, False, 0, -1.0, math.nan, math.inf, -math.inf, 10**400, "1"):
            with self.subTest(value=repr(value)), self.assertRaises(ValueError):
                JointCore(self.specs, feedback_max_age_s=value)
        with self.assertRaises(ValueError):
            JointCore(self.specs, clock=0)

    def test_zero_timestamp_and_exact_freshness_boundary(self):
        clock = DeterministicClock(0.0)
        core, _station = self._ready_station(clock)

        received = core.snapshot()
        self.assertEqual(tuple(joint.received_at for joint in received.joints), (0.0, 0.0))
        self.assertEqual(received.feedback_ages_s, (0.0, 0.0))

        clock.value = 1.0
        at_boundary = core.snapshot()
        self.assertEqual(at_boundary.feedback_ages_s, (1.0, 1.0))
        self.assertTrue(core.arm().accepted)

        with self.assertRaises(FrozenInstanceError):
            at_boundary.joints[0].received_at = 1.0
        with self.assertRaises(TypeError):
            at_boundary.feedback_ages_s[0] = 0.0

    def test_checked_rejects_feedback_older_than_limit(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)
        for spec in self.specs:
            self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)

        clock.value = 1.000001
        rejected = core.checked()
        self.assertEqual(rejected.code, DecisionCode.STALE_FEEDBACK)
        self.assertIs(core.snapshot().state, State.CHECKING)
        self.assertFalse(core.snapshot().fault_latched)
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.CHECKING)

    def test_bad_id_and_observation_do_not_refresh_receipt_time(self):
        clock = DeterministicClock(0.0)
        core, _station = self._ready_station(clock)
        initial = core.snapshot()
        calls_before = clock.calls

        clock.value = 0.5
        self.assertEqual(
            core.receive(14, SAMPLE, HEALTHY_STOP).code,
            DecisionCode.UNKNOWN_JOINT,
        )
        self.assertEqual(
            core.receive(self.specs[0].motor_id, object(), HEALTHY_STOP).code,
            DecisionCode.INVALID_OBSERVATION,
        )
        self.assertEqual(clock.calls, calls_before)
        self.assertEqual(
            tuple(joint.received_at for joint in core.snapshot().joints),
            tuple(joint.received_at for joint in initial.joints),
        )

        clock.value = 1.000001
        self.assertEqual(core.arm().code, DecisionCode.STALE_FEEDBACK)

    def test_fresh_j1_cannot_hide_stale_j2_from_arm_or_tick(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        station.writes.clear()

        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        clock.value = 1.000001
        before_writes = list(station.writes)
        rejected = station.arm()
        self.assertEqual(rejected.code, DecisionCode.STALE_FEEDBACK)
        self.assertIs(core.snapshot().state, State.READY)
        self.assertEqual(station.writes, before_writes)

        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        station.writes.clear()
        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(station.arm().accepted)
        clock.value = 1.000001
        before_writes = list(station.writes)
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(station.writes, before_writes)

    def test_disconnect_invalidates_age_and_stale_fault_needs_acknowledged_check(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        self.assertTrue(station.arm().accepted)

        clock.value = 1.1
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        before_disconnect = core.snapshot()

        self.assertTrue(station.disconnect().accepted)
        disconnected = core.snapshot()
        self.assertTrue(all(joint.received_at is None for joint in disconnected.joints))
        self.assertEqual(disconnected.feedback_ages_s, (None, None))
        self.assertEqual(before_disconnect.feedback_ages_s, (1.1, 1.1))
        self.assertTrue(disconnected.fault_latched)

        self.assertTrue(station.connect().accepted)
        writes_after_connect = list(station.writes)
        self.assertEqual(
            station.check().code,
            DecisionCode.FAULT_ACK_REQUIRED,
        )
        self.assertEqual(station.writes, writes_after_connect)

        station.writes.clear()
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertEqual(
            station.writes,
            [command(spec.motor_id, mode=0) for spec in self.specs],
        )
        self.assertIs(core.snapshot().state, State.READY)
        self.assertFalse(core.snapshot().fault_latched)


def core_at(test, state, clock=None):
    if clock is None:
        clock = DeterministicClock(0.0)
    core = JointCore(test.specs, clock=clock)
    station = FakeStation(core)
    if state is State.DISCONNECTED:
        return core
    if state is State.CONNECTING:
        test.assertTrue(core.begin_connect().accepted)
        return core

    test.assertTrue(station.connect().accepted)
    if state is State.CONNECTED:
        return core
    if state is State.CHECKING:
        test.assertTrue(core.begin_check().accepted)
        return core

    test.assertTrue(station.check().accepted)
    if state is State.READY:
        return core
    if state is State.ARMED:
        test.assertTrue(station.arm().accepted)
        return core
    if state is State.MOVING:
        test.assertTrue(station.arm().accepted)
        window = station.issue_window(1.0)
        target = Target(
            0,
            (
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
        )
        test.assertTrue(core.submit_target(target).accepted)
        test.assertIsNotNone(station.refresh())
        return core
    if state is State.STOPPED:
        test.assertTrue(station.stop().accepted)
        return core
    if state is State.FAULT:
        test.assertTrue(station.arm().accepted)
        test.assertTrue(core.receive(
            test.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=1, warnings=0, timeout=False),
        ).accepted)
        return core
    raise AssertionError(f"{state} is not reachable")


class ControllerStateTests(unittest.TestCase):
    def setUp(self):
        self.clock = lambda: 0.0
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0)),
            JointSpec("J2", 1, JointMap(1, 1, 0.0)),
        )


    def test_joint_set_is_nonempty_unique_and_owned(self):
        mapping = JointMap(1, 1, 0.0)
        with self.assertRaises(ValueError):
            JointCore(())
        with self.assertRaises(ValueError):
            JointCore((JointSpec("J1", 0, mapping), JointSpec("J1", 1, mapping)))
        with self.assertRaises(ValueError):
            JointCore((JointSpec("J1", 0, mapping), JointSpec("J2", 0, mapping)))
        with self.assertRaises(ValueError):
            JointSpec("J1", True, mapping)

        supplied = [JointSpec("J1", 0, mapping)]
        core = JointCore(supplied, clock=self.clock)
        supplied.clear()
        self.assertEqual(tuple(spec.name for spec in core.joint_specs), ("J1",))

    def test_health_and_source_records_reject_invalid_values(self):
        for kwargs in (
            dict(mode=True, errors=0, warnings=0, timeout=False),
            dict(mode=0, errors=True, warnings=0, timeout=False),
            dict(mode=0, errors=0, warnings=-1, timeout=False),
            dict(mode=0, errors=0, warnings=0, timeout=1),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                MotorHealth(**kwargs)
        with self.assertRaises(ValueError):
            SourceIdentity("other", "x", 1)

    def test_fake_lifecycle_writes_only_after_accepted_actions(self):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        expected = [command(spec.motor_id, mode=0) for spec in self.specs]

        self.assertFalse(station.check().accepted)
        self.assertFalse(station.stop().accepted)
        self.assertEqual(station.writes, [])

        self.assertTrue(station.connect().accepted)
        self.assertEqual(station.writes, expected)
        station.writes.clear()
        self.assertFalse(station.connect().accepted)
        self.assertEqual(station.writes, [])

        self.assertTrue(station.check().accepted)
        self.assertEqual(station.writes, expected)
        self.assertIs(core.snapshot().state, State.READY)
        station.writes.clear()
        self.assertTrue(station.arm().accepted)
        self.assertIs(core.snapshot().state, State.ARMED)
        self.assertTrue(station.stop().accepted)
        self.assertEqual(station.writes, expected)
        self.assertIs(core.snapshot().state, State.STOPPED)

    def test_arm_requires_current_stop_feedback(self):
        core = core_at(self, State.READY)
        self.assertTrue(core.receive(1, SAMPLE, MotorHealth(1, 0, 0, False)))
        before = core.snapshot()
        self.assertEqual(core.arm().code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot(), before)
        self.assertTrue(core.receive(1, SAMPLE, HEALTHY_STOP))
        self.assertTrue(core.arm())

    def test_check_requires_every_healthy_joint_in_stop_mode(self):
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)

        before = core.snapshot()
        rejected = core.checked()
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.OBSERVATIONS_INCOMPLETE)
        self.assertEqual(core.snapshot(), before)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        foc = MotorHealth(mode=1, errors=0, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, foc).accepted)
        before = core.snapshot()
        self.assertEqual(core.checked().code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot(), before)

        unhealthy = MotorHealth(mode=0, errors=0, warnings=1, timeout=False)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, unhealthy).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        before = core.snapshot()
        rejected = core.checked()
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.INVALID_STATE)
        self.assertEqual(core.snapshot(), before)

        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP))
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertTrue(core.begin_check(acknowledge_fault=True))
        self.assertTrue(core.snapshot().fault_latched)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP))
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertIs(core.snapshot().state, State.READY)

    def test_fault_survives_stop_disconnect_reconnect_and_healthy_packets(self):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)

        bad_health = MotorHealth(mode=0, errors=4, warnings=2, timeout=True)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, bad_health).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        station.writes.clear()
        self.assertTrue(station.stop().accepted)
        self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        self.assertTrue(station.disconnect().accepted)
        disconnected = core.snapshot()
        self.assertIs(disconnected.state, State.DISCONNECTED)
        self.assertTrue(disconnected.fault_latched)
        self.assertTrue(all(not joint.valid for joint in disconnected.joints))
        self.assertIsNone(disconnected.source)

        self.assertTrue(station.connect().accepted)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.snapshot().fault_latched)
        before = core.snapshot()
        self.assertEqual(core.begin_check().code, DecisionCode.FAULT_ACK_REQUIRED)
        self.assertEqual(core.snapshot(), before)

        station.writes.clear()
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
        self.assertIs(core.snapshot().state, State.READY)
        self.assertFalse(core.snapshot().fault_latched)

    def test_disconnect_and_new_connection_invalidate_observations(self):
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        prior = core.snapshot()
        self.assertTrue(prior.joints[0].valid)

        self.assertTrue(core.disconnect().accepted)
        self.assertTrue(all(not joint.valid for joint in core.snapshot().joints))
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SourceIdentity("fixture", "controller-test", 2)).accepted)
        self.assertTrue(all(not joint.valid for joint in core.snapshot().joints))
        self.assertTrue(prior.joints[0].valid)

    def test_snapshots_are_immutable_owned_values(self):
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        before = core.snapshot()
        self.assertIsInstance(before.joints, tuple)
        self.assertIsInstance(before.joint_names, tuple)
        self.assertIsInstance(before.dispatch_attempts, tuple)
        self.assertEqual(before.dispatch_attempts, (None, None))
        self.assertFalse(hasattr(core, "pending_target"))
        self.assertFalse(hasattr(before, "pending_target"))

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        after = core.snapshot()
        self.assertFalse(before.joints[0].valid)
        self.assertTrue(after.joints[0].valid)
        with self.assertRaises(FrozenInstanceError):
            after.state = State.FAULT
        with self.assertRaises(FrozenInstanceError):
            after.joints[0].health = HEALTHY_STOP
        with self.assertRaises(TypeError):
            after.joints[0] = before.joints[0]
        with self.assertRaises(TypeError):
            after.dispatch_attempts[0] = before.dispatch_attempts[0]

    def test_invalid_transition_matrix_preserves_snapshot(self):
        rejected = {
            State.DISCONNECTED: ("connected", "begin_check", "checked", "arm", "stop"),
            State.CONNECTING: ("begin_connect", "begin_check", "checked", "arm", "stop"),
            State.CONNECTED: ("begin_connect", "connected", "checked", "arm"),
            State.CHECKING: ("begin_connect", "connected", "begin_check", "arm"),
            State.READY: ("begin_connect", "connected", "begin_check", "checked"),
            State.ARMED: ("begin_connect", "connected", "begin_check", "checked", "arm"),
            State.MOVING: ("begin_connect", "connected", "begin_check", "checked", "arm"),
            State.STOPPED: ("begin_connect", "connected", "checked", "arm"),
            State.FAULT: ("begin_connect", "connected", "begin_check", "checked", "arm"),
        }

        for state, events in rejected.items():
            for event in events + ("wrong_joint",):
                with self.subTest(state=state, event=event):
                    core = core_at(self, state)
                    station = FakeStation(core)
                    before = core.snapshot()
                    action = {
                        "begin_connect": station.connect,
                        "connected": lambda: core.connected(SOURCE),
                        "begin_check": station.check,
                        "checked": core.checked,
                        "arm": core.arm,
                        "stop": station.stop,
                        "wrong_joint": lambda: core.receive(14, SAMPLE, HEALTHY_STOP),
                    }[event]
                    decision = action()
                    self.assertFalse(decision.accepted)
                    self.assertFalse(decision)
                    self.assertEqual(station.writes, [])
                    self.assertEqual(core.snapshot(), before)


class JointFaultTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0)),
            JointSpec("J2", 1, JointMap(1, 1, 0.0)),
        )

    def _ready_core(self, clock=None, *, feedback_max_age_s=1.0):
        if clock is None:
            clock = DeterministicClock(0.0)
        core = JointCore(
            self.specs,
            clock=clock,
            feedback_max_age_s=feedback_max_age_s,
        )
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)
        for spec in self.specs:
            self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        return core

    def test_stale_j2_attributes_only_stale_joint_with_refreshed_j1(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock, feedback_max_age_s=1.0)
        self.assertTrue(core.arm().accepted)
        self.assertIs(core.snapshot().state, State.ARMED)

        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)

        clock.value = 1.1
        self.assertTrue(core.tick().accepted)
        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.affected_joints, ("J2",))
        self.assertEqual(len(snap.faults), 1)

        j2_fault = snap.faults[0]
        self.assertEqual(j2_fault.name, "J2")
        self.assertEqual(j2_fault.motor_id, 1)
        self.assertTrue(j2_fault.stale)
        self.assertEqual(j2_fault.errors, 0)
        self.assertEqual(j2_fault.warnings, 0)
        self.assertFalse(j2_fault.timeout)
        self.assertIsNone(j2_fault.communication_error)

        self.assertNotIn("J1", snap.affected_joints)
        self.assertEqual(snap.joints[0].received_at, 0.8)
        self.assertEqual(snap.joints[1].received_at, 0.0)

    def test_unknown_bits_and_32bit_error_mask_retained(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock)
        self.assertTrue(core.arm().accepted)

        unknown_errors = 0x80000004
        status = MotorHealth(mode=0, errors=unknown_errors, warnings=5, timeout=True)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, status).accepted)

        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertEqual(snap.affected_joints, ("J1",))
        j1_fault = snap.faults[0]
        self.assertEqual(j1_fault.errors, unknown_errors)
        self.assertEqual(j1_fault.errors & 0x80000000, 0x80000000)
        self.assertEqual(j1_fault.warnings, 5)
        self.assertTrue(j1_fault.timeout)
        self.assertFalse(j1_fault.stale)

        for kwargs in (
            dict(mode=0, errors=-1, warnings=0, timeout=False),
            dict(mode=0, errors=0x1_0000_0000, warnings=0, timeout=False),
            dict(mode=0, errors=0, warnings=-1, timeout=False),
            dict(mode=0, errors=0, warnings=8, timeout=False),
            dict(mode=0, errors=0, warnings=0, timeout="True"),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                MotorHealth(**kwargs)

        for kwargs in (
            dict(name="J1", motor_id=0, errors=-1),
            dict(name="J1", motor_id=0, errors=0x1_0000_0000),
            dict(name="J1", motor_id=0, warnings=-1),
            dict(name="J1", motor_id=0, warnings=8),
            dict(name="J1", motor_id=0, timeout=1),
            dict(name="J1", motor_id=0, stale=1),
            dict(name="", motor_id=0),
            dict(name="J1", motor_id=15),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                JointFault(**kwargs)

    def test_healthy_after_fault_preserves_latched_attribution(self):
        core = self._ready_core()
        self.assertTrue(core.arm().accepted)

        unhealthy = MotorHealth(mode=0, errors=0x02, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, unhealthy).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))
        self.assertEqual(core.snapshot().faults[0].errors, 0x02)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        snap = core.snapshot()

        self.assertTrue(snap.joints[0].healthy)
        self.assertEqual(snap.joints[0].errors, 0)
        self.assertEqual(snap.joints[0].health.errors, 0)

        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.affected_joints, ("J1",))
        self.assertEqual(len(snap.faults), 1)
        self.assertEqual(snap.faults[0].errors, 0x02)
        self.assertNotEqual(snap.faults[0].errors, 0)

    def test_multiple_faults_on_joint_preserves_prior_flags_with_bounded_storage(self):
        core = self._ready_core()

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x01, warnings=1, timeout=False),
        ).accepted)

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x04, warnings=2, timeout=True),
        ).accepted)

        self.assertTrue(core.communication_failed(
            self.specs[0].motor_id,
            CommunicationFailure.DRIVER_FAILURE,
        ).accepted)

        snap = core.snapshot()
        self.assertEqual(len(snap.faults), 1)
        j1_fault = snap.faults[0]
        self.assertEqual(j1_fault.name, "J1")
        self.assertEqual(j1_fault.errors, 0x05)
        self.assertEqual(j1_fault.warnings, 3)
        self.assertTrue(j1_fault.timeout)
        self.assertEqual(j1_fault.communication_error, CommunicationFailure.DRIVER_FAILURE)
        self.assertIn(CommunicationFailure.DRIVER_FAILURE, j1_fault.communication_errors)

        for _ in range(10):
            self.assertTrue(core.receive(
                self.specs[0].motor_id,
                SAMPLE,
                MotorHealth(mode=0, errors=0x02, warnings=0, timeout=False),
            ).accepted)
        self.assertEqual(len(core.snapshot().faults), 1)
        self.assertEqual(core.snapshot().faults[0].errors, 0x07)

    def test_communication_failures_with_fixed_enum_codes(self):
        for code in (
            CommunicationFailure.TIMEOUT,
            CommunicationFailure.INVALID_FEEDBACK,
            CommunicationFailure.DRIVER_FAILURE,
        ):
            with self.subTest(code=code):
                core = self._ready_core()
                decision = core.communication_failed(self.specs[0].motor_id, code)
                self.assertTrue(decision.accepted)
                snap = core.snapshot()
                self.assertIs(snap.state, State.FAULT)
                self.assertEqual(snap.affected_joints, ("J1",))
                fault = snap.faults[0]
                self.assertEqual(fault.communication_error, code)
                self.assertFalse(fault.timeout)
                self.assertEqual(snap.joints[0].communication_error, code)
                self.assertFalse(snap.joints[0].healthy)

        core = self._ready_core()
        self.assertTrue(core.communication_failed(self.specs[1].motor_id, CommunicationFailure.INVALID_FEEDBACK).accepted)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))
        self.assertEqual(core.snapshot().faults[0].communication_error, CommunicationFailure.INVALID_FEEDBACK)

    def test_current_communication_status_clears_without_erasing_cause(self):
        core = self._ready_core()
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT))
        before = core.snapshot()
        self.assertTrue(core.receive(0, SAMPLE, HEALTHY_STOP))
        after = core.snapshot()
        self.assertTrue(after.joints[0].healthy)
        self.assertIsNone(after.joints[0].communication_error)
        self.assertEqual(after.faults, before.faults)
        self.assertIs(after.state, State.FAULT)

    def test_fault_record_requires_bounded_consistent_communication_codes(self):
        a, b = CommunicationFailure.TIMEOUT, CommunicationFailure.DRIVER_FAILURE
        for kwargs in (dict(communication_error=a, communication_errors=(b,)),
                       dict(communication_errors=(a, a)),
                       dict(communication_errors=(a,) * 4)):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                JointFault("J1", 0, **kwargs)
        record = JointFault("J1", 0, communication_error=a, communication_errors=(a, b))
        self.assertIs(record.communication_error, a)
        self.assertEqual(record.communication_errors, (a, b))

    def test_unknown_ids_and_invalid_codes_reject_unchanged(self):
        core = self._ready_core()
        before = core.snapshot()

        self.assertEqual(core.communication_failed(0, "timeout").code,
                         DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot(), before)

        rejected_id = core.communication_failed(14, CommunicationFailure.TIMEOUT)
        self.assertFalse(rejected_id)
        self.assertEqual(rejected_id.code, DecisionCode.UNKNOWN_JOINT)
        self.assertEqual(core.snapshot(), before)

        self.assertEqual(
            core.communication_failed(True, CommunicationFailure.TIMEOUT).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed("0", CommunicationFailure.TIMEOUT).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(core.snapshot(), before)

        self.assertEqual(
            core.communication_failed(0, "unrecognized_failure").code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, RuntimeError("comm timeout")).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, 999).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, None).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(core.snapshot(), before)

    def test_failed_recovery_retains_causes(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock, feedback_max_age_s=1.0)
        self.assertTrue(core.arm().accepted)

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x04, warnings=0, timeout=False),
        ).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        rejected = core.begin_check(acknowledge_fault=False)
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.FAULT_ACK_REQUIRED)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
        self.assertIs(core.snapshot().state, State.CHECKING)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertEqual(core.checked().code, DecisionCode.OBSERVATIONS_INCOMPLETE)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        non_stop = MotorHealth(mode=1, errors=0, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, non_stop).accepted)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertEqual(core.checked().code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        clock.value = 2.0
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertEqual(core.checked().code, DecisionCode.STALE_FEEDBACK)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertEqual(core.arm().code, DecisionCode.INVALID_STATE)

    def test_successful_recovery_clears_fault_causes(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)

        self.assertTrue(core.communication_failed(
            self.specs[1].motor_id,
            CommunicationFailure.TIMEOUT,
        ).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.disconnect().accepted)
        self.assertIs(core.snapshot().state, State.DISCONNECTED)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.connect().accepted)
        self.assertIs(core.snapshot().state, State.CONNECTED)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        snap = core.snapshot()
        self.assertIs(snap.state, State.READY)
        self.assertFalse(snap.fault_latched)
        self.assertEqual(snap.faults, ())
        self.assertEqual(snap.affected_joints, ())

    def test_independent_second_core_unchanged_by_fault(self):
        specs2 = (
            JointSpec("J3", 2, JointMap(1, 1, 0.0)),
            JointSpec("J4", 3, JointMap(1, 1, 0.0)),
        )
        clock = DeterministicClock(0.0)
        core1 = JointCore(self.specs, clock=clock)
        core2 = JointCore(specs2, clock=clock)

        station1 = FakeStation(core1)
        station2 = FakeStation(core2)
        self.assertTrue(station1.connect().accepted)
        self.assertTrue(station1.check().accepted)
        self.assertTrue(station1.arm().accepted)

        self.assertTrue(station2.connect().accepted)
        self.assertTrue(station2.check().accepted)
        self.assertTrue(station2.arm().accepted)

        self.assertTrue(core1.communication_failed(
            self.specs[0].motor_id,
            CommunicationFailure.DRIVER_FAILURE,
        ).accepted)
        snap1 = core1.snapshot()
        self.assertIs(snap1.state, State.FAULT)
        self.assertTrue(snap1.fault_latched)
        self.assertEqual(snap1.affected_joints, ("J1",))

        snap2 = core2.snapshot()
        self.assertIs(snap2.state, State.ARMED)
        self.assertFalse(snap2.fault_latched)
        self.assertEqual(snap2.faults, ())
        self.assertEqual(snap2.affected_joints, ())
        self.assertTrue(station2.stop().accepted)
        self.assertIs(core2.snapshot().state, State.STOPPED)

    def test_immutability_of_fault_records_and_snapshot_collections(self):
        fault = JointFault("J1", 0, errors=1, warnings=2, timeout=True)
        with self.assertRaises(FrozenInstanceError):
            fault.errors = 0
        with self.assertRaises(FrozenInstanceError):
            fault.name = "other"

        core = self._ready_core()
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
        snap = core.snapshot()

        self.assertIsInstance(snap.faults, tuple)
        self.assertIsInstance(snap.affected_joints, tuple)
        with self.assertRaises(FrozenInstanceError):
            snap.faults[0].timeout = False
        with self.assertRaises(TypeError):
            snap.faults[0] = fault
        with self.assertRaises(TypeError):
            snap.affected_joints[0] = "J2"







if __name__ == "__main__":
    unittest.main()

```

### test_controller_targets.py
```
import unittest
from dataclasses import FrozenInstanceError
import math
from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    IntentWindow,
    JointSpec,
    MotorHealth,
    State,
    Target,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointTarget

from test_controller import DeterministicClock, FakeStation, SAMPLE, HEALTHY_STOP, core_at


class LatestTargetTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1.0, 1, 0.0)),
            JointSpec("J2", 1, JointMap(1.0, 1, 0.0)),
        )

    def test_ten_thousand_accepted_updates_leave_one_newest_target_and_repeated_refresh(self):
        clock = DeterministicClock(0.0)
        # Keep feedback fresh beyond this one-second goal window so this test
        # isolates expiry instead of also triggering the default 0.5s stale fault.
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.2)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)
        self.assertIsNone(core.snapshot().admitted_target)

        window = station.issue_window(1.0)
        last_target = None
        for i in range(10_000):
            target = Target(
                i,
                (
                    JointTarget(q_rad=i * 0.0001, dq_rad_s=0.0, tau_nm=0.0, kp=1.0, kd=0.1),
                    JointTarget(q_rad=-i * 0.0001, dq_rad_s=0.0, tau_nm=0.0, kp=1.0, kd=0.1),
                ),
                window=window,
            )
            decision = station.submit(target)
            self.assertTrue(decision.accepted)
            last_target = target

        snap = core.snapshot()
        self.assertEqual(snap.admitted_target, last_target)
        self.assertEqual(snap.last_sequence, 9999)
        self.assertIs(snap.state, State.ARMED)

        refreshed = station.refresh()
        self.assertIsNotNone(refreshed)
        self.assertEqual(refreshed.target, last_target)
        self.assertIs(core.snapshot().state, State.MOVING)
        self.assertEqual(core.snapshot().admitted_target, last_target)

        # Repeated refresh of admitted goal succeeds while within window
        second_refreshed = station.refresh()
        self.assertIsNotNone(second_refreshed)
        self.assertEqual(second_refreshed.target, last_target)
        self.assertIs(core.snapshot().state, State.MOVING)

        # Expiry withdraws admitted goal and disarms to STOPPED
        clock.value = 1.1
        expired_refreshed = station.refresh()
        self.assertIsNone(expired_refreshed)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)

    def test_immutable_owned_vector(self):
        jt1 = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
        jt2 = JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)
        window = IntentWindow(0, 0.0, 1.0)

        for bad_joints in (
            [jt1, jt2],
            "not a tuple",
            123,
            None,
            {jt1, jt2},
        ):
            with self.subTest(bad_joints=repr(bad_joints)), self.assertRaises(ValueError):
                Target(0, bad_joints, window=window)

        with self.assertRaises(ValueError):
            Target(0, (), window=window)

        for bad_elements in (
            (jt1, "not a joint target"),
            (1, 2),
            (jt1, None),
        ):
            with self.subTest(bad_elements=repr(bad_elements)), self.assertRaises(ValueError):
                Target(0, bad_elements, window=window)

        for bad_window in (None, "window", 123, object()):
            with self.subTest(bad_window=repr(bad_window)), self.assertRaises(ValueError):
                Target(0, (jt1, jt2), window=bad_window)

        target = Target(0, (jt1, jt2), window=window)
        with self.assertRaises(FrozenInstanceError):
            target.sequence = 1
        with self.assertRaises(FrozenInstanceError):
            target.joints = (jt2, jt1)
        with self.assertRaises(FrozenInstanceError):
            target.window = window
        with self.assertRaises(TypeError):
            target.joints[0] = jt2
        with self.assertRaises(FrozenInstanceError):
            target.joints[0].q_rad = 99.0

        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)
        core_window = station.issue_window(1.0)
        valid_target = Target(0, (jt1, jt2), window=core_window)
        self.assertTrue(station.submit(valid_target).accepted)

        snap = core.snapshot()
        self.assertEqual(snap.admitted_target, valid_target)
        self.assertEqual(snap.last_sequence, 0)
        with self.assertRaises(FrozenInstanceError):
            snap.admitted_target = None
        with self.assertRaises(FrozenInstanceError):
            snap.last_sequence = 1
        with self.assertRaises(TypeError):
            snap.admitted_target.joints[0] = jt1
        with self.assertRaises(FrozenInstanceError):
            snap.admitted_target.joints[0].tau_nm = 0.5

    def test_malformed_incomplete_and_invalid_mapped_outputs_preserve_prior_target(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)

        jt1 = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
        jt2 = JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)
        w1 = station.issue_window(1.0)
        prior_target = Target(1, (jt1, jt2), window=w1)
        self.assertTrue(station.submit(prior_target).accepted)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        for malformed in (None, "target", 42, object(), [jt1, jt2]):
            with self.subTest(malformed=repr(malformed)):
                decision = core.submit_target(malformed)
                self.assertFalse(decision.accepted)
                self.assertEqual(decision.code, DecisionCode.INVALID_ARGUMENT)
                self.assertEqual(core.snapshot().admitted_target, prior_target)
                self.assertEqual(core.snapshot().last_sequence, 1)

        for wrong_vector in (
            Target(2, (jt1,), window=w1),
            Target(2, (jt1, jt2, jt1), window=w1),
        ):
            with self.subTest(wrong_vector=wrong_vector):
                decision = core.submit_target(wrong_vector)
                self.assertFalse(decision.accepted)
                self.assertEqual(decision.code, DecisionCode.INVALID_ARGUMENT)
                self.assertEqual(core.snapshot().admitted_target, prior_target)
                self.assertEqual(core.snapshot().last_sequence, 1)

        huge_speed = Target(2, (JointTarget(0.0, 1e7, 0.0, 1.0, 0.1), jt2), window=w1)
        rej = core.submit_target(huge_speed)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        huge_kp = Target(2, (JointTarget(0.0, 0.0, 0.0, 31.0, 0.1), jt2), window=w1)
        rej = core.submit_target(huge_kp)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        huge_kd = Target(2, (JointTarget(0.0, 0.0, 0.0, 1.0, 6.1), jt2), window=w1)
        rej = core.submit_target(huge_kd)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        huge_pos = Target(2, (JointTarget(1e7, 0.0, 0.0, 1.0, 0.1), jt2), window=w1)
        rej = core.submit_target(huge_pos)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

    def test_each_fault_path_clears_pending_without_fake_foc_writes(self):
        for action in ('packet', 'communication', 'tick'):
            with self.subTest(action=action):
                clock = DeterministicClock(0.0)
                core = JointCore(self.specs, clock=clock)
                station = FakeStation(core)
                self.assertTrue(station.connect())
                self.assertTrue(station.check())
                self.assertTrue(station.arm())
                w = station.issue_window(1.0)
                target = Target(0, (JointTarget(0, 0, 0, 1, .1),) * 2, window=w)
                self.assertTrue(station.submit(target))
                self.assertEqual(core.snapshot().last_sequence, 0)
                station.writes.clear()
                if action == 'packet':
                    self.assertTrue(core.receive(1, SAMPLE, MotorHealth(0, 4, 0, False)))
                elif action == 'communication':
                    self.assertTrue(core.communication_failed(1, CommunicationFailure.TIMEOUT))
                else:
                    clock.value = .6
                    self.assertTrue(core.tick())
                self.assertIs(core.snapshot().state, State.FAULT)
                self.assertIsNone(core.snapshot().admitted_target)
                self.assertEqual(core.snapshot().last_sequence, 0)
                self.assertIsNone(station.refresh())
                self.assertEqual(station.writes, [])

    def test_mapped_torque_outside_codec_bounds_rejects(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)

        jt1 = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
        jt2 = JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)
        w = station.issue_window(1.0)
        prior_target = Target(1, (jt1, jt2), window=w)
        self.assertTrue(station.submit(prior_target).accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)

        too_high = Target(2, (JointTarget(0.0, 0.0, 3.501, 1.0, 0.1), jt2), window=w)
        rej = core.submit_target(too_high)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        too_low = Target(2, (JointTarget(0.0, 0.0, -3.501, 1.0, 0.1), jt2), window=w)
        rej = core.submit_target(too_low)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        specs_ratio = (
            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.0)),
            JointSpec("J2", 1, JointMap(reduction=1.0, direction=1, zero_output_rad=0.0)),
        )
        core_ratio = JointCore(specs_ratio, clock=clock)
        station_ratio = FakeStation(core_ratio)
        self.assertTrue(station_ratio.connect().accepted)
        self.assertTrue(station_ratio.check().accepted)
        self.assertTrue(station_ratio.arm().accepted)
        w_ratio = station_ratio.issue_window(1.0)

        rej_ratio = core_ratio.submit_target(
            Target(1, (JointTarget(0.0, 0.0, 12.0, 9.0, 0.9), jt2), window=w_ratio)
        )
        self.assertFalse(rej_ratio.accepted)
        self.assertEqual(rej_ratio.code, DecisionCode.INVALID_ARGUMENT)
        self.assertIsNone(core_ratio.snapshot().admitted_target)
        self.assertEqual(core_ratio.snapshot().last_sequence, -1)

    def test_successful_fake_adapter_uses_actual_codec_foc_packets_with_independent_expected_mappings(self):
        clock = DeterministicClock(0.0)
        specs = (
            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25)),
            JointSpec("J2", 1, JointMap(reduction=2.0, direction=1, zero_output_rad=0.1)),
        )
        core = JointCore(specs, clock=clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)
        station.writes.clear()

        jt1 = JointTarget(q_rad=0.1, dq_rad_s=1.0, tau_nm=-6.0, kp=18.0, kd=4.5)
        jt2 = JointTarget(q_rad=0.2, dq_rad_s=-1.0, tau_nm=3.0, kp=8.0, kd=2.0)
        w = station.issue_window(1.0)
        target = Target(1, (jt1, jt2), window=w)

        decision = station.submit(target)
        self.assertTrue(decision.accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)
        self.assertEqual(station.writes, [])

        expected_pkt_1 = command(
            0,
            mode=1,
            rpm=-180.0 / math.tau,
            kd=0.5,
            torque=2.0,
            watchdog=True,
            position=-0.05,
            kp=2.0,
        )

        expected_pkt_2 = command(
            1,
            mode=1,
            rpm=-120.0 / math.tau,
            kd=0.5,
            torque=1.5,
            watchdog=True,
            position=0.5,
            kp=2.0,
        )

        refreshed = station.refresh()
        self.assertIsNotNone(refreshed)
        self.assertEqual(refreshed.target, target)
        self.assertEqual(station.writes, [expected_pkt_1, expected_pkt_2])
        self.assertIs(core.snapshot().state, State.MOVING)
        self.assertEqual(core.snapshot().last_sequence, 1)

    def test_no_writes_on_rejection_stale_fault_stop_disconnect(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)
        station.writes.clear()

        jt1 = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
        jt2 = JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)
        w = station.issue_window(1.0)
        valid_target = Target(1, (jt1, jt2), window=w)

        bad_target = Target(2, (JointTarget(0.0, 0.0, 10.0, 1.0, 0.1), jt2), window=w)
        self.assertFalse(station.submit(bad_target).accepted)
        self.assertEqual(station.writes, [])

        self.assertIsNone(station.refresh())
        self.assertEqual(station.writes, [])

        self.assertTrue(station.submit(valid_target).accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)
        clock.value = 1.000001
        w2 = station.issue_window(1.0)
        valid_target_newer = Target(2, (jt1, jt2), window=w2)
        self.assertEqual(station.submit(valid_target_newer).code, DecisionCode.STALE_FEEDBACK)
        self.assertEqual(station.writes, [])

        self.assertIsNone(station.refresh())
        self.assertEqual(station.writes, [])
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        w3 = station.issue_window(1.0)
        valid_target_3 = Target(3, (jt1, jt2), window=w3)
        self.assertEqual(station.submit(valid_target_3).code, DecisionCode.INVALID_STATE)
        self.assertIsNone(station.refresh())
        self.assertEqual(station.writes, [])

        station.writes.clear()
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        station.writes.clear()
        self.assertTrue(station.arm().accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)
        w4 = station.issue_window(1.0)
        valid_target_4 = Target(4, (jt1, jt2), window=w4)
        self.assertTrue(station.submit(valid_target_4).accepted)
        self.assertEqual(core.snapshot().last_sequence, 4)

        station.writes.clear()
        self.assertTrue(station.stop().accepted)
        self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertEqual(core.snapshot().last_sequence, 4)
        station.writes.clear()
        self.assertIsNone(station.refresh())
        self.assertEqual(station.writes, [])

        core2 = JointCore(self.specs, clock=clock)
        station2 = FakeStation(core2)
        self.assertTrue(station2.connect().accepted)
        self.assertTrue(station2.check().accepted)
        self.assertTrue(station2.arm().accepted)
        self.assertEqual(core2.snapshot().last_sequence, -1)
        w5 = station2.issue_window(1.0)
        valid_target_5 = Target(1, (jt1, jt2), window=w5)
        self.assertTrue(station2.submit(valid_target_5).accepted)
        self.assertEqual(core2.snapshot().last_sequence, 1)
        station2.writes.clear()

        self.assertTrue(station2.disconnect().accepted)
        self.assertEqual(station2.writes, [])
        self.assertIsNone(core2.snapshot().admitted_target)
        self.assertEqual(core2.snapshot().last_sequence, 1)
        self.assertIsNone(station2.refresh())
        self.assertEqual(station2.writes, [])

    def test_stale_feedback_discovered_on_refresh_clears_pending_and_latches_fault(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=0.5)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)

        w = station.issue_window(1.0)
        target = Target(1, (
            JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
        ), window=w)
        self.assertTrue(station.submit(target).accepted)
        self.assertEqual(core.snapshot().admitted_target, target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        clock.value = 0.4
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)

        clock.value = 0.6
        refreshed = station.refresh()
        self.assertIsNone(refreshed)

        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertIsNone(snap.admitted_target)
        self.assertEqual(snap.last_sequence, 1)
        self.assertEqual(snap.affected_joints, ("J2",))
        self.assertEqual(len(snap.faults), 1)
        self.assertTrue(snap.faults[0].stale)
        self.assertEqual(snap.faults[0].name, "J2")

        self.assertEqual(station.check().code, DecisionCode.FAULT_ACK_REQUIRED)

    def test_only_armed_and_moving_may_submit_and_refresh(self):
        clock = DeterministicClock(0.0)
        w = IntentWindow(0, 0.0, 1.0)
        target = Target(1, (
            JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
        ), window=w)

        rejected_states = (
            State.DISCONNECTED,
            State.CONNECTING,
            State.CONNECTED,
            State.CHECKING,
            State.READY,
            State.STOPPED,
            State.FAULT,
        )
        for state in rejected_states:
            with self.subTest(state=state):
                core = core_at(self, state)
                before = core.snapshot()
                self.assertEqual(core.submit_target(target).code, DecisionCode.INVALID_STATE)
                self.assertIsNone(core.prepare_refresh())
                self.assertEqual(core.snapshot(), before)

        core = core_at(self, State.ARMED)
        armed_station = FakeStation(core)
        w_arm = armed_station.issue_window(1.0)
        arm_target = Target(1, (
            JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
        ), window=w_arm)
        self.assertTrue(core.submit_target(arm_target).accepted)
        self.assertEqual(core.snapshot().admitted_target, arm_target)
        self.assertEqual(core.snapshot().last_sequence, 1)
        plan = armed_station.refresh()
        self.assertIsNotNone(plan)
        self.assertEqual(plan.target, arm_target)
        self.assertIs(core.snapshot().state, State.MOVING)
        self.assertEqual(core.snapshot().last_sequence, 1)

        w_move = armed_station.issue_window(1.0)
        target2 = Target(2, (
            JointTarget(0.3, 0.0, 0.0, 1.0, 0.1),
            JointTarget(0.4, 0.0, 0.0, 1.0, 0.1),
        ), window=w_move)
        self.assertTrue(core.submit_target(target2).accepted)
        self.assertEqual(core.snapshot().admitted_target, target2)
        self.assertEqual(core.snapshot().last_sequence, 2)
        plan2 = armed_station.refresh()
        self.assertIsNotNone(plan2)
        self.assertEqual(plan2.target, target2)
        self.assertIs(core.snapshot().state, State.MOVING)
        self.assertEqual(core.snapshot().last_sequence, 2)


class CommandSequenceTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1.0, 1, 0.0)),
            JointSpec("J2", 1, JointMap(1.0, 1, 0.0)),
        )
        self.valid_joints = (
            JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
        )

    def _armed_station(self, clock=None):
        if clock is None:
            clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)
        return core, station, clock

    def test_actual_order_1_5_5_2_6_ends_at_6(self):
        core, station, _ = self._armed_station()
        self.assertEqual(core.snapshot().last_sequence, -1)
        self.assertIsNone(core.snapshot().admitted_target)

        w = station.issue_window(1.0)
        t1 = Target(1, self.valid_joints, window=w)
        d1 = station.submit(t1)
        self.assertTrue(d1.accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)
        self.assertEqual(core.snapshot().admitted_target, t1)

        t5 = Target(5, self.valid_joints, window=w)
        d5 = station.submit(t5)
        self.assertTrue(d5.accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        station.writes.clear()
        t5_dup = Target(5, self.valid_joints, window=w)
        d5_dup = station.submit(t5_dup)
        self.assertFalse(d5_dup.accepted)
        self.assertEqual(d5_dup.code, DecisionCode.DUPLICATE_OR_OLDER)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)
        self.assertEqual(station.writes, [])

        t2 = Target(2, self.valid_joints, window=w)
        d2 = station.submit(t2)
        self.assertFalse(d2.accepted)
        self.assertEqual(d2.code, DecisionCode.DUPLICATE_OR_OLDER)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)
        self.assertEqual(station.writes, [])

        t6 = Target(6, self.valid_joints, window=w)
        d6 = station.submit(t6)
        self.assertTrue(d6.accepted)
        self.assertEqual(core.snapshot().last_sequence, 6)
        self.assertEqual(core.snapshot().admitted_target, t6)

        station.writes.clear()
        plan = station.refresh()
        self.assertIsNotNone(plan)
        self.assertEqual(plan.target, t6)
        self.assertIs(core.snapshot().state, State.MOVING)
        self.assertEqual(core.snapshot().admitted_target, t6)
        self.assertEqual(core.snapshot().last_sequence, 6)
        self.assertEqual(len(station.writes), 2)

    def test_boundaries_0_and_uint64max(self):
        core, station, _ = self._armed_station()
        self.assertEqual(core.snapshot().last_sequence, -1)

        w = station.issue_window(1.0)
        t0 = Target(0, self.valid_joints, window=w)
        self.assertTrue(station.submit(t0).accepted)
        self.assertEqual(core.snapshot().last_sequence, 0)
        self.assertEqual(core.snapshot().admitted_target, t0)

        d0_dup = station.submit(t0)
        self.assertFalse(d0_dup.accepted)
        self.assertEqual(d0_dup.code, DecisionCode.DUPLICATE_OR_OLDER)
        self.assertEqual(core.snapshot().last_sequence, 0)
        self.assertEqual(core.snapshot().admitted_target, t0)

        uint64_max = (1 << 64) - 1
        t_max = Target(uint64_max, self.valid_joints, window=w)
        self.assertTrue(station.submit(t_max).accepted)
        self.assertEqual(core.snapshot().last_sequence, uint64_max)
        self.assertEqual(core.snapshot().admitted_target, t_max)

        d_max_dup = station.submit(t_max)
        self.assertFalse(d_max_dup.accepted)
        self.assertEqual(d_max_dup.code, DecisionCode.DUPLICATE_OR_OLDER)
        self.assertEqual(core.snapshot().last_sequence, uint64_max)

        t_smaller = Target(uint64_max - 1, self.valid_joints, window=w)
        d_smaller = station.submit(t_smaller)
        self.assertFalse(d_smaller.accepted)
        self.assertEqual(d_smaller.code, DecisionCode.DUPLICATE_OR_OLDER)
        self.assertEqual(core.snapshot().last_sequence, uint64_max)

    def test_sequence_type_and_range_rejections(self):
        w = IntentWindow(0, 0.0, 1.0)
        invalid_sequences = (
            True,
            False,
            -1,
            -100,
            0.0,
            1.5,
            math.nan,
            math.inf,
            -math.inf,
            "0",
            "1",
            "100",
            1 << 64,
            (1 << 64) + 1,
            None,
            object(),
        )
        for bad_seq in invalid_sequences:
            with self.subTest(bad_seq=repr(bad_seq)), self.assertRaises(ValueError):
                Target(bad_seq, self.valid_joints, window=w)

        target = Target(1, self.valid_joints, window=w)
        with self.assertRaises(FrozenInstanceError):
            target.sequence = 2

    def test_invalid_higher_vector_or_mapping_preserves_pending_and_watermark_and_never_blocks_smaller(self):
        core, station, _ = self._armed_station()
        w = station.issue_window(1.0)
        t5 = Target(5, self.valid_joints, window=w)
        self.assertTrue(station.submit(t5).accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        bad_len = Target(10, (self.valid_joints[0],), window=w)
        d_bad_len = station.submit(bad_len)
        self.assertFalse(d_bad_len.accepted)
        self.assertEqual(d_bad_len.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        bad_map = Target(10, (JointTarget(0.0, 0.0, 10.0, 1.0, 0.1), self.valid_joints[1]), window=w)
        d_bad_map = station.submit(bad_map)
        self.assertFalse(d_bad_map.accepted)
        self.assertEqual(d_bad_map.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        bad_second = Target(10, (self.valid_joints[0], JointTarget(0, 0, 10, 1, .1)), window=w)
        before = core.snapshot()
        self.assertEqual(station.submit(bad_second).code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot(), before)

        t7 = Target(7, self.valid_joints, window=w)
        d7 = station.submit(t7)
        self.assertTrue(d7.accepted)
        self.assertEqual(core.snapshot().last_sequence, 7)
        self.assertEqual(core.snapshot().admitted_target, t7)

    def test_watermark_survives_consumption_stop_fault_disconnect_reconnect_and_recovery(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)

        w1 = station.issue_window(1.0)
        t10 = Target(10, self.valid_joints, window=w1)
        self.assertTrue(station.submit(t10).accepted)
        self.assertEqual(core.snapshot().last_sequence, 10)

        plan = station.refresh()
        self.assertIsNotNone(plan)
        self.assertEqual(plan.target, t10)
        self.assertIs(core.snapshot().state, State.MOVING)
        self.assertEqual(core.snapshot().last_sequence, 10)

        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertEqual(core.snapshot().last_sequence, 10)

        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)
        self.assertEqual(core.snapshot().last_sequence, 10)

        bad_health = MotorHealth(mode=0, errors=1, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, bad_health).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().last_sequence, 10)

        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().last_sequence, 10)

        self.assertTrue(station.disconnect().accepted)
        self.assertIs(core.snapshot().state, State.DISCONNECTED)
        self.assertEqual(core.snapshot().last_sequence, 10)

        self.assertTrue(station.connect().accepted)
        self.assertIs(core.snapshot().state, State.CONNECTED)
        self.assertEqual(core.snapshot().last_sequence, 10)

        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertIs(core.snapshot().state, State.READY)
        self.assertEqual(core.snapshot().last_sequence, 10)

        self.assertTrue(station.arm().accepted)
        self.assertIs(core.snapshot().state, State.ARMED)
        self.assertEqual(core.snapshot().last_sequence, 10)

        w2 = station.issue_window(1.0)
        t10_new = Target(10, self.valid_joints, window=w2)
        d10_dup = station.submit(t10_new)
        self.assertFalse(d10_dup.accepted)
        self.assertEqual(d10_dup.code, DecisionCode.DUPLICATE_OR_OLDER)
        self.assertEqual(core.snapshot().last_sequence, 10)

        t9 = Target(9, self.valid_joints, window=w2)
        d9 = station.submit(t9)
        self.assertFalse(d9.accepted)
        self.assertEqual(d9.code, DecisionCode.DUPLICATE_OR_OLDER)
        self.assertEqual(core.snapshot().last_sequence, 10)

        t11 = Target(11, self.valid_joints, window=w2)
        d11 = station.submit(t11)
        self.assertTrue(d11.accepted)
        self.assertEqual(core.snapshot().last_sequence, 11)
        self.assertEqual(core.snapshot().admitted_target, t11)

    def test_stale_submission_latches_fault_clears_goal_and_preserves_watermark(self):
        core, station, clock = self._armed_station()
        w = station.issue_window(1.0)
        t5 = Target(5, self.valid_joints, window=w)
        self.assertTrue(station.submit(t5).accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        clock.value = 1.000001
        w2 = station.issue_window(1.0)
        t10 = Target(10, self.valid_joints, window=w2)
        d_stale = station.submit(t10)
        self.assertFalse(d_stale.accepted)
        self.assertEqual(d_stale.code, DecisionCode.STALE_FEEDBACK)
        self.assertEqual(core.snapshot().last_sequence, 5)
        stale_snapshot = core.snapshot()
        self.assertIsNone(stale_snapshot.admitted_target)
        self.assertIs(stale_snapshot.state, State.FAULT)

        rejected_states = (
            State.DISCONNECTED,
            State.CONNECTING,
            State.CONNECTED,
            State.CHECKING,
            State.READY,
            State.STOPPED,
            State.FAULT,
        )
        for state in rejected_states:
            with self.subTest(state=state):
                state_core = core_at(self, state)
                self.assertIs(state_core.snapshot().state, state)
                self.assertEqual(state_core.snapshot().last_sequence, -1)
                w_state = state_core.issue_window(1.0)
                d = state_core.submit_target(Target(20, self.valid_joints, window=w_state))
                self.assertFalse(d.accepted)
                self.assertEqual(d.code, DecisionCode.INVALID_STATE)
                self.assertEqual(state_core.snapshot().last_sequence, -1)
                self.assertIsNone(state_core.snapshot().admitted_target)

    def test_new_core_starts_negative_one_and_independent_watermarks(self):
        core1 = JointCore(self.specs, clock=DeterministicClock(0.0))
        core2 = JointCore(self.specs, clock=DeterministicClock(0.0))
        self.assertEqual(core1.snapshot().last_sequence, -1)
        self.assertEqual(core2.snapshot().last_sequence, -1)

        station1 = FakeStation(core1)
        self.assertTrue(station1.connect().accepted)
        self.assertTrue(station1.check().accepted)
        self.assertTrue(station1.arm().accepted)

        w = station1.issue_window(1.0)
        t10 = Target(10, self.valid_joints, window=w)
        self.assertTrue(station1.submit(t10).accepted)
        self.assertEqual(core1.snapshot().last_sequence, 10)
        self.assertEqual(core2.snapshot().last_sequence, -1)


if __name__ == "__main__":
    unittest.main()

```

### test_controller_expiry.py
```
"""Acceptance tests for C07 command expiry, window authority, and refresh dispatch."""

import math
import unittest
from unittest.mock import patch

from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    IntentWindow,
    JointSpec,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget
from im6014_serial import TransactionTimeoutError, WriteCancelledError, exchange
from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP


SOURCE = SourceIdentity("fixture", "expiry-test", 1)


class ControllerExpiryTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1.0, 1, 0.0)),
            JointSpec("J2", 1, JointMap(1.0, 1, 0.0)),
        )
        self.valid_joints = (
            JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
        )

    def _armed_core(self, clock=None, *, feedback_max_age_s=1.0, max_window_s=1.0):
        if clock is None:
            clock = DeterministicClock(0.0)
        core = JointCore(
            self.specs,
            clock=clock,
            feedback_max_age_s=feedback_max_age_s,
            max_window_s=max_window_s,
        )
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)
        return core, station, clock

    def test_expired_incoming_and_equality_boundary_reject_without_watermark_corruption(self):
        core, station, clock = self._armed_core()
        self.assertEqual(core.snapshot().last_sequence, -1)

        # Submit valid initial target to establish watermark at 5
        w0 = station.issue_window(0.5)
        t0 = Target(5, self.valid_joints, window=w0)
        self.assertTrue(station.submit(t0).accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t0)

        # Issue window valid for 0.4s (expires at 0.4s)
        w1 = station.issue_window(0.4)
        self.assertEqual(w1.created_at_s, 0.0)
        self.assertEqual(w1.expires_at_s, 0.4)

        # Exact equality boundary: now == expires_at_s is expired
        clock.value = 0.4
        t_boundary = Target(6, self.valid_joints, window=w1)
        d_boundary = station.submit(t_boundary)
        self.assertFalse(d_boundary.accepted)
        self.assertEqual(d_boundary.code, DecisionCode.EXPIRED)
        # Watermark and valid goal preserved
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t0)

        # Strictly past expiry: now > expires_at_s is expired
        clock.value = 0.40001
        t_past = Target(7, self.valid_joints, window=w1)
        d_past = station.submit(t_past)
        self.assertFalse(d_past.accepted)
        self.assertEqual(d_past.code, DecisionCode.EXPIRED)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t0)

    def test_delayed_computation_cannot_get_new_arrival_ttl(self):
        core, station, clock = self._armed_core()
        # Client requests window at time 0.0 valid for 0.2s
        w1 = station.issue_window(0.2)
        self.assertEqual(w1.expires_at_s, 0.2)

        # Client computation takes 0.3s (now is 0.3)
        clock.value = 0.3
        target1 = Target(1, self.valid_joints, window=w1)
        # Arrival at core does NOT grant new TTL; rejects as EXPIRED
        decision = station.submit(target1)
        self.assertFalse(decision.accepted)
        self.assertEqual(decision.code, DecisionCode.EXPIRED)
        self.assertEqual(core.snapshot().last_sequence, -1)
        self.assertIsNone(core.snapshot().admitted_target)

        # Client cannot forge a window with extended expiry
        forged_window = IntentWindow(w1.id, w1.created_at_s, 0.9)
        forged_target = Target(1, self.valid_joints, window=forged_window)
        d_forged = station.submit(forged_target)
        self.assertFalse(d_forged.accepted)
        self.assertEqual(d_forged.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().last_sequence, -1)

        # If station issues a new window w2, client cannot submit old computation with w1
        w2 = station.issue_window(0.2)
        d_old = station.submit(target1)
        self.assertFalse(d_old.accepted)
        self.assertEqual(d_old.code, DecisionCode.EXPIRED)

    def test_new_submission_cannot_revive_expired_moving_goal(self):
        core, station, clock = self._armed_core()
        first_window = station.issue_window(0.2)
        first = Target(5, self.valid_joints, window=first_window)
        self.assertTrue(station.submit(first).accepted)
        self.assertIsNotNone(station.refresh())
        self.assertIs(core.snapshot().state, State.MOVING)

        clock.value = first_window.expires_at_s
        fresh_window = station.issue_window(0.2)
        replacement = Target(6, self.valid_joints, window=fresh_window)
        decision = station.submit(replacement)

        self.assertFalse(decision.accepted)
        self.assertEqual(decision.code, DecisionCode.EXPIRED)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertEqual(core.snapshot().last_sequence, 5)

    def test_invalid_replacement_preserves_only_a_still_valid_goal(self):
        core, station, clock = self._armed_core()
        window = station.issue_window(0.2)
        current = Target(5, self.valid_joints, window=window)
        self.assertTrue(station.submit(current).accepted)

        invalid = Target(9, (self.valid_joints[0],), window=window)
        decision = station.submit(invalid)
        self.assertFalse(decision.accepted)
        self.assertEqual(decision.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().admitted_target, current)
        self.assertEqual(core.snapshot().last_sequence, 5)

        clock.value = window.expires_at_s
        fresh_window = station.issue_window(0.2)
        invalid_after_expiry = Target(10, (self.valid_joints[0],), window=fresh_window)
        expired_decision = station.submit(invalid_after_expiry)
        self.assertFalse(expired_decision.accepted)
        self.assertEqual(expired_decision.code, DecisionCode.EXPIRED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertEqual(core.snapshot().last_sequence, 5)

    def test_goal_expires_after_admission_and_before_prepare_or_actual_write(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)
        self.assertEqual(core.snapshot().admitted_target, target)

        # Goal expires after admission: clock moves to 0.55 before prepare_refresh
        clock.value = 0.55
        plan = core.prepare_refresh()
        self.assertIsNone(plan)
        # Goal is withdrawn and core disarms to STOPPED
        snap = core.snapshot()
        self.assertIsNone(snap.admitted_target)
        self.assertIsNone(snap.prepared_plan)
        self.assertIs(snap.state, State.STOPPED)

    def test_two_joint_first_write_then_expiry_or_revoke_blocks_second_and_records_only_first(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Joint 0 claim and complete write
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        d0 = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertTrue(d0.accepted)
        self.assertIs(core.snapshot().state, State.MOVING)

        # Check J0 record is stored, J1 is still None
        records_after_j0 = core.snapshot().dispatched_records
        self.assertIsNotNone(records_after_j0[0])
        self.assertEqual(records_after_j0[0].sequence, 1)
        self.assertEqual(records_after_j0[0].target, self.valid_joints[0])
        self.assertIsNone(records_after_j0[1])

        # Expiry occurs before Joint 1 write
        clock.value = 0.55
        # Joint 1 claim fails due to expiry
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))

        # Core disarms to STOPPED, goal withdrawn, J0 record preserved, J1 remained unwritten
        snap = core.snapshot()
        self.assertIs(snap.state, State.STOPPED)
        self.assertIsNone(snap.admitted_target)
        self.assertIsNone(snap.prepared_plan)
        self.assertIsNotNone(snap.dispatched_records[0])
        self.assertIsNone(snap.dispatched_records[1])

    def test_reset_input_buffer_advancing_clock_causes_final_gate_cancellation_with_zero_mode1_write(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Fake bus where reset_input_buffer takes enough time to advance the clock past expiry
        written_packets = []

        class TimeAdvancingBus:
            def __init__(self):
                self.timeout = 0.1
                self.in_waiting = 0

            def reset_input_buffer(self):
                clock.value = 0.6  # Past window expiry of 0.5s!

            def write(self, packet):
                written_packets.append(packet)
                return len(packet)

            def read(self, size):
                return b""

        bus = TimeAdvancingBus()
        pkt = command(0, mode=1)

        with self.assertRaises(WriteCancelledError):
            exchange(
                bus,
                pkt,
                motor_id=0,
                deadline_s=0.2,
                before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
                on_write=lambda res: core.dispatch_result(plan.plan_id, 0, res),
            )

        # Zero mode-1 packets were written to the bus!
        self.assertEqual(written_packets, [])
        # Final gate cancellation disarmed core to STOPPED and withdrew goal
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)

    def test_expiry_during_feedback_wait_causes_no_later_write(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # First joint writes successfully
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)

        # Feedback wait takes long time, crossing expiry
        clock.value = 0.55

        # Attempting second joint write: claim fails because goal has expired
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
        # Core is disarmed to STOPPED
        self.assertIs(core.snapshot().state, State.STOPPED)

    def test_repeated_refresh_bounded_until_expiry(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)

        # At t=0.1, refresh succeeds
        clock.value = 0.1
        plan1 = station.refresh()
        self.assertIsNotNone(plan1)
        self.assertEqual(plan1.target, target)
        self.assertIs(core.snapshot().state, State.MOVING)

        # At t=0.2, second refresh succeeds with the same admitted goal
        clock.value = 0.2
        plan2 = station.refresh()
        self.assertIsNotNone(plan2)
        self.assertEqual(plan2.target, target)

        # At t=0.4, third refresh succeeds
        clock.value = 0.4
        plan3 = station.refresh()
        self.assertIsNotNone(plan3)

        # At t=0.5, window expires: refresh returns None and disarms to STOPPED
        clock.value = 0.5
        plan_expired = station.refresh()
        self.assertIsNone(plan_expired)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)

    def test_invalid_higher_seq_preserves_valid_goal(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        t5 = Target(5, self.valid_joints, window=w)
        self.assertTrue(station.submit(t5).accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        # High sequence with invalid joint target count
        bad_high = Target(100, (self.valid_joints[0],), window=w)
        d_bad = station.submit(bad_high)
        self.assertFalse(d_bad.accepted)
        self.assertEqual(d_bad.code, DecisionCode.INVALID_ARGUMENT)

        # Watermark is still 5, admitted goal is still t5
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        # High sequence with out-of-range torque
        bad_torque = Target(100, (JointTarget(0, 0, 10.0, 1, .1), self.valid_joints[1]), window=w)
        d_torque = station.submit(bad_torque)
        self.assertFalse(d_torque.accepted)
        self.assertEqual(d_torque.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

    def test_stop_fault_disconnect_invalidate_plans_but_retain_sequence(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(10, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)
        self.assertEqual(core.snapshot().last_sequence, 10)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)
        self.assertEqual(core.snapshot().prepared_plan, plan)

        # Stop invalidates plan and goal, retains sequence watermark
        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertEqual(core.snapshot().last_sequence, 10)

        # Re-arm and set up new target
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)
        w2 = station.issue_window(1.0)
        target2 = Target(12, self.valid_joints, window=w2)
        self.assertTrue(station.submit(target2).accepted)
        plan2 = core.prepare_refresh()
        self.assertIsNotNone(plan2)

        # Fault invalidates plan and goal, retains sequence
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertEqual(core.snapshot().last_sequence, 12)

        # Disconnect invalidates plan and goal, retains sequence
        self.assertTrue(station.disconnect().accepted)
        self.assertIs(core.snapshot().state, State.DISCONNECTED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertEqual(core.snapshot().last_sequence, 12)

    def test_wrong_duplicate_out_of_order_claims_reject(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Wrong plan ID rejects
        self.assertFalse(core.claim_dispatch(plan.plan_id + 99, 0))

        # Out-of-order joint index rejects (index 1 before index 0)
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))

        # Correct claim of index 0
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))

        # Duplicate claim of index 0 rejects
        self.assertFalse(core.claim_dispatch(plan.plan_id, 0))

        # Out-of-bounds index rejects
        self.assertFalse(core.claim_dispatch(plan.plan_id, 5))
        self.assertFalse(core.claim_dispatch(plan.plan_id, -1))

        # One unresolved write blocks both reprepare and the next joint.
        self.assertIsNone(core.prepare_refresh())
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
        self.assertFalse(core.dispatch_result(plan.plan_id + 99, 0, WriteResult.COMPLETE).accepted)
        self.assertFalse(core.dispatch_result(plan.plan_id, 1, WriteResult.COMPLETE).accepted)
        self.assertFalse(core.dispatch_result(plan.plan_id, 0, None).accepted)
        self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)

        # Joint 1 is claimable only after joint 0's outcome arrives.
        self.assertTrue(core.claim_dispatch(plan.plan_id, 1))
        self.assertTrue(core.dispatch_result(plan.plan_id, 1, WriteResult.COMPLETE).accepted)

    def test_stop_after_claim_preserves_completed_receipt_without_rearming(self):
        core, station, clock = self._armed_core()
        target = Target(1, self.valid_joints, window=station.issue_window(1.0))
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        claim_time = clock.value

        self.assertTrue(core.stop().accepted)
        receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)

        self.assertTrue(receipt.accepted)
        snapshot = core.snapshot()
        self.assertIs(snapshot.state, State.STOPPED)
        self.assertIsNone(snapshot.admitted_target)
        self.assertIsNone(snapshot.prepared_plan)
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
        self.assertIsNone(core.prepare_refresh())
        self.assertFalse(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)

    def test_expiry_after_claim_preserves_completed_receipt_without_moving(self):
        core, station, clock = self._armed_core()
        window = station.issue_window(0.2)
        target = Target(1, self.valid_joints, window=window)
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        claim_time = clock.value

        clock.value = window.expires_at_s
        receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)

        self.assertTrue(receipt.accepted)
        snapshot = core.snapshot()
        self.assertIs(snapshot.state, State.STOPPED)
        self.assertIsNone(snapshot.admitted_target)
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))

    def test_invalidated_plan_receipt_records_write_without_reviving_old_goal(self):
        core, station, clock = self._armed_core()
        first = Target(1, self.valid_joints, window=station.issue_window(1.0))
        self.assertTrue(station.submit(first).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))

        replacement = Target(2, self.valid_joints, window=station.issue_window(1.0))
        self.assertTrue(station.submit(replacement).accepted)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertIsNone(core.prepare_refresh())

        receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertTrue(receipt.accepted)
        snapshot = core.snapshot()
        self.assertIs(snapshot.admitted_target, replacement)
        self.assertIs(snapshot.state, State.ARMED)
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertIsNone(snapshot.prepared_plan)

        replacement_plan = core.prepare_refresh()
        self.assertIsNotNone(replacement_plan)
        self.assertIs(replacement_plan.target, replacement)

    def test_complete_write_then_bad_timeout_feedback_still_counted_actually_dispatched(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Joint 0 claims and writes successfully
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        d_res = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertTrue(d_res.accepted)

        # Dispatched record is committed
        snap_after_write = core.snapshot()
        self.assertIsNotNone(snap_after_write.dispatched_records[0])
        self.assertEqual(snap_after_write.dispatched_records[0].sequence, 1)

        # Feedback from serial communication times out
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
        snap_after_failure = core.snapshot()
        self.assertIs(snap_after_failure.state, State.FAULT)
        # Dispatched record is STILL preserved despite communication failure!
        self.assertIsNotNone(snap_after_failure.dispatched_records[0])
        self.assertEqual(snap_after_failure.dispatched_records[0].sequence, 1)

    def test_partial_failed_write_faults(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # J0 claims, but write fails
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        d_fail = core.dispatch_result(plan.plan_id, 0, WriteResult.FAILED)
        self.assertFalse(d_fail.accepted)
        self.assertEqual(d_fail.code, DecisionCode.FAULT_LATCHED)

        # Latches fault on joint 0
        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.affected_joints, ("J1",))
        self.assertEqual(snap.faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)
        # Motion withdrawn, plan invalidated
        self.assertIsNone(snap.admitted_target)
        self.assertIsNone(snap.prepared_plan)
        # J0 was not completely written so dispatched record is None
        self.assertIsNone(snap.dispatched_records[0])
        self.assertEqual(snap.dispatch_attempts[0].result, WriteResult.FAILED)

    def test_partial_attempt_keeps_previous_complete_dispatched_record(self):
        core, station, clock = self._armed_core()
        first = Target(1, self.valid_joints, window=station.issue_window(1.0))
        self.assertTrue(station.submit(first).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)

        next_target = Target(2, self.valid_joints, window=station.issue_window(1.0))
        self.assertTrue(core.submit_target(next_target).accepted)
        next_plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(next_plan.plan_id, 0))
        failed = core.dispatch_result(next_plan.plan_id, 0, WriteResult.PARTIAL)

        self.assertFalse(failed.accepted)
        snapshot = core.snapshot()
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.PARTIAL)
        self.assertEqual(snapshot.dispatch_attempts[0].sequence, 2)

    def test_complete_write_is_recorded_then_invalid_end_clock_faults_joint(self):
        for invalid_end_time in (math.nan, 0.5):
            with self.subTest(invalid_end_time=invalid_end_time):
                core, station, clock = self._armed_core(DeterministicClock(1.0))
                target = Target(1, self.valid_joints, window=station.issue_window(1.0))
                self.assertTrue(station.submit(target).accepted)
                plan = core.prepare_refresh()
                claim_time = clock.value

                transaction_clock = DeterministicClock(0.0)
                writes = []

                class ClockFailingBus:
                    timeout = 0.1

                    def reset_input_buffer(self):
                        pass

                    def write(self, packet):
                        writes.append(packet)
                        clock.value = invalid_end_time
                        transaction_clock.value = 0.1
                        return len(packet)

                with patch("im6014_serial._monotonic", transaction_clock):
                    with self.assertRaises(TransactionTimeoutError):
                        exchange(
                            ClockFailingBus(), b"x" * 20, 0, deadline_s=0.05,
                            before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
                            on_write=lambda result: core.dispatch_result(plan.plan_id, 0, result),
                        )
                self.assertEqual(len(writes), 1)
                with self.assertRaises(ValueError):
                    core.snapshot()

                clock.value = claim_time
                snapshot = core.snapshot()
                self.assertIs(snapshot.state, State.FAULT)
                self.assertEqual(snapshot.faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)
                self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
                self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
                self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.COMPLETE)
                self.assertIsNone(snapshot.admitted_target)
                self.assertFalse(core.begin_check().accepted)
                self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)

    def test_exchange_reports_actual_write_before_enforcing_deadline(self):
        transaction_clock = DeterministicClock(0.0)
        results = []

        class DeadlineBus:
            timeout = 0.1

            def __init__(self, returned):
                self.returned = returned
                self.write_count = 0

            def reset_input_buffer(self):
                pass

            def write(self, packet):
                self.write_count += 1
                transaction_clock.value = 0.1
                return self.returned

        complete_bus = DeadlineBus(20)
        with patch("im6014_serial._monotonic", transaction_clock):
            with self.assertRaises(TransactionTimeoutError):
                exchange(complete_bus, b"x" * 20, 0, deadline_s=0.05, on_write=results.append)
        self.assertEqual(complete_bus.write_count, 1)
        self.assertEqual(results, [WriteResult.COMPLETE])

        transaction_clock.value = 0.0
        results.clear()
        partial_bus = DeadlineBus(1)
        with patch("im6014_serial._monotonic", transaction_clock):
            with self.assertRaises(TransactionTimeoutError):
                exchange(partial_bus, b"x" * 20, 0, deadline_s=0.05, on_write=results.append)
        self.assertEqual(partial_bus.write_count, 1)
        self.assertEqual(results, [WriteResult.PARTIAL])

    def test_expiry_after_successful_claim_reports_zero_write_failure(self):
        core, station, _ = self._armed_core()
        target = Target(1, self.valid_joints, window=station.issue_window(1.0))
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()

        transaction_clock = DeterministicClock(0.0)
        results = []

        class DeadlineBus:
            timeout = 0.1

            def __init__(self):
                self.write_count = 0

            def reset_input_buffer(self):
                pass

            def write(self, packet):
                self.write_count += 1
                return len(packet)

        def claim_then_expire():
            self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
            transaction_clock.value = 0.05
            return True

        def record_result(result):
            results.append(result)
            return core.dispatch_result(plan.plan_id, 0, result)

        bus = DeadlineBus()
        with patch("im6014_serial._monotonic", transaction_clock):
            with self.assertRaises(TransactionTimeoutError):
                exchange(
                    bus, b"x" * 20, 0, deadline_s=0.05,
                    before_write=claim_then_expire,
                    on_write=record_result,
                )

        self.assertEqual(bus.write_count, 0)
        self.assertEqual(results, [WriteResult.FAILED])
        snapshot = core.snapshot()
        self.assertIs(snapshot.state, State.FAULT)
        self.assertEqual(snapshot.faults[0].motor_id, 0)
        self.assertEqual(snapshot.faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)
        self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.FAILED)
        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)

    def test_exchange_reports_raised_write_once_and_callback_failure_stops_feedback(self):
        results = []
        core, station, _ = self._armed_core()
        target = Target(1, self.valid_joints, window=station.issue_window(1.0))
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()

        class RaisingBus:
            timeout = 0.1

            def __init__(self):
                self.write_count = 0

            def reset_input_buffer(self):
                pass

            def write(self, packet):
                self.write_count += 1
                raise OSError("driver failure")

        def record_result(result):
            results.append(result)
            return core.dispatch_result(plan.plan_id, 0, result)

        raising_bus = RaisingBus()
        with self.assertRaisesRegex(OSError, "driver failure"):
            exchange(
                raising_bus, b"x" * 20, 0,
                before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
                on_write=record_result,
            )
        self.assertEqual(raising_bus.write_count, 1)
        self.assertEqual(results, [WriteResult.FAILED])
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().dispatch_attempts[0].result, WriteResult.FAILED)

        class CompleteBus:
            timeout = 0.1

            def __init__(self):
                self.write_count = 0
                self.read_called = False

            def reset_input_buffer(self):
                pass

            def write(self, packet):
                self.write_count += 1
                return len(packet)

            def read(self, size):
                self.read_called = True
                return b""

        bus = CompleteBus()
        callback_calls = []

        def broken_callback(result):
            callback_calls.append(result)
            raise RuntimeError("receipt failed")

        with self.assertRaisesRegex(RuntimeError, "receipt failed"):
            exchange(bus, b"x" * 20, 0, on_write=broken_callback)
        self.assertEqual(bus.write_count, 1)
        self.assertEqual(callback_calls, [WriteResult.COMPLETE])
        self.assertFalse(bus.read_called)

    def test_clock_regression_before_receive_cannot_replace_sample_or_timestamp(self):
        clock = DeterministicClock(10.0)
        core = JointCore(self.specs, clock=clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)

        # Valid receive at t=10.0
        sample_initial = JointSample(0.5, 0.0, 0.0)
        self.assertTrue(core.receive(0, sample_initial, HEALTHY_STOP).accepted)
        snap_initial = core.snapshot()
        self.assertEqual(snap_initial.joints[0].received_at, 10.0)
        self.assertEqual(snap_initial.joints[0].sample.q_rad, 0.5)

        # Clock regresses to 5.0
        clock.value = 5.0
        corrupt_sample = JointSample(9.9, 0.0, 0.0)
        with self.assertRaises(ValueError):
            core.receive(0, corrupt_sample, HEALTHY_STOP)

        # High-water mark check threw BEFORE overwriting observation
        # Previous observation remains uncorrupted
        clock.value = 10.0  # restore to valid non-regressing time for snapshot
        snap_after = core.snapshot()
        self.assertEqual(snap_after.joints[0].received_at, 10.0)
        self.assertEqual(snap_after.joints[0].sample.q_rad, 0.5)

    def test_invalid_clock_cannot_release_writes(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w)
        self.assertTrue(station.submit(target).accepted)

        # Non-finite clock raises before prepare_refresh releases any plan
        clock.value = math.nan
        with self.assertRaises(ValueError):
            core.prepare_refresh()

        clock.value = 0.1
        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Regressing clock raises before claim_dispatch releases write
        clock.value = 0.05  # Regressed!
        with self.assertRaises(ValueError):
            core.claim_dispatch(plan.plan_id, 0)

        # Stop still works even if clock fails or raises
        clock.value = math.nan
        stop_decision = station.stop()
        self.assertTrue(stop_decision.accepted)

    def test_max_window_s_configuration_and_monotonically_increasing_window_ids(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, max_window_s=0.5)

        # Window exceeding max_window_s rejects
        with self.assertRaises(ValueError):
            core.issue_window(0.6)

        # Monotonically increasing window IDs without wrap
        w0 = core.issue_window(0.2)
        w1 = core.issue_window(0.2)
        w2 = core.issue_window(0.5)
        self.assertEqual(w0.id, 0)
        self.assertEqual(w1.id, 1)
        self.assertEqual(w2.id, 2)
        self.assertTrue(w0.id < w1.id < w2.id)

        # Only latest offered window (w2) is admitted
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm().accepted)

        # Older window w0 is rejected
        t_old = Target(1, self.valid_joints, window=w0)
        d_old = station.submit(t_old)
        self.assertFalse(d_old.accepted)
        self.assertEqual(d_old.code, DecisionCode.EXPIRED)

        # Latest window w2 is accepted
        t_latest = Target(1, self.valid_joints, window=w2)
        d_latest = station.submit(t_latest)
        self.assertTrue(d_latest.accepted)


if __name__ == "__main__":
    unittest.main()

```

### test_serial_deadline.py
```
import os
import pty
import select
import threading
import time
import unittest
from unittest.mock import patch

import serial
import spin_5rpm as s
import im6014_serial as transport
from fake_serial import FakeClock, FakeChunk, FakeSerial
from test_protocol import CAPTURED


class B09Deadline(unittest.TestCase):
    def test_read_timeout_cannot_overrun_budget_and_restores(self):
        for original in (None, 0, .5):
            clock = FakeClock()
            bus = FakeSerial(clock=clock, timeout=original, write_timeout=.5)
            with self.subTest(timeout=original), patch.object(transport, "_monotonic", clock.monotonic):
                with self.assertRaisesRegex(RuntimeError, "deadline"):
                    s.exchange(bus, s.command(0), 0, .02)
            self.assertLessEqual(clock.monotonic(), .020001)
            self.assertEqual((bus.timeout, bus.write_timeout), (original, .5))
            self.assertEqual(len(bus.writes), 1)

    def test_reset_and_write_share_entry_budget(self):
        clock = FakeClock()
        bus = FakeSerial(clock=clock, timeout=.5, write_timeout=.5)
        bus.reset_delay = .03
        with patch.object(transport, "_monotonic", clock.monotonic):
            with self.assertRaisesRegex(RuntimeError, "deadline"):
                s.exchange(bus, s.command(0), 0, .02)
        self.assertEqual(len(bus.writes), 0)
        self.assertEqual((bus.timeout, bus.write_timeout), (.5, .5))
        clock = FakeClock()
        bus = FakeSerial(clock=clock, timeout=.5, write_timeout=.5)
        bus.reset_delay = .005
        bus.write_delay = .04
        with patch.object(transport, "_monotonic", clock.monotonic):
            with self.assertRaises((RuntimeError, TimeoutError)):
                s.exchange(bus, s.command(0), 0, .02)
        self.assertLessEqual(clock.monotonic(), .020001)
        self.assertEqual((bus.timeout, bus.write_timeout), (.5, .5))
        self.assertEqual(len(bus.writes), 1)

    def test_late_frame_is_not_success(self):
        clock = FakeClock()
        bus = FakeSerial(responses=[(FakeChunk(CAPTURED, .021),)], clock=clock,
                         timeout=None, write_timeout=None)
        with patch.object(transport, "_monotonic", clock.monotonic):
            with self.assertRaisesRegex(RuntimeError, "deadline"):
                s.exchange(bus, s.command(0), 0, .02)
        self.assertEqual((bus.timeout, bus.write_timeout), (None, None))
        self.assertLessEqual(clock.monotonic(), .020001)

    def test_errors_partial_write_and_success_restore_settings(self):
        for operation in ("read", "write", "reset", "partial", "success"):
            clock = FakeClock()
            bus = FakeSerial(responses=[(CAPTURED,)], clock=clock,
                             timeout=.5, write_timeout=0)
            if operation in ("read", "write", "reset"):
                setattr(bus, operation + "_error", OSError(operation))
            elif operation == "partial":
                bus.write_result = 19
            with self.subTest(operation=operation), patch.object(transport, "_monotonic", clock.monotonic):
                if operation == "success":
                    self.assertEqual(s.exchange(bus, s.command(0), 0)["raw"], CAPTURED.hex())
                else:
                    with self.assertRaises((RuntimeError, OSError)):
                        s.exchange(bus, s.command(0), 0)
            self.assertEqual((bus.timeout, bus.write_timeout), (.5, 0))


    def test_settings_failure_is_transport_fault_and_restores_both(self):
        class SetterBus(FakeSerial):
            def __setattr__(self, name, value):
                if getattr(self, "reject", False) and name in ("timeout", "write_timeout"):
                    self.attempts.append((name, value))
                    if name == "timeout" and (value == .5 if self.restore_failure else value != .5):
                        raise ValueError("timeout setter rejected")
                super().__setattr__(name, value)
        for restore_failure in (False, True):
            clock = FakeClock()
            bus = SetterBus(responses=[(CAPTURED,)], clock=clock, timeout=.5, write_timeout=.5)
            bus.attempts = []
            bus.restore_failure = restore_failure
            bus.reject = True
            with self.subTest(restore_failure=restore_failure), patch.object(transport, "_monotonic", clock.monotonic):
                with self.assertRaises(RuntimeError):
                    s.exchange(bus, s.command(0), 0, .02)
            self.assertIn(("timeout", .5), bus.attempts)
            self.assertIn(("write_timeout", .5), bus.attempts)
            self.assertEqual(bus.write_timeout, .5)

    def test_restore_failure_preserves_primary_fault_and_no_result(self):
        class RestoreBus(FakeSerial):
            def __setattr__(self, name, value):
                if getattr(self, "reject_restore", False) and name == "timeout" and value == .5:
                    raise ValueError("cannot restore")
                super().__setattr__(name, value)
        clock = FakeClock()
        bus = RestoreBus(clock=clock, timeout=.5, write_timeout=.5, read_error=OSError("primary read fault"))
        bus.reject_restore = True
        with patch.object(transport, "_monotonic", clock.monotonic):
            with self.assertRaisesRegex(RuntimeError, "restore.*primary read fault"):
                s.exchange(bus, s.command(0), 0, .02)
        self.assertEqual(bus.write_timeout, .5)

    def test_restoration_and_decode_time_cannot_return_late_success(self):
        class SlowRestoreBus(FakeSerial):
            def __setattr__(self, name, value):
                if getattr(self, "slow_restore", False) and name == "timeout" and value == .5:
                    self.clock.advance(.021)
                super().__setattr__(name, value)
        clock = FakeClock()
        bus = SlowRestoreBus(responses=[(CAPTURED,)], clock=clock, timeout=.5, write_timeout=.5)
        bus.slow_restore = True
        with patch.object(transport, "_monotonic", clock.monotonic):
            with self.assertRaisesRegex(RuntimeError, "deadline"):
                s.exchange(bus, s.command(0), 0, .02)
        self.assertEqual((bus.timeout, bus.write_timeout), (.5, .5))
        clock = FakeClock()
        bus = FakeSerial(responses=[(CAPTURED,)], clock=clock)
        decode = transport.feedback
        def slow_decode(*args):
            clock.advance(.021)
            return decode(*args)
        with patch.object(transport, "_monotonic", clock.monotonic), patch.object(transport, "feedback", slow_decode):
            with self.assertRaisesRegex(RuntimeError, "deadline"):
                s.exchange(bus, s.command(0), 0, .02)

    def test_zero_infinite_write_settings_are_bounded_and_invalid_deadlines_do_no_io(self):
        for original in (None, 0, .5):
            clock = FakeClock()
            bus = FakeSerial(responses=[(CAPTURED,)], clock=clock, write_timeout=original)
            write = bus.write
            def checked_write(packet):
                self.assertGreater(bus.write_timeout, 0)
                self.assertLessEqual(bus.write_timeout, .02)
                return write(packet)
            bus.write = checked_write
            with self.subTest(original=original), patch.object(transport, "_monotonic", clock.monotonic):
                s.exchange(bus, s.command(0), 0, .02)
            self.assertEqual(bus.write_timeout, original)
        for deadline in (0, -.1, float("nan"), float("inf")):
            bus = FakeSerial()
            with self.subTest(deadline=deadline), self.assertRaises(ValueError):
                s.exchange(bus, s.command(0), 0, deadline)
            self.assertEqual(bus.writes, ())


class B09PseudoTerminal(unittest.TestCase):
    def open_bus(self, timeout, write_timeout):
        master, slave = pty.openpty()
        self.addCleanup(os.close, master)
        self.addCleanup(os.close, slave)
        bus = serial.Serial(os.ttyname(slave), baudrate=6000000,
                            timeout=timeout, write_timeout=write_timeout, exclusive=True)
        self.addCleanup(bus.close)
        return master, bus

    def test_real_missing_reply_five_runs_per_timeout(self):
        for original in (None, 0, .5):
            elapsed = []
            for repeat in range(5):
                master, bus = self.open_bus(original, original)
                start = time.monotonic()
                with self.subTest(timeout=original, repeat=repeat):
                    with self.assertRaisesRegex(RuntimeError, "deadline"):
                        s.exchange(bus, s.command(0), 0, .02)
                    actual = time.monotonic() - start
                    elapsed.append(actual)
                    self.assertGreaterEqual(actual, .018)
                    self.assertLess(actual, .07)
                    self.assertEqual((bus.timeout, bus.write_timeout), (original, original))
                    self.assertEqual(os.read(master, 20), s.command(0))
            print(f"PTY missing reply timeout={original}: elapsed seconds {elapsed}", flush=True)

    def test_real_fragmented_reply_after_exact_request(self):
        master, bus = self.open_bus(None, None)
        errors = []
        requests = []
        def reply():
            try:
                request = b""
                until = time.monotonic() + .2
                while len(request) < 20 and time.monotonic() < until:
                    ready, _, _ = select.select([master], [], [], max(0, until - time.monotonic()))
                    if ready:
                        request += os.read(master, 20 - len(request))
                requests.append(request)
                for byte in CAPTURED:
                    os.write(master, bytes([byte]))
                    time.sleep(.0002)
            except BaseException as error:
                errors.append(error)
        thread = threading.Thread(target=reply)
        thread.start()
        try:
            self.assertEqual(s.exchange(bus, s.command(0), 0, .1)["raw"], CAPTURED.hex())
        finally:
            thread.join(.5)
        self.assertFalse(thread.is_alive())
        self.assertEqual(errors, [])
        self.assertEqual(requests, [s.command(0)])
        self.assertEqual((bus.timeout, bus.write_timeout), (None, None))

    def test_real_saturated_write_has_positive_deadline(self):
        for original in (None, 0, .5):
            _, bus = self.open_bus(.5, original)
            start = time.monotonic()
            with self.subTest(write_timeout=original), self.assertRaises((serial.SerialTimeoutException, RuntimeError)):
                s.exchange(bus, b"x" * 1000000, 0, .02)
            elapsed = time.monotonic() - start
            self.assertLess(elapsed, .07)
            self.assertEqual((bus.timeout, bus.write_timeout), (.5, original))
            print(f"PTY saturated write timeout={original}: elapsed seconds {elapsed}", flush=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)

```

### docs/joint-api.md
```
# Joint mapping

The bench GUI and CLI use actuator output units. The mapping API converts external joint units before packet encoding. It does not open a serial port.

```python
from joint_mapping import JointMap, JointTarget, OutputSample

mapping = JointMap(reduction=3, direction=-1, zero_output_rad=0.25)
output = mapping.to_output(JointTarget(-0.5, 2, 12, 36, 9))
joint = mapping.from_output(OutputSample(output.q_rad, output.rpm, output.tau_nm))
```

This example produces an output position of 1.75 rad, speed of about -57.2958 rpm, torque of -4 Nm, Kp of 4 and Kd of 1. Reverse conversion recovers the original position, speed and torque. The resulting torque exceeds the bench encoder's ±3.5 Nm policy, so encoding it rejects the command. Mapping never clips a value to make it pass.

`JointTarget` uses rad, rad/s and Nm. `OutputTarget` uses rad, rpm and Nm. The offset is in actuator output radians. The internal motor reduction stays inside the codec. Ideal gain conversion assumes compatible stiffness and damping definitions. Friction, backlash, efficiency and physical calibration remain unmeasured.

Run a single offline acceptance check from the repository root:

```sh
.venv/bin/python -B scripts/check_milestone.py B11
```

The command prints the path to its receipt and raw logs under `evidence/runs`. The test checks ratios 1, 3 and 6 in both directions, nonzero offsets, independent numeric anchors and invalid values.

## Passive port inspection

```python
from im6014_port import PortConfig, inspect_port
from spin_5rpm import PORT

report = inspect_port(PortConfig(PORT, 6_000_000), ports=())
```

`ports=()` makes this example use only the configured by-id basename. The report names its evidence source and does not establish communication with the motor. Normal inspection can also read passive OS enumeration metadata. Known wrong serial numbers or interfaces reject with expected and observed values. Unknown metadata stays explicitly unverified.

For an alternate adapter route, set both `expected_serial=None` and `expected_channel=None`. This removes the FTDI identity assertion. It does not bypass later device ownership checks or establish motor communication. The bench GUI and CLI default to the recorded FTDI serial and interface 3.

## Diagnostic capture

`PacketCapture` holds at most 256 records by default. Each record contains capped packet prefixes, allowlisted decoded fields, a fixed outcome code, and explicit source and connection metadata. Exported snapshots own their lists and dictionaries. Exception messages, environment values and arbitrary serial-object fields are excluded. An unavailable or regressing capture end clock exports `ended_s=None` and preserves the exchange result or original error. An invalid start clock rejects before exchange.

The GUI includes its ring in the existing JSON snapshot. The CLI enables it in `main`; direct `run(bus, args, log)` callers retain the original uncaptured behavior. Tests opt in with `fixture` provenance. A `physical` label records the caller's declaration and does not independently prove device identity.

## Cooperating bus ownership

Both real bench open sites use `open_managed_port(PortConfig(...), serial_factory=...)`. It checks passive identity before device acquisition and construction. A successful result owns `bus`; call `close()` and inspect its boolean result. `False` means ownership remains held because closure was not confirmed. Retry cleanup before reconnecting. A context manager raises `PortCloseError` on an otherwise normal exit with unconfirmed close; its `managed_port` remains available for cleanup.

This API opens hardware when given a motor path. Its acceptance tests use Linux PTYs exclusively. The device lease coordinates these workbench clients; it cannot exclude a raw client that ignores the lock.

When passive identity metadata is incomplete, the default route reports it as unverified and still permits device acquisition; known mismatches reject. The serial factory must expose the pyserial `is_open` status for confirmed cleanup. A missing status retains the lease. Neither passive inspection nor opening establishes CRC-valid motor communication.

## Controller lifecycle and freshness

`JointCore` owns a fixed ordered set of unique `JointSpec` names and motor IDs. Its states and immutable `Snapshot` are transport-free; `connected(SourceIdentity(...))` records a declaration and never opens hardware. `Decision` evaluates to its `accepted` value.

Connect, check, and arm are distinct steps. `receive(id, JointSample(...), MotorHealth(...))` stamps each valid observation with the core's monotonic clock. `checked()` needs fresh healthy Stop-mode feedback from every active joint. `arm()` requires fresh healthy Stop-mode feedback. The configurable maximum age defaults to 0.5 seconds; this software policy is not a measured loop-rate guarantee. Snapshot `feedback_ages_s` preserves joint order and uses `None` before receipt. Timestamp zero is valid. Unknown IDs and invalid records do not refresh timestamps.

Call `tick()` to fault READY, ARMED, or MOVING when feedback ages out. Stop, disconnect/reconnect, and healthy packets do not clear a fault latch. Recovery requires `begin_check(acknowledge_fault=True)` followed by fresh healthy Stop feedback and successful `checked()`. The check clears observations first. Target dispatch, attributed fault records and command ordering are the next milestones.

## Attributed faults

`Snapshot.faults` holds immutable `JointFault` records in configured joint order. `affected_joints` derives their names. Error and warning masks accumulate by bitwise OR, and watchdog timeout and stale flags latch. Communication codes are fixed `CommunicationFailure` enum values; they do not imply an actuator watchdog timeout. Current healthy feedback clears the current communication observation while the cause remains latched. Stop and reconnect retain causes. Only an explicitly acknowledged, complete, fresh, healthy Stop check clears them. Each core stores at most one record per configured joint and a unique union of at most three fixed communication codes per record. `communication_error` is the most recent cause; `communication_errors` is a first-occurrence union, not a chronological event history. A supplied most-recent code must belong to that union.

When opening fails and cleanup cannot confirm closure, `open_managed_port` raises `PortCloseError` with `managed_port` for retry and the original error as `__cause__`. Context exit uses the same exception when closure fails, retaining any body exception as its cause. If cleanup succeeds, the original exception propagates normally.

## Latest target and command expiry

`Target(sequence, joints, window)` contains an immutable complete tuple of `JointTarget` values in configured order and a required station-issued `IntentWindow(id, created_at_s, expires_at_s)`. `JointCore.issue_window(valid_for_s)` issues the latest offered window with a monotonic ID and bounded duration (`max_window_s`, default 1.0s). `submit_target` first expires or faults an existing goal as needed, then validates the incoming window against the latest offered window, checks expiry (exact equality with expiry is expired), checks mapped output codec representability, and enforces monotonic command sequence ordering before admitting the goal. A rejected replacement keeps an existing goal only while that goal remains valid.

`consume_target` is deleted in favor of explicit refresh lifecycle: `prepare_refresh()`, `claim_dispatch(plan_id, index)`, and `dispatch_result(plan_id, index, result)`. An admitted goal is refreshed repeatedly until its window expires. Preparing a plan proposes a refresh vector without dispatching. `claim_dispatch` verifies freshness, health, goal expiry, and ordered joint index immediately before each write. Only one claim may await an outcome; the core blocks another joint claim and plan preparation until it arrives. Stop, expiry, target replacement, or fault can invalidate the plan without discarding that in-flight receipt. `exchange` reports the returned or raised write result once immediately after the driver outcome; successful returns are deadline-checked before feedback. If the final deadline check expires after the pre-write hook grants a claim but before `bus.write`, it reports `FAILED` once even though zero bytes were written, resolving the claim and faulting the attributed joint. `Snapshot.dispatch_attempts` holds the latest outcome per joint and distinguishes complete, partial, and failed writes. `dispatch_result` commits a dispatched record only for a complete write. A dispatched record's `dispatched_at_s` is the valid claim/write start time, not a fabricated completion timestamp. Partial and failed writes fault the affected joint while preserving its prior complete record. A late receipt for an invalidated plan is recorded but cannot restore motion. When an admitted goal expires, housekeeping withdraws it, invalidates pending plans, and disarms the core to `STOPPED` (latched fault preserved), requiring a new check and arm cycle. Sequence watermarks survive consumption, stop, fault, and disconnect.

### Offline controller example

```python
from joint_contract import IntentWindow, JointSpec, MotorHealth, SourceIdentity, State, Target, WriteResult
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget

core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25)),), clock=lambda: 0.0)
assert core.begin_connect()
assert core.connected(SourceIdentity("fixture", "example", 1))
assert core.begin_check()
assert core.receive(0, JointSample(0, 0, 0), MotorHealth(0, 0, 0, False))
assert core.checked()
assert core.arm()
window = core.issue_window(0.5)
target = Target(6, (JointTarget(.1, 1, -6, 18, 4.5),), window=window)
assert core.submit_target(target)
plan = core.prepare_refresh()
assert plan is not None
assert core.claim_dispatch(plan.plan_id, 0)
assert core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
assert core.snapshot().state is State.MOVING
assert core.snapshot().dispatched_records[0].sequence == 6
assert core.stop()
assert core.snapshot().last_sequence == 6
```

This example performs no serial operations. A station adapter must validate its own physical setup and own packet transmission when later milestones add one.

## Core and ownership limits

The injected core clock must be finite and monotonic. Invalid or regressing time rejects operations that need a fresh gate; snapshots also require that clock contract. If a complete write receipt arrives after its end clock becomes invalid, the core preserves that known write and claim timestamp, then latches a driver failure and withdraws motion until acknowledged recovery. The default clock is `time.monotonic`. Sequence `2**64 - 1` exhausts that core's stream. Start a new core for a new stream; reconnecting or acknowledging a fault never resets ordering. Owner generations remain C08.

The fixed per-user lock namespace under `/tmp` coordinates cooperating processes. A hostile local user can pre-create the name and deny access; validation fails closed. An administrator must remove a foreign-owned obstruction. Lockfiles persist to preserve flock inode identity, including after device-number reuse. Do not delete them while clients may be running. No automatic pruning or hostile-local-user availability guarantee is supplied.

```

### scripts/check_milestone.py
```
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


CHECKS = {
    'B11': 'test_joint_mapping',
    'B12': 'test_numerical_inputs',
    'B13': 'test_port_config',
    'B14': 'test_diagnostic_capture',
    'C01': 'test_bus_owner',
    'C02': 'test_controller.ControllerStateTests',
    'C03': 'test_controller.FeedbackAgeTests',
    'C04': 'test_controller.JointFaultTests',
    'C05': 'test_controller_targets.LatestTargetTests',
    'C06': 'test_controller_targets.CommandSequenceTests',
    'C07': 'test_controller_expiry',
}


def fingerprint(repo):
    paths = sorted(repo.glob('*.py')) + [
        repo / 'scripts/check_offline_baseline.sh',
        repo / 'scripts/check_milestone.py', repo / 'USER_MANUAL.md',
    ]
    return {str(p.relative_to(repo)): {
        'bytes': p.stat().st_size,
        'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
    } for p in paths}


def main():
    repo = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description='Run one audited offline milestone check.')
    parser.add_argument('unit', choices=CHECKS)
    parser.add_argument('--python', type=Path, default=repo / '.venv/bin/python')
    parser.add_argument('--evidence-root', type=Path, default=repo / 'evidence/runs')
    args = parser.parse_args()
    root = args.evidence_root.resolve()
    if root == repo or root == Path('/') or repo in root.parents and repo / 'evidence/runs' != root and repo / 'evidence/runs' not in root.parents:
        parser.error('Evidence inside the repository must be under evidence/runs')
    out = root / (args.unit + '-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    out.mkdir(parents=True, exist_ok=False)
    before = fingerprint(repo)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    command = [str(args.python.absolute()), '-B', '-m', 'unittest', '-v', CHECKS[args.unit]]
    result = subprocess.run(command, cwd=repo, capture_output=True, text=True,
                            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen'))
    (out / 'stdout.log').write_text(result.stdout)
    (out / 'stderr.log').write_text(result.stderr)
    unchanged = before == fingerprint(repo)
    (out / 'receipt.json').write_text(json.dumps({
        'unit': args.unit, 'command': command, 'cwd': str(repo), 'baseHead': head,
        'sourceFiles': before, 'sourceUnchanged': unchanged,
        'exitCode': result.returncode, 'recordedAt': datetime.now(timezone.utc).isoformat(),
        'physicalIO': 'none; parent reviewed fixtures or pseudo-terminals before execution',
    }, indent=2) + '\n')
    print(result.stdout, end='')
    print(result.stderr, end='')
    print('Receipt:', out / 'receipt.json')
    return result.returncode if unchanged else 2


if __name__ == '__main__':
    raise SystemExit(main())

```

### scripts/check_offline_baseline.sh
```
#!/usr/bin/env bash
set -u
set -o pipefail

if (( $# > 2 )); then
    printf 'Usage: %s [absolute-python] [evidence-root]\n' "$0" >&2
    exit 2
fi

caller_dir="$(pwd -P)"
script_path="$(realpath -e -- "$0")" || exit 2
repo_dir="$(cd -- "$(dirname -- "$script_path")/.." && pwd -P)"
python_arg="${1:-$repo_dir/.venv/bin/python}"
evidence_arg="${2:-$repo_dir/evidence/runs}"
case "$python_arg$evidence_arg" in
    *$'\n'*|*$'\t'*) printf 'Paths cannot contain tabs or newlines.\n' >&2; exit 2 ;;
esac

case "$python_arg" in
    /*) ;;
    *) python_arg="$caller_dir/$python_arg" ;;
esac
python_dir_arg="$(dirname -- "$python_arg")"
python_name="$(basename -- "$python_arg")"
python_dir="$(cd -- "$python_dir_arg" 2>/dev/null && pwd -P)" || {
    printf 'Python interpreter does not exist: %s\n' "$python_arg" >&2
    exit 2
}
python_path="$python_dir/$python_name"
if [[ ! -f "$python_path" || ! -x "$python_path" ]]; then
    printf 'Python interpreter must be an executable file: %s\n' "$python_path" >&2
    exit 2
fi

case "$evidence_arg" in
    /*) ;;
    *) evidence_arg="$caller_dir/$evidence_arg" ;;
esac
mkdir -p -- "$evidence_arg" || {
    printf 'Could not create evidence root: %s\n' "$evidence_arg" >&2
    exit 2
}
evidence_root="$(realpath -e -- "$evidence_arg")" || exit 2
if [[ "$evidence_root" == / || "$evidence_root" == "$repo_dir" ]]; then
    printf 'Refusing unsafe evidence root: %s\n' "$evidence_root" >&2
    exit 2
fi
case "$evidence_root/" in
    "$repo_dir/"*)
        case "$evidence_root/" in
            "$repo_dir/evidence/runs/"|"$repo_dir/evidence/runs/"*) ;;
            *) printf 'Evidence inside the repository must be under evidence/runs: %s\n' "$evidence_root" >&2; exit 2 ;;
        esac
        ;;
esac

run_dir="$(mktemp -d -- "$evidence_root/run-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXXXX")" || exit 2
scratch="$(mktemp -d -- "$run_dir/.source-XXXXXXXX")" || exit 2
cleanup() {
    rm -rf -- "$scratch"
}
trap cleanup EXIT

printf 'check\texit_code\n' > "$run_dir/checks.tsv"
failed=0
record_check() {
    local name="$1"
    local code="$2"
    printf '%s\t%s\n' "$name" "$code" >> "$run_dir/checks.tsv"
    if (( code != 0 )); then failed=1; fi
}
run_logged() {
    local name="$1"
    shift
    "$@" > "$run_dir/$name.log" 2>&1
    local code=$?
    record_check "$name" "$code"
    return 0
}

files=(motor_dashboard.py motor_session.py spin_5rpm.py im6014_codec.py im6014_serial.py fake_serial.py test_spin_5rpm.py test_dashboard.py test_startup.py test_startup_verifier.py test_protocol.py test_serial_deadline.py evidence/boundary/vendor-crc-vectors.json USER_MANUAL.md joint_mapping.py test_joint_mapping.py test_numerical_inputs.py im6014_port.py test_port_config.py test_diagnostic_capture.py test_bus_owner.py joint_contract.py joint_controller.py test_controller.py test_controller_targets.py test_controller_expiry.py)
for name in "${files[@]}"; do
    mkdir -p -- "$scratch/$(dirname -- "$name")" || exit 2
    if ! cp -- "$repo_dir/$name" "$scratch/$name" || ! cmp -s -- "$repo_dir/$name" "$scratch/$name"; then
        printf 'Could not create a byte-identical baseline copy: %s\n' "$name" >&2
        exit 2
    fi
done

if "$python_path" -c 'import sys; print(sys.version)' > "$run_dir/python-version.txt" 2>&1; then
    record_check interpreter 0
else
    code=$?
    record_check interpreter "$code"
fi

cd -- "$scratch" || exit 2
run_logged packet-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" test_spin_5rpm.py
run_logged protocol-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_protocol
run_logged serial-deadline-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_serial_deadline
run_logged milestone-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_joint_mapping test_numerical_inputs test_port_config test_diagnostic_capture test_bus_owner test_controller test_controller_targets test_controller_expiry
run_logged dashboard-tests env QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1 "$python_path" test_dashboard.py
for name in dashboard_preview.png dashboard_dark_preview.png dashboard_test_results.json; do
    if [[ -f "$scratch/$name" ]]; then
        if ! cp -- "$scratch/$name" "$run_dir/$name"; then record_check "copy-$name" 1; fi
    fi
done

run_logged startup-verifier-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" test_startup_verifier.py
run_logged startup-real env QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1 \
    "$python_path" test_startup.py --source real --evidence-dir "$run_dir/startup-real"
run_logged startup-demo env QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1 \
    "$python_path" test_startup.py --source demo --evidence-dir "$run_dir/startup-demo"

printf 'Evidence: %s\n' "$run_dir"
cat "$run_dir/checks.tsv"
exit "$failed"

```

### test_startup.py
```
"""Verify the real dashboard entry point starts and closes without motor I/O."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import traceback


def _need(condition, message):
    if not condition:
        raise AssertionError(message)


def validate_report(report):
    _need(report.get("system_exit") is True, "application main did not exit through SystemExit")
    _need(not report.get("callback_errors"), "event-loop callback or close raised an exception")
    _need(report.get("exit_code") == 0, f"application exit code was {report.get('exit_code')!r}")
    _need(not report.get("main_exception"), "application main raised an exception")
    _need(report.get("argv_restored") is True, "sys.argv was not restored")
    _need(report.get("window_captured") is True, "Dashboard constructor did not produce a window")
    _need(report.get("callback_ran") is True, "event-loop verification callback did not run")
    _need(report.get("callback_completed") is True, "event-loop verification callback did not complete")

    source = report.get("source")
    _need(source in ("real", "demo"), f"invalid source mode: {source!r}")
    pre, post = report.get("pre") or {}, report.get("post") or {}
    expected_demo = source == "demo"
    for name, observation in (("pre-close", pre), ("post-close", post)):
        _need(observation.get("bus_is_none") is True, f"{name}: session bus was not None")
        _need(observation.get("state") == "Disconnected", f"{name}: dashboard was not Disconnected")
        _need(observation.get("connected") is False, f"{name}: session reported connected")
        _need(observation.get("armed") is False, f"{name}: session was armed")
        _need(observation.get("tx") == 0 and observation.get("rx") == 0,
              f"{name}: packet counters were not zero")
        _need(observation.get("source_selected_demo") is expected_demo,
              f"{name}: selected source did not match {source}")
    _need(pre.get("window_visible") is True, "dashboard window was not visible")
    _need(pre.get("timer_active") is True, "dashboard UI timer was not active")
    _need(pre.get("worker_alive") is True, "serial-owner worker was not alive before close")
    _need(pre.get("event_loop_tick_seen") is True, "normal UI timer did not update in the event loop")
    _need(post.get("window_visible") is False, "dashboard window remained visible after close")
    _need(post.get("timer_active") is False, "dashboard UI timer remained active after close")
    _need(post.get("worker_alive") is False, "serial-owner worker remained alive after close")
    _need(report.get("close_returned") is True, "normal window close did not succeed")

    counts = report.get("sentinel_counts") or {}
    for name in ("serial_open", "demo_open", "exchange"):
        _need(counts.get(name) == 0, f"forbidden {name} attempt count was {counts.get(name)!r}")

    screenshot = report.get("screenshot") or {}
    _need(screenshot.get("saved") is True, "rendered dashboard screenshot was not saved")
    _need(screenshot.get("width", 0) > 0 and screenshot.get("height", 0) > 0,
          "rendered dashboard screenshot has invalid dimensions")
    _need(screenshot.get("bytes", 0) > 0, "rendered dashboard screenshot is empty")
    digest = screenshot.get("sha256", "")
    _need(len(digest) == 64 and all(c in "0123456789abcdef" for c in digest),
          "rendered dashboard screenshot has an invalid SHA-256")


class ForbiddenMotorIO:
    def __init__(self):
        self.counts = {"serial_open": 0, "demo_open": 0, "exchange": 0}

    def reject(self, kind, *args, **kwargs):
        self.counts[kind] += 1
        raise RuntimeError(f"offline startup verifier blocked {kind}")

    def serial(self, *args, **kwargs):
        return self.reject("serial_open", *args, **kwargs)

    def demo(self, *args, **kwargs):
        return self.reject("demo_open", *args, **kwargs)

    def exchange(self, *args, **kwargs):
        return self.reject("exchange", *args, **kwargs)


def _observe(window, event_loop_tick_seen=False):
    snap = window.session.snapshot()
    return {
        "bus_is_none": window.session.bus is None,
        "state": snap["state"],
        "connected": snap["connected"],
        "armed": snap["armed"],
        "tx": snap["tx"],
        "rx": snap["rx"],
        "source_selected_demo": window.source.currentIndex() == 1,
        "window_visible": window.isVisible(),
        "timer_active": window.timer.isActive(),
        "worker_alive": window.session.thread.is_alive(),
        "event_loop_tick_seen": bool(event_loop_tick_seen),
    }


def _cleanup_after_main(window, state):
    if window is None or not hasattr(window, "session") or not window.session.thread.is_alive():
        return
    try:
        if not state["callback_completed"] and hasattr(window, "timer"):
            state["close_returned"] = bool(window.close())
            state["post"] = _observe(window, False)
        else:
            window.session.close()
    except BaseException:
        state["callback_errors"].append("post-main cleanup failed\n" + traceback.format_exc())


def _fingerprint(root):
    names = ("motor_dashboard.py", "motor_session.py", "spin_5rpm.py", "im6014_codec.py", "im6014_serial.py", "fake_serial.py", "USER_MANUAL.md",
             "test_spin_5rpm.py", "test_dashboard.py", "test_startup.py", "test_startup_verifier.py", "test_protocol.py", "test_serial_deadline.py", "evidence/boundary/vendor-crc-vectors.json", "joint_mapping.py", "test_joint_mapping.py", "test_numerical_inputs.py", "im6014_port.py", "test_port_config.py", "test_diagnostic_capture.py", "test_bus_owner.py", "joint_contract.py", "joint_controller.py", "test_controller.py", "test_controller_targets.py", "test_controller_expiry.py")
    files = {}
    for name in names:
        path = root / name
        data = path.read_bytes()
        files[name] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    return files


def run(source, evidence_dir):
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    evidence_dir = Path(evidence_dir).expanduser().resolve()
    evidence_dir.mkdir(parents=True, exist_ok=False)
    screenshot_path = evidence_dir / "dashboard.png"
    result_path = evidence_dir / "startup-result.json"
    root = Path(__file__).resolve().parent
    original_argv = sys.argv
    original_argv_values = list(original_argv)
    main_argv = [str(root / "motor_dashboard.py")]
    if source == "demo":
        main_argv.append("--demo")

    io = ForbiddenMotorIO()
    state = {
        "app": None,
        "window": None,
        "initial_ping": None,
        "callback_ran": False,
        "callback_completed": False,
        "callback_errors": [],
        "pre": None,
        "post": None,
        "close_returned": False,
        "screenshot": None,
    }

    try:
        from PySide6.QtCore import QTimer
        from PySide6.QtWidgets import QApplication
        import motor_dashboard as dashboard
        import motor_session

        original_dashboard = dashboard.Dashboard
        original_application = dashboard.QApplication

        def add_error(label):
            state["callback_errors"].append(label + "\n" + traceback.format_exc())

        def close_after_inspection():
            if state["callback_ran"]:
                return
            state["callback_ran"] = True
            window = state["window"]
            app = state["app"]
            try:
                if window is None:
                    raise AssertionError("Dashboard constructor did not produce a window")
                app.processEvents()
                event_tick = (state["initial_ping"] is not None and
                              window.session.last_ui > state["initial_ping"])
                state["pre"] = _observe(window, event_tick)
                pixmap = window.grab()
                _need(not pixmap.isNull(), "dashboard grab returned a null pixmap")
                _need(pixmap.width() > 0 and pixmap.height() > 0, "dashboard grab has invalid dimensions")
                _need(pixmap.save(str(screenshot_path), "PNG"), "could not save dashboard PNG")
                image = screenshot_path.read_bytes()
                state["screenshot"] = {
                    "path": str(screenshot_path),
                    "saved": screenshot_path.is_file(),
                    "width": pixmap.width(),
                    "height": pixmap.height(),
                    "bytes": len(image),
                    "sha256": hashlib.sha256(image).hexdigest(),
                }
            except BaseException:
                add_error("startup observation failed")
            finally:
                try:
                    app.setQuitOnLastWindowClosed(False)
                    if window is not None:
                        state["close_returned"] = bool(window.close())
                        state["post"] = _observe(window, False)
                except BaseException:
                    add_error("normal window close failed")
                state["callback_completed"] = True
                app.exit(1 if state["callback_errors"] else 0)

        def watchdog():
            if state["callback_completed"]:
                return
            state["callback_errors"].append("startup event-loop watchdog expired")
            app = state["app"]
            window = state["window"]
            try:
                if window is not None:
                    app.setQuitOnLastWindowClosed(False)
                    state["close_returned"] = bool(window.close())
                    state["post"] = _observe(window, False)
            except BaseException:
                add_error("watchdog cleanup failed")
            app.exit(1)

        class CapturingDashboard(original_dashboard):
            def __init__(self, demo=False):
                state["window"] = self
                super().__init__(demo)
                state["initial_ping"] = self.session.last_ui
                QTimer.singleShot(350, close_after_inspection)

        def capture_application(*args, **kwargs):
            app = original_application(*args, **kwargs)
            state["app"] = app
            app.setQuitOnLastWindowClosed(False)
            QTimer.singleShot(15000, watchdog)
            return app

        from unittest.mock import patch
        with patch.object(dashboard, "Dashboard", CapturingDashboard), \
             patch.object(dashboard, "QApplication", capture_application), \
             patch.object(dashboard.list_ports, "comports", return_value=[]), \
             patch.object(motor_session.serial, "Serial", io.serial), \
             patch.object(motor_session, "DemoSerial", io.demo), \
             patch.object(motor_session, "exchange", io.exchange):
            sys.argv = main_argv
            system_exit = False
            exit_code = None
            main_exception = None
            try:
                dashboard.main()
            except SystemExit as error:
                system_exit = True
                exit_code = 0 if error.code is None else error.code
            except BaseException:
                main_exception = traceback.format_exc()
            finally:
                sys.argv = original_argv
                argv_restored = sys.argv is original_argv and sys.argv == original_argv_values

            _cleanup_after_main(state["window"], state)

        report = {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "source": source,
            "argv": main_argv,
            "python": {"executable": sys.executable, "version": sys.version},
            "packages": {
                "PySide6": importlib.metadata.version("PySide6"),
                "pyserial": importlib.metadata.version("pyserial"),
            },
            "source_fingerprint": _fingerprint(root),
            "system_exit": system_exit,
            "exit_code": exit_code,
            "main_exception": main_exception,
            "argv_restored": argv_restored,
            "window_captured": state["window"] is not None,
            "callback_ran": state["callback_ran"],
            "callback_completed": state["callback_completed"],
            "callback_errors": state["callback_errors"],
            "pre": state["pre"],
            "post": state["post"],
            "close_returned": state["close_returned"],
            "sentinel_counts": dict(io.counts),
            "screenshot": state["screenshot"],
        }
        validate_report(report)
        with result_path.open("x", encoding="utf-8") as result_file:
            json.dump(report, result_file, indent=2)
            result_file.write("\n")
        print(f"PASS: {source} dashboard startup and shutdown; evidence: {evidence_dir}", flush=True)
        return 0
    except BaseException as error:
        print(f"FAIL: {source} dashboard startup verification: {error}", file=sys.stderr, flush=True)
        if "report" in locals():
            print(json.dumps(report, indent=2), file=sys.stderr, flush=True)
        else:
            traceback.print_exc()
        return 1
    finally:
        sys.argv = original_argv


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", choices=("real", "demo"), required=True)
    parser.add_argument("--evidence-dir", required=True)
    args = parser.parse_args()
    return run(args.source, args.evidence_dir)


if __name__ == "__main__":
    raise SystemExit(main())

```


## Review Rubric

# Review Rubric

Review through whichever lenses are relevant. Not every lens applies to every change. Use judgment.

## Correctness

Does the code actually do what the intent says it should?

- Edge cases: empty inputs, nil/undefined, boundary values, concurrent access
- Error handling: are errors caught, propagated, or silently swallowed?
- Off-by-one, type coercion, integer overflow, string encoding
- State management: race conditions, stale closures, dangling references
- Does the happy path work? Does the sad path work?
- Idempotency: what happens if this operation runs twice, or if a previous run crashed halfway? If the answer is "it depends on what state was left behind," there's a missing reconciliation step.
- Concurrency: if multiple actors can touch the same mutable state (files, branches, shared data), is access serialized structurally (locks, sequential phases, exclusive ownership), or by conventions that won't hold?

When you find a potential bug, trace the execution path. Don't just flag "this could be nil". Show the call chain that makes it nil.

## Root Causes vs. Symptoms

Is the code fixing the actual problem or papering over a symptom?

Answering this often requires looking beyond the changed files. Read the surrounding code (callers, callees, type definitions, sibling modules) and understand the architecture the change lives in. Use the tools available to you (Read, Grep, Glob) to explore. Follow the call chain. Read the types. Understand why the code exists before judging whether the change addresses the right layer.

- Guard clauses that mask a deeper invariant violation
- Retry logic that hides a broken contract
- Type casts that silence a modeling error
- If you see a workaround, ask: why is the workaround needed? What would a proper fix look like?
- A fix in module A that should really be a fix in module B's contract
- Instructions where structure would be better: if the fix is a comment saying "don't do X" or a convention someone has to remember, ask whether it could instead be a type constraint, a lint rule, or a runtime check that makes the wrong thing impossible

## Structural Integrity

Does the code fit well into the system it's part of?

- Boundary discipline: is validation at system boundaries, or scattered through business logic? Validate data once where it enters the system, then trust it internally.
- Abstraction level: is the code mixing high-level orchestration with low-level detail?
- Coupling: does this change introduce dependencies that will make future changes harder?
- Data model fit: do the data structures match the actual access patterns? The right structure makes downstream code obvious. The wrong one fights you at every turn.
- Bolted-on vs. integrated: was the change patched onto the existing design, or does it read as if the design always accounted for it? If the new requirement had been known from the start, would the code look like this?
- Legacy dual-paths: does the change introduce a new API while keeping the old one alive? If there are no external consumers, migrate callers and delete the old path in the same wave. Don't leave compatibility layers that will become permanent.

Don't penalize simple code for lacking abstraction. Premature abstraction is worse than duplication.

## Verification

Can you tell that this code works from reading it?

- Are there tests? Do they test behavior or implementation details?
- Are there assertions/invariants that would catch regressions?
- If this is a bug fix: is there a test for the bug?
- If this touches an integration boundary: is the full path tested?
- Check the real thing, not a proxy. If the code checks liveness via file mtime or cached state instead of reading the actual value, that's a verification gap.
- For delegated or async work: does the code verify actual output artifacts, or does it trust self-reports and summaries?

## Complexity Budget

Is the complexity justified by what the code accomplishes?

- Code that could be simpler without losing correctness or clarity
- Abstractions that serve only one call site
- Configuration or parameterization for cases that don't exist yet
- Dead code, unused imports, vestigial parameters
- Over-engineering: "just in case" code paths with no current callers
- Obsolete compatibility paths kept alive for transitional stability that's no longer needed. If the migration is done, delete the scaffolding
- Does the user experience justify the complexity? Every feature, control, and option should earn its place. Half-finished features are worse than missing ones.

Simpler is better unless simpler is wrong. Three lines of duplication beat a premature abstraction.

## Security

For each security finding, trace the input path through the code and show it.

- User input flowing to dangerous sinks (SQL, shell, eval, innerHTML) without sanitization
- Authentication/authorization gaps in new endpoints
- Secrets in code, logs, or error messages
- TOCTOU (time-of-check-time-of-use) in security-critical paths


## Code Quality Lens

# Code Quality Review

Each reviewer applies this code-quality lens in addition to the rubric. It is a strict standard focused on implementation quality, maintainability, abstraction quality, and codebase health.

Above all, be ambitious about code structure. Do not merely identify local cleanup. Actively search for "code judo" moves, restructurings that preserve behavior while making the implementation dramatically simpler, smaller, more direct, and more elegant.

## Core Prompt

Start from this baseline:

> Perform a deep code quality audit of the current branch's changes.
> Rethink how to structure / implement the changes to meaningfully improve code quality without impacting behavior.
> Work to improve abstractions, modularity, reduce Spaghetti code, improve succinctness and legibility.
> Be ambitious, if there is a clear path to improving the implementation that involves restructuring some of the codebase, go for it.
> Be extremely thorough and rigorous. Measure twice, cut once.

## Dimensions

Each dimension is stated once. Apply the ones that are relevant.

0. **Be ambitious about structural simplification.** Do not stop at "this could be a bit cleaner." Look for reframings that make whole branches, helpers, modes, conditionals, or layers disappear. Assume a "code judo" move is often available. It uses the existing architecture more effectively and makes the change dramatically simpler. If you can delete complexity rather than rearrange it, push hard for that.

1. **Do not let a PR push a file from under 1k lines to over 1k lines without a very strong reason.** Treat this as a strong smell. Prefer extracting helpers, subcomponents, or modules. If the diff crosses that threshold, ask whether the code should be decomposed first. Waive only for a compelling structural reason where the resulting file stays clearly organized.

2. **Do not allow spaghetti growth in existing code.** Be suspicious of new ad-hoc conditionals, scattered special cases, or one-off branches inserted into unrelated flows. Treat "weird if statements in random places" as a design problem, not a style nit. Prefer pushing the logic into a dedicated helper, state machine, or module instead of tangling an existing path.

3. **Bias toward cleaning the design, not just accepting working code.** If behavior can stay the same while the structure becomes meaningfully cleaner, push for the cleaner version. Prefer simplifications that remove moving pieces over refactors that spread the same complexity around.

4. **Prefer direct, boring, maintainable code over hacky or magical code.** Treat brittle, ad-hoc, or "magic" behavior as a problem. Be skeptical of generic mechanisms that hide simple data-shape assumptions. Flag thin abstractions, identity wrappers, or pass-through helpers that add indirection without buying clarity.

5. **Push on type and boundary cleanliness when it affects maintainability.** Question unnecessary optionality, `unknown`, `any`, or cast-heavy code when a clearer type boundary could exist. Prefer explicit typed models over loosely-shaped ad-hoc objects. If a branch leans on a silent fallback to paper over an unclear invariant, ask whether the boundary should be made explicit.

6. **Keep logic in the canonical layer and reuse existing helpers.** Call out feature logic leaking into shared paths or implementation details leaking through APIs. Prefer existing canonical utilities over bespoke one-offs. Push code toward the right package, service, or module instead of normalizing drift.

7. **Treat unnecessary sequential orchestration and non-atomic updates as design smells when the cleaner structure is obvious.** If independent work is serialized for no reason, ask whether it should run in parallel. If related updates can leave state half-applied, push for a more atomic structure. Do not over-index on micro-optimizations, but do flag avoidable orchestration complexity that makes the code more brittle.

## Output Expectations

Prioritize structural code-quality regressions and missed simplifications first, then spaghetti and branching complexity, then boundary, type, and file-size concerns, then smaller modularity and legibility issues.

## Approval Bar

Do not approve merely because behavior seems correct. Treat these as presumptive blockers unless the author can justify them: the PR keeps a lot of incidental complexity when a code-judo move would delete it. Pushes a file from below 1000 lines to above 1000 lines. Adds ad-hoc branching that tangles an existing flow. Scatters feature checks across shared code. Adds an unnecessary abstraction, wrapper, or cast-heavy contract, or duplicates an existing helper or puts logic in the wrong layer when there is a clear canonical home. If those conditions are not met, leave explicit, actionable feedback and push for a cleaner decomposition.

## Review Tone

Be direct, serious, and demanding about quality. Do not be rude, but do not soften major maintainability issues into mild suggestions. If the code is making the codebase messier, say so. If the implementation missed an obvious dramatic simplification, say that too. Do not be satisfied with "maybe rename this" when the real issue is structural.


## Instructions

Review the code through every lens in the rubric and the code-quality lens above that you find relevant. Do not force lenses that don't apply. A simple bug fix does not need paragraphs about architectural integrity.

For each finding, provide:

1. **Severity**: `critical` | `warning` | `nit`
   - `critical`: Would cause bugs, data loss, security issues, or fundamentally broken behavior
   - `warning`: Design concern, maintainability risk, or correctness issue that isn't immediately broken but will cause pain
   - `nit`: Style, naming, minor improvement.
2. **Finding**: What the problem is, in concrete terms. Reference specific lines/functions.
3. **Evidence**: Why you believe this is a problem. Show your reasoning. Don't just assert.
4. **Suggestion** (optional): What you'd do instead, if you have a concrete alternative. Skip this if you don't have a clear fix.

## What Makes a Good Finding

- It references specific code, not vague concerns ("this could be better")
- It explains WHY something is a problem, not just THAT it is
- It distinguishes between "this is broken" and "I would have done this differently"
- It considers the stated intent. A finding that ignores the context of what's being built is a bad finding

## What to Avoid

- Restating what the code does without identifying a problem
- Praising the code. You're an adversary, not a cheerleader. If you find nothing wrong, say "no findings" and stop.

## Output

Return your findings as a structured list. If you have zero findings, say so. An empty review is a valid outcome.

```
## Findings

### 1. [Severity] Short title
**Location**: file:line or function name
**Finding**: What's wrong
**Evidence**: Why this matters
**Suggestion**: (optional) What to do instead

### 2. [Severity] Short title
...
```
