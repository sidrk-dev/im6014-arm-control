Review only the complete supplied text. No tool requests, shell, filesystem, repository access, network, delegation or edits. All tools are forbidden for this text-only reviewer assignment. Return ONLY a JSON array of at most six concrete actionable findings, each with severity P0/P1/P2, repository path, one-based line, problem, reproducible evidence and narrow fix. Return [] when no supported finding. Do not output private reasoning, speculative design wishes or claim checks were run. Parent verifies every finding; supplied software checks establish no physical outcome.

Review C10 at exact head f7865c69b3b13ea1e94c27e2fc425cad32f845b7 over accepted C09 efb398f174e1f75e158590c0828dba8933b0891e. C10 requirements: required positive finite V and reference gap; exact two independent derivative and wire velocity sequences; canonical inward grid points and cached bytes; actual complete write commits only thatjoint at preparation sampletime, unknown/failed/partial no commit; measured healthy checked Stop anchor zero velocities never fabricated dispatch; h0 only same-goal exact unchanged cache/history; oversized gaps withdraw; nonzero unrepresentable motion explicitly Stop with only actually failing joint attribution, zero objective mayhold; prepare badclock revokes then rethrows, finalgate denies badclock. Ownership/expiry/later revoked/disconnected actual write receipts mustremain truthful. Parent checked16focused4correctedreproductions768exactspeed+768h0cache184milestone9baselinegroups18dashboard/fourcaptures/sourcehashes. No physical I/O. Future C11-C16 acceleration/lead/effort/thermal/station gates aren't implemented yet and must not be reported as C10 missingfeatures. Review source rather than treating green checks as proof.

## im6014_codec.py
1: import math
2: import struct
3: from collections.abc import Callable
4: 
5: RATIO = 38 / 3
6: RPM_MIN = -32768 / 64 / RATIO * 60
7: RPM_MAX = 32767 / 64 / RATIO * 60
8: POSITION_MIN = -2147483648 / 32768 / RATIO * math.tau
9: POSITION_MAX = 2147483647 / 32768 / RATIO * math.tau
10: RAW_POSITION_MIN = -2147483648
11: RAW_POSITION_MAX = 2147483647
12: RAW_RPM_MIN = -32768
13: RAW_RPM_MAX = 32767
14: 
15: 
16: def raw_to_position(raw_position):
17:     if type(raw_position) is not int or not RAW_POSITION_MIN <= raw_position <= RAW_POSITION_MAX:
18:         raise ValueError('raw_position must be a signed 32-bit integer')
19:     return raw_position / 32768 / RATIO * math.tau
20: 
21: 
22: def position_to_raw(position):
23:     position = _finite_control(position, 'Position')
24:     return _signed_raw(position / math.tau * RATIO * 32768,
25:                        RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')
26: 
27: 
28: def raw_to_rpm(raw_rpm):
29:     if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
30:         raise ValueError('raw_rpm must be a signed 16-bit integer')
31:     return raw_rpm / 64 / RATIO * 60
32: 
33: 
34: def rpm_to_raw(rpm):
35:     rpm = _finite_control(rpm, 'Speed')
36:     return _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')
37: 
38: 
39: def _motor_id(value, name='Individual ID'):
40:     if type(value) is not int or not 0 <= value <= 14:
41:         raise ValueError(f'{name} must be an integer from 0 to 14')
42:     return value
43: 
44: 
45: def _finite_control(value, name):
46:     if isinstance(value, bool) or not isinstance(value, (int, float)):
47:         raise ValueError(f'{name} must be a finite int or float')
48:     try:
49:         result = float(value)
50:     except (OverflowError, TypeError, ValueError) as error:
51:         raise ValueError(f'{name} must be finite') from error
52:     if not math.isfinite(result):
53:         raise ValueError(f'{name} must be finite')
54:     return result
55: 
56: 
57: def _signed_raw(value, minimum, maximum, name):
58:     raw = round(value)
59:     if not minimum <= raw <= maximum:
60:         raise ValueError(f'{name} cannot be represented by the motor protocol')
61:     return raw
62: 
63: 
64: def _torque_raw(value):
65:     return _signed_raw(value / RATIO * 2560, -32768, 32767, 'Feedforward torque')
66: 
67: 
68: def _kp_raw(value):
69:     return _signed_raw(value / RATIO ** 2 * 12800, -32768, 32767, 'Kp')
70: 
71: 
72: def _kd_raw(value):
73:     return _signed_raw(value / RATIO ** 2 * 51200, -32768, 32767, 'Kd')
74: 
75: 
76: def _raw_position(value):
77:     if type(value) is not int or not RAW_POSITION_MIN <= value <= RAW_POSITION_MAX:
78:         raise ValueError('raw_position must be a signed 32-bit integer')
79:     return value
80: 
81: 
82: def crc32(data):
83:     if len(data) % 4:
84:         raise ValueError('CRC input must contain complete four-byte words')
85:     crc = 0xFFFFFFFF
86:     for start in range(0, len(data), 4):
87:         for byte in data[start:start + 4][::-1]:
88:             crc ^= byte << 24
89:             for _ in range(8):
90:                 crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
91:     return crc
92: 
93: 
94: def command(motor_id, mode=0, rpm=0, kd=0, torque=0, watchdog=True, position=0, kp=0):
95:     position = _finite_control(position, 'Position')
96:     if not POSITION_MIN <= position <= POSITION_MAX:
97:         raise ValueError('Position cannot be encoded in the motor protocol')
98:     if mode == 0 and position != 0.0:
99:         raise ValueError('Stop must have zero targets; FOC requires watchdog')
100:     position_raw = _signed_raw(position / math.tau * RATIO * 32768,
101:                                RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')
102:     return command_with_raw_position(
103:         motor_id,
104:         position_raw,
105:         mode=mode,
106:         rpm=rpm,
107:         kd=kd,
108:         torque=torque,
109:         watchdog=watchdog,
110:         kp=kp,
111:     )
112: 
113: 
114: def command_with_raw_position(
115:     motor_id, raw_position, mode=0, rpm=0, kd=0, torque=0, watchdog=True, kp=0, raw_rpm=None
116: ):
117:     """Encode a command while preserving an already selected position grid code."""
118:     motor_id = _motor_id(motor_id)
119:     raw_position = _raw_position(raw_position)
120:     if type(mode) is not int or mode not in (0, 1):
121:         raise ValueError('Individual ID 0–14 and Stop/FOC modes only')
122:     if type(watchdog) is not bool:
123:         raise ValueError('Watchdog must be a bool')
124:     rpm, kd, torque, kp = (
125:         _finite_control(value, name) for value, name in
126:         ((rpm, 'Speed'), (kd, 'Kd'), (torque, 'Feedforward torque'),
127:          (kp, 'Kp'))
128:     )
129:     if not RPM_MIN <= rpm <= RPM_MAX:
130:         raise ValueError('Speed cannot be encoded in the motor protocol; this is not a rated-speed limit')
131:     if not 0 <= kd <= 6 or not 0 <= kp <= 30 or not -3.5 <= torque <= 3.5:
132:         raise ValueError('Bench limits: Kd 0–6, Kp 0–30, feedforward torque ±3.5 Nm')
133:     torque_raw = _torque_raw(torque)
134:     if raw_rpm is not None:
135:         if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
136:             raise ValueError('raw_rpm must be a signed 16-bit integer')
137:         rpm_raw = raw_rpm
138:     else:
139:         rpm_raw = _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')
140:     kp_raw = _kp_raw(kp)
141:     kd_raw = _kd_raw(kd)
142:     if mode == 0 and (rpm or kd or torque or raw_position or kp or (raw_rpm is not None and raw_rpm != 0)) or mode == 1 and not watchdog:
143:         raise ValueError('Stop must have zero targets; FOC requires watchdog')
144:     raw = b'\xfe\xee' + bytes([motor_id | mode << 4 | int(watchdog) << 7, 0])
145:     raw += struct.pack('<hhihh', torque_raw, rpm_raw, raw_position, kp_raw, kd_raw)
146:     return raw + struct.pack('<I', crc32(raw))
147: 
148: 
149: def project_position_raw(
150:     wanted_q,
151:     q_min,
152:     q_max,
153:     map_decoded_position: Callable[[float], float],
154:     direction: int,
155: ) -> int | None:
156:     """Choose the nearest raw position whose mapped decoded value is in bounds.
157: 
158:     ``map_decoded_position`` maps decoded actuator radians to the caller's
159:     position domain. ``direction`` declares whether that mapping increases or
160:     decreases as the raw position code increases. Bounds are closed.
161:     """
162:     wanted_q = _finite_control(wanted_q, 'Wanted position')
163:     q_min = _finite_control(q_min, 'Minimum position')
164:     q_max = _finite_control(q_max, 'Maximum position')
165:     if q_min > q_max:
166:         raise ValueError('Minimum position must not exceed maximum position')
167:     if not callable(map_decoded_position):
168:         raise ValueError('Position mapping must be callable')
169:     if type(direction) is not int or direction not in (-1, 1):
170:         raise ValueError('Position mapping direction must be -1 or 1')
171: 
172:     ordered_min = direction * (q_min if direction == 1 else q_max)
173:     ordered_max = direction * (q_max if direction == 1 else q_min)
174:     ordered_wanted = direction * wanted_q
175: 
176:     def mapped(raw_position):
177:         decoded = raw_to_position(raw_position)
178:         try:
179:             result = map_decoded_position(decoded)
180:         except (ArithmeticError, TypeError, ValueError) as error:
181:             raise ValueError('Position mapping is not representable') from error
182:         return direction * _finite_control(result, 'Mapped position')
183: 
184:     def first_raw_satisfying(bound, *, strict):
185:         left = RAW_POSITION_MIN
186:         right = RAW_POSITION_MAX + 1
187:         while left < right:
188:             mid = (left + right) // 2
189:             value = mapped(mid)
190:             matches = value > bound if strict else value >= bound
191:             if matches:
192:                 right = mid
193:             else:
194:                 left = mid + 1
195:         return left
196: 
197:     first = first_raw_satisfying(ordered_min, strict=False)
198:     last = first_raw_satisfying(ordered_max, strict=True) - 1
199:     if first > RAW_POSITION_MAX or last < first:
200:         return None
201: 
202:     candidate = first_raw_satisfying(ordered_wanted, strict=False)
203:     if candidate < first:
204:         return first
205:     if candidate > last:
206:         return last
207:     if candidate == first:
208:         return candidate
209: 
210:     current_delta = abs(mapped(candidate) - ordered_wanted)
211:     prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
212:     return candidate - 1 if prior_delta <= current_delta else candidate
213: 
214: 
215: def project_speed_raw(
216:     wanted_dq,
217:     v_min,
218:     v_max,
219:     map_decoded_speed: Callable[[float], float],
220:     direction: int,
221: ) -> int | None:
222:     """Choose the nearest raw speed whose mapped decoded value is in bounds.
223: 
224:     ``map_decoded_speed`` maps decoded actuator RPM to the caller's
225:     speed domain. ``direction`` declares whether that mapping increases or
226:     decreases as the raw speed code increases. Bounds are closed.
227:     """
228:     wanted_dq = _finite_control(wanted_dq, 'Wanted speed')
229:     v_min = _finite_control(v_min, 'Minimum speed')
230:     v_max = _finite_control(v_max, 'Maximum speed')
231:     if v_min > v_max:
232:         raise ValueError('Minimum speed must not exceed maximum speed')
233:     if not callable(map_decoded_speed):
234:         raise ValueError('Speed mapping must be callable')
235:     if type(direction) is not int or direction not in (-1, 1):
236:         raise ValueError('Speed mapping direction must be -1 or 1')
237: 
238:     ordered_min = direction * (v_min if direction == 1 else v_max)
239:     ordered_max = direction * (v_max if direction == 1 else v_min)
240:     ordered_wanted = direction * wanted_dq
241: 
242:     def mapped(raw_speed):
243:         decoded = raw_to_rpm(raw_speed)
244:         try:
245:             result = map_decoded_speed(decoded)
246:         except (ArithmeticError, TypeError, ValueError) as error:
247:             raise ValueError('Speed mapping is not representable') from error
248:         return direction * _finite_control(result, 'Mapped speed')
249: 
250:     def first_raw_satisfying(bound, *, strict):
251:         left = RAW_RPM_MIN
252:         right = RAW_RPM_MAX + 1
253:         while left < right:
254:             mid = (left + right) // 2
255:             value = mapped(mid)
256:             matches = value > bound if strict else value >= bound
257:             if matches:
258:                 right = mid
259:             else:
260:                 left = mid + 1
261:         return left
262: 
263:     first = first_raw_satisfying(ordered_min, strict=False)
264:     last = first_raw_satisfying(ordered_max, strict=True) - 1
265:     if first > RAW_RPM_MAX or last < first:
266:         return None
267: 
268:     candidate = first_raw_satisfying(ordered_wanted, strict=False)
269:     if candidate < first:
270:         return first
271:     if candidate > last:
272:         return last
273:     if candidate == first:
274:         return candidate
275: 
276:     current_delta = abs(mapped(candidate) - ordered_wanted)
277:     prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
278:     return candidate - 1 if prior_delta <= current_delta else candidate
279: 
280: 
281: def feedback(raw, motor_id):
282:     motor_id = _motor_id(motor_id, 'Expected motor ID')
283:     if not isinstance(raw, (bytes, bytearray, memoryview)):
284:         raise ValueError('Feedback frame must be a bytes-like buffer')
285:     try:
286:         raw = bytes(raw)
287:     except (TypeError, ValueError) as error:
288:         raise ValueError('Feedback frame must be a bytes-like buffer') from error
289:     if len(raw) != 26 or raw[:2] != b'\xfc\xee':
290:         raise RuntimeError('Invalid feedback length/header')
291:     if struct.unpack('<I', raw[22:])[0] != crc32(raw[2:22]):
292:         raise RuntimeError('Feedback CRC mismatch')
293:     m, td, tw, v, tq, sp, pos, err, flags, _, _ = struct.unpack('<BbBBhhiIHBB', raw[2:22])
294:     if m & 15 != motor_id or (m >> 4) & 7 not in (0, 1):
295:         raise RuntimeError('Feedback ID/mode mismatch')
296:     return dict(id=m & 15, mode=(m >> 4) & 7, timeout=m >> 7,
297:                 driver_c=td, winding_c=tw, voltage=v / 2,
298:                 torque_nm=tq / 2560 * RATIO, rpm=sp / 64 / RATIO * 60,
299:                 position_rad=pos / 32768 / RATIO * math.tau,
300:                 errors=err, warnings=(flags >> 13) & 7, raw=raw.hex())
301: 
302: 
303: def decode_command(raw):
304:     if not isinstance(raw, (bytes, bytearray, memoryview)):
305:         raise ValueError('Command frame must be a bytes-like buffer')
306:     try:
307:         raw = bytes(raw)
308:     except (TypeError, ValueError) as error:
309:         raise ValueError('Command frame must be a bytes-like buffer') from error
310:     if len(raw) != 20 or raw[:2] != b'\xfe\xee':
311:         raise ValueError('Invalid command length/header')
312:     if struct.unpack('<I', raw[16:])[0] != crc32(raw[:16]):
313:         raise ValueError('Command CRC mismatch')
314:     m = raw[2]
315:     motor_id = m & 0x0F
316:     mode = (m >> 4) & 0x07
317:     watchdog = bool(m & 0x80)
318:     if motor_id > 14 or mode not in (0, 1) or raw[3] != 0:
319:         raise ValueError('Invalid command ID, mode, or reserved byte')
320:     if mode == 1 and not watchdog:
321:         raise ValueError('FOC command requires watchdog')
322:     tq, sp, pos, kp, kd = struct.unpack('<hhihh', raw[4:16])
323:     if mode == 0 and (tq or sp or pos or kp or kd):
324:         raise ValueError('Stop command must have zero targets')
325:     decoded = dict(
326:         motor_id=motor_id,
327:         mode=mode,
328:         watchdog=watchdog,
329:         raw_torque=tq,
330:         raw_rpm=sp,
331:         raw_position=pos,
332:         raw_kp=kp,
333:         raw_kd=kd,
334:         torque_nm=tq / 2560 * RATIO,
335:         rpm=sp / 64 / RATIO * 60,
336:         position_rad=pos / 32768 / RATIO * math.tau,
337:         kp=kp * (RATIO ** 2) / 12800,
338:         kd=kd * (RATIO ** 2) / 51200,
339:         raw=raw.hex(),
340:     )
341:     if not _torque_raw(-3.5) <= tq <= _torque_raw(3.5):
342:         raise ValueError('Feedforward torque is outside the canonical command range')
343:     if not 0 <= kp <= _kp_raw(30.0) or not 0 <= kd <= _kd_raw(6.0):
344:         raise ValueError('Gain is outside the canonical command range')
345:     return decoded

## joint_mapping.py
1: from dataclasses import dataclass
2: import math
3: 
4: 
5: def _finite(value, name):
6:     if isinstance(value, bool) or not isinstance(value, (int, float)):
7:         raise ValueError(f"{name} must be a real int or float")
8:     try:
9:         result = float(value)
10:     except (OverflowError, TypeError, ValueError) as exc:
11:         raise ValueError(f"{name} must be finite") from exc
12:     if not math.isfinite(result):
13:         raise ValueError(f"{name} must be finite")
14:     return result
15: 
16: 
17: def _result(value, name, nonzero_inputs=None):
18:     if not math.isfinite(value):
19:         raise ValueError(f"{name} result must be finite")
20:     if nonzero_inputs and value == 0.0 and all(item != 0.0 for item in nonzero_inputs):
21:         raise ValueError(f"{name} result underflowed")
22:     return value
23: 
24: 
25: def _multiply(name, *values):
26:     result = 1.0
27:     for index, value in enumerate(values):
28:         result *= value
29:         _result(result, name, values[:index + 1])
30:     return result
31: 
32: 
33: def _divide(numerator, denominator, name):
34:     try:
35:         result = numerator / denominator
36:     except (OverflowError, ZeroDivisionError) as exc:
37:         raise ValueError(f"{name} result is not representable") from exc
38:     return _result(result, name, (numerator,))
39: 
40: 
41: def _add(left, right, name):
42:     return _result(left + right, name)
43: 
44: 
45: def _subtract(left, right, name):
46:     return _result(left - right, name)
47: 
48: 
49: @dataclass(frozen=True)
50: class JointMap:
51:     reduction: float
52:     direction: int
53:     zero_output_rad: float
54: 
55:     def __post_init__(self):
56:         reduction = _finite(self.reduction, "reduction")
57:         if reduction <= 0.0:
58:             raise ValueError("reduction must be positive")
59:         if type(self.direction) is not int or self.direction not in (-1, 1):
60:             raise ValueError("direction must be the integer -1 or 1")
61:         object.__setattr__(self, "reduction", reduction)
62:         object.__setattr__(self, "zero_output_rad", _finite(self.zero_output_rad, "zero_output_rad"))
63: 
64:     def to_output(self, target: "JointTarget") -> "OutputTarget":
65:         if not isinstance(target, JointTarget):
66:             raise ValueError("target must be a JointTarget")
67: 
68:         signed_reduction = _multiply("signed reduction", float(self.direction), self.reduction)
69:         q_rad = _add(
70:             self.zero_output_rad,
71:             _multiply("output position", signed_reduction, target.q_rad),
72:             "output position",
73:         )
74:         output_rad_s = _multiply("output velocity", signed_reduction, target.dq_rad_s)
75:         rpm = _divide(_multiply("output speed", output_rad_s, 60.0), math.tau, "output speed")
76:         tau_nm = _divide(
77:             _multiply("output torque", float(self.direction), target.tau_nm),
78:             self.reduction,
79:             "output torque",
80:         )
81:         kp = _divide(_divide(target.kp, self.reduction, "output kp"), self.reduction, "output kp")
82:         kd = _divide(_divide(target.kd, self.reduction, "output kd"), self.reduction, "output kd")
83:         return OutputTarget(q_rad=q_rad, rpm=rpm, tau_nm=tau_nm, kp=kp, kd=kd)
84: 
85:     def from_output(self, sample: "OutputSample") -> "JointSample":
86:         if not isinstance(sample, OutputSample):
87:             raise ValueError("sample must be an OutputSample")
88: 
89:         q_delta = _subtract(sample.q_rad, self.zero_output_rad, "joint position")
90:         q_rad = _divide(
91:             _multiply("joint position", float(self.direction), q_delta),
92:             self.reduction,
93:             "joint position",
94:         )
95:         output_rad_s = _divide(
96:             _multiply("joint velocity", sample.rpm, math.tau),
97:             60.0,
98:             "joint velocity",
99:         )
100:         dq_rad_s = _divide(
101:             _multiply("joint velocity", float(self.direction), output_rad_s),
102:             self.reduction,
103:             "joint velocity",
104:         )
105:         tau_nm = _multiply("joint torque", float(self.direction), self.reduction, sample.tau_nm)
106:         return JointSample(q_rad=q_rad, dq_rad_s=dq_rad_s, tau_nm=tau_nm)
107: 
108: 
109: @dataclass(frozen=True)
110: class JointTarget:
111:     q_rad: float
112:     dq_rad_s: float
113:     tau_nm: float
114:     kp: float
115:     kd: float
116: 
117:     def __post_init__(self):
118:         for name in ("q_rad", "dq_rad_s", "tau_nm", "kp", "kd"):
119:             object.__setattr__(self, name, _finite(getattr(self, name), name))
120:         if self.kp < 0.0 or self.kd < 0.0:
121:             raise ValueError("kp and kd must be nonnegative")
122: 
123: 
124: @dataclass(frozen=True)
125: class OutputTarget:
126:     q_rad: float
127:     rpm: float
128:     tau_nm: float
129:     kp: float
130:     kd: float
131: 
132:     def __post_init__(self):
133:         for name in ("q_rad", "rpm", "tau_nm", "kp", "kd"):
134:             object.__setattr__(self, name, _finite(getattr(self, name), name))
135:         if self.kp < 0.0 or self.kd < 0.0:
136:             raise ValueError("kp and kd must be nonnegative")
137: 
138: 
139: @dataclass(frozen=True)
140: class OutputSample:
141:     q_rad: float
142:     rpm: float
143:     tau_nm: float
144: 
145:     def __post_init__(self):
146:         for name in ("q_rad", "rpm", "tau_nm"):
147:             object.__setattr__(self, name, _finite(getattr(self, name), name))
148: 
149: 
150: @dataclass(frozen=True)
151: class JointSample:
152:     q_rad: float
153:     dq_rad_s: float
154:     tau_nm: float
155: 
156:     def __post_init__(self):
157:         for name in ("q_rad", "dq_rad_s", "tau_nm"):
158:             object.__setattr__(self, name, _finite(getattr(self, name), name))

## joint_contract.py
1: """Frozen domain records and status types for joint control.
2: 
3: All records are immutable (frozen) data contracts with no transport or clock ownership.
4: """
5: 
6: from dataclasses import dataclass
7: from enum import Enum
8: from fractions import Fraction
9: import math
10: from typing import Literal
11: 
12: from im6014_codec import decode_command
13: from joint_mapping import JointMap, JointSample, JointTarget
14: 
15: 
16: class State(Enum):
17:     DISCONNECTED = "disconnected"
18:     CONNECTING = "connecting"
19:     CONNECTED = "connected"
20:     CHECKING = "checking"
21:     READY = "ready"
22:     ARMED = "armed"
23:     MOVING = "moving"
24:     STOPPED = "stopped"
25:     FAULT = "fault"
26: 
27: 
28: class DecisionCode(str, Enum):
29:     ACCEPTED = "accepted"
30:     INVALID_STATE = "invalid_state"
31:     INVALID_ARGUMENT = "invalid_argument"
32:     INVALID_OWNER = "invalid_owner"
33:     INVALID_SOURCE = "invalid_source"
34:     UNKNOWN_JOINT = "unknown_joint"
35:     INVALID_OBSERVATION = "invalid_observation"
36:     FAULT_ACK_REQUIRED = "fault_ack_required"
37:     FAULT_LATCHED = "fault_latched"
38:     OBSERVATIONS_INCOMPLETE = "observations_incomplete"
39:     STALE_FEEDBACK = "stale_feedback"
40:     UNHEALTHY = "unhealthy"
41:     NOT_STOPPED = "not_stopped"
42:     DUPLICATE_OR_OLDER = "duplicate_or_older"
43:     EXPIRED = "expired"
44:     POSITION_OUT_OF_BOUNDS = "position_out_of_bounds"
45:     SPEED_OUT_OF_BOUNDS = "speed_out_of_bounds"
46:     REFERENCE_GAP_EXCEEDED = "reference_gap_exceeded"
47:     CONSTRAINT_VIOLATION = "constraint_violation"
48: 
49: 
50: class CommunicationFailure(str, Enum):
51:     TIMEOUT = "timeout"
52:     INVALID_FEEDBACK = "invalid_feedback"
53:     DRIVER_FAILURE = "driver_failure"
54:     CLOCK_FAILURE = "clock_failure"
55:     PREWRITE_DEADLINE = "prewrite_deadline"
56: 
57: 
58: class WriteResult(str, Enum):
59:     COMPLETE = "complete"
60:     PARTIAL = "partial"
61:     FAILED = "failed"
62:     PREWRITE_DEADLINE = "prewrite_deadline"
63: 
64: 
65: @dataclass(frozen=True)
66: class Decision:
67:     accepted: bool
68:     code: DecisionCode
69: 
70:     def __post_init__(self) -> None:
71:         if type(self.accepted) is not bool:
72:             raise ValueError("accepted must be a bool")
73:         if not isinstance(self.code, DecisionCode):
74:             raise ValueError("code must be a DecisionCode")
75:         if self.accepted != (self.code is DecisionCode.ACCEPTED):
76:             raise ValueError("accepted must match the decision code")
77: 
78:     def __bool__(self) -> bool:
79:         return self.accepted
80: 
81: 
82: @dataclass(frozen=True)
83: class JointSpec:
84:     name: str
85:     motor_id: int
86:     mapping: JointMap
87:     q_min_rad: float
88:     q_max_rad: float
89:     v_max_rad_s: float
90:     limits_provenance: str
91: 
92:     def __post_init__(self) -> None:
93:         if type(self.name) is not str or not self.name.strip():
94:             raise ValueError("joint name must be a non-empty string")
95:         if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
96:             raise ValueError("motor_id must be an integer from 0 to 14")
97:         if not isinstance(self.mapping, JointMap):
98:             raise ValueError("mapping must be a JointMap")
99: 
100:         if isinstance(self.q_min_rad, bool) or not isinstance(self.q_min_rad, (int, float)):
101:             raise ValueError("q_min_rad must be a finite real number")
102:         if isinstance(self.q_max_rad, bool) or not isinstance(self.q_max_rad, (int, float)):
103:             raise ValueError("q_max_rad must be a finite real number")
104:         try:
105:             min_val = float(self.q_min_rad)
106:             max_val = float(self.q_max_rad)
107:         except (OverflowError, TypeError, ValueError) as exc:
108:             raise ValueError("position limits must be finite") from exc
109:         if not math.isfinite(min_val) or not math.isfinite(max_val):
110:             raise ValueError("position limits must be finite")
111:         if min_val > max_val:
112:             raise ValueError("q_min_rad must be less than or equal to q_max_rad")
113: 
114:         if isinstance(self.v_max_rad_s, bool) or not isinstance(self.v_max_rad_s, (int, float)):
115:             raise ValueError("v_max_rad_s must be a finite positive real number")
116:         try:
117:             v_max_val = float(self.v_max_rad_s)
118:         except (OverflowError, TypeError, ValueError) as exc:
119:             raise ValueError("speed limit must be finite") from exc
120:         if not math.isfinite(v_max_val) or v_max_val <= 0.0:
121:             raise ValueError("v_max_rad_s must be finite and positive")
122: 
123:         if (
124:             type(self.limits_provenance) is not str
125:             or not self.limits_provenance.strip()
126:             or len(self.limits_provenance) > 256
127:         ):
128:             raise ValueError("limits_provenance must be a bounded non-empty string")
129: 
130:         object.__setattr__(self, "q_min_rad", min_val)
131:         object.__setattr__(self, "q_max_rad", max_val)
132:         object.__setattr__(self, "v_max_rad_s", v_max_val)
133: 
134: @dataclass(frozen=True)
135: class JointFault:
136:     name: str
137:     motor_id: int
138:     errors: int = 0
139:     warnings: int = 0
140:     timeout: bool = False
141:     communication_error: CommunicationFailure | None = None
142:     stale: bool = False
143:     communication_errors: tuple[CommunicationFailure, ...] = ()
144:     position_limit: bool = False
145:     speed_limit: bool = False
146:     constraint_fault: bool = False
147: 
148:     def __post_init__(self) -> None:
149:         if type(self.name) is not str or not self.name.strip():
150:             raise ValueError("joint name must be a non-empty string")
151:         if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
152:             raise ValueError("motor_id must be an integer from 0 to 14")
153:         if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
154:             raise ValueError("errors must be a uint32 integer")
155:         if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
156:             raise ValueError("warnings must be a uint3 integer")
157:         if type(self.timeout) is not bool:
158:             raise ValueError("timeout must be a bool")
159:         if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
160:             raise ValueError("communication_error must be a CommunicationFailure or None")
161:         if type(self.stale) is not bool:
162:             raise ValueError("stale must be a bool")
163:         if type(self.communication_errors) is not tuple or any(
164:             not isinstance(c, CommunicationFailure) for c in self.communication_errors
165:         ):
166:             raise ValueError("communication_errors must be a tuple of CommunicationFailure")
167:         if type(self.position_limit) is not bool:
168:             raise ValueError("position_limit must be a bool")
169:         if type(self.speed_limit) is not bool:
170:             raise ValueError("speed_limit must be a bool")
171:         if type(self.constraint_fault) is not bool:
172:             raise ValueError("constraint_fault must be a bool")
173: 
174:         if len(self.communication_errors) != len(set(self.communication_errors)):
175:             raise ValueError("communication_errors must contain unique codes")
176:         if self.communication_error is not None and self.communication_errors and (
177:             self.communication_error not in self.communication_errors
178:         ):
179:             raise ValueError("communication_error must belong to communication_errors")
180: 
181:         if self.communication_error is not None and not self.communication_errors:
182:             object.__setattr__(self, "communication_errors", (self.communication_error,))
183:         elif self.communication_errors and self.communication_error is None:
184:             object.__setattr__(self, "communication_error", self.communication_errors[-1])
185: 
186: 
187: @dataclass(frozen=True)
188: class MotorHealth:
189:     mode: int
190:     errors: int
191:     warnings: int
192:     timeout: bool
193: 
194:     def __post_init__(self) -> None:
195:         if type(self.mode) is not int or self.mode not in (0, 1):
196:             raise ValueError("mode must be the integer 0 or 1")
197:         if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
198:             raise ValueError("errors must be a uint32 integer")
199:         if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
200:             raise ValueError("warnings must be a uint3 integer")
201:         if type(self.timeout) is not bool:
202:             raise ValueError("timeout must be a bool")
203: 
204:     @property
205:     def healthy(self) -> bool:
206:         return self.errors == 0 and self.warnings == 0 and not self.timeout
207: 
208: 
209: @dataclass(frozen=True)
210: class SourceIdentity:
211:     backend: Literal["physical", "demo", "fixture"]
212:     identity: str
213:     connection: int
214: 
215:     def __post_init__(self) -> None:
216:         if type(self.backend) is not str or self.backend not in ("physical", "demo", "fixture"):
217:             raise ValueError("backend must be physical, demo, or fixture")
218:         if type(self.identity) is not str or not self.identity.strip():
219:             raise ValueError("identity must be a non-empty string")
220:         if type(self.connection) is not int or self.connection < 0:
221:             raise ValueError("connection must be a nonnegative integer")
222: 
223: 
224: @dataclass(frozen=True)
225: class JointStatus:
226:     sample: JointSample | None = None
227:     health: MotorHealth | None = None
228:     received_at: float | None = None
229:     communication_error: CommunicationFailure | None = None
230: 
231:     def __post_init__(self) -> None:
232:         if (self.sample is None) != (self.health is None):
233:             raise ValueError("sample and health must both be present or both be absent")
234:         if self.sample is not None and not isinstance(self.sample, JointSample):
235:             raise ValueError("sample must be a JointSample")
236:         if self.health is not None and not isinstance(self.health, MotorHealth):
237:             raise ValueError("health must be MotorHealth")
238:         if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
239:             raise ValueError("communication_error must be a CommunicationFailure or None")
240:         if self.valid and self.received_at is None:
241:             raise ValueError("a valid observation requires received_at")
242:         if self.received_at is not None:
243:             if isinstance(self.received_at, bool) or not isinstance(self.received_at, (int, float)):
244:                 raise ValueError("received_at must be a finite real number or None")
245:             try:
246:                 received_at = float(self.received_at)
247:             except (OverflowError, TypeError, ValueError) as exc:
248:                 raise ValueError("received_at must be finite") from exc
249:             if not math.isfinite(received_at):
250:                 raise ValueError("received_at must be finite")
251:             if not self.valid:
252:                 raise ValueError("received_at requires a valid observation")
253:             object.__setattr__(self, "received_at", received_at)
254: 
255:     @property
256:     def valid(self) -> bool:
257:         return self.sample is not None and self.health is not None
258: 
259:     @property
260:     def healthy(self) -> bool:
261:         return self.valid and self.health.healthy and self.communication_error is None
262: 
263:     @property
264:     def errors(self) -> int:
265:         return self.health.errors if self.health is not None else 0
266: 
267:     @property
268:     def warnings(self) -> int:
269:         return self.health.warnings if self.health is not None else 0
270: 
271:     @property
272:     def timeout(self) -> bool:
273:         return self.health.timeout if self.health is not None else False
274: 
275: 
276: @dataclass(frozen=True)
277: class OwnerToken:
278:     epoch: str
279:     generation: int
280:     connection_id: str
281: 
282:     def __post_init__(self) -> None:
283:         if type(self.epoch) is not str or not self.epoch.strip() or len(self.epoch) > 64:
284:             raise ValueError("epoch must be a bounded non-empty string")
285:         if type(self.generation) is not int or not (1 <= self.generation <= (1 << 64) - 1):
286:             raise ValueError("generation must be an integer from 1 to 2**64 - 1")
287:         if type(self.connection_id) is not str or not self.connection_id.strip() or len(self.connection_id) > 64:
288:             raise ValueError("connection_id must be a bounded non-empty string")
289: 
290: 
291: def owner_tokens_match(candidate: object, current: object) -> bool:
292:     return (
293:         type(candidate) is OwnerToken
294:         and type(current) is OwnerToken
295:         and candidate.epoch == current.epoch
296:         and candidate.generation == current.generation
297:         and candidate.connection_id == current.connection_id
298:     )
299: 
300: 
301: @dataclass(frozen=True)
302: class IntentWindow:
303:     id: int
304:     created_at_s: float
305:     expires_at_s: float
306: 
307:     def __post_init__(self) -> None:
308:         if type(self.id) is not int or not (0 <= self.id <= (1 << 64) - 1):
309:             raise ValueError("window ID must be an integer from 0 to 2**64 - 1")
310:         if isinstance(self.created_at_s, bool) or not isinstance(self.created_at_s, (int, float)):
311:             raise ValueError("created_at_s must be a finite real number")
312:         if isinstance(self.expires_at_s, bool) or not isinstance(self.expires_at_s, (int, float)):
313:             raise ValueError("expires_at_s must be a finite real number")
314:         try:
315:             created = float(self.created_at_s)
316:             expires = float(self.expires_at_s)
317:         except (OverflowError, TypeError, ValueError) as exc:
318:             raise ValueError("window timestamps must be finite") from exc
319:         if not math.isfinite(created) or not math.isfinite(expires):
320:             raise ValueError("window timestamps must be finite")
321:         if expires <= created:
322:             raise ValueError("expires_at_s must be strictly greater than created_at_s")
323:         object.__setattr__(self, "created_at_s", created)
324:         object.__setattr__(self, "expires_at_s", expires)
325: 
326: 
327: @dataclass(frozen=True)
328: class Target:
329:     sequence: int
330:     joints: tuple[JointTarget, ...]
331:     window: IntentWindow
332:     owner: OwnerToken
333: 
334:     def __post_init__(self) -> None:
335:         if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
336:             raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
337:         if type(self.joints) is not tuple:
338:             raise ValueError("joints must be a tuple of JointTarget")
339:         if not self.joints:
340:             raise ValueError("joints must be a non-empty tuple")
341:         if any(not isinstance(joint, JointTarget) for joint in self.joints):
342:             raise ValueError("every joint target must be a JointTarget")
343:         if not isinstance(self.window, IntentWindow):
344:             raise ValueError("window must be an IntentWindow")
345:         if type(self.owner) is not OwnerToken:
346:             raise ValueError("owner must be an OwnerToken")
347: 
348: 
349: @dataclass(frozen=True)
350: class JointTrajectoryReference:
351:     q_rad: float
352:     position_step_velocity_rad_s: Fraction
353:     encoded_velocity_rad_s: float
354:     sample_time_s: float
355:     is_emitted: bool = False
356:     requested_goal: JointTarget | None = None
357:     emitted_target: JointTarget | None = None
358:     packet: bytes | None = None
359: 
360:     def __post_init__(self) -> None:
361:         for name, val in (("q_rad", self.q_rad),
362:                           ("encoded_velocity_rad_s", self.encoded_velocity_rad_s),
363:                           ("sample_time_s", self.sample_time_s)):
364:             if isinstance(val, bool) or not isinstance(val, (int, float)):
365:                 raise ValueError(f"{name} must be a finite real number")
366:             try:
367:                 v = float(val)
368:             except (OverflowError, TypeError, ValueError) as exc:
369:                 raise ValueError(f"{name} must be finite") from exc
370:             if not math.isfinite(v):
371:                 raise ValueError(f"{name} must be finite")
372:             object.__setattr__(self, name, v)
373: 
374:         derivative = self.position_step_velocity_rad_s
375:         if isinstance(derivative, bool) or not isinstance(derivative, (int, float, Fraction)):
376:             raise ValueError("position_step_velocity_rad_s must be an exact finite rational")
377:         if isinstance(derivative, Fraction):
378:             exact_derivative = derivative
379:         else:
380:             try:
381:                 as_float = float(derivative)
382:             except (OverflowError, TypeError, ValueError) as exc:
383:                 raise ValueError("position_step_velocity_rad_s must be finite") from exc
384:             if not math.isfinite(as_float):
385:                 raise ValueError("position_step_velocity_rad_s must be finite")
386:             exact_derivative = Fraction(as_float)
387:         object.__setattr__(self, "position_step_velocity_rad_s", exact_derivative)
388: 
389:         if type(self.is_emitted) is not bool:
390:             raise ValueError("is_emitted must be a bool")
391:         if self.is_emitted:
392:             if not isinstance(self.requested_goal, JointTarget):
393:                 raise ValueError("an emitted reference requires its requested goal")
394:             if not isinstance(self.emitted_target, JointTarget):
395:                 raise ValueError("an emitted reference requires its decoded target")
396:             if type(self.packet) is not bytes:
397:                 raise ValueError("an emitted reference requires immutable packet bytes")
398:             try:
399:                 decoded = decode_command(self.packet)
400:             except ValueError as exc:
401:                 raise ValueError("an emitted reference requires a canonical command") from exc
402:             if decoded["mode"] != 1 or not decoded["watchdog"]:
403:                 raise ValueError("an emitted reference requires a watchdog-enabled FOC command")
404:             if self.q_rad != self.emitted_target.q_rad:
405:                 raise ValueError("reference position must match its decoded target")
406:             if self.encoded_velocity_rad_s != self.emitted_target.dq_rad_s:
407:                 raise ValueError("encoded velocity must match its decoded target")
408:         else:
409:             if (
410:                 self.requested_goal is not None
411:                 or self.emitted_target is not None
412:                 or self.packet is not None
413:             ):
414:                 raise ValueError("an unemitted Stop anchor cannot contain an emitted command")
415:             if exact_derivative != 0 or self.encoded_velocity_rad_s != 0.0:
416:                 raise ValueError("an unemitted Stop anchor must have zero velocity history")
417: 
418: 
419: @dataclass(frozen=True)
420: class RefreshPlan:
421:     plan_id: int
422:     target: Target
423:     prepared_at_s: float
424:     joint_targets: tuple[JointTarget, ...]
425:     packets: tuple[bytes, ...]
426:     proposed_references: tuple[JointTrajectoryReference, ...]
427: 
428:     def __post_init__(self) -> None:
429:         if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
430:             raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
431:         if not isinstance(self.target, Target):
432:             raise ValueError("target must be a Target")
433:         if isinstance(self.prepared_at_s, bool) or not isinstance(self.prepared_at_s, (int, float)):
434:             raise ValueError("prepared_at_s must be a finite real number")
435:         try:
436:             prepared = float(self.prepared_at_s)
437:         except (OverflowError, TypeError, ValueError) as exc:
438:             raise ValueError("prepared_at_s must be finite") from exc
439:         if not math.isfinite(prepared):
440:             raise ValueError("prepared_at_s must be finite")
441:         object.__setattr__(self, "prepared_at_s", prepared)
442:         if type(self.joint_targets) is not tuple or not self.joint_targets:
443:             raise ValueError("joint_targets must be a non-empty tuple")
444:         if any(not isinstance(jt, JointTarget) for jt in self.joint_targets):
445:             raise ValueError("every joint target must be a JointTarget")
446:         if len(self.target.joints) != len(self.joint_targets):
447:             raise ValueError("joint_targets must match the complete target vector")
448:         if type(self.packets) is not tuple or len(self.packets) != len(self.joint_targets):
449:             raise ValueError("packets must be a tuple matching joint_targets")
450:         for packet in self.packets:
451:             if type(packet) is not bytes:
452:                 raise ValueError("packets must contain immutable bytes")
453:             try:
454:                 decoded = decode_command(packet)
455:             except ValueError as exc:
456:                 raise ValueError("packets must contain canonical commands") from exc
457:             if decoded["mode"] != 1 or not decoded["watchdog"]:
458:                 raise ValueError("refresh packets must be watchdog-enabled FOC commands")
459:         if (
460:             type(self.proposed_references) is not tuple
461:             or len(self.proposed_references) != len(self.joint_targets)
462:         ):
463:             raise ValueError("proposed_references must match joint_targets length")
464:         for goal, target, packet, reference in zip(
465:             self.target.joints,
466:             self.joint_targets,
467:             self.packets,
468:             self.proposed_references,
469:         ):
470:             if not isinstance(reference, JointTrajectoryReference) or not reference.is_emitted:
471:                 raise ValueError("every plan requires a complete emitted reference")
472:             if reference.requested_goal != goal:
473:                 raise ValueError("reference goal must match the admitted joint goal")
474:             if reference.emitted_target != target or reference.packet != packet:
475:                 raise ValueError("reference target and packet must match the prepared command")
476:             if reference.sample_time_s > prepared:
477:                 raise ValueError("reference sample time cannot follow plan preparation")
478: 
479:     @property
480:     def window(self) -> IntentWindow:
481:         return self.target.window
482: 
483:     @property
484:     def owner(self) -> OwnerToken:
485:         return self.target.owner
486: 
487: 
488: @dataclass(frozen=True)
489: class JointDispatchedRecord:
490:     sequence: int
491:     target: JointTarget
492:     dispatched_at_s: float
493:     owner: OwnerToken
494: 
495:     def __post_init__(self) -> None:
496:         if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
497:             raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
498:         if not isinstance(self.target, JointTarget):
499:             raise ValueError("target must be a JointTarget")
500:         if type(self.owner) is not OwnerToken:
501:             raise ValueError("owner must be an OwnerToken")
502:         if isinstance(self.dispatched_at_s, bool) or not isinstance(self.dispatched_at_s, (int, float)):
503:             raise ValueError("dispatched_at_s must be a finite real number")
504:         try:
505:             dispatched = float(self.dispatched_at_s)
506:         except (OverflowError, TypeError, ValueError) as exc:
507:             raise ValueError("dispatched_at_s must be finite") from exc
508:         if not math.isfinite(dispatched):
509:             raise ValueError("dispatched_at_s must be finite")
510:         object.__setattr__(self, "dispatched_at_s", dispatched)
511: 
512: 
513: @dataclass(frozen=True)
514: class JointDispatchAttempt:
515:     plan_id: int
516:     sequence: int
517:     target: JointTarget
518:     result: WriteResult
519:     started_at_s: float
520:     owner: OwnerToken
521: 
522:     def __post_init__(self) -> None:
523:         if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
524:             raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
525:         if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
526:             raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
527:         if not isinstance(self.target, JointTarget):
528:             raise ValueError("target must be a JointTarget")
529:         if not isinstance(self.result, WriteResult):
530:             raise ValueError("result must be a WriteResult")
531:         if type(self.owner) is not OwnerToken:
532:             raise ValueError("owner must be an OwnerToken")
533:         if isinstance(self.started_at_s, bool) or not isinstance(self.started_at_s, (int, float)):
534:             raise ValueError("started_at_s must be a finite real number")
535:         try:
536:             started = float(self.started_at_s)
537:         except (OverflowError, TypeError, ValueError) as exc:
538:             raise ValueError("started_at_s must be finite") from exc
539:         if not math.isfinite(started):
540:             raise ValueError("started_at_s must be finite")
541:         object.__setattr__(self, "started_at_s", started)
542: 
543: 
544: @dataclass(frozen=True)
545: class Snapshot:
546:     state: State
547:     joint_names: tuple[str, ...]
548:     joints: tuple[JointStatus, ...]
549:     source: SourceIdentity | None
550:     fault_latched: bool
551:     feedback_ages_s: tuple[float | None, ...]
552:     faults: tuple[JointFault, ...] = ()
553:     admitted_target: Target | None = None
554:     prepared_plan: RefreshPlan | None = None
555:     dispatched_records: tuple[JointDispatchedRecord | None, ...] = ()
556:     last_sequence: int = -1
557:     dispatch_attempts: tuple[JointDispatchAttempt | None, ...] = ()
558:     latest_owner: OwnerToken | None = None
559:     current_owner: OwnerToken | None = None
560:     confirmed_references: tuple[JointTrajectoryReference | None, ...] = ()
561: 
562:     def __post_init__(self) -> None:
563:         if not isinstance(self.state, State):
564:             raise ValueError("state must be a State")
565:         if type(self.joint_names) is not tuple or any(type(name) is not str for name in self.joint_names):
566:             raise ValueError("joint_names must be a tuple of strings")
567:         if type(self.joints) is not tuple or any(not isinstance(joint, JointStatus) for joint in self.joints):
568:             raise ValueError("joints must be a tuple of JointStatus")
569:         if type(self.feedback_ages_s) is not tuple:
570:             raise ValueError("feedback_ages_s must be a tuple")
571:         if len(self.joint_names) != len(self.joints):
572:             raise ValueError("joint names and statuses must have equal lengths")
573:         if len(self.feedback_ages_s) != len(self.joints):
574:             raise ValueError("feedback ages and joint statuses must have equal lengths")
575:         normalized_ages: list[float | None] = []
576:         for joint, age in zip(self.joints, self.feedback_ages_s):
577:             if joint.received_at is None:
578:                 if age is not None:
579:                     raise ValueError("feedback age must be None before a joint is received")
580:                 normalized_ages.append(None)
581:                 continue
582:             if isinstance(age, bool) or not isinstance(age, (int, float)):
583:                 raise ValueError("feedback age must be a finite nonnegative number")
584:             try:
585:                 age_value = float(age)
586:             except (OverflowError, TypeError, ValueError) as exc:
587:                 raise ValueError("feedback age must be finite") from exc
588:             if not math.isfinite(age_value) or age_value < 0.0:
589:                 raise ValueError("feedback age must be finite and nonnegative")
590:             normalized_ages.append(age_value)
591:         object.__setattr__(self, "feedback_ages_s", tuple(normalized_ages))
592:         if self.source is not None and not isinstance(self.source, SourceIdentity):
593:             raise ValueError("source must be a SourceIdentity or None")
594:         if type(self.fault_latched) is not bool:
595:             raise ValueError("fault_latched must be a bool")
596:         if type(self.faults) is not tuple or any(not isinstance(f, JointFault) for f in self.faults):
597:             raise ValueError("faults must be a tuple of JointFault")
598:         if self.admitted_target is not None and not isinstance(self.admitted_target, Target):
599:             raise ValueError("admitted_target must be a Target or None")
600:         if self.prepared_plan is not None and not isinstance(self.prepared_plan, RefreshPlan):
601:             raise ValueError("prepared_plan must be a RefreshPlan or None")
602:         if not self.dispatched_records:
603:             object.__setattr__(self, "dispatched_records", tuple(None for _ in self.joints))
604:         else:
605:             if type(self.dispatched_records) is not tuple or len(self.dispatched_records) != len(self.joints):
606:                 raise ValueError("dispatched_records must be a tuple with length matching joints")
607:             if any(r is not None and not isinstance(r, JointDispatchedRecord) for r in self.dispatched_records):
608:                 raise ValueError("every dispatched record must be a JointDispatchedRecord or None")
609:         if not self.dispatch_attempts:
610:             object.__setattr__(self, "dispatch_attempts", tuple(None for _ in self.joints))
611:         else:
612:             if type(self.dispatch_attempts) is not tuple or len(self.dispatch_attempts) != len(self.joints):
613:                 raise ValueError("dispatch_attempts must be a tuple with length matching joints")
614:             if any(r is not None and not isinstance(r, JointDispatchAttempt) for r in self.dispatch_attempts):
615:                 raise ValueError("every dispatch attempt must be a JointDispatchAttempt or None")
616:         if type(self.last_sequence) is not int or not (-1 <= self.last_sequence <= (1 << 64) - 1):
617:             raise ValueError("last_sequence must be an integer from -1 to 2**64 - 1")
618:         if self.latest_owner is not None and type(self.latest_owner) is not OwnerToken:
619:             raise ValueError("latest_owner must be an OwnerToken or None")
620:         if self.current_owner is not None and type(self.current_owner) is not OwnerToken:
621:             raise ValueError("current_owner must be an OwnerToken or None")
622:         if not self.confirmed_references:
623:             object.__setattr__(self, "confirmed_references", tuple(None for _ in self.joints))
624:         else:
625:             if type(self.confirmed_references) is not tuple or len(self.confirmed_references) != len(self.joints):
626:                 raise ValueError("confirmed_references must be a tuple with length matching joints")
627:             if any(r is not None and not isinstance(r, JointTrajectoryReference) for r in self.confirmed_references):
628:                 raise ValueError("every confirmed reference must be a JointTrajectoryReference or None")
629: 
630:     @property
631:     def affected_joints(self) -> tuple[str, ...]:
632:         return tuple(fault.name for fault in self.faults)

## joint_reference.py
1: """Pure joint reference validation and canonical packet preparation."""
2: 
3: from dataclasses import dataclass
4: from fractions import Fraction
5: import math
6: from im6014_codec import (
7:     command,
8:     command_with_raw_position,
9:     decode_command,
10:     project_position_raw,
11:     project_speed_raw,
12:     raw_to_position,
13: )
14: from joint_contract import (
15:     DecisionCode,
16:     JointSpec,
17:     JointTrajectoryReference,
18:     Target,
19: )
20: from joint_mapping import JointTarget, OutputSample
21: 
22: __all__ = (
23:     "prepare_reference_joint",
24:     "shape_reference_joint",
25:     "prepare_complete_reference",
26:     "validate_target_vector",
27:     "ReferenceFailure",
28:     "ReferenceBatchResult",
29: )
30: 
31: 
32: @dataclass(frozen=True)
33: class ReferenceFailure:
34:     code: DecisionCode
35:     joint_index: int | None
36: 
37:     def __post_init__(self) -> None:
38:         if not isinstance(self.code, DecisionCode):
39:             raise ValueError("reference failure code must be a DecisionCode")
40:         if self.joint_index is not None and (
41:             type(self.joint_index) is not int or self.joint_index < 0
42:         ):
43:             raise ValueError("joint_index must be a nonnegative integer or None")
44: 
45: 
46: @dataclass(frozen=True)
47: class ReferenceBatchResult:
48:     joint_targets: tuple[JointTarget, ...] | None
49:     packets: tuple[bytes, ...] | None
50:     proposed_references: tuple[JointTrajectoryReference, ...] | None
51:     failures: tuple[ReferenceFailure, ...]
52: 
53:     def __post_init__(self) -> None:
54:         if type(self.failures) is not tuple or any(
55:             not isinstance(failure, ReferenceFailure) for failure in self.failures
56:         ):
57:             raise ValueError("failures must be a tuple of ReferenceFailure")
58:         if self.failures:
59:             if any(
60:                 value is not None
61:                 for value in (self.joint_targets, self.packets, self.proposed_references)
62:             ):
63:                 raise ValueError("a failed batch cannot expose a partial plan")
64:             indices = [failure.joint_index for failure in self.failures]
65:             if len(indices) != len(set(indices)):
66:                 raise ValueError("a batch can report at most one failure per joint")
67:             return
68: 
69:         if (
70:             type(self.joint_targets) is not tuple
71:             or type(self.packets) is not tuple
72:             or type(self.proposed_references) is not tuple
73:             or not self.joint_targets
74:             or len(self.joint_targets) != len(self.packets)
75:             or len(self.joint_targets) != len(self.proposed_references)
76:         ):
77:             raise ValueError("a successful batch requires complete parallel tuples")
78:         if any(not isinstance(target, JointTarget) for target in self.joint_targets):
79:             raise ValueError("every batch target must be a JointTarget")
80:         if any(type(packet) is not bytes for packet in self.packets):
81:             raise ValueError("every batch packet must be immutable bytes")
82:         if any(not isinstance(ref, JointTrajectoryReference) for ref in self.proposed_references):
83:             raise ValueError("every batch reference must be a JointTrajectoryReference")
84: 
85:     @property
86:     def ready(self) -> bool:
87:         return not self.failures
88: 
89: 
90: def prepare_reference_joint(
91:     spec: JointSpec, target: JointTarget
92: ) -> tuple[DecisionCode | None, JointTarget | None, bytes | None]:
93:     """Validate a request and bind its actual decoded command to canonical bytes."""
94:     if not isinstance(spec, JointSpec) or not isinstance(target, JointTarget):
95:         return DecisionCode.INVALID_ARGUMENT, None, None
96:     if target.q_rad < spec.q_min_rad or target.q_rad > spec.q_max_rad:
97:         return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
98:     if abs(target.dq_rad_s) > spec.v_max_rad_s:
99:         return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
100: 
101:     try:
102:         output = spec.mapping.to_output(target)
103:         # Validate the original mapped request through the ordinary codec before
104:         # projecting its position onto an inward representable grid point.
105:         command(
106:             spec.motor_id,
107:             mode=1,
108:             rpm=output.rpm,
109:             kd=output.kd,
110:             torque=output.tau_nm,
111:             watchdog=True,
112:             position=output.q_rad,
113:             kp=output.kp,
114:         )
115:         raw_position = project_position_raw(
116:             target.q_rad,
117:             spec.q_min_rad,
118:             spec.q_max_rad,
119:             lambda output_q: spec.mapping.from_output(
120:                 OutputSample(output_q, 0.0, 0.0)
121:             ).q_rad,
122:             spec.mapping.direction,
123:         )
124:         if raw_position is None:
125:             return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
126: 
127:         raw_rpm = project_speed_raw(
128:             target.dq_rad_s,
129:             -spec.v_max_rad_s,
130:             spec.v_max_rad_s,
131:             lambda output_rpm: spec.mapping.from_output(
132:                 OutputSample(0.0, output_rpm, 0.0)
133:             ).dq_rad_s,
134:             spec.mapping.direction,
135:         )
136:         if raw_rpm is None:
137:             return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
138:     except (ArithmeticError, TypeError, ValueError):
139:         return DecisionCode.INVALID_ARGUMENT, None, None
140: 
141:     try:
142:         packet = command_with_raw_position(
143:             spec.motor_id,
144:             raw_position,
145:             mode=1,
146:             rpm=output.rpm,
147:             kd=output.kd,
148:             torque=output.tau_nm,
149:             watchdog=True,
150:             kp=output.kp,
151:             raw_rpm=raw_rpm,
152:         )
153:         decoded = decode_command(packet)
154:         actual_output = spec.mapping.from_output(
155:             OutputSample(
156:                 decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
157:             )
158:         )
159:         gain_scale = spec.mapping.reduction ** 2
160:         actual_target = JointTarget(
161:             q_rad=actual_output.q_rad,
162:             dq_rad_s=actual_output.dq_rad_s,
163:             tau_nm=actual_output.tau_nm,
164:             kp=decoded["kp"] * gain_scale,
165:             kd=decoded["kd"] * gain_scale,
166:         )
167:     except (ArithmeticError, TypeError, ValueError):
168:         return DecisionCode.INVALID_ARGUMENT, None, None
169: 
170:     if not spec.q_min_rad <= actual_target.q_rad <= spec.q_max_rad:
171:         return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
172:     if abs(actual_target.dq_rad_s) > spec.v_max_rad_s:
173:         return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
174:     return None, actual_target, packet
175: 
176: 
177: def validate_target_vector(
178:     specs: tuple[JointSpec, ...], target: Target
179: ) -> tuple[ReferenceFailure, ...]:
180:     """Validate every admitted joint request before replacing the current goal."""
181:     if not isinstance(target, Target) or len(target.joints) != len(specs):
182:         return (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
183: 
184:     failures: list[ReferenceFailure] = []
185:     for index, (spec, joint_target) in enumerate(zip(specs, target.joints)):
186:         code, _, _ = prepare_reference_joint(spec, joint_target)
187:         if code is not None:
188:             failures.append(ReferenceFailure(code, index))
189:     return tuple(failures)
190: 
191: 
192: def shape_reference_joint(
193:     spec: JointSpec,
194:     target: JointTarget,
195:     confirmed_ref: JointTrajectoryReference,
196:     now: float,
197:     max_reference_gap_s: float,
198: ) -> tuple[
199:     DecisionCode | None,
200:     JointTarget | None,
201:     JointTrajectoryReference | None,
202:     bytes | None,
203: ]:
204:     """Shape one discrete reference point and retain its exact emitted command."""
205:     if (
206:         not isinstance(spec, JointSpec)
207:         or not isinstance(target, JointTarget)
208:         or not isinstance(confirmed_ref, JointTrajectoryReference)
209:     ):
210:         return DecisionCode.INVALID_ARGUMENT, None, None, None
211: 
212:     normalized: list[float] = []
213:     for val in (
214:         target.q_rad,
215:         target.dq_rad_s,
216:         target.tau_nm,
217:         target.kp,
218:         target.kd,
219:         now,
220:         max_reference_gap_s,
221:     ):
222:         if isinstance(val, bool) or not isinstance(val, (int, float)):
223:             return DecisionCode.INVALID_ARGUMENT, None, None, None
224:         try:
225:             numeric = float(val)
226:         except (OverflowError, TypeError, ValueError):
227:             return DecisionCode.INVALID_ARGUMENT, None, None, None
228:         if not math.isfinite(numeric):
229:             return DecisionCode.INVALID_ARGUMENT, None, None, None
230:         normalized.append(numeric)
231:     (
232:         goal_q,
233:         goal_dq,
234:         goal_tau,
235:         goal_kp,
236:         goal_kd,
237:         now,
238:         max_reference_gap_s,
239:     ) = normalized
240:     if max_reference_gap_s <= 0.0:
241:         return DecisionCode.INVALID_ARGUMENT, None, None, None
242: 
243:     if goal_q < spec.q_min_rad or goal_q > spec.q_max_rad:
244:         return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
245:     if abs(goal_dq) > spec.v_max_rad_s:
246:         return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None, None
247: 
248:     h = now - confirmed_ref.sample_time_s
249:     if not math.isfinite(h) or h < 0.0:
250:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
251:     if h > max_reference_gap_s:
252:         return DecisionCode.REFERENCE_GAP_EXCEEDED, None, None, None
253: 
254:     if h == 0.0:
255:         if not confirmed_ref.is_emitted:
256:             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
257:         if target != confirmed_ref.requested_goal:
258:             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
259:         if (
260:             confirmed_ref.emitted_target is None
261:             or confirmed_ref.packet is None
262:         ):
263:             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
264:         return (
265:             None,
266:             confirmed_ref.emitted_target,
267:             confirmed_ref,
268:             confirmed_ref.packet,
269:         )
270: 
271:     # Use exact rational arithmetic over the stored finite float-domain values.
272:     # The sample cadence is the actual float subtraction above, not a decimal
273:     # interpretation of either timestamp.
274:     try:
275:         h_exact = Fraction(h)
276:         q_prev_exact = Fraction(confirmed_ref.q_rad)
277:         q_min_exact = Fraction(spec.q_min_rad)
278:         q_max_exact = Fraction(spec.q_max_rad)
279:         v_max_exact = Fraction(spec.v_max_rad_s)
280: 
281:         v_pos_lo = (q_min_exact - q_prev_exact) / h_exact
282:         v_pos_hi = (q_max_exact - q_prev_exact) / h_exact
283:         v_lo = max(-v_max_exact, v_pos_lo)
284:         v_hi = min(v_max_exact, v_pos_hi)
285:         if v_lo > v_hi:
286:             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
287: 
288:         # q and dq jointly define a one-step objective; q does not replace dq.
289:         v_desired = (Fraction(goal_q) - q_prev_exact) / h_exact + Fraction(goal_dq)
290:         v_projected = max(v_lo, min(v_hi, v_desired))
291:         q_continuous = q_prev_exact + v_projected * h_exact
292:         q_next_lo = max(q_min_exact, q_prev_exact - v_max_exact * h_exact)
293:         q_next_hi = min(q_max_exact, q_prev_exact + v_max_exact * h_exact)
294:         if q_next_lo > q_next_hi or not q_next_lo <= q_continuous <= q_next_hi:
295:             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
296: 
297:         q_wanted = float(q_continuous)
298:         q_lower = float(q_next_lo)
299:         q_upper = float(q_next_hi)
300:         if not all(math.isfinite(value) for value in (q_wanted, q_lower, q_upper)):
301:             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
302:     except (ArithmeticError, TypeError, ValueError):
303:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
304: 
305:     try:
306:         output_req = spec.mapping.to_output(
307:             JointTarget(goal_q, goal_dq, goal_tau, goal_kp, goal_kd)
308:         )
309:         command(
310:             spec.motor_id,
311:             mode=1,
312:             rpm=output_req.rpm,
313:             kd=output_req.kd,
314:             torque=output_req.tau_nm,
315:             watchdog=True,
316:             position=output_req.q_rad,
317:             kp=output_req.kp,
318:         )
319:         raw_pos = project_position_raw(
320:             q_wanted,
321:             q_lower,
322:             q_upper,
323:             lambda out_q: spec.mapping.from_output(OutputSample(out_q, 0.0, 0.0)).q_rad,
324:             spec.mapping.direction,
325:         )
326:     except (ArithmeticError, TypeError, ValueError):
327:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
328: 
329:     if raw_pos is None:
330:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
331: 
332:     def mapped_position(raw_position: int) -> float:
333:         return spec.mapping.from_output(
334:             OutputSample(raw_to_position(raw_position), 0.0, 0.0)
335:         ).q_rad
336: 
337:     try:
338:         q_emitted = mapped_position(raw_pos)
339:         q_emitted_exact = Fraction(q_emitted)
340:         position_step_velocity = (q_emitted_exact - q_prev_exact) / h_exact
341:         safe_position = (
342:             q_min_exact <= q_emitted_exact <= q_max_exact
343:             and q_next_lo <= q_emitted_exact <= q_next_hi
344:         )
345:         safe_step = abs(position_step_velocity) <= v_max_exact
346:         if not safe_position or not safe_step:
347:             if q_emitted_exact < q_next_lo or position_step_velocity < -v_max_exact:
348:                 raw_step = spec.mapping.direction
349:             elif q_emitted_exact > q_next_hi or position_step_velocity > v_max_exact:
350:                 raw_step = -spec.mapping.direction
351:             else:
352:                 return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
353:             raw_candidate = raw_pos + raw_step
354:             candidate_q = mapped_position(raw_candidate)
355:             candidate_q_exact = Fraction(candidate_q)
356:             candidate_velocity = (candidate_q_exact - q_prev_exact) / h_exact
357:             if not (
358:                 q_min_exact <= candidate_q_exact <= q_max_exact
359:                 and q_next_lo <= candidate_q_exact <= q_next_hi
360:                 and abs(candidate_velocity) <= v_max_exact
361:             ):
362:                 return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
363:             raw_pos = raw_candidate
364:             q_emitted = candidate_q
365:             q_emitted_exact = candidate_q_exact
366:             position_step_velocity = candidate_velocity
367:     except (ArithmeticError, TypeError, ValueError):
368:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
369: 
370:     try:
371:         raw_rpm = project_speed_raw(
372:             goal_dq,
373:             -spec.v_max_rad_s,
374:             spec.v_max_rad_s,
375:             lambda out_rpm: spec.mapping.from_output(OutputSample(0.0, out_rpm, 0.0)).dq_rad_s,
376:             spec.mapping.direction,
377:         )
378:     except (ArithmeticError, TypeError, ValueError):
379:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
380: 
381:     if raw_rpm is None:
382:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
383: 
384:     try:
385:         packet = command_with_raw_position(
386:             spec.motor_id,
387:             raw_pos,
388:             mode=1,
389:             kd=output_req.kd,
390:             torque=output_req.tau_nm,
391:             watchdog=True,
392:             kp=output_req.kp,
393:             raw_rpm=raw_rpm,
394:         )
395:         decoded = decode_command(packet)
396:         actual_output = spec.mapping.from_output(
397:             OutputSample(decoded["position_rad"], decoded["rpm"], decoded["torque_nm"])
398:         )
399:         gain_scale = spec.mapping.reduction ** 2
400:         actual_target = JointTarget(
401:             q_rad=actual_output.q_rad,
402:             dq_rad_s=actual_output.dq_rad_s,
403:             tau_nm=actual_output.tau_nm,
404:             kp=decoded["kp"] * gain_scale,
405:             kd=decoded["kd"] * gain_scale,
406:         )
407:     except (ArithmeticError, TypeError, ValueError):
408:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
409: 
410:     actual_q_exact = Fraction(actual_target.q_rad)
411:     actual_position_step_velocity = (actual_q_exact - q_prev_exact) / h_exact
412:     if not q_min_exact <= actual_q_exact <= q_max_exact:
413:         return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
414:     if not q_next_lo <= actual_q_exact <= q_next_hi:
415:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
416:     if v_desired != 0 and actual_target.q_rad == confirmed_ref.q_rad:
417:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
418:     if abs(Fraction(actual_target.dq_rad_s)) > v_max_exact:
419:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
420:     if abs(actual_position_step_velocity) > v_max_exact:
421:         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
422: 
423:     proposed_ref = JointTrajectoryReference(
424:         q_rad=actual_target.q_rad,
425:         position_step_velocity_rad_s=actual_position_step_velocity,
426:         encoded_velocity_rad_s=actual_target.dq_rad_s,
427:         sample_time_s=now,
428:         is_emitted=True,
429:         requested_goal=JointTarget(goal_q, goal_dq, goal_tau, goal_kp, goal_kd),
430:         emitted_target=actual_target,
431:         packet=packet,
432:     )
433:     return None, actual_target, proposed_ref, packet
434: 
435: 
436: def prepare_complete_reference(
437:     specs: tuple[JointSpec, ...],
438:     target: Target,
439:     confirmed_references: tuple[JointTrajectoryReference, ...],
440:     now: float,
441:     max_reference_gap_s: float,
442: ) -> ReferenceBatchResult:
443:     """Shape all joints and report every failed index without exposing a partial plan."""
444:     if (
445:         type(specs) is not tuple
446:         or not specs
447:         or any(not isinstance(spec, JointSpec) for spec in specs)
448:         or not isinstance(target, Target)
449:         or len(target.joints) != len(specs)
450:         or type(confirmed_references) is not tuple
451:         or len(confirmed_references) != len(specs)
452:     ):
453:         return ReferenceBatchResult(
454:             None, None, None, (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
455:         )
456: 
457:     actual_targets: list[JointTarget] = []
458:     packets: list[bytes] = []
459:     proposed_references: list[JointTrajectoryReference] = []
460:     failures: list[ReferenceFailure] = []
461: 
462:     for index, (spec, joint_target, conf_ref) in enumerate(
463:         zip(specs, target.joints, confirmed_references)
464:     ):
465:         code, actual_target, prop_ref, packet = shape_reference_joint(
466:             spec, joint_target, conf_ref, now, max_reference_gap_s
467:         )
468:         if code is not None or actual_target is None or prop_ref is None or packet is None:
469:             failures.append(
470:                 ReferenceFailure(code or DecisionCode.CONSTRAINT_VIOLATION, index)
471:             )
472:             continue
473:         actual_targets.append(actual_target)
474:         packets.append(packet)
475:         proposed_references.append(prop_ref)
476: 
477:     if failures:
478:         return ReferenceBatchResult(None, None, None, tuple(failures))
479:     return ReferenceBatchResult(
480:         tuple(actual_targets), tuple(packets), tuple(proposed_references), ()
481:     )

## joint_controller.py
1: """Transport-free lifecycle and health state for an ordered joint set.
2: 
3: All methods on a JointCore belong to one calling thread. The core owns no
4: transport and all externally visible records are immutable snapshots.
5: """
6: 
7: from collections.abc import Iterable
8: from dataclasses import dataclass
9: from fractions import Fraction
10: import math
11: import secrets
12: import time
13: 
14: from joint_contract import (
15:     CommunicationFailure,
16:     Decision,
17:     DecisionCode,
18:     IntentWindow,
19:     JointDispatchAttempt,
20:     JointDispatchedRecord,
21:     JointFault,
22:     JointSpec,
23:     JointStatus,
24:     JointTrajectoryReference,
25:     MotorHealth,
26:     OwnerToken,
27:     RefreshPlan,
28:     Snapshot,
29:     SourceIdentity,
30:     State,
31:     Target,
32:     WriteResult,
33:     owner_tokens_match,
34: )
35: from joint_mapping import JointSample
36: from joint_reference import prepare_complete_reference, validate_target_vector
37: 
38: __all__ = ("JointCore",)
39: 
40: 
41: @dataclass(frozen=True)
42: class _DispatchClaim:
43:     plan: RefreshPlan
44:     index: int
45:     started_at_s: float
46: 
47: 
48: class JointCore:
49:     """Thread-confined state machine for one fixed, ordered set of joints.
50: 
51:     The core public API assumes trusted station callers; C16 server binds its
52:     actual connection identity rather than trusting client-supplied JSON fields.
53:     No authentication claims are made beyond that boundary.
54:     """
55: 
56:     def __init__(
57:         self,
58:         joints: Iterable[JointSpec],
59:         *,
60:         max_reference_gap_s: float,
61:         feedback_max_age_s: float = 0.5,
62:         max_window_s: float = 1.0,
63:         clock=None,
64:     ):
65:         if isinstance(max_reference_gap_s, bool) or not isinstance(max_reference_gap_s, (int, float)):
66:             raise ValueError("max_reference_gap_s must be a finite positive real number")
67:         try:
68:             max_reference_gap_s = float(max_reference_gap_s)
69:         except (OverflowError, TypeError, ValueError) as exc:
70:             raise ValueError("max_reference_gap_s must be finite") from exc
71:         if not math.isfinite(max_reference_gap_s) or max_reference_gap_s <= 0.0:
72:             raise ValueError("max_reference_gap_s must be finite and positive")
73: 
74:         if isinstance(feedback_max_age_s, bool) or not isinstance(feedback_max_age_s, (int, float)):
75:             raise ValueError("feedback_max_age_s must be a finite positive real number")
76:         try:
77:             feedback_max_age_s = float(feedback_max_age_s)
78:         except (OverflowError, TypeError, ValueError) as exc:
79:             raise ValueError("feedback_max_age_s must be finite") from exc
80:         if not math.isfinite(feedback_max_age_s) or feedback_max_age_s <= 0.0:
81:             raise ValueError("feedback_max_age_s must be finite and positive")
82: 
83:         if isinstance(max_window_s, bool) or not isinstance(max_window_s, (int, float)):
84:             raise ValueError("max_window_s must be a finite positive real number")
85:         try:
86:             max_window_s = float(max_window_s)
87:         except (OverflowError, TypeError, ValueError) as exc:
88:             raise ValueError("max_window_s must be finite") from exc
89:         if not math.isfinite(max_window_s) or max_window_s <= 0.0:
90:             raise ValueError("max_window_s must be finite and positive")
91: 
92:         if clock is None:
93:             clock = time.monotonic
94:         if not callable(clock):
95:             raise ValueError("clock must be callable")
96: 
97:         self._epoch = secrets.token_hex(16)
98: 
99:         try:
100:             specs = tuple(joints)
101:         except TypeError as exc:
102:             raise ValueError("joints must be an iterable of JointSpec") from exc
103:         if not specs:
104:             raise ValueError("at least one active joint is required")
105:         if any(not isinstance(spec, JointSpec) for spec in specs):
106:             raise ValueError("every joint must be a JointSpec")
107:         if len({spec.name for spec in specs}) != len(specs):
108:             raise ValueError("joint names must be unique")
109:         if len({spec.motor_id for spec in specs}) != len(specs):
110:             raise ValueError("motor IDs must be unique")
111: 
112:         self._specs: tuple[JointSpec, ...] = specs
113:         self._id_to_index: dict[int, int] = {
114:             spec.motor_id: index for index, spec in enumerate(specs)
115:         }
116:         self._state: State = State.DISCONNECTED
117:         self._observations: list[JointStatus] = [JointStatus() for _ in specs]
118:         self._source: SourceIdentity | None = None
119:         self._max_reference_gap_s = max_reference_gap_s
120:         self._feedback_max_age_s = feedback_max_age_s
121:         self._max_window_s = max_window_s
122:         self._clock = clock
123:         self._now_high_water_s: float | None = None
124:         self._next_window_id: int = 0
125:         self._offered_window: IntentWindow | None = None
126:         self._next_generation: int = 1
127:         self._latest_owner: OwnerToken | None = None
128:         self._current_owner: OwnerToken | None = None
129:         self._admitted_target: Target | None = None
130:         self._prepared_plan: RefreshPlan | None = None
131:         self._next_plan_id: int = 0
132:         self._next_dispatch_index: int = 0
133:         self._dispatch_claim: _DispatchClaim | None = None
134:         self._dispatched_records: list[JointDispatchedRecord | None] = [None for _ in specs]
135:         self._dispatch_attempts: list[JointDispatchAttempt | None] = [None for _ in specs]
136:         self._confirmed_references: list[JointTrajectoryReference | None] = [None for _ in specs]
137:         self._faults: dict[str, JointFault] = {}
138:         self._last_sequence: int = -1
139: 
140:     @property
141:     def max_reference_gap_s(self) -> float:
142:         return self._max_reference_gap_s
143: 
144:     @property
145:     def joint_specs(self) -> tuple[JointSpec, ...]:
146:         return self._specs
147: 
148:     @property
149:     def admitted_target(self) -> Target | None:
150:         return self._admitted_target
151: 
152:     @staticmethod
153:     def _accepted() -> Decision:
154:         return Decision(True, DecisionCode.ACCEPTED)
155: 
156:     @staticmethod
157:     def _rejected(code: DecisionCode) -> Decision:
158:         return Decision(False, code)
159: 
160:     def _clear_observations(self) -> None:
161:         self._observations = [JointStatus() for _ in self._specs]
162: 
163:     def _invalidate_plan(self) -> None:
164:         self._prepared_plan = None
165:         self._next_dispatch_index = 0
166: 
167:     def _revoke_authority(self) -> None:
168:         self._current_owner = None
169:         self._offered_window = None
170:         self._admitted_target = None
171:         self._invalidate_plan()
172: 
173:     def claim_owner(self, connection_id: str) -> OwnerToken:
174:         """Issue and claim owner authority for a trusted station caller.
175: 
176:         The core public API assumes trusted station callers; C16 server binds its
177:         actual connection identity rather than trusting client-supplied JSON fields.
178:         No authentication claims are made beyond that boundary.
179:         """
180:         if (
181:             type(connection_id) is not str
182:             or not connection_id.strip()
183:             or len(connection_id) > 64
184:         ):
185:             raise ValueError("connection_id must be a bounded non-empty string")
186:         was_owned = self._current_owner is not None
187:         stop_for_claim = self._state in (
188:             State.CHECKING,
189:             State.READY,
190:             State.ARMED,
191:             State.MOVING,
192:         ) or (was_owned and self._state not in (State.DISCONNECTED, State.CONNECTING))
193:         self._revoke_authority()
194:         if self._state in (State.DISCONNECTED, State.CONNECTING):
195:             pass
196:         elif self._state is State.FAULT or self._faults:
197:             self._state = State.FAULT
198:         elif stop_for_claim:
199:             self._state = State.STOPPED
200: 
201:         if self._next_generation > (1 << 64) - 1:
202:             raise OverflowError("owner generation sequence exhausted")
203: 
204:         generation = self._next_generation
205:         self._next_generation += 1
206:         token = OwnerToken(
207:             epoch=self._epoch,
208:             generation=generation,
209:             connection_id=connection_id,
210:         )
211:         self._current_owner = token
212:         self._latest_owner = token
213:         return token
214: 
215:     def _record_dispatch_failure(
216:         self, index: int, cause: CommunicationFailure
217:     ) -> None:
218:         spec = self._specs[index]
219:         self._latch_joint_fault(
220:             spec.name,
221:             spec.motor_id,
222:             communication_error=cause,
223:         )
224:         joint = self._observations[index]
225:         self._observations[index] = JointStatus(
226:             joint.sample,
227:             joint.health,
228:             joint.received_at,
229:             cause,
230:         )
231: 
232:     def _latch_joint_fault(
233:         self,
234:         name: str,
235:         motor_id: int,
236:         *,
237:         errors: int = 0,
238:         warnings: int = 0,
239:         timeout: bool = False,
240:         communication_error: CommunicationFailure | None = None,
241:         stale: bool = False,
242:         position_limit: bool = False,
243:         speed_limit: bool = False,
244:         constraint_fault: bool = False,
245:     ) -> None:
246:         existing = self._faults.get(name) or JointFault(name, motor_id)
247:         communication_errors = existing.communication_errors
248:         if communication_error is not None and communication_error not in communication_errors:
249:             communication_errors += (communication_error,)
250:         fault = JointFault(
251:             name, motor_id,
252:             errors=existing.errors | errors,
253:             warnings=existing.warnings | warnings,
254:             timeout=existing.timeout or timeout,
255:             stale=existing.stale or stale,
256:             communication_error=communication_error or existing.communication_error,
257:             communication_errors=communication_errors,
258:             position_limit=existing.position_limit or position_limit,
259:             speed_limit=existing.speed_limit or speed_limit,
260:             constraint_fault=existing.constraint_fault or constraint_fault,
261:         )
262:         self._faults[name] = fault
263:         if self._state is not State.DISCONNECTED:
264:             self._state = State.FAULT
265:         self._revoke_authority()
266: 
267:     def _withdraw_expired_goal(self) -> None:
268:         self._revoke_authority()
269:         if self._faults:
270:             self._state = State.FAULT
271:         elif self._state in (State.ARMED, State.MOVING):
272:             self._state = State.STOPPED
273: 
274:     def _now(self) -> float:
275:         value = self._clock()
276:         if isinstance(value, bool) or not isinstance(value, (int, float)):
277:             raise ValueError("clock must return a finite real number")
278:         try:
279:             result = float(value)
280:         except (OverflowError, TypeError, ValueError) as exc:
281:             raise ValueError("clock must return a finite real number") from exc
282:         if not math.isfinite(result):
283:             raise ValueError("clock must return a finite real number")
284:         if self._now_high_water_s is not None and result < self._now_high_water_s:
285:             raise ValueError(
286:                 f"clock regressed from {self._now_high_water_s} to {result}"
287:             )
288:         self._now_high_water_s = result
289:         return result
290: 
291:     @staticmethod
292:     def _age(received_at: float, now: float) -> float:
293:         age = now - received_at
294:         if not math.isfinite(age) or age < 0.0:
295:             raise ValueError("clock must be monotonic and feedback age finite")
296:         return age
297: 
298:     def _all_fresh(self, now: float) -> bool:
299:         return all(
300:             joint.valid
301:             and joint.received_at is not None
302:             and self._age(joint.received_at, now) <= self._feedback_max_age_s
303:             for joint in self._observations
304:         )
305: 
306:     def _housekeeping(self, now: float) -> DecisionCode | None:
307:         if self._state in (State.READY, State.ARMED, State.MOVING):
308:             stale_by_joint: list[bool] = []
309:             pos_outside_by_joint: list[bool] = []
310:             speed_outside_by_joint: list[bool] = []
311:             for spec, joint in zip(self._specs, self._observations):
312:                 stale_by_joint.append(
313:                     not joint.valid
314:                     or joint.received_at is None
315:                     or self._age(joint.received_at, now) > self._feedback_max_age_s
316:                 )
317:                 pos_outside_by_joint.append(
318:                     joint.valid
319:                     and joint.sample is not None
320:                     and (joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad)
321:                 )
322:                 speed_outside_by_joint.append(
323:                     joint.valid
324:                     and joint.sample is not None
325:                     and (abs(joint.sample.dq_rad_s) > spec.v_max_rad_s)
326:                 )
327:             for spec, stale, pos_out, speed_out in zip(
328:                 self._specs, stale_by_joint, pos_outside_by_joint, speed_outside_by_joint
329:             ):
330:                 if stale or pos_out or speed_out:
331:                     self._latch_joint_fault(
332:                         spec.name,
333:                         spec.motor_id,
334:                         stale=stale,
335:                         position_limit=pos_out,
336:                         speed_limit=speed_out,
337:                     )
338:             if any(stale_by_joint):
339:                 return DecisionCode.STALE_FEEDBACK
340:             if any(pos_outside_by_joint):
341:                 return DecisionCode.POSITION_OUT_OF_BOUNDS
342:             if any(speed_outside_by_joint):
343:                 return DecisionCode.SPEED_OUT_OF_BOUNDS
344:         if (
345:             self._admitted_target is not None
346:             and now >= self._admitted_target.window.expires_at_s
347:         ):
348:             self._withdraw_expired_goal()
349:             return DecisionCode.EXPIRED
350:         return None
351: 
352:     def issue_window(self, valid_for_s: float) -> IntentWindow:
353:         if isinstance(valid_for_s, bool) or not isinstance(valid_for_s, (int, float)):
354:             raise ValueError("valid_for_s must be a finite positive real number")
355:         try:
356:             valid_for_s = float(valid_for_s)
357:         except (OverflowError, TypeError, ValueError) as exc:
358:             raise ValueError("valid_for_s must be finite") from exc
359:         if not math.isfinite(valid_for_s) or valid_for_s <= 0.0:
360:             raise ValueError("valid_for_s must be finite and positive")
361:         if valid_for_s > self._max_window_s:
362:             raise ValueError(
363:                 f"valid_for_s ({valid_for_s}) exceeds configured maximum window ({self._max_window_s})"
364:             )
365:         now = self._now()
366:         window_id = self._next_window_id
367:         if window_id > (1 << 64) - 1:
368:             raise OverflowError("window ID sequence exhausted")
369:         self._next_window_id += 1
370:         window = IntentWindow(
371:             id=window_id,
372:             created_at_s=now,
373:             expires_at_s=now + valid_for_s,
374:         )
375:         self._offered_window = window
376:         return window
377: 
378:     def begin_connect(self) -> Decision:
379:         if self._state is not State.DISCONNECTED or self._dispatch_claim is not None:
380:             return self._rejected(DecisionCode.INVALID_STATE)
381:         self._state = State.CONNECTING
382:         return self._accepted()
383: 
384:     def connected(self, source: SourceIdentity) -> Decision:
385:         if self._state is not State.CONNECTING:
386:             return self._rejected(DecisionCode.INVALID_STATE)
387:         if not isinstance(source, SourceIdentity):
388:             return self._rejected(DecisionCode.INVALID_SOURCE)
389:         self._clear_observations()
390:         self._source = source
391:         self._state = State.CONNECTED
392:         return self._accepted()
393: 
394:     def begin_check(self, *, acknowledge_fault: bool = False) -> Decision:
395:         if type(acknowledge_fault) is not bool:
396:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
397:         if self._state not in (State.CONNECTED, State.STOPPED, State.FAULT) or self._dispatch_claim is not None:
398:             return self._rejected(DecisionCode.INVALID_STATE)
399:         if bool(self._faults) and not acknowledge_fault:
400:             return self._rejected(DecisionCode.FAULT_ACK_REQUIRED)
401:         self._clear_observations()
402:         self._admitted_target = None
403:         self._confirmed_references = [None for _ in self._specs]
404:         self._invalidate_plan()
405:         self._state = State.CHECKING
406:         return self._accepted()
407: 
408:     def receive(
409:         self, motor_id: int, sample: JointSample, status: MotorHealth
410:     ) -> Decision:
411:         if self._state not in (
412:             State.CONNECTED,
413:             State.CHECKING,
414:             State.READY,
415:             State.ARMED,
416:             State.MOVING,
417:             State.STOPPED,
418:             State.FAULT,
419:         ):
420:             return self._rejected(DecisionCode.INVALID_STATE)
421:         if type(motor_id) is not int:
422:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
423:         index = self._id_to_index.get(motor_id)
424:         if index is None:
425:             return self._rejected(DecisionCode.UNKNOWN_JOINT)
426:         if not isinstance(sample, JointSample) or not isinstance(status, MotorHealth):
427:             return self._rejected(DecisionCode.INVALID_OBSERVATION)
428: 
429:         now = self._now()
430:         self._observations[index] = JointStatus(sample, status, now)
431:         spec = self._specs[index]
432:         position_limit = (
433:             sample.q_rad < spec.q_min_rad or sample.q_rad > spec.q_max_rad
434:         )
435:         speed_limit = (
436:             abs(sample.dq_rad_s) > spec.v_max_rad_s
437:         )
438:         if not status.healthy or position_limit or speed_limit:
439:             self._latch_joint_fault(
440:                 spec.name,
441:                 motor_id,
442:                 errors=status.errors,
443:                 warnings=status.warnings,
444:                 timeout=status.timeout,
445:                 position_limit=position_limit,
446:                 speed_limit=speed_limit,
447:             )
448:         if position_limit:
449:             return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
450:         if speed_limit:
451:             return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
452:         return self._accepted()
453: 
454:     def communication_failed(
455:         self, motor_id: int, code: CommunicationFailure
456:     ) -> Decision:
457:         if self._state in (State.DISCONNECTED, State.CONNECTING):
458:             return self._rejected(DecisionCode.INVALID_STATE)
459:         if type(motor_id) is not int:
460:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
461:         index = self._id_to_index.get(motor_id)
462:         if index is None:
463:             return self._rejected(DecisionCode.UNKNOWN_JOINT)
464: 
465:         if not isinstance(code, CommunicationFailure):
466:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
467:         failure_code = code
468: 
469:         spec = self._specs[index]
470:         self._latch_joint_fault(
471:             spec.name,
472:             motor_id,
473:             communication_error=failure_code,
474:         )
475:         joint = self._observations[index]
476:         self._observations[index] = JointStatus(
477:             joint.sample, joint.health, joint.received_at, failure_code
478:         )
479:         return self._accepted()
480: 
481:     def checked(self) -> Decision:
482:         if self._state is not State.CHECKING:
483:             return self._rejected(DecisionCode.INVALID_STATE)
484:         if any(not joint.valid for joint in self._observations):
485:             return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
486:         now = self._now()
487:         if not self._all_fresh(now):
488:             return self._rejected(DecisionCode.STALE_FEEDBACK)
489:         if any(not joint.healthy for joint in self._observations):
490:             return self._rejected(DecisionCode.UNHEALTHY)
491:         if any(joint.health.mode != 0 for joint in self._observations):
492:             return self._rejected(DecisionCode.NOT_STOPPED)
493: 
494:         pos_out_of_bounds = [
495:             spec
496:             for spec, joint in zip(self._specs, self._observations)
497:             if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
498:         ]
499:         speed_out_of_bounds = [
500:             spec
501:             for spec, joint in zip(self._specs, self._observations)
502:             if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
503:         ]
504:         if pos_out_of_bounds or speed_out_of_bounds:
505:             for spec in pos_out_of_bounds:
506:                 self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
507:             for spec in speed_out_of_bounds:
508:                 self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
509:             if pos_out_of_bounds:
510:                 return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
511:             return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
512: 
513:         self._state = State.READY
514:         self._faults.clear()
515:         self._confirmed_references = [
516:             JointTrajectoryReference(
517:                 q_rad=joint.sample.q_rad,
518:                 position_step_velocity_rad_s=0.0,
519:                 encoded_velocity_rad_s=0.0,
520:                 sample_time_s=joint.received_at,
521:                 is_emitted=False,
522:             )
523:             for joint in self._observations
524:         ]
525:         return self._accepted()
526: 
527:     def arm(self, owner: OwnerToken) -> Decision:
528:         if self._state is not State.READY:
529:             return self._rejected(DecisionCode.INVALID_STATE)
530:         if not owner_tokens_match(owner, self._current_owner):
531:             return self._rejected(DecisionCode.INVALID_OWNER)
532:         if bool(self._faults):
533:             return self._rejected(DecisionCode.FAULT_LATCHED)
534:         if any(not joint.valid for joint in self._observations):
535:             return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
536:         now = self._now()
537:         if not self._all_fresh(now):
538:             return self._rejected(DecisionCode.STALE_FEEDBACK)
539:         if any(not joint.healthy for joint in self._observations):
540:             return self._rejected(DecisionCode.UNHEALTHY)
541:         if any(joint.health.mode != 0 for joint in self._observations):
542:             return self._rejected(DecisionCode.NOT_STOPPED)
543: 
544:         pos_out_of_bounds = [
545:             spec
546:             for spec, joint in zip(self._specs, self._observations)
547:             if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
548:         ]
549:         speed_out_of_bounds = [
550:             spec
551:             for spec, joint in zip(self._specs, self._observations)
552:             if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
553:         ]
554:         if pos_out_of_bounds or speed_out_of_bounds:
555:             for spec in pos_out_of_bounds:
556:                 self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
557:             for spec in speed_out_of_bounds:
558:                 self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
559:             if pos_out_of_bounds:
560:                 return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
561:             return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
562: 
563:         self._state = State.ARMED
564:         return self._accepted()
565: 
566:     def tick(self) -> Decision:
567:         if self._state in (State.DISCONNECTED, State.CONNECTING):
568:             return self._rejected(DecisionCode.INVALID_STATE)
569:         now = self._now()
570:         self._housekeeping(now)
571:         return self._accepted()
572: 
573:     def submit_target(self, target: Target) -> Decision:
574:         if self._state not in (State.ARMED, State.MOVING):
575:             return self._rejected(DecisionCode.INVALID_STATE)
576:         now = self._now()
577:         housekeeping = self._housekeeping(now)
578:         if housekeeping is not None:
579:             return self._rejected(housekeeping)
580:         if self._state not in (State.ARMED, State.MOVING):
581:             return self._rejected(DecisionCode.INVALID_STATE)
582:         if any(not joint.healthy for joint in self._observations):
583:             return self._rejected(DecisionCode.UNHEALTHY)
584: 
585:         if not isinstance(target, Target) or len(target.joints) != len(self._specs):
586:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
587: 
588:         if not owner_tokens_match(target.owner, self._current_owner):
589:             return self._rejected(DecisionCode.INVALID_OWNER)
590: 
591:         if not isinstance(target.window, IntentWindow):
592:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
593:         if self._offered_window is None:
594:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
595:         if target.window.id < self._offered_window.id:
596:             return self._rejected(DecisionCode.EXPIRED)
597:         if target.window.id != self._offered_window.id:
598:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
599:         if (
600:             target.window.created_at_s != self._offered_window.created_at_s
601:             or target.window.expires_at_s != self._offered_window.expires_at_s
602:         ):
603:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
604:         if now >= target.window.expires_at_s:
605:             return self._rejected(DecisionCode.EXPIRED)
606: 
607:         validation_failures = validate_target_vector(self._specs, target)
608:         if validation_failures:
609:             return self._rejected(validation_failures[0].code)
610: 
611:         if target.sequence <= self._last_sequence:
612:             return self._rejected(DecisionCode.DUPLICATE_OR_OLDER)
613: 
614:         self._admitted_target = target
615:         self._last_sequence = target.sequence
616:         self._invalidate_plan()
617:         return self._accepted()
618: 
619:     def prepare_refresh(self) -> RefreshPlan | None:
620:         if self._dispatch_claim is not None:
621:             return None
622:         if self._state not in (State.ARMED, State.MOVING):
623:             return None
624:         if self._state is State.FAULT or bool(self._faults):
625:             return None
626:         try:
627:             now = self._now()
628:         except ValueError:
629:             self.stop()
630:             raise
631:         if self._housekeeping(now) is not None:
632:             return None
633:         if any(not joint.healthy for joint in self._observations):
634:             return None
635:         if self._admitted_target is None:
636:             return None
637:         if not owner_tokens_match(self._admitted_target.owner, self._current_owner):
638:             return None
639: 
640:         for spec, joint in zip(self._specs, self._observations):
641:             if not joint.valid or joint.sample is None:
642:                 return None
643:             pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
644:             speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
645:             if pos_out or speed_out:
646:                 self._latch_joint_fault(spec.name, spec.motor_id, position_limit=pos_out, speed_limit=speed_out)
647:                 self.stop()
648:                 return None
649: 
650:         for spec, conf_ref in zip(self._specs, self._confirmed_references):
651:             if conf_ref is None:
652:                 return None
653:             gap = now - conf_ref.sample_time_s
654:             if not math.isfinite(gap) or gap < 0.0:
655:                 self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
656:                 self.stop()
657:                 return None
658:             if gap > self._max_reference_gap_s:
659:                 self.stop()
660:                 return None
661: 
662:         prepared = prepare_complete_reference(
663:             self._specs,
664:             self._admitted_target,
665:             tuple(self._confirmed_references),
666:             now,
667:             self._max_reference_gap_s,
668:         )
669:         if not prepared.ready:
670:             for failure in prepared.failures:
671:                 if failure.joint_index is None:
672:                     continue
673:                 spec = self._specs[failure.joint_index]
674:                 if failure.code is DecisionCode.POSITION_OUT_OF_BOUNDS:
675:                     self._latch_joint_fault(
676:                         spec.name, spec.motor_id, position_limit=True
677:                     )
678:                 elif failure.code is DecisionCode.SPEED_OUT_OF_BOUNDS:
679:                     self._latch_joint_fault(
680:                         spec.name, spec.motor_id, speed_limit=True
681:                     )
682:                 else:
683:                     self._latch_joint_fault(
684:                         spec.name, spec.motor_id, constraint_fault=True
685:                     )
686:             self.stop()
687:             return None
688: 
689:         plan_id = self._next_plan_id
690:         if plan_id > (1 << 64) - 1:
691:             raise OverflowError("plan ID sequence exhausted")
692:         self._next_plan_id += 1
693: 
694:         plan = RefreshPlan(
695:             plan_id=plan_id,
696:             target=self._admitted_target,
697:             prepared_at_s=now,
698:             joint_targets=prepared.joint_targets,
699:             packets=prepared.packets,
700:             proposed_references=prepared.proposed_references,
701:         )
702:         self._prepared_plan = plan
703:         self._next_dispatch_index = 0
704:         return plan
705: 
706:     def claim_dispatch(self, plan_id: int, index: int) -> bool:
707:         if (
708:             type(plan_id) is not int
709:             or type(index) is not int
710:         ):
711:             return False
712:         if self._dispatch_claim is not None:
713:             return False
714:         if self._prepared_plan is None or self._prepared_plan.plan_id != plan_id:
715:             return False
716:         if self._state not in (State.ARMED, State.MOVING):
717:             return False
718:         if self._state is State.FAULT or bool(self._faults):
719:             return False
720:         if index < 0 or index >= len(self._specs):
721:             return False
722:         if index != self._next_dispatch_index:
723:             return False
724: 
725:         now = self._now()
726:         if self._housekeeping(now) is not None:
727:             return False
728:         if self._admitted_target is None or self._prepared_plan is None:
729:             return False
730:         if not owner_tokens_match(self._prepared_plan.target.owner, self._current_owner):
731:             return False
732:         if any(not joint.healthy for joint in self._observations):
733:             return False
734: 
735:         if not self._all_fresh(now):
736:             return False
737:         for spec, joint in zip(self._specs, self._observations):
738:             if not joint.valid or joint.sample is None:
739:                 return False
740:             pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
741:             speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
742:             if pos_out or speed_out:
743:                 self._latch_joint_fault(spec.name, spec.motor_id, position_limit=pos_out, speed_limit=speed_out)
744:                 self.stop()
745:                 return False
746: 
747:         conf_ref = self._confirmed_references[index]
748:         if conf_ref is not None:
749:             gap = now - conf_ref.sample_time_s
750:             if not math.isfinite(gap) or gap < 0.0 or gap > self._max_reference_gap_s:
751:                 self.stop()
752:                 return False
753: 
754:         plan_joint = self._prepared_plan.joint_targets[index]
755:         spec = self._specs[index]
756:         if plan_joint.q_rad < spec.q_min_rad or plan_joint.q_rad > spec.q_max_rad:
757:             self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
758:             self.stop()
759:             return False
760:         if abs(plan_joint.dq_rad_s) > spec.v_max_rad_s:
761:             self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
762:             self.stop()
763:             return False
764: 
765:         prop_ref = self._prepared_plan.proposed_references[index]
766:         if (
767:             prop_ref.requested_goal != self._prepared_plan.target.joints[index]
768:             or prop_ref.emitted_target != plan_joint
769:             or prop_ref.packet != self._prepared_plan.packets[index]
770:             or prop_ref.sample_time_s > self._prepared_plan.prepared_at_s
771:         ):
772:             self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
773:             self.stop()
774:             return False
775:         if conf_ref is None:
776:             self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
777:             self.stop()
778:             return False
779:         if prop_ref.sample_time_s == conf_ref.sample_time_s:
780:             if prop_ref != conf_ref:
781:                 self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
782:                 self.stop()
783:                 return False
784:         elif (
785:             prop_ref.sample_time_s != self._prepared_plan.prepared_at_s
786:             or prop_ref.sample_time_s <= conf_ref.sample_time_s
787:         ):
788:             self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
789:             self.stop()
790:             return False
791:         if (
792:             abs(prop_ref.position_step_velocity_rad_s) > Fraction(spec.v_max_rad_s)
793:             or abs(Fraction(prop_ref.encoded_velocity_rad_s)) > Fraction(spec.v_max_rad_s)
794:         ):
795:             self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
796:             self.stop()
797:             return False
798: 
799:         self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
800:         return True
801: 
802:     def dispatch_result(
803:         self, plan_id: int, index: int, result: WriteResult
804:     ) -> Decision:
805:         if (
806:             type(plan_id) is not int
807:             or type(index) is not int
808:         ):
809:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
810:         if not isinstance(result, WriteResult):
811:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
812:         claim = self._dispatch_claim
813:         if claim is None or claim.plan.plan_id != plan_id or claim.index != index:
814:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
815:         if index < 0 or index >= len(self._specs):
816:             return self._rejected(DecisionCode.INVALID_ARGUMENT)
817: 
818:         plan = claim.plan
819:         joint_target = plan.joint_targets[index]
820:         self._dispatch_attempts[index] = JointDispatchAttempt(
821:             plan_id=plan.plan_id,
822:             sequence=plan.target.sequence,
823:             target=joint_target,
824:             result=result,
825:             started_at_s=claim.started_at_s,
826:             owner=plan.target.owner,
827:         )
828:         if result is WriteResult.COMPLETE:
829:             record = JointDispatchedRecord(
830:                 sequence=plan.target.sequence,
831:                 target=joint_target,
832:                 dispatched_at_s=claim.started_at_s,
833:                 owner=plan.target.owner,
834:             )
835:             self._dispatched_records[index] = record
836:             self._confirmed_references[index] = plan.proposed_references[index]
837:             try:
838:                 now = self._now()
839:             except Exception:
840:                 self._record_dispatch_failure(index, CommunicationFailure.CLOCK_FAILURE)
841:                 self._dispatch_claim = None
842:                 return self._rejected(DecisionCode.FAULT_LATCHED)
843: 
844:             housekeeping = self._housekeeping(now)
845:             still_current = (
846:                 self._prepared_plan is plan
847:                 and self._admitted_target is plan.target
848:                 and self._state in (State.ARMED, State.MOVING)
849:                 and not self._faults
850:                 and owner_tokens_match(self._current_owner, plan.target.owner)
851:             )
852:             if still_current and housekeeping is None:
853:                 self._next_dispatch_index = index + 1
854:                 self._state = State.MOVING
855:             self._dispatch_claim = None
856:             return self._accepted()
857: 
858:         cause = (
859:             CommunicationFailure.PREWRITE_DEADLINE
860:             if result is WriteResult.PREWRITE_DEADLINE
861:             else CommunicationFailure.DRIVER_FAILURE
862:         )
863:         self._record_dispatch_failure(index, cause)
864:         self._dispatch_claim = None
865:         return self._rejected(DecisionCode.FAULT_LATCHED)
866: 
867:     def stop(self) -> Decision:
868:         if self._state in (State.DISCONNECTED, State.CONNECTING):
869:             return self._rejected(DecisionCode.INVALID_STATE)
870:         self._revoke_authority()
871:         if self._state is State.FAULT or bool(self._faults):
872:             self._state = State.FAULT
873:         else:
874:             self._state = State.STOPPED
875:         return self._accepted()
876: 
877:     def disconnect(self) -> Decision:
878:         self._state = State.DISCONNECTED
879:         self._source = None
880:         self._clear_observations()
881:         self._confirmed_references = [None for _ in self._specs]
882:         self._revoke_authority()
883:         return self._accepted()
884: 
885:     def snapshot(self) -> Snapshot:
886:         received = [joint.received_at for joint in self._observations]
887:         now = self._now() if any(value is not None for value in received) else None
888:         ages = tuple(
889:             None if value is None else self._age(value, now)
890:             for value in received
891:         )
892:         faults = tuple(self._faults[spec.name] for spec in self._specs
893:                        if spec.name in self._faults)
894:         return Snapshot(
895:             state=self._state,
896:             joint_names=tuple(spec.name for spec in self._specs),
897:             joints=tuple(self._observations),
898:             source=self._source,
899:             fault_latched=bool(self._faults),
900:             feedback_ages_s=ages,
901:             faults=faults,
902:             admitted_target=self._admitted_target,
903:             prepared_plan=self._prepared_plan,
904:             dispatched_records=tuple(self._dispatched_records),
905:             dispatch_attempts=tuple(self._dispatch_attempts),
906:             last_sequence=self._last_sequence,
907:             latest_owner=self._latest_owner,
908:             current_owner=self._current_owner,
909:             confirmed_references=tuple(self._confirmed_references),
910:         )

## test_controller_limits.py
1: """Targeted unit and acceptance tests for C09 inclusive joint position bounds."""
2: 
3: import math
4: import random
5: import struct
6: import unittest
7: from dataclasses import replace
8: from fractions import Fraction
9: from unittest.mock import patch
10: 
11: from im6014_codec import (
12:     POSITION_MAX,
13:     POSITION_MIN,
14:     RAW_POSITION_MAX,
15:     RAW_POSITION_MIN,
16:     RATIO,
17:     RPM_MAX,
18:     RPM_MIN,
19:     command,
20:     command_with_raw_position,
21:     crc32,
22:     decode_command,
23:     position_to_raw,
24:     project_position_raw,
25:     raw_to_position,
26: )
27: from joint_contract import (
28:     CommunicationFailure,
29:     DecisionCode,
30:     IntentWindow,
31:     JointDispatchAttempt,
32:     JointDispatchedRecord,
33:     JointFault,
34:     JointSpec,
35:     JointStatus,
36:     JointTrajectoryReference,
37:     MotorHealth,
38:     OwnerToken,
39:     RefreshPlan,
40:     Snapshot,
41:     SourceIdentity,
42:     State,
43:     Target,
44:     WriteResult,
45:     owner_tokens_match,
46: )
47: from joint_controller import JointCore
48: from joint_mapping import JointMap, JointSample, JointTarget, OutputSample
49: from joint_reference import (
50:     ReferenceBatchResult,
51:     ReferenceFailure,
52:     prepare_reference_joint,
53:     shape_reference_joint,
54: )
55: from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP, SAMPLE
56: 
57: SOURCE = SourceIdentity("fixture", "limits-test", 1)
58: 
59: 
60: def _with_command_crc(packet):
61:     return packet[:16] + struct.pack("<I", crc32(packet[:16]))
62: 
63: 
64: class PositionLimitTests(unittest.TestCase):
65:     def setUp(self):
66:         self.clock = DeterministicClock(0.0)
67:         self.specs = (
68:             JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1.0, 2.0, 100.0, "fixture: software position limits J1"),
69:             JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -0.5, 0.5, 100.0, "fixture: software position limits J2"),
70:         )
71:         self.valid_sample_j1 = JointSample(0.1, 0.0, 0.0)
72:         self.valid_sample_j2 = JointSample(0.0, 0.0, 0.0)
73: 
74:     def _armed_station(self, connection_id="tester"):
75:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
76:         station = FakeStation(core)
77:         self.assertTrue(station.connect().accepted)
78:         owner = station.claim(connection_id)
79:         # Check with valid within-bounds observations
80:         self.assertTrue(core.begin_check().accepted)
81:         self.assertTrue(core.receive(0, self.valid_sample_j1, HEALTHY_STOP).accepted)
82:         self.assertTrue(core.receive(1, self.valid_sample_j2, HEALTHY_STOP).accepted)
83:         self.assertTrue(core.checked().accepted)
84:         self.assertTrue(station.arm(owner).accepted)
85:         return core, station, owner
86: 
87:     @staticmethod
88:     def _project(spec, wanted_q):
89:         return project_position_raw(
90:             wanted_q,
91:             spec.q_min_rad,
92:             spec.q_max_rad,
93:             lambda output_q: spec.mapping.from_output(
94:                 OutputSample(output_q, 0.0, 0.0)
95:             ).q_rad,
96:             spec.mapping.direction,
97:         )
98: 
99:     def test_exact_lower_and_upper_requests_accepted(self):
100:         core, station, owner = self._armed_station()
101:         window = station.issue_window(1.0)
102: 
103:         # Exact lower on J1 (-1.0), exact upper on J2 (0.5)
104:         t1 = Target(
105:             1,
106:             (
107:                 JointTarget(-1.0, 0.0, 0.0, 1.0, 0.1),
108:                 JointTarget(0.5, 0.0, 0.0, 1.0, 0.1),
109:             ),
110:             window=window,
111:             owner=owner,
112:         )
113:         dec1 = station.submit(t1)
114:         self.assertTrue(dec1.accepted)
115:         self.assertEqual(core.snapshot().last_sequence, 1)
116: 
117:         station.writes.clear()
118:         self.clock.value += 0.05
119:         plan = station.refresh()
120:         self.assertIsNotNone(plan)
121:         self.assertEqual(len(station.writes), 2)
122:         self.assertEqual(station.writes, list(plan.packets))
123:         self.assertIs(core.snapshot().state, State.MOVING)
124: 
125:         # Exact upper on J1 (2.0), exact lower on J2 (-0.5)
126:         t2 = Target(
127:             2,
128:             (
129:                 JointTarget(2.0, 0.0, 0.0, 1.0, 0.1),
130:                 JointTarget(-0.5, 0.0, 0.0, 1.0, 0.1),
131:             ),
132:             window=window,
133:             owner=owner,
134:         )
135:         dec2 = station.submit(t2)
136:         self.assertTrue(dec2.accepted)
137:         self.assertEqual(core.snapshot().last_sequence, 2)
138: 
139:     def test_one_representable_step_outside_bounds_rejected(self):
140:         core, station, owner = self._armed_station()
141:         window = station.issue_window(1.0)
142: 
143:         prior_target = Target(
144:             1,
145:             (
146:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
147:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
148:             ),
149:             window=window,
150:             owner=owner,
151:         )
152:         self.assertTrue(station.submit(prior_target).accepted)
153:         self.assertEqual(core.snapshot().last_sequence, 1)
154: 
155:         # One step below lower bound on J1 (-1.0001 < -1.0)
156:         below = Target(
157:             2,
158:             (
159:                 JointTarget(-1.0001, 0.0, 0.0, 1.0, 0.1),
160:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
161:             ),
162:             window=window,
163:             owner=owner,
164:         )
165:         dec_below = station.submit(below)
166:         self.assertFalse(dec_below.accepted)
167:         self.assertEqual(dec_below.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
168:         self.assertEqual(core.snapshot().admitted_target, prior_target)
169:         self.assertEqual(core.snapshot().last_sequence, 1)
170: 
171:         # One step above upper bound on J2 (0.5001 > 0.5)
172:         above = Target(
173:             3,
174:             (
175:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
176:                 JointTarget(0.5001, 0.0, 0.0, 1.0, 0.1),
177:             ),
178:             window=window,
179:             owner=owner,
180:         )
181:         dec_above = station.submit(above)
182:         self.assertFalse(dec_above.accepted)
183:         self.assertEqual(dec_above.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
184:         self.assertEqual(core.snapshot().admitted_target, prior_target)
185:         self.assertEqual(core.snapshot().last_sequence, 1)
186: 
187:     def test_negative_direction_and_nonzero_zero_reduction_map(self):
188:         specs_mapped = (
189:             JointSpec(
190:                 "J1",
191:                 0,
192:                 JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25),
193:                 -1.0,
194:                 1.0,
195:                 100.0,
196:                 "fixture: software limits negative direction",
197:             ),
198:             JointSpec(
199:                 "J2",
200:                 1,
201:                 JointMap(reduction=2.0, direction=1, zero_output_rad=-0.1),
202:                 -0.5,
203:                 0.5,
204:                 100.0,
205:                 "fixture: software limits positive direction",
206:             ),
207:         )
208:         core = JointCore(specs_mapped, clock=self.clock, max_reference_gap_s=1.0)
209:         station = FakeStation(core)
210:         self.assertTrue(station.connect().accepted)
211:         owner = station.claim("mapped-client")
212:         self.assertTrue(core.begin_check().accepted)
213:         self.assertTrue(core.receive(0, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
214:         self.assertTrue(core.receive(1, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
215:         self.assertTrue(core.checked().accepted)
216:         self.assertTrue(station.arm(owner).accepted)
217: 
218:         window = station.issue_window(1.0)
219:         # Exact lower on J1 (-1.0), exact upper on J2 (0.5)
220:         target = Target(
221:             1,
222:             (
223:                 JointTarget(-1.0, 0.0, 0.0, 1.0, 0.1),
224:                 JointTarget(0.5, 0.0, 0.0, 1.0, 0.1),
225:             ),
226:             window=window,
227:             owner=owner,
228:         )
229:         self.assertTrue(station.submit(target).accepted)
230:         station.writes.clear()
231:         self.clock.value += 0.05
232:         plan = station.refresh()
233:         self.assertIsNotNone(plan)
234:         self.assertEqual(len(station.writes), 2)
235:         self.assertEqual(station.writes, list(plan.packets))
236: 
237:         # Verify decoded command positions stay within bounds
238:         dec_pkt_0 = decode_command(station.writes[0])
239:         decoded_sample_0 = specs_mapped[0].mapping.from_output(
240:             OutputSample(dec_pkt_0["position_rad"], 0.0, 0.0)
241:         )
242:         self.assertGreaterEqual(decoded_sample_0.q_rad, specs_mapped[0].q_min_rad)
243:         self.assertLessEqual(decoded_sample_0.q_rad, specs_mapped[0].q_max_rad)
244: 
245:         # Target outside bounds with negative direction is rejected
246:         outside = Target(
247:             2,
248:             (
249:                 JointTarget(1.05, 0.0, 0.0, 1.0, 0.1),
250:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
251:             ),
252:             window=window,
253:             owner=owner,
254:         )
255:         rej = station.submit(outside)
256:         self.assertFalse(rej.accepted)
257:         self.assertEqual(rej.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
258: 
259:     def test_zero_width_interval_and_no_representable_safe_command(self):
260:         # Case A: zero-width interval on exact representable grid point
261:         raw_code = 1000
262:         grid_pos = raw_to_position(raw_code)
263:         spec_zero_width = JointSpec(
264:             "J1",
265:             0,
266:             JointMap(1.0, 1, 0.0),
267:             grid_pos,
268:             grid_pos,
269:             10.0,
270:             "fixture: exact grid point interval",
271:         )
272:         found_code = self._project(spec_zero_width, grid_pos)
273:         self.assertEqual(found_code, raw_code)
274: 
275:         # Case B: interval strictly between two representable grid points
276:         raw0 = 2000
277:         raw1 = 2001
278:         pos0 = raw_to_position(raw0)
279:         pos1 = raw_to_position(raw1)
280:         mid = (pos0 + pos1) / 2.0
281:         # Interval narrower than one raw step containing no integer code
282:         spec_empty_grid = JointSpec(
283:             "J1",
284:             0,
285:             JointMap(1.0, 1, 0.0),
286:             mid - 1e-9,
287:             mid + 1e-9,
288:             10.0,
289:             "fixture: empty grid interval",
290:         )
291:         found_none = self._project(spec_empty_grid, mid)
292:         self.assertIsNone(found_none)
293: 
294:         # Submission on spec with no representable command is rejected
295:         core = JointCore((spec_empty_grid,), clock=self.clock, max_reference_gap_s=1.0)
296:         station = FakeStation(core)
297:         self.assertTrue(station.connect().accepted)
298:         owner = station.claim("zero-client")
299:         self.assertTrue(core.begin_check().accepted)
300:         self.assertTrue(core.receive(0, JointSample(mid, 0.0, 0.0), HEALTHY_STOP).accepted)
301:         self.assertTrue(core.checked().accepted)
302:         self.assertTrue(station.arm(owner).accepted)
303: 
304:         w = station.issue_window(1.0)
305:         t = Target(1, (JointTarget(mid, 0.0, 0.0, 1.0, 0.1),), window=w, owner=owner)
306:         dec = station.submit(t)
307:         self.assertFalse(dec.accepted)
308:         self.assertEqual(dec.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
309: 
310:     def test_malformed_spec_and_fault_config_rejected(self):
311:         mapping = JointMap(1.0, 1, 0.0)
312: 
313:         # q_min_rad > q_max_rad
314:         with self.assertRaises(ValueError):
315:             JointSpec("J1", 0, mapping, 1.0, 0.0, 10.0, "fixture: invalid min max")
316: 
317:         # non-numeric / bool types
318:         with self.assertRaises(ValueError):
319:             JointSpec("J1", 0, mapping, True, 1.0, 10.0, "fixture: bool min")
320:         with self.assertRaises(ValueError):
321:             JointSpec("J1", 0, mapping, 0.0, False, 10.0, "fixture: bool max")
322:         with self.assertRaises(ValueError):
323:             JointSpec("J1", 0, mapping, "0.0", 1.0, 10.0, "fixture: str min")
324: 
325:         # infinite / NaN
326:         with self.assertRaises(ValueError):
327:             JointSpec("J1", 0, mapping, float("-inf"), 1.0, 10.0, "fixture: neg inf min")
328:         with self.assertRaises(ValueError):
329:             JointSpec("J1", 0, mapping, 0.0, float("inf"), 10.0, "fixture: inf max")
330:         with self.assertRaises(ValueError):
331:             JointSpec("J1", 0, mapping, float("nan"), 1.0, 10.0, "fixture: nan min")
332:         with self.assertRaises(ValueError):
333:             JointSpec("J1", 0, mapping, 0, 10**400, 10.0, "fixture: overflowing max")
334: 
335:         # v_max_rad_s <= 0 or not finite
336:         with self.assertRaises(ValueError):
337:             JointSpec("J1", 0, mapping, -1.0, 1.0, 0.0, "fixture: zero v_max")
338:         with self.assertRaises(ValueError):
339:             JointSpec("J1", 0, mapping, -1.0, 1.0, -10.0, "fixture: negative v_max")
340:         with self.assertRaises(ValueError):
341:             JointSpec("J1", 0, mapping, -1.0, 1.0, float("inf"), "fixture: inf v_max")
342:         with self.assertRaises(ValueError):
343:             JointSpec("J1", 0, mapping, -1.0, 1.0, float("nan"), "fixture: nan v_max")
344:         with self.assertRaises(ValueError):
345:             JointSpec("J1", 0, mapping, -1.0, 1.0, "10.0", "fixture: str v_max")
346: 
347:         # invalid provenance
348:         with self.assertRaises(ValueError):
349:             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "")
350:         with self.assertRaises(ValueError):
351:             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "   ")
352:         with self.assertRaises(ValueError):
353:             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 123)
354:         with self.assertRaises(ValueError):
355:             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "x" * 257)
356: 
357:         with self.assertRaises(TypeError):
358:             JointSpec("J1", 0, mapping, -1.0, 1.0)
359:         with self.assertRaises(TypeError):
360:             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0)
361:         with self.assertRaises(TypeError):
362:             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, provenance="legacy alias")
363: 
364:         # JointFault position_limit type validation
365:         with self.assertRaises(ValueError):
366:             JointFault("J1", 0, position_limit="bad")
367:         with self.assertRaises(ValueError):
368:             JointFault("J1", 0, speed_limit="bad")
369:         with self.assertRaises(ValueError):
370:             JointFault("J1", 0, constraint_fault="bad")
371:         jf = JointFault("J1", 0, position_limit=True, speed_limit=True, constraint_fault=True)
372:         self.assertTrue(jf.position_limit)
373:         self.assertTrue(jf.speed_limit)
374:         self.assertTrue(jf.constraint_fault)
375:         self.assertFalse(hasattr(jf, "position_out_of_bounds"))
376: 
377:     def test_multi_joint_invalid_last_joint_cannot_replace_goal_or_watermark(self):
378:         core, station, owner = self._armed_station()
379:         window = station.issue_window(1.0)
380: 
381:         prior_target = Target(
382:             1,
383:             (
384:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
385:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
386:             ),
387:             window=window,
388:             owner=owner,
389:         )
390:         self.assertTrue(station.submit(prior_target).accepted)
391:         self.assertEqual(core.snapshot().last_sequence, 1)
392: 
393:         # Target 2: Joint 0 valid (0.2 within [-1.0, 2.0]), Joint 1 invalid (10.0 outside [-0.5, 0.5])
394:         invalid_target = Target(
395:             2,
396:             (
397:                 JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
398:                 JointTarget(10.0, 0.0, 0.0, 1.0, 0.1),
399:             ),
400:             window=window,
401:             owner=owner,
402:         )
403:         decision = station.submit(invalid_target)
404:         self.assertFalse(decision.accepted)
405:         self.assertEqual(decision.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
406: 
407:         # Atomically preserves admitted target and watermark sequence
408:         self.assertEqual(core.snapshot().admitted_target, prior_target)
409:         self.assertEqual(core.snapshot().last_sequence, 1)
410: 
411:     def test_measured_outside_bounds_at_admission_and_final_write_gate(self):
412:         # 1. Measured outside at receive during checking latches fault
413:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
414:         self.assertTrue(core.begin_connect().accepted)
415:         self.assertTrue(core.connected(SOURCE).accepted)
416:         self.assertTrue(core.begin_check().accepted)
417:         # J1 upper bound is 2.0; receive 2.5
418:         rej = core.receive(0, JointSample(2.5, 0.0, 0.0), HEALTHY_STOP)
419:         self.assertFalse(rej.accepted)
420:         self.assertEqual(rej.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
421:         self.assertTrue(core.snapshot().faults[0].position_limit)
422:         self.assertIs(core.snapshot().state, State.FAULT)
423: 
424:         # 2. Final write gate rechecks current measured bounds
425:         core2, station2, owner2 = self._armed_station("gate-client")
426:         w2 = station2.issue_window(1.0)
427:         t2 = Target(
428:             1,
429:             (
430:                 JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
431:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
432:             ),
433:             window=w2,
434:             owner=owner2,
435:         )
436:         self.assertTrue(station2.submit(t2).accepted)
437:         self.clock.value += 0.05
438:         plan = core2.prepare_refresh()
439:         self.assertIsNotNone(plan)
440: 
441:         # Before claim_dispatch, feedback reports J2 position exceeds upper limit 0.5
442:         core2.receive(1, JointSample(0.6, 0.0, 0.0), HEALTHY_STOP)
443:         # claim_dispatch must fail, latch position_limit fault, and deny write
444:         claimed = core2.claim_dispatch(plan.plan_id, 0)
445:         self.assertFalse(claimed)
446:         joint2_fault = next(
447:             fault for fault in core2.snapshot().faults if fault.motor_id == self.specs[1].motor_id
448:         )
449:         self.assertTrue(joint2_fault.position_limit)
450:         self.assertIs(core2.snapshot().state, State.FAULT)
451: 
452:     def test_unhealthy_outside_feedback_preserves_both_fault_causes(self):
453:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
454:         self.assertTrue(core.begin_connect().accepted)
455:         self.assertTrue(core.connected(SOURCE).accepted)
456:         self.assertTrue(core.begin_check().accepted)
457:         unhealthy = MotorHealth(mode=0, errors=0x04, warnings=2, timeout=True)
458: 
459:         decision = core.receive(0, JointSample(2.5, 0.0, 0.0), unhealthy)
460: 
461:         self.assertEqual(decision.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
462:         self.assertEqual(core.snapshot().affected_joints, ("J1",))
463:         fault = core.snapshot().faults[0]
464:         self.assertEqual(fault.errors, 0x04)
465:         self.assertEqual(fault.warnings, 2)
466:         self.assertTrue(fault.timeout)
467:         self.assertTrue(fault.position_limit)
468: 
469:     def test_attributed_fault_and_recovery(self):
470:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
471:         station = FakeStation(core)
472:         self.assertTrue(station.connect().accepted)
473:         owner = station.claim("recovery-tester")
474:         self.assertTrue(core.begin_check().accepted)
475:         # Induce position_limit fault on J1
476:         core.receive(0, JointSample(3.0, 0.0, 0.0), HEALTHY_STOP)
477:         self.assertTrue(core.snapshot().faults[0].position_limit)
478:         self.assertFalse(hasattr(core.snapshot().faults[0], "position_out_of_bounds"))
479: 
480:         # Submitting new target does NOT clear fault
481:         w = station.issue_window(1.0)
482:         t = Target(1, (JointTarget(0.0, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)), window=w, owner=owner)
483:         dec = station.submit(t)
484:         self.assertFalse(dec.accepted)
485:         self.assertTrue(core.snapshot().faults[0].position_limit)
486: 
487:         # arm fails while faulted
488:         self.assertFalse(station.arm(owner).accepted)
489: 
490:         # Recovery attempt with measured position still out of bounds fails
491:         self.assertTrue(station.stop().accepted)
492:         owner2 = station.claim("recovery-tester-2")
493:         self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
494:         self.assertFalse(core.receive(0, JointSample(3.0, 0.0, 0.0), HEALTHY_STOP).accepted)
495:         self.assertFalse(core.checked().accepted)
496: 
497:         # Proper recovery with acknowledged stop check inside bounds succeeds
498:         self.assertTrue(station.stop().accepted)
499:         owner3 = station.claim("recovery-tester-3")
500:         self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
501:         self.assertTrue(core.receive(0, self.valid_sample_j1, HEALTHY_STOP).accepted)
502:         self.assertTrue(core.receive(
503:             1, JointSample(self.specs[1].q_max_rad, 0.0, 0.0), HEALTHY_STOP
504:         ).accepted)
505:         self.assertTrue(core.checked().accepted)
506:         self.assertTrue(station.arm(owner3).accepted)
507:         self.assertEqual(core.snapshot().faults, ())
508:         self.assertFalse(core.snapshot().fault_latched)
509: 
510:     def test_codec_rounding_overshoot_produces_inward_actual_safe_endpoint(self):
511:         spec = JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -0.1, 0.1, 10.0, "fixture: rounding overshoot test")
512:         target = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
513: 
514:         requested_output = spec.mapping.to_output(target)
515:         requested_raw = position_to_raw(requested_output.q_rad)
516:         self.assertEqual(requested_raw, 6606)
517:         self.assertGreater(raw_to_position(requested_raw), spec.q_max_rad)
518: 
519:         code, actual_target, packet = prepare_reference_joint(spec, target)
520:         self.assertIsNone(code)
521:         self.assertIsNotNone(actual_target)
522:         self.assertIsNotNone(packet)
523: 
524:         # Actual reference must be strictly <= spec.q_max_rad
525:         self.assertLessEqual(actual_target.q_rad, spec.q_max_rad)
526:         self.assertGreaterEqual(actual_target.q_rad, spec.q_min_rad)
527: 
528:         dec = decode_command(packet)
529:         self.assertEqual(dec["raw_position"], 6605)
530:         self.assertLess(raw_to_position(dec["raw_position"]), spec.q_max_rad)
531:         self.assertEqual(dec["position_rad"], raw_to_position(dec["raw_position"]))
532: 
533:         requested = decode_command(command(
534:             spec.motor_id,
535:             mode=1,
536:             rpm=requested_output.rpm,
537:             kd=requested_output.kd,
538:             torque=requested_output.tau_nm,
539:             watchdog=True,
540:             position=requested_output.q_rad,
541:             kp=requested_output.kp,
542:         ))
543:         for field in ("raw_rpm", "raw_torque", "raw_kp", "raw_kd"):
544:             self.assertEqual(dec[field], requested[field])
545:         self.assertEqual(actual_target.q_rad, spec.mapping.from_output(
546:             OutputSample(dec["position_rad"], dec["rpm"], dec["torque_nm"])
547:         ).q_rad)
548:         self.assertEqual(packet, command_with_raw_position(
549:             spec.motor_id,
550:             6605,
551:             mode=1,
552:             rpm=requested_output.rpm,
553:             kd=requested_output.kd,
554:             torque=requested_output.tau_nm,
555:             watchdog=True,
556:             kp=requested_output.kp,
557:         ))
558: 
559:     def test_repeated_safe_refresh_preserves_canonical_packets_and_inward_reference(self):
560:         core, station, owner = self._armed_station()
561:         window = station.issue_window(1.0)
562:         # Use codec-grid goals and a positive cadence with representable motion.
563:         endpoint_j1 = raw_to_position(position_to_raw(1.0))
564:         endpoint_j2 = raw_to_position(position_to_raw(0.4))
565:         target = Target(
566:             1,
567:             (
568:                 JointTarget(endpoint_j1, 0.0, 0.0, 1.0, 0.1),
569:                 JointTarget(endpoint_j2, 0.0, 0.0, 1.0, 0.1),
570:             ),
571:             window=window,
572:             owner=owner,
573:         )
574:         self.assertTrue(station.submit(target).accepted)
575: 
576:         # Multiple refreshes within window emit canonical packets consistently
577:         for step in range(5):
578:             self.clock.value += 0.01
579:             station.writes.clear()
580:             plan = station.refresh()
581:             self.assertIsNotNone(plan)
582:             self.assertEqual(len(station.writes), 2)
583:             self.assertEqual(station.writes, list(plan.packets))
584:             self.assertEqual(core.snapshot().last_sequence, 1)
585:             self.assertIs(core.snapshot().state, State.MOVING)
586: 
587:     def test_im6014_codec_decode_command_and_helpers(self):
588:         pkt = command(
589:             2,
590:             mode=1,
591:             position=1.5,
592:             rpm=10.0,
593:             torque=0.5,
594:             kp=5.0,
595:             kd=1.0,
596:             watchdog=True,
597:         )
598:         dec = decode_command(pkt)
599:         self.assertEqual(dec["motor_id"], 2)
600:         self.assertEqual(dec["mode"], 1)
601:         self.assertTrue(dec["watchdog"])
602:         self.assertEqual(dec["raw_position"], position_to_raw(1.5))
603:         self.assertAlmostEqual(dec["position_rad"], 1.5, delta=1e-4)
604:         self.assertEqual(dec["raw_rpm"], 135)
605:         self.assertEqual(dec["rpm"], 135 / 64 / RATIO * 60)
606:         self.assertEqual(dec["raw_torque"], 101)
607:         self.assertEqual(dec["torque_nm"], 101 / 2560 * RATIO)
608: 
609:         # Corrupt CRC
610:         corrupt = bytearray(pkt)
611:         corrupt[-1] ^= 0xFF
612:         with self.assertRaises(ValueError):
613:             decode_command(bytes(corrupt))
614: 
615:         # Invalid length
616:         with self.assertRaises(ValueError):
617:             decode_command(pkt[:19])
618: 
619:         # Stop commands are valid canonical packets.
620:         stop_pkt = command(2, mode=0)
621:         decoded_stop = decode_command(stop_pkt)
622:         self.assertEqual(decoded_stop["mode"], 0)
623:         self.assertEqual(decoded_stop["raw_position"], 0)
624:         no_watchdog_stop = decode_command(command(2, mode=0, watchdog=False))
625:         self.assertEqual(no_watchdog_stop["mode"], 0)
626:         self.assertFalse(no_watchdog_stop["watchdog"])
627: 
628:         for byte_index, value in ((0, 0), (1, 0), (3, 1)):
629:             malformed = bytearray(pkt)
630:             malformed[byte_index] = value
631:             with self.subTest(byte_index=byte_index), self.assertRaises(ValueError):
632:                 decode_command(_with_command_crc(malformed))
633: 
634:         for field, update in (
635:             ("reserved mode bits", lambda raw: raw.__setitem__(2, raw[2] | 0x20)),
636:             ("invalid individual ID", lambda raw: raw.__setitem__(2, (raw[2] & 0xF0) | 0x0F)),
637:             ("missing FOC watchdog", lambda raw: raw.__setitem__(2, raw[2] & 0x7F)),
638:         ):
639:             malformed = bytearray(pkt)
640:             update(malformed)
641:             with self.subTest(field=field), self.assertRaises(ValueError):
642:                 decode_command(_with_command_crc(malformed))
643: 
644:         malformed_stop = bytearray(stop_pkt)
645:         malformed_stop[4] = 1
646:         with self.assertRaises(ValueError):
647:             decode_command(_with_command_crc(malformed_stop))
648: 
649:         # Raw conversions
650:         self.assertEqual(position_to_raw(raw_to_position(0)), 0)
651:         self.assertEqual(position_to_raw(raw_to_position(100)), 100)
652:         self.assertEqual(position_to_raw(raw_to_position(-100)), -100)
653:         self.assertEqual(position_to_raw(raw_to_position(RAW_POSITION_MAX)), RAW_POSITION_MAX)
654:         self.assertEqual(position_to_raw(raw_to_position(RAW_POSITION_MIN)), RAW_POSITION_MIN)
655: 
656:     def test_decoder_accepts_canonical_input_endpoints_and_rejects_raw_values_outside_them(self):
657:         for position, rpm, torque, kp, kd in (
658:             (POSITION_MIN, RPM_MIN, -3.5, 0.0, 0.0),
659:             (POSITION_MAX, RPM_MAX, 3.5, 30.0, 6.0),
660:         ):
661:             with self.subTest(position=position, rpm=rpm, torque=torque, kp=kp, kd=kd):
662:                 packet = command(
663:                     0, mode=1, position=position, rpm=rpm,
664:                     torque=torque, kp=kp, kd=kd, watchdog=True,
665:                 )
666:                 decoded = decode_command(packet)
667:                 self.assertEqual(decoded["raw"], packet.hex())
668:                 expected_position_raw = RAW_POSITION_MIN if position == POSITION_MIN else RAW_POSITION_MAX
669:                 expected_rpm_raw = -32768 if rpm == RPM_MIN else 32767
670:                 self.assertEqual(decoded["raw_position"], expected_position_raw)
671:                 self.assertEqual(decoded["raw_rpm"], expected_rpm_raw)
672:                 if kd == 6.0:
673:                     self.assertGreater(decoded["kd"], 6.0)
674: 
675:         endpoint_fields = (
676:             ("feedforward", 4, command(0, mode=1, torque=-3.5), command(0, mode=1, torque=3.5)),
677:             ("kp", 12, command(0, mode=1, kp=0.0), command(0, mode=1, kp=30.0)),
678:             ("kd", 14, command(0, mode=1, kd=0.0), command(0, mode=1, kd=6.0)),
679:         )
680:         for field, offset, low_packet, high_packet in endpoint_fields:
681:             low_raw = struct.unpack_from("<h", low_packet, offset)[0]
682:             high_raw = struct.unpack_from("<h", high_packet, offset)[0]
683:             invalid_raw_values = (
684:                 (f"{field} below image", low_raw - 1),
685:                 (f"{field} at raw minimum", -32768),
686:                 (f"{field} above image", high_raw + 1),
687:                 (f"{field} at raw maximum", 32767),
688:             )
689:             for name, raw_value in invalid_raw_values:
690:                 malformed = bytearray(command(0, mode=1))
691:                 struct.pack_into("<h", malformed, offset, raw_value)
692:                 with self.subTest(name=name), self.assertRaises(ValueError):
693:                     decode_command(_with_command_crc(malformed))
694: 
695:     def test_actual_reference_matches_every_canonical_wire_field(self):
696:         mapping = JointMap(3.0, -1, 0.25)
697:         spec = JointSpec(
698:             "J1", 0, mapping, -2.0, 2.0, 10.0, "fixture: canonical reference test"
699:         )
700:         requested = JointTarget(0.321, 0.123, 0.321, 1.234, 0.123)
701: 
702:         code, actual, packet = prepare_reference_joint(spec, requested)
703: 
704:         self.assertIsNone(code)
705:         self.assertIsNotNone(actual)
706:         decoded = decode_command(packet)
707:         expected = mapping.from_output(OutputSample(
708:             decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
709:         ))
710:         self.assertEqual(actual.q_rad, expected.q_rad)
711:         self.assertEqual(actual.dq_rad_s, expected.dq_rad_s)
712:         self.assertEqual(actual.tau_nm, expected.tau_nm)
713:         self.assertEqual(actual.kp, decoded["kp"] * mapping.reduction ** 2)
714:         self.assertEqual(actual.kd, decoded["kd"] * mapping.reduction ** 2)
715: 
716:     def test_unencodable_mapped_request_is_invalid_not_projected_into_range(self):
717:         spec = JointSpec(
718:             "J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8,
719:             "fixture: wide software position limits",
720:         )
721:         code, actual, packet = prepare_reference_joint(
722:             spec, JointTarget(1e7, 0.0, 0.0, 1.0, 0.1)
723:         )
724:         self.assertIs(code, DecisionCode.INVALID_ARGUMENT)
725:         self.assertIsNone(actual)
726:         self.assertIsNone(packet)
727: 
728:     def test_mapping_overflow_is_invalid_argument(self):
729:         spec = JointSpec(
730:             "J1", 0, JointMap(1e-308, 1, 0.0), -1.0, 1.0, 10.0,
731:             "fixture: mapping overflow limits",
732:         )
733:         code, actual, packet = prepare_reference_joint(
734:             spec, JointTarget(0.0, 0.0, 0.0, 0.0, 0.0)
735:         )
736:         self.assertIs(code, DecisionCode.INVALID_ARGUMENT)
737:         self.assertIsNone(actual)
738:         self.assertIsNone(packet)
739: 
740:     def test_refresh_plan_requires_exact_count_canonical_packet_bytes(self):
741:         core, station, owner = self._armed_station()
742:         target = Target(
743:             1,
744:             (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
745:              JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)),
746:             window=station.issue_window(1.0),
747:             owner=owner,
748:         )
749:         self.assertTrue(station.submit(target).accepted)
750:         self.clock.value += 0.05
751:         plan = core.prepare_refresh()
752:         self.assertIsNotNone(plan)
753:         self.assertEqual(len(plan.packets), len(plan.joint_targets))
754:         self.assertTrue(all(type(packet) is bytes for packet in plan.packets))
755: 
756:         with self.assertRaises(TypeError):
757:             RefreshPlan(
758:                 plan.plan_id, target, plan.prepared_at_s, plan.joint_targets
759:             )
760:         with self.assertRaises(ValueError):
761:             replace(plan, packets=plan.packets[:-1])
762:         with self.assertRaises(ValueError):
763:             replace(plan, packets=list(plan.packets))
764:         with self.assertRaises(ValueError):
765:             replace(
766:                 plan,
767:                 packets=tuple(command(spec.motor_id, mode=0) for spec in self.specs),
768:             )
769: 
770:     def test_prepare_failure_only_attributes_the_joint_with_position_failure(self):
771:         core, station, owner = self._armed_station()
772:         target = Target(
773:             1,
774:             (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
775:              JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)),
776:             window=station.issue_window(1.0),
777:             owner=owner,
778:         )
779:         self.assertTrue(station.submit(target).accepted)
780:         self.clock.value += 0.05
781: 
782:         with patch(
783:             "joint_controller.prepare_complete_reference",
784:             return_value=ReferenceBatchResult(
785:                 None,
786:                 None,
787:                 None,
788:                 (ReferenceFailure(DecisionCode.POSITION_OUT_OF_BOUNDS, 1),),
789:             ),
790:         ):
791:             self.assertIsNone(core.prepare_refresh())
792: 
793:         snapshot = core.snapshot()
794:         self.assertEqual(snapshot.affected_joints, ("J2",))
795:         self.assertTrue(snapshot.faults[0].position_limit)
796: 
797:     def test_generic_prepare_failure_does_not_mislabel_every_joint_position_limited(self):
798:         core, station, owner = self._armed_station()
799:         target = Target(
800:             1,
801:             (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
802:              JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)),
803:             window=station.issue_window(1.0),
804:             owner=owner,
805:         )
806:         self.assertTrue(station.submit(target).accepted)
807:         self.clock.value += 0.05
808: 
809:         with patch(
810:             "joint_controller.prepare_complete_reference",
811:             return_value=ReferenceBatchResult(
812:                 None,
813:                 None,
814:                 None,
815:                 (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),),
816:             ),
817:         ):
818:             self.assertIsNone(core.prepare_refresh())
819: 
820:         snapshot = core.snapshot()
821:         self.assertEqual(snapshot.state, State.STOPPED)
822:         self.assertFalse(snapshot.fault_latched)
823:         self.assertEqual(snapshot.faults, ())
824:         self.assertIsNone(snapshot.admitted_target)
825: 
826:     def test_owner_matching_uses_exact_type_and_boundary_records_reject_subclasses(self):
827:         class EqualAnyOwner(OwnerToken):
828:             def __eq__(self, other):
829:                 return True
830: 
831:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
832:         station = FakeStation(core)
833:         self.assertTrue(station.connect().accepted)
834:         owner = station.claim("owner-test")
835:         self.assertTrue(station.check().accepted)
836:         impostor = EqualAnyOwner("wrong-epoch", owner.generation, "other-client")
837: 
838:         self.assertTrue(owner_tokens_match(owner, OwnerToken(
839:             owner.epoch, owner.generation, owner.connection_id
840:         )))
841:         self.assertFalse(owner_tokens_match(impostor, owner))
842:         self.assertEqual(core.arm(impostor).code, DecisionCode.INVALID_OWNER)
843: 
844:         valid_joint = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
845:         window = IntentWindow(1, 0.0, 1.0)
846:         with self.assertRaises(ValueError):
847:             Target(1, (valid_joint,), window, impostor)
848:         with self.assertRaises(ValueError):
849:             JointDispatchedRecord(1, valid_joint, 0.0, impostor)
850:         with self.assertRaises(ValueError):
851:             JointDispatchAttempt(
852:                 1, 1, valid_joint, WriteResult.COMPLETE, 0.0, impostor
853:             )
854: 
855:         for field in ("latest_owner", "current_owner"):
856:             with self.subTest(field=field), self.assertRaises(ValueError):
857:                 Snapshot(
858:                     State.DISCONNECTED,
859:                     ("J1",),
860:                     (JointStatus(),),
861:                     None,
862:                     False,
863:                     (None,),
864:                     **{field: impostor},
865:                 )
866: 
867:         fresh = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
868:         self.assertEqual(fresh.arm(impostor).code, DecisionCode.INVALID_STATE)
869: 
870:     def test_late_failed_outcomes_settle_after_disconnect_and_allow_new_check(self):
871:         for result in (
872:             WriteResult.FAILED,
873:             WriteResult.PARTIAL,
874:             WriteResult.PREWRITE_DEADLINE,
875:         ):
876:             with self.subTest(result=result):
877:                 clock = DeterministicClock(0.0)
878:                 spec = JointSpec(
879:                     "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0,
880:                     "fixture: late receipt limits",
881:                 )
882:                 core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
883:                 station = FakeStation(core)
884:                 self.assertTrue(station.connect().accepted)
885:                 owner = station.claim("late-receipt")
886:                 self.assertTrue(station.check().accepted)
887:                 self.assertTrue(station.arm(owner).accepted)
888: 
889:                 first = Target(
890:                     1,
891:                     (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),),
892:                     station.issue_window(1.0),
893:                     owner,
894:                 )
895:                 self.assertTrue(station.submit(first).accepted)
896:                 clock.value += 0.05
897:                 first_plan = core.prepare_refresh()
898:                 self.assertTrue(core.claim_dispatch(first_plan.plan_id, 0))
899:                 self.assertTrue(core.dispatch_result(
900:                     first_plan.plan_id, 0, WriteResult.COMPLETE
901:                 ).accepted)
902: 
903:                 second = Target(
904:                     2,
905:                     (JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),),
906:                     station.issue_window(1.0),
907:                     owner,
908:                 )
909:                 self.assertTrue(station.submit(second).accepted)
910:                 clock.value += 0.05
911:                 second_plan = core.prepare_refresh()
912:                 self.assertTrue(core.claim_dispatch(second_plan.plan_id, 0))
913:                 self.assertTrue(core.disconnect().accepted)
914:                 self.assertFalse(core.begin_connect().accepted)
915: 
916:                 receipt = core.dispatch_result(second_plan.plan_id, 0, result)
917:                 self.assertFalse(receipt.accepted)
918:                 snapshot = core.snapshot()
919:                 self.assertIs(snapshot.state, State.DISCONNECTED)
920:                 self.assertIsNone(snapshot.source)
921:                 self.assertIsNone(snapshot.current_owner)
922:                 self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
923:                 self.assertEqual(snapshot.dispatch_attempts[0].sequence, 2)
924:                 self.assertIs(snapshot.dispatch_attempts[0].result, result)
925:                 self.assertTrue(snapshot.fault_latched)
926: 
927:                 self.assertTrue(station.connect().accepted)
928:                 new_owner = station.claim("new-owner")
929:                 self.assertNotEqual(owner.generation, new_owner.generation)
930:                 self.assertTrue(station.check(acknowledge_fault=True).accepted)
931:                 self.assertTrue(station.arm(new_owner).accepted)
932:                 self.assertIs(core.snapshot().state, State.ARMED)
933: 
934:     def test_complete_write_with_bad_end_clock_after_disconnect_keeps_full_record(self):
935:         class EndClock(DeterministicClock):
936:             fail = False
937: 
938:             def __call__(self):
939:                 self.calls += 1
940:                 return math.nan if self.fail else self.value
941: 
942:         clock = EndClock(0.0)
943:         spec = JointSpec(
944:             "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0,
945:             "fixture: late complete limits",
946:         )
947:         core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
948:         station = FakeStation(core)
949:         self.assertTrue(station.connect().accepted)
950:         owner = station.claim("late-complete")
951:         self.assertTrue(station.check().accepted)
952:         self.assertTrue(station.arm(owner).accepted)
953:         target = Target(
954:             1,
955:             (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),),
956:             station.issue_window(1.0),
957:             owner,
958:         )
959:         self.assertTrue(station.submit(target).accepted)
960:         clock.value += 0.05
961:         plan = core.prepare_refresh()
962:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
963:         self.assertTrue(core.disconnect().accepted)
964: 
965:         clock.fail = True
966:         receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
967:         self.assertFalse(receipt.accepted)
968:         clock.fail = False
969:         snapshot = core.snapshot()
970:         self.assertIs(snapshot.state, State.DISCONNECTED)
971:         self.assertIsNone(snapshot.source)
972:         self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.COMPLETE)
973:         self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
974:         self.assertEqual(
975:             snapshot.faults[0].communication_error, CommunicationFailure.CLOCK_FAILURE
976:         )
977: 
978:         self.assertTrue(station.connect().accepted)
979:         new_owner = station.claim("late-complete-new-owner")
980:         self.assertTrue(station.check(acknowledge_fault=True).accepted)
981:         self.assertTrue(station.arm(new_owner).accepted)
982:         self.assertIs(core.snapshot().state, State.ARMED)
983: 
984:     def test_seeded_extreme_mappings_keep_reference_and_packet_congruent(self):
985:         rng = random.Random(9009)
986:         for index in range(40):
987:             reduction = 10 ** rng.uniform(-6, 6)
988:             direction = rng.choice((-1, 1))
989:             zero = rng.uniform(-2.5, 2.5)
990:             output_q = rng.uniform(-1.0, 1.0)
991:             q = direction * (output_q - zero) / reduction
992:             half_width = abs(raw_to_position(4)) / reduction
993:             spec = JointSpec(
994:                 f"J{index}",
995:                 index % 15,
996:                 JointMap(reduction, direction, zero),
997:                 q - half_width,
998:                 q + half_width,
999:                 1e8,
1000:                 "fixture: seeded software limits",
1001:             )
1002:             output_velocity = rng.uniform(-0.5, 0.5)
1003:             output_torque = rng.uniform(-0.1, 0.1)
1004:             requested = JointTarget(
1005:                 q,
1006:                 direction * output_velocity / reduction,
1007:                 direction * output_torque * reduction,
1008:                 2.0 * reduction ** 2,
1009:                 0.3 * reduction ** 2,
1010:             )
1011: 
1012:             code, actual, packet = prepare_reference_joint(spec, requested)
1013: 
1014:             with self.subTest(index=index, reduction=reduction, direction=direction):
1015:                 self.assertIsNone(code)
1016:                 self.assertIsNotNone(actual)
1017:                 self.assertIsNotNone(packet)
1018:                 decoded = decode_command(packet)
1019:                 self.assertGreaterEqual(actual.q_rad, spec.q_min_rad)
1020:                 self.assertLessEqual(actual.q_rad, spec.q_max_rad)
1021:                 expected = spec.mapping.from_output(OutputSample(
1022:                     decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
1023:                 ))
1024:                 self.assertEqual(actual.q_rad, expected.q_rad)
1025:                 self.assertEqual(actual.dq_rad_s, expected.dq_rad_s)
1026:                 self.assertEqual(actual.tau_nm, expected.tau_nm)
1027:                 self.assertEqual(actual.kp, decoded["kp"] * reduction ** 2)
1028:                 self.assertEqual(actual.kd, decoded["kd"] * reduction ** 2)
1029:                 self.assertEqual(
1030:                     decoded["raw_position"], self._project(spec, requested.q_rad)
1031:                 )
1032: 
1033:                 mapped = spec.mapping.to_output(requested)
1034:                 request_decoded = decode_command(command(
1035:                     spec.motor_id,
1036:                     mode=1,
1037:                     rpm=mapped.rpm,
1038:                     kd=mapped.kd,
1039:                     torque=mapped.tau_nm,
1040:                     watchdog=True,
1041:                     position=mapped.q_rad,
1042:                     kp=mapped.kp,
1043:                 ))
1044:                 for field in ("raw_rpm", "raw_torque", "raw_kp", "raw_kd"):
1045:                     self.assertEqual(decoded[field], request_decoded[field])
1046: 
1047: 
1048: 
1049: class ReferenceSpeedTests(unittest.TestCase):
1050:     def setUp(self):
1051:         self.clock = DeterministicClock(10.0)
1052:         self.spec1 = JointSpec(
1053:             "J1",
1054:             0,
1055:             JointMap(1.0, 1, 0.0),
1056:             -2.0,
1057:             2.0,
1058:             1.0,  # v_max_rad_s = 1.0 rad/s
1059:             "fixture: speed limit test J1",
1060:         )
1061:         self.spec2 = JointSpec(
1062:             "J2",
1063:             1,
1064:             JointMap(1.0, 1, 0.0),
1065:             -1.0,
1066:             1.0,
1067:             2.0,  # v_max_rad_s = 2.0 rad/s
1068:             "fixture: speed limit test J2",
1069:         )
1070:         self.specs = (self.spec1, self.spec2)
1071:         self.sample1 = JointSample(0.0, 0.0, 0.0)
1072:         self.sample2 = JointSample(0.0, 0.0, 0.0)
1073: 
1074:     def _armed_station(self, max_reference_gap_s=1.0):
1075:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=max_reference_gap_s)
1076:         station = FakeStation(core)
1077:         self.assertTrue(station.connect().accepted)
1078:         owner = station.claim("speed-tester")
1079:         self.assertTrue(core.begin_check().accepted)
1080:         self.assertTrue(core.receive(0, self.sample1, HEALTHY_STOP).accepted)
1081:         self.assertTrue(core.receive(1, self.sample2, HEALTHY_STOP).accepted)
1082:         self.assertTrue(core.checked().accepted)
1083:         self.assertTrue(station.arm(owner).accepted)
1084:         return core, station, owner
1085: 
1086:     def assert_reference_speed_certificate(self, previous, current, spec):
1087:         h = current.sample_time_s - previous.sample_time_s
1088:         self.assertGreater(h, 0.0)
1089:         exact_position_step_velocity = (
1090:             Fraction(current.q_rad) - Fraction(previous.q_rad)
1091:         ) / Fraction(h)
1092:         self.assertEqual(
1093:             current.position_step_velocity_rad_s,
1094:             exact_position_step_velocity,
1095:         )
1096:         self.assertIsInstance(current.position_step_velocity_rad_s, Fraction)
1097:         exact_speed_limit = Fraction(spec.v_max_rad_s)
1098:         self.assertLessEqual(abs(exact_position_step_velocity), exact_speed_limit)
1099:         self.assertLessEqual(
1100:             abs(Fraction(current.encoded_velocity_rad_s)), exact_speed_limit
1101:         )
1102: 
1103:     def test_checked_sample_initializes_unemitted_stop_reference(self):
1104:         core, station, owner = self._armed_station()
1105:         snapshot = core.snapshot()
1106:         self.assertEqual(len(snapshot.confirmed_references), 2)
1107:         ref0 = snapshot.confirmed_references[0]
1108:         self.assertIsNotNone(ref0)
1109:         self.assertEqual(ref0.q_rad, 0.0)
1110:         self.assertEqual(ref0.position_step_velocity_rad_s, 0.0)
1111:         self.assertEqual(ref0.encoded_velocity_rad_s, 0.0)
1112:         self.assertEqual(ref0.sample_time_s, 10.0)
1113:         self.assertFalse(ref0.is_emitted)
1114: 
1115:     def test_zero_elapsed_on_fresh_stop_anchor_cannot_dispatch_write(self):
1116:         core, station, owner = self._armed_station()
1117:         window = station.issue_window(1.0)
1118:         target = Target(
1119:             1,
1120:             (
1121:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1122:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1123:             ),
1124:             window=window,
1125:             owner=owner,
1126:         )
1127:         self.assertTrue(station.submit(target).accepted)
1128:         # clock has NOT advanced (h == 0) from checked anchor
1129:         self.assertIsNone(core.prepare_refresh())
1130:         snapshot = core.snapshot()
1131:         self.assertIs(snapshot.state, State.FAULT)
1132:         self.assertTrue(snapshot.faults[0].constraint_fault)
1133: 
1134:     def test_zero_elapsed_repeated_refresh_emits_unchanged_command(self):
1135:         core, station, owner = self._armed_station()
1136:         window = station.issue_window(1.0)
1137:         target1 = Target(
1138:             1,
1139:             (
1140:                 JointTarget(0.05, 0.25, 0.15, 1.2, 0.3),
1141:                 JointTarget(0.05, 0.25, 0.15, 1.2, 0.3),
1142:             ),
1143:             window=window,
1144:             owner=owner,
1145:         )
1146:         self.assertTrue(station.submit(target1).accepted)
1147:         station.writes.clear()
1148:         self.clock.value += 0.05
1149:         plan1 = station.refresh()
1150:         self.assertIsNotNone(plan1)
1151:         self.assertEqual(len(station.writes), 2)
1152:         first_packets = list(station.writes)
1153:         first_reference = core.snapshot().confirmed_references[0]
1154:         self.assertNotEqual(first_reference.q_rad, target1.joints[0].q_rad)
1155: 
1156:         # Without advancing clock (h == 0), refresh again with same target
1157:         station.writes.clear()
1158:         plan2 = station.refresh()
1159:         self.assertIsNotNone(plan2)
1160:         self.assertEqual(station.writes, first_packets)
1161:         self.assertEqual(plan2.packets, plan1.packets)
1162:         self.assertEqual(plan2.joint_targets[0].q_rad, plan1.joint_targets[0].q_rad)
1163:         self.assertEqual(core.snapshot().confirmed_references[0], first_reference)
1164: 
1165:         # But changing target at h == 0 cannot jump
1166:         target2 = Target(
1167:             2,
1168:             (
1169:                 JointTarget(0.1, 0.25, 0.2, 1.2, 0.3),
1170:                 JointTarget(0.1, 0.25, 0.2, 1.2, 0.3),
1171:             ),
1172:             window=window,
1173:             owner=owner,
1174:         )
1175:         self.assertTrue(station.submit(target2).accepted)
1176:         station.writes.clear()
1177:         self.assertIsNone(station.refresh())
1178:         self.assertIs(core.snapshot().state, State.FAULT)
1179:         self.assertEqual(station.writes, [])
1180:         self.assertEqual(core.snapshot().confirmed_references[0], first_reference)
1181: 
1182:     def test_fixed_and_varied_h_progression_within_speed_bound(self):
1183:         core, station, owner = self._armed_station()
1184:         window = station.issue_window(1.0)
1185:         # Large goal demanding maximum reference speed
1186:         target = Target(
1187:             1,
1188:             (
1189:                 JointTarget(1.5, 0.0, 0.0, 1.0, 0.1),
1190:                 JointTarget(0.8, 0.0, 0.0, 1.0, 0.1),
1191:             ),
1192:             window=window,
1193:             owner=owner,
1194:         )
1195:         self.assertTrue(station.submit(target).accepted)
1196: 
1197:         previous_ref = core.snapshot().confirmed_references[0]
1198:         self.clock.value += 0.05
1199:         plan1 = station.refresh()
1200:         self.assertIsNotNone(plan1)
1201:         ref1 = core.snapshot().confirmed_references[0]
1202:         self.assertGreater(ref1.q_rad, 0.04)
1203:         self.assert_reference_speed_certificate(previous_ref, ref1, self.spec1)
1204: 
1205:         previous_ref = ref1
1206:         self.clock.value += 0.02
1207:         plan2 = station.refresh()
1208:         self.assertIsNotNone(plan2)
1209:         ref2 = core.snapshot().confirmed_references[0]
1210:         step2 = ref2.q_rad - previous_ref.q_rad
1211:         self.assertGreater(step2, 0.015)
1212:         self.assert_reference_speed_certificate(previous_ref, ref2, self.spec1)
1213: 
1214:         previous_ref = ref2
1215:         self.clock.value += 0.1
1216:         plan3 = station.refresh()
1217:         self.assertIsNotNone(plan3)
1218:         ref3 = core.snapshot().confirmed_references[0]
1219:         step3 = ref3.q_rad - previous_ref.q_rad
1220:         self.assertGreater(step3, 0.09)
1221:         self.assert_reference_speed_certificate(previous_ref, ref3, self.spec1)
1222: 
1223:     def test_positive_negative_and_reversal_bounded(self):
1224:         core, station, owner = self._armed_station()
1225:         window = station.issue_window(1.0)
1226:         # Move positive toward 0.5
1227:         t_pos = Target(
1228:             1,
1229:             (
1230:                 JointTarget(0.5, 0.0, 0.0, 1.0, 0.1),
1231:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
1232:             ),
1233:             window=window,
1234:             owner=owner,
1235:         )
1236:         self.assertTrue(station.submit(t_pos).accepted)
1237:         previous_ref = core.snapshot().confirmed_references[0]
1238:         self.clock.value += 0.05
1239:         self.assertIsNotNone(station.refresh())
1240:         ref_pos = core.snapshot().confirmed_references[0]
1241:         self.assertGreater(ref_pos.position_step_velocity_rad_s, 0.0)
1242:         self.assert_reference_speed_certificate(previous_ref, ref_pos, self.spec1)
1243: 
1244:         # Reverse toward negative -0.5
1245:         t_neg = Target(
1246:             2,
1247:             (
1248:                 JointTarget(-0.5, 0.0, 0.0, 1.0, 0.1),
1249:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
1250:             ),
1251:             window=window,
1252:             owner=owner,
1253:         )
1254:         self.assertTrue(station.submit(t_neg).accepted)
1255:         previous_ref = ref_pos
1256:         self.clock.value += 0.05
1257:         self.assertIsNotNone(station.refresh())
1258:         ref_rev = core.snapshot().confirmed_references[0]
1259:         self.assertLess(ref_rev.position_step_velocity_rad_s, 0.0)
1260:         self.assert_reference_speed_certificate(previous_ref, ref_rev, self.spec1)
1261: 
1262:     def test_reference_gap_exact_bound_and_exceeded(self):
1263:         core, station, owner = self._armed_station(max_reference_gap_s=0.125)
1264:         window = station.issue_window(1.0)
1265:         _, canonical_j1, _ = prepare_reference_joint(
1266:             self.spec1, JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
1267:         )
1268:         _, canonical_j2, _ = prepare_reference_joint(
1269:             self.spec2, JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
1270:         )
1271:         self.assertIsNotNone(canonical_j1)
1272:         self.assertIsNotNone(canonical_j2)
1273:         target = Target(
1274:             1,
1275:             (
1276:                 canonical_j1,
1277:                 canonical_j2,
1278:             ),
1279:             window=window,
1280:             owner=owner,
1281:         )
1282:         self.assertTrue(station.submit(target).accepted)
1283: 
1284:         # The binary-exact cadence is exactly max_reference_gap_s.
1285:         self.clock.value = 10.125
1286:         self.assertIsNotNone(station.refresh())
1287:         self.assertIs(core.snapshot().state, State.MOVING)
1288: 
1289:         # Move the absolute sample time one float step beyond an exact second interval.
1290:         self.clock.value = math.nextafter(10.25, math.inf)
1291:         self.assertIsNone(station.refresh())
1292:         snapshot = core.snapshot()
1293:         self.assertIs(snapshot.state, State.STOPPED)
1294:         self.assertIsNone(snapshot.admitted_target)
1295: 
1296:     def test_invalid_and_nonfinite_dt_fails_closed(self):
1297:         core, station, owner = self._armed_station()
1298:         window = station.issue_window(1.0)
1299:         target = Target(
1300:             1,
1301:             (
1302:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1303:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1304:             ),
1305:             window=window,
1306:             owner=owner,
1307:         )
1308:         self.assertTrue(station.submit(target).accepted)
1309: 
1310:         # Clock goes backwards (negative dt)
1311:         self.clock.value += 0.05
1312:         plan = core.prepare_refresh()
1313:         self.assertIsNotNone(plan)
1314:         self.assertIs(core.snapshot().prepared_plan, plan)
1315:         confirmed_before = core.snapshot().confirmed_references
1316:         station.writes.clear()
1317:         self.clock.value -= 0.1
1318:         with self.assertRaises(ValueError):
1319:             core.prepare_refresh()
1320:         self.clock.value = plan.prepared_at_s
1321:         snapshot = core.snapshot()
1322:         self.assertIs(snapshot.state, State.STOPPED)
1323:         self.assertIsNone(snapshot.admitted_target)
1324:         self.assertIsNone(snapshot.prepared_plan)
1325:         self.assertIsNone(snapshot.current_owner)
1326:         self.assertEqual(snapshot.confirmed_references, confirmed_before)
1327:         self.assertEqual(snapshot.last_sequence, 1)
1328:         self.assertEqual(station.writes, [])
1329:         self.assertIsNone(core.prepare_refresh())
1330: 
1331:         # Non-finite clock
1332:         self.clock.value = plan.prepared_at_s
1333:         core2, station2, owner2 = self._armed_station()
1334:         window2 = station2.issue_window(1.0)
1335:         target2 = Target(
1336:             1,
1337:             (
1338:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1339:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1340:             ),
1341:             window=window2,
1342:             owner=owner2,
1343:         )
1344:         self.assertTrue(station2.submit(target2).accepted)
1345:         confirmed_before2 = core2.snapshot().confirmed_references
1346:         station2.writes.clear()
1347:         self.clock.value = float("nan")
1348:         with self.assertRaises(ValueError):
1349:             core2.prepare_refresh()
1350:         self.clock.value = plan.prepared_at_s
1351:         snapshot2 = core2.snapshot()
1352:         self.assertIs(snapshot2.state, State.STOPPED)
1353:         self.assertIsNone(snapshot2.admitted_target)
1354:         self.assertIsNone(snapshot2.prepared_plan)
1355:         self.assertIsNone(snapshot2.current_owner)
1356:         self.assertEqual(snapshot2.confirmed_references, confirmed_before2)
1357:         self.assertEqual(snapshot2.last_sequence, 1)
1358:         self.assertEqual(station2.writes, [])
1359:         self.assertIsNone(core2.prepare_refresh())
1360: 
1361:     def test_preparing_and_unwritten_vector_cannot_advance_history(self):
1362:         core, station, owner = self._armed_station()
1363:         window = station.issue_window(1.0)
1364:         target = Target(
1365:             1,
1366:             (
1367:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1368:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1369:             ),
1370:             window=window,
1371:             owner=owner,
1372:         )
1373:         self.assertTrue(station.submit(target).accepted)
1374: 
1375:         init_ref = core.snapshot().confirmed_references[0]
1376:         self.clock.value += 0.05
1377:         plan = core.prepare_refresh()
1378:         self.assertIsNotNone(plan)
1379: 
1380:         # Preparing did NOT advance confirmed references
1381:         ref_after_prep = core.snapshot().confirmed_references[0]
1382:         self.assertEqual(init_ref, ref_after_prep)
1383: 
1384:         # Unwritten vector dropped; advance clock further
1385:         self.clock.value += 0.05
1386:         plan2 = core.prepare_refresh()
1387:         self.assertIsNotNone(plan2)
1388:         # History is still the initial confirmed reference
1389:         self.assertEqual(core.snapshot().confirmed_references[0], init_ref)
1390: 
1391:     def test_first_joint_full_write_and_second_failure_commits_only_first(self):
1392:         core, station, owner = self._armed_station()
1393:         window = station.issue_window(1.0)
1394:         target = Target(
1395:             1,
1396:             (
1397:                 JointTarget(0.05, 0.0, 0.0, 1.0, 0.1),
1398:                 JointTarget(0.05, 0.0, 0.0, 1.0, 0.1),
1399:             ),
1400:             window=window,
1401:             owner=owner,
1402:         )
1403:         self.assertTrue(station.submit(target).accepted)
1404:         self.clock.value += 0.05
1405:         plan = core.prepare_refresh()
1406:         self.assertIsNotNone(plan)
1407: 
1408:         ref0_init = core.snapshot().confirmed_references[0]
1409:         ref1_init = core.snapshot().confirmed_references[1]
1410: 
1411:         # Joint 0 completes write
1412:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
1413:         self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)
1414: 
1415:         # Joint 0 confirmed reference is committed
1416:         ref0_committed = core.snapshot().confirmed_references[0]
1417:         self.assertNotEqual(ref0_committed, ref0_init)
1418:         self.assertEqual(ref0_committed.sample_time_s, plan.prepared_at_s)
1419: 
1420:         # Joint 1 fails write
1421:         self.assertTrue(core.claim_dispatch(plan.plan_id, 1))
1422:         failure = core.dispatch_result(plan.plan_id, 1, WriteResult.FAILED)
1423:         self.assertFalse(failure.accepted)
1424:         self.assertIs(failure.code, DecisionCode.FAULT_LATCHED)
1425: 
1426:         # The failed write is recorded and faults J2, without advancing its history.
1427:         snapshot = core.snapshot()
1428:         self.assertEqual(snapshot.confirmed_references[0], ref0_committed)
1429:         self.assertEqual(snapshot.confirmed_references[1], ref1_init)
1430:         self.assertEqual(snapshot.dispatch_attempts[1].result, WriteResult.FAILED)
1431:         self.assertIs(snapshot.state, State.FAULT)
1432:         self.assertIsNone(snapshot.admitted_target)
1433:         self.assertIsNone(snapshot.current_owner)
1434:         self.assertEqual(len(snapshot.faults), 1)
1435:         self.assertEqual(snapshot.faults[0].motor_id, self.specs[1].motor_id)
1436:         self.assertIs(
1437:             snapshot.faults[0].communication_error,
1438:             CommunicationFailure.DRIVER_FAILURE,
1439:         )
1440: 
1441:     def test_quantization_stall_on_nonzero_objective_vs_deliberate_hold(self):
1442:         core, station, owner = self._armed_station()
1443:         window = station.issue_window(1.0)
1444: 
1445:         # Case A: Deliberate hold (goal matches prev q, zero velocity)
1446:         hold_target = Target(
1447:             1,
1448:             (
1449:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
1450:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
1451:             ),
1452:             window=window,
1453:             owner=owner,
1454:         )
1455:         self.assertTrue(station.submit(hold_target).accepted)
1456:         self.clock.value += 0.001
1457:         hold_plan = station.refresh()
1458:         self.assertIsNotNone(hold_plan)
1459:         self.assertIs(core.snapshot().state, State.MOVING)
1460: 
1461:         # Case B: Nonzero objective with too-small cadence (quantization stall)
1462:         stall_target = Target(
1463:             2,
1464:             (
1465:                 JointTarget(1.0, 0.0, 0.0, 1.0, 0.1),
1466:                 JointTarget(0.5, 0.0, 0.0, 1.0, 0.1),
1467:             ),
1468:             window=window,
1469:             owner=owner,
1470:         )
1471:         self.assertTrue(station.submit(stall_target).accepted)
1472:         self.clock.value += 1e-6  # Tiny cadence where v_max * h < 1 raw tick
1473:         stall_plan = station.refresh()
1474:         self.assertIsNone(stall_plan)
1475:         snapshot = core.snapshot()
1476:         self.assertIs(snapshot.state, State.FAULT)
1477:         self.assertTrue(snapshot.faults[0].constraint_fault)
1478: 
1479:     def test_dual_stream_velocities_independent_and_both_bounded(self):
1480:         core, station, owner = self._armed_station()
1481:         window = station.issue_window(1.0)
1482:         target = Target(
1483:             1,
1484:             (
1485:                 JointTarget(0.08, 0.2, 0.0, 1.0, 0.1),
1486:                 JointTarget(0.05, 0.1, 0.0, 1.0, 0.1),
1487:             ),
1488:             window=window,
1489:             owner=owner,
1490:         )
1491:         self.assertTrue(station.submit(target).accepted)
1492:         self.clock.value += 0.05
1493:         plan = station.refresh()
1494:         self.assertIsNotNone(plan)
1495: 
1496:         ref0 = core.snapshot().confirmed_references[0]
1497:         # Verify both independent streams are exactly within spec V (1.0 rad/s).
1498:         initial_ref = JointTrajectoryReference(0.0, Fraction(0), 0.0, 10.0, False)
1499:         self.assert_reference_speed_certificate(initial_ref, ref0, self.spec1)
1500:         # Verify they are tracked as separate explicit values
1501:         self.assertIsInstance(ref0.position_step_velocity_rad_s, Fraction)
1502:         self.assertIsInstance(ref0.encoded_velocity_rad_s, float)
1503: 
1504:     def test_zero_objective_cancellation_is_not_quantization_stall(self):
1505:         spec = JointSpec(
1506:             "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0,
1507:             "fixture: zero-objective cancellation test",
1508:         )
1509:         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
1510:         target = JointTarget(0.1, -1.0, 0.0, 1.0, 0.1)
1511: 
1512:         code, emitted, reference, packet = shape_reference_joint(
1513:             spec, target, anchor, 0.1, 1.0
1514:         )
1515: 
1516:         self.assertIsNone(code)
1517:         self.assertIsNotNone(emitted)
1518:         self.assertIsNotNone(reference)
1519:         self.assertIsNotNone(packet)
1520:         self.assertEqual(emitted.q_rad, 0.0)
1521:         self.assertEqual(reference.position_step_velocity_rad_s, Fraction(0))
1522: 
1523:     def test_finite_extreme_objective_uses_exact_projection_without_overflow(self):
1524:         spec = JointSpec(
1525:             "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.5e308,
1526:             "fixture: finite extreme objective",
1527:         )
1528:         anchor = JointTrajectoryReference(-1.0, Fraction(0), 0.0, 0.0, False)
1529:         target = JointTarget(1.0, 0.0, 0.0, 1.0, 0.1)
1530: 
1531:         code, emitted, reference, packet = shape_reference_joint(
1532:             spec, target, anchor, 1e-308, 1.0
1533:         )
1534: 
1535:         self.assertIsNone(code)
1536:         self.assertIsNotNone(emitted)
1537:         self.assertIsNotNone(reference)
1538:         self.assertIsNotNone(packet)
1539:         self.assertGreater(reference.position_step_velocity_rad_s, 0)
1540:         self.assertLessEqual(
1541:             reference.position_step_velocity_rad_s, Fraction(spec.v_max_rad_s)
1542:         )
1543: 
1544:     def test_oversized_integer_time_inputs_fail_closed_without_raising(self):
1545:         spec = JointSpec(
1546:             "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0,
1547:             "fixture: oversized integer time",
1548:         )
1549:         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
1550:         target = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
1551: 
1552:         for now, gap in ((10**400, 1.0), (1.0, 10**400)):
1553:             code, emitted, reference, packet = shape_reference_joint(
1554:                 spec, target, anchor, now, gap
1555:             )
1556:             self.assertIs(code, DecisionCode.INVALID_ARGUMENT)
1557:             self.assertIsNone(emitted)
1558:             self.assertIsNone(reference)
1559:             self.assertIsNone(packet)
1560: 
1561:     def test_quantization_stall_fault_is_attributed_only_to_failing_joint(self):
1562:         clock = DeterministicClock(0.0)
1563:         specs = (
1564:             JointSpec(
1565:                 "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001,
1566:                 "fixture: tiny-cadence stall J1",
1567:             ),
1568:             JointSpec(
1569:                 "J2", 1, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001,
1570:                 "fixture: tiny-cadence hold J2",
1571:             ),
1572:         )
1573:         core = JointCore(specs, clock=clock, max_reference_gap_s=1.0)
1574:         station = FakeStation(core)
1575:         self.assertTrue(station.connect().accepted)
1576:         owner = station.claim("quantization-stall-test")
1577:         self.assertTrue(core.begin_check().accepted)
1578:         self.assertTrue(core.receive(0, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
1579:         self.assertTrue(core.receive(1, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
1580:         self.assertTrue(core.checked().accepted)
1581:         self.assertTrue(station.arm(owner).accepted)
1582:         window = station.issue_window(1.0)
1583:         target = Target(
1584:             1,
1585:             (
1586:                 JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
1587:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
1588:             ),
1589:             window=window,
1590:             owner=owner,
1591:         )
1592:         self.assertTrue(station.submit(target).accepted)
1593:         clock.value = 1e-10
1594: 
1595:         self.assertIsNone(core.prepare_refresh())
1596:         snapshot = core.snapshot()
1597:         self.assertEqual(snapshot.affected_joints, ("J1",))
1598:         self.assertTrue(snapshot.faults[0].constraint_fault)
1599: 
1600:     def test_final_write_gate_rechecks_gap_and_limits(self):
1601:         core, station, owner = self._armed_station(max_reference_gap_s=0.2)
1602:         window = station.issue_window(0.5)
1603:         target = Target(
1604:             1,
1605:             (
1606:                 JointTarget(0.05, 0.0, 0.0, 1.0, 0.1),
1607:                 JointTarget(0.05, 0.0, 0.0, 1.0, 0.1),
1608:             ),
1609:             window=window,
1610:             owner=owner,
1611:         )
1612:         self.assertTrue(station.submit(target).accepted)
1613:         self.clock.value += 0.05
1614:         plan = core.prepare_refresh()
1615:         self.assertIsNotNone(plan)
1616: 
1617:         # Before claim_dispatch, time advances past max_reference_gap_s
1618:         self.clock.value += 0.25
1619:         # Gate must deny write
1620:         self.assertFalse(core.claim_dispatch(plan.plan_id, 0))
1621: 
1622: 
1623: if __name__ == "__main__":
1624:     unittest.main()

## test_controller_expiry.py
1: """Acceptance tests for C07 command expiry, window authority, and refresh dispatch."""
2: 
3: import math
4: import unittest
5: from unittest.mock import patch
6: 
7: from im6014_codec import command, position_to_raw, raw_to_position
8: from joint_contract import (
9:     CommunicationFailure,
10:     DecisionCode,
11:     IntentWindow,
12:     JointSpec,
13:     MotorHealth,
14:     OwnerToken,
15:     SourceIdentity,
16:     State,
17:     Target,
18:     WriteResult,
19: )
20: from joint_controller import JointCore
21: from joint_mapping import JointMap, JointSample, JointTarget
22: from im6014_serial import TransactionTimeoutError, WriteCancelledError, exchange
23: from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP
24: 
25: 
26: SOURCE = SourceIdentity("fixture", "expiry-test", 1)
27: 
28: 
29: class ControllerExpiryTests(unittest.TestCase):
30:     def setUp(self):
31:         self.specs = (
32:             JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
33:             JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
34:         )
35:         self.valid_joints = (
36:             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
37:             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
38:         )
39: 
40:     def _armed_core(self, clock=None, *, feedback_max_age_s=1.0, max_window_s=1.0):
41:         if clock is None:
42:             clock = DeterministicClock(0.0)
43:         core = JointCore(
44:             self.specs,
45:             clock=clock,
46:             feedback_max_age_s=feedback_max_age_s,
47:             max_window_s=max_window_s,
48:             max_reference_gap_s=1.0,
49:         )
50:         station = FakeStation(core)
51:         self.assertTrue(station.connect().accepted)
52:         owner = station.claim("fixture")
53:         self.assertTrue(station.check().accepted)
54:         self.assertTrue(station.arm(owner).accepted)
55:         return core, station, clock
56: 
57:     def test_expired_incoming_and_equality_boundary_reject_without_watermark_corruption(self):
58:         core, station, clock = self._armed_core()
59:         self.assertEqual(core.snapshot().last_sequence, -1)
60: 
61:         # Submit valid initial target to establish watermark at 5
62:         w0 = station.issue_window(0.5)
63:         t0 = Target(5, self.valid_joints, window=w0, owner=station.owner)
64:         self.assertTrue(station.submit(t0).accepted)
65:         self.assertEqual(core.snapshot().last_sequence, 5)
66:         self.assertEqual(core.snapshot().admitted_target, t0)
67: 
68:         # Issue window valid for 0.4s (expires at 0.4s)
69:         w1 = station.issue_window(0.4)
70:         self.assertEqual(w1.created_at_s, 0.0)
71:         self.assertEqual(w1.expires_at_s, 0.4)
72: 
73:         # Exact equality boundary: now == expires_at_s is expired
74:         clock.value = 0.4
75:         t_boundary = Target(6, self.valid_joints, window=w1, owner=station.owner)
76:         d_boundary = station.submit(t_boundary)
77:         self.assertFalse(d_boundary.accepted)
78:         self.assertEqual(d_boundary.code, DecisionCode.EXPIRED)
79:         # Watermark and valid goal preserved
80:         self.assertEqual(core.snapshot().last_sequence, 5)
81:         self.assertEqual(core.snapshot().admitted_target, t0)
82: 
83:         # Strictly past expiry: now > expires_at_s is expired
84:         clock.value = 0.40001
85:         t_past = Target(7, self.valid_joints, window=w1, owner=station.owner)
86:         d_past = station.submit(t_past)
87:         self.assertFalse(d_past.accepted)
88:         self.assertEqual(d_past.code, DecisionCode.EXPIRED)
89:         self.assertEqual(core.snapshot().last_sequence, 5)
90:         self.assertEqual(core.snapshot().admitted_target, t0)
91: 
92:     def test_delayed_computation_cannot_get_new_arrival_ttl(self):
93:         core, station, clock = self._armed_core()
94:         # Client requests window at time 0.0 valid for 0.2s
95:         w1 = station.issue_window(0.2)
96:         self.assertEqual(w1.expires_at_s, 0.2)
97: 
98:         # Client computation takes 0.3s (now is 0.3)
99:         clock.value = 0.3
100:         target1 = Target(1, self.valid_joints, window=w1, owner=station.owner)
101:         # Arrival at core does NOT grant new TTL; rejects as EXPIRED
102:         decision = station.submit(target1)
103:         self.assertFalse(decision.accepted)
104:         self.assertEqual(decision.code, DecisionCode.EXPIRED)
105:         self.assertEqual(core.snapshot().last_sequence, -1)
106:         self.assertIsNone(core.snapshot().admitted_target)
107: 
108:         # Client cannot forge a window with extended expiry
109:         forged_window = IntentWindow(w1.id, w1.created_at_s, 0.9)
110:         forged_target = Target(1, self.valid_joints, window=forged_window, owner=station.owner)
111:         d_forged = station.submit(forged_target)
112:         self.assertFalse(d_forged.accepted)
113:         self.assertEqual(d_forged.code, DecisionCode.INVALID_ARGUMENT)
114:         self.assertEqual(core.snapshot().last_sequence, -1)
115: 
116:         # If station issues a new window w2, client cannot submit old computation with w1
117:         w2 = station.issue_window(0.2)
118:         d_old = station.submit(target1)
119:         self.assertFalse(d_old.accepted)
120:         self.assertEqual(d_old.code, DecisionCode.EXPIRED)
121: 
122:     def test_new_submission_cannot_revive_expired_moving_goal(self):
123:         core, station, clock = self._armed_core()
124:         first_window = station.issue_window(0.2)
125:         first = Target(5, self.valid_joints, window=first_window, owner=station.owner)
126:         self.assertTrue(station.submit(first).accepted)
127:         clock.value = 0.05
128:         self.assertIsNotNone(station.refresh())
129:         self.assertIs(core.snapshot().state, State.MOVING)
130: 
131:         clock.value = first_window.expires_at_s
132:         fresh_window = station.issue_window(0.2)
133:         replacement = Target(6, self.valid_joints, window=fresh_window, owner=station.owner)
134:         decision = station.submit(replacement)
135: 
136:         self.assertFalse(decision.accepted)
137:         self.assertEqual(decision.code, DecisionCode.EXPIRED)
138:         self.assertIs(core.snapshot().state, State.STOPPED)
139:         self.assertIsNone(core.snapshot().admitted_target)
140:         self.assertEqual(core.snapshot().last_sequence, 5)
141: 
142:     def test_invalid_replacement_preserves_only_a_still_valid_goal(self):
143:         core, station, clock = self._armed_core()
144:         window = station.issue_window(0.2)
145:         current = Target(5, self.valid_joints, window=window, owner=station.owner)
146:         self.assertTrue(station.submit(current).accepted)
147: 
148:         invalid = Target(9, (self.valid_joints[0],), window=window, owner=station.owner)
149:         decision = station.submit(invalid)
150:         self.assertFalse(decision.accepted)
151:         self.assertEqual(decision.code, DecisionCode.INVALID_ARGUMENT)
152:         self.assertEqual(core.snapshot().admitted_target, current)
153:         self.assertEqual(core.snapshot().last_sequence, 5)
154: 
155:         clock.value = window.expires_at_s
156:         fresh_window = station.issue_window(0.2)
157:         invalid_after_expiry = Target(10, (self.valid_joints[0],), window=fresh_window, owner=station.owner)
158:         expired_decision = station.submit(invalid_after_expiry)
159:         self.assertFalse(expired_decision.accepted)
160:         self.assertEqual(expired_decision.code, DecisionCode.EXPIRED)
161:         self.assertIsNone(core.snapshot().admitted_target)
162:         self.assertIs(core.snapshot().state, State.STOPPED)
163:         self.assertEqual(core.snapshot().last_sequence, 5)
164: 
165:     def test_goal_expires_after_admission_and_before_prepare_or_actual_write(self):
166:         core, station, clock = self._armed_core()
167:         w = station.issue_window(0.5)
168:         target = Target(1, self.valid_joints, window=w, owner=station.owner)
169:         self.assertTrue(station.submit(target).accepted)
170:         self.assertEqual(core.snapshot().admitted_target, target)
171: 
172:         # Goal expires after admission: clock moves to 0.55 before prepare_refresh
173:         clock.value = 0.55
174:         plan = core.prepare_refresh()
175:         self.assertIsNone(plan)
176:         # Goal is withdrawn and core disarms to STOPPED
177:         snap = core.snapshot()
178:         self.assertIsNone(snap.admitted_target)
179:         self.assertIsNone(snap.prepared_plan)
180:         self.assertIs(snap.state, State.STOPPED)
181: 
182:     def test_two_joint_first_write_then_expiry_or_revoke_blocks_second_and_records_only_first(self):
183:         core, station, clock = self._armed_core()
184:         w = station.issue_window(0.5)
185:         target = Target(1, self.valid_joints, window=w, owner=station.owner)
186:         self.assertTrue(station.submit(target).accepted)
187: 
188:         clock.value = 0.05
189:         plan = core.prepare_refresh()
190:         self.assertIsNotNone(plan)
191: 
192:         # Joint 0 claim and complete write
193:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
194:         d0 = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
195:         self.assertTrue(d0.accepted)
196:         self.assertIs(core.snapshot().state, State.MOVING)
197: 
198:         # Check J0 record is stored, J1 is still None
199:         records_after_j0 = core.snapshot().dispatched_records
200:         self.assertIsNotNone(records_after_j0[0])
201:         self.assertEqual(records_after_j0[0].sequence, 1)
202:         self.assertEqual(records_after_j0[0].target, plan.joint_targets[0])
203:         self.assertIsNone(records_after_j0[1])
204: 
205:         # Expiry occurs before Joint 1 write
206:         clock.value = 0.55
207:         # Joint 1 claim fails due to expiry
208:         self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
209: 
210:         # Core disarms to STOPPED, goal withdrawn, J0 record preserved, J1 remained unwritten
211:         snap = core.snapshot()
212:         self.assertIs(snap.state, State.STOPPED)
213:         self.assertIsNone(snap.admitted_target)
214:         self.assertIsNone(snap.prepared_plan)
215:         self.assertIsNotNone(snap.dispatched_records[0])
216:         self.assertIsNone(snap.dispatched_records[1])
217: 
218:     def test_reset_input_buffer_advancing_clock_causes_final_gate_cancellation_with_zero_mode1_write(self):
219:         core, station, clock = self._armed_core()
220:         w = station.issue_window(0.5)
221:         target = Target(1, self.valid_joints, window=w, owner=station.owner)
222:         self.assertTrue(station.submit(target).accepted)
223: 
224:         clock.value = 0.05
225:         plan = core.prepare_refresh()
226:         self.assertIsNotNone(plan)
227: 
228:         # Fake bus where reset_input_buffer takes enough time to advance the clock past expiry
229:         written_packets = []
230: 
231:         class TimeAdvancingBus:
232:             def __init__(self):
233:                 self.timeout = 0.1
234:                 self.in_waiting = 0
235: 
236:             def reset_input_buffer(self):
237:                 clock.value = 0.6  # Past window expiry of 0.5s!
238: 
239:             def write(self, packet):
240:                 written_packets.append(packet)
241:                 return len(packet)
242: 
243:             def read(self, size):
244:                 return b""
245: 
246:         bus = TimeAdvancingBus()
247:         pkt = command(0, mode=1)
248: 
249:         with self.assertRaises(WriteCancelledError):
250:             exchange(
251:                 bus,
252:                 pkt,
253:                 motor_id=0,
254:                 deadline_s=0.2,
255:                 before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
256:                 on_write=lambda res: core.dispatch_result(plan.plan_id, 0, res),
257:             )
258: 
259:         # Zero mode-1 packets were written to the bus!
260:         self.assertEqual(written_packets, [])
261:         # Final gate cancellation disarmed core to STOPPED and withdrew goal
262:         self.assertIs(core.snapshot().state, State.STOPPED)
263:         self.assertIsNone(core.snapshot().admitted_target)
264: 
265:     def test_expiry_during_feedback_wait_causes_no_later_write(self):
266:         core, station, clock = self._armed_core()
267:         w = station.issue_window(0.5)
268:         target = Target(1, self.valid_joints, window=w, owner=station.owner)
269:         self.assertTrue(station.submit(target).accepted)
270: 
271:         clock.value = 0.05
272:         plan = core.prepare_refresh()
273:         self.assertIsNotNone(plan)
274: 
275:         # First joint writes successfully
276:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
277:         self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)
278: 
279:         # Feedback wait takes long time, crossing expiry
280:         clock.value = 0.55
281: 
282:         # Attempting second joint write: claim fails because goal has expired
283:         self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
284:         # Core is disarmed to STOPPED
285:         self.assertIs(core.snapshot().state, State.STOPPED)
286: 
287:     def test_repeated_refresh_bounded_until_expiry(self):
288:         core, station, clock = self._armed_core()
289:         w = station.issue_window(0.5)
290:         stable_joints = (
291:             JointTarget(raw_to_position(position_to_raw(0.1)), 0.0, 0.0, 1.0, 0.1),
292:             JointTarget(raw_to_position(position_to_raw(0.2)), 0.0, 0.0, 1.0, 0.1),
293:         )
294:         target = Target(1, stable_joints, window=w, owner=station.owner)
295:         self.assertTrue(station.submit(target).accepted)
296: 
297:         # At t=0.1, refresh succeeds
298:         clock.value = 0.1
299:         plan1 = station.refresh()
300:         self.assertIsNotNone(plan1)
301:         self.assertEqual(plan1.target, target)
302:         self.assertIs(core.snapshot().state, State.MOVING)
303: 
304:         # At t=0.2, second refresh succeeds with the same admitted goal
305:         clock.value = 0.2
306:         plan2 = station.refresh()
307:         self.assertIsNotNone(plan2)
308:         self.assertEqual(plan2.target, target)
309: 
310:         # At t=0.4, third refresh succeeds
311:         clock.value = 0.4
312:         plan3 = station.refresh()
313:         self.assertIsNotNone(plan3)
314: 
315:         # At t=0.5, window expires: refresh returns None and disarms to STOPPED
316:         clock.value = 0.5
317:         plan_expired = station.refresh()
318:         self.assertIsNone(plan_expired)
319:         self.assertIs(core.snapshot().state, State.STOPPED)
320:         self.assertIsNone(core.snapshot().admitted_target)
321: 
322:     def test_invalid_higher_seq_preserves_valid_goal(self):
323:         core, station, clock = self._armed_core()
324:         w = station.issue_window(1.0)
325:         t5 = Target(5, self.valid_joints, window=w, owner=station.owner)
326:         self.assertTrue(station.submit(t5).accepted)
327:         self.assertEqual(core.snapshot().last_sequence, 5)
328:         self.assertEqual(core.snapshot().admitted_target, t5)
329: 
330:         # High sequence with invalid joint target count
331:         bad_high = Target(100, (self.valid_joints[0],), window=w, owner=station.owner)
332:         d_bad = station.submit(bad_high)
333:         self.assertFalse(d_bad.accepted)
334:         self.assertEqual(d_bad.code, DecisionCode.INVALID_ARGUMENT)
335: 
336:         # Watermark is still 5, admitted goal is still t5
337:         self.assertEqual(core.snapshot().last_sequence, 5)
338:         self.assertEqual(core.snapshot().admitted_target, t5)
339: 
340:         # High sequence with out-of-range torque
341:         bad_torque = Target(100, (JointTarget(0, 0, 10.0, 1, .1), self.valid_joints[1]), window=w, owner=station.owner)
342:         d_torque = station.submit(bad_torque)
343:         self.assertFalse(d_torque.accepted)
344:         self.assertEqual(d_torque.code, DecisionCode.INVALID_ARGUMENT)
345:         self.assertEqual(core.snapshot().last_sequence, 5)
346:         self.assertEqual(core.snapshot().admitted_target, t5)
347: 
348:     def test_stop_fault_disconnect_invalidate_plans_but_retain_sequence(self):
349:         core, station, clock = self._armed_core()
350:         w = station.issue_window(1.0)
351:         target = Target(10, self.valid_joints, window=w, owner=station.owner)
352:         self.assertTrue(station.submit(target).accepted)
353:         self.assertEqual(core.snapshot().last_sequence, 10)
354: 
355:         clock.value = 0.05
356:         plan = core.prepare_refresh()
357:         self.assertIsNotNone(plan)
358:         self.assertEqual(core.snapshot().prepared_plan, plan)
359: 
360:         # Stop invalidates plan and goal, retains sequence watermark
361:         self.assertTrue(station.stop().accepted)
362:         self.assertIs(core.snapshot().state, State.STOPPED)
363:         self.assertIsNone(core.snapshot().admitted_target)
364:         self.assertIsNone(core.snapshot().prepared_plan)
365:         self.assertEqual(core.snapshot().last_sequence, 10)
366: 
367:         # Re-arm and set up new target
368:         owner2 = station.claim("fixture-2")
369:         self.assertTrue(station.check().accepted)
370:         self.assertTrue(station.arm(owner2).accepted)
371:         w2 = station.issue_window(1.0)
372:         target2 = Target(12, self.valid_joints, window=w2, owner=owner2)
373:         self.assertTrue(station.submit(target2).accepted)
374:         clock.value = 0.1
375:         plan2 = core.prepare_refresh()
376:         self.assertIsNotNone(plan2)
377: 
378:         # Fault invalidates plan and goal, retains sequence
379:         self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
380:         self.assertIs(core.snapshot().state, State.FAULT)
381:         self.assertIsNone(core.snapshot().admitted_target)
382:         self.assertIsNone(core.snapshot().prepared_plan)
383:         self.assertEqual(core.snapshot().last_sequence, 12)
384: 
385:         # Disconnect invalidates plan and goal, retains sequence
386:         self.assertTrue(station.disconnect().accepted)
387:         self.assertIs(core.snapshot().state, State.DISCONNECTED)
388:         self.assertIsNone(core.snapshot().admitted_target)
389:         self.assertIsNone(core.snapshot().prepared_plan)
390:         self.assertEqual(core.snapshot().last_sequence, 12)
391: 
392:     def test_wrong_duplicate_out_of_order_claims_reject(self):
393:         core, station, clock = self._armed_core()
394:         w = station.issue_window(1.0)
395:         target = Target(1, self.valid_joints, window=w, owner=station.owner)
396:         self.assertTrue(station.submit(target).accepted)
397: 
398:         clock.value = 0.05
399:         plan = core.prepare_refresh()
400:         self.assertIsNotNone(plan)
401: 
402:         # Wrong plan ID rejects
403:         self.assertFalse(core.claim_dispatch(plan.plan_id + 99, 0))
404: 
405:         # Out-of-order joint index rejects (index 1 before index 0)
406:         self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
407: 
408:         # Correct claim of index 0
409:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
410: 
411:         # Duplicate claim of index 0 rejects
412:         self.assertFalse(core.claim_dispatch(plan.plan_id, 0))
413: 
414:         # Out-of-bounds index rejects
415:         self.assertFalse(core.claim_dispatch(plan.plan_id, 5))
416:         self.assertFalse(core.claim_dispatch(plan.plan_id, -1))
417: 
418:         # One unresolved write blocks both reprepare and the next joint.
419:         self.assertIsNone(core.prepare_refresh())
420:         self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
421:         self.assertFalse(core.dispatch_result(plan.plan_id + 99, 0, WriteResult.COMPLETE).accepted)
422:         self.assertFalse(core.dispatch_result(plan.plan_id, 1, WriteResult.COMPLETE).accepted)
423:         self.assertFalse(core.dispatch_result(plan.plan_id, 0, None).accepted)
424:         self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)
425: 
426:         # Joint 1 is claimable only after joint 0's outcome arrives.
427:         self.assertTrue(core.claim_dispatch(plan.plan_id, 1))
428:         self.assertTrue(core.dispatch_result(plan.plan_id, 1, WriteResult.COMPLETE).accepted)
429: 
430:     def test_stop_after_claim_preserves_completed_receipt_without_rearming(self):
431:         core, station, clock = self._armed_core()
432:         target = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
433:         self.assertTrue(station.submit(target).accepted)
434:         clock.value = 0.05
435:         plan = core.prepare_refresh()
436:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
437:         claim_time = clock.value
438: 
439:         self.assertTrue(core.stop().accepted)
440:         receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
441: 
442:         self.assertTrue(receipt.accepted)
443:         snapshot = core.snapshot()
444:         self.assertIs(snapshot.state, State.STOPPED)
445:         self.assertIsNone(snapshot.admitted_target)
446:         self.assertIsNone(snapshot.prepared_plan)
447:         self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
448:         self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
449:         self.assertIsNone(core.prepare_refresh())
450:         self.assertFalse(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)
451: 
452:     def test_expiry_after_claim_preserves_completed_receipt_without_moving(self):
453:         core, station, clock = self._armed_core()
454:         window = station.issue_window(0.2)
455:         target = Target(1, self.valid_joints, window=window, owner=station.owner)
456:         self.assertTrue(station.submit(target).accepted)
457:         clock.value = 0.05
458:         plan = core.prepare_refresh()
459:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
460:         claim_time = clock.value
461: 
462:         clock.value = window.expires_at_s
463:         receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
464: 
465:         self.assertTrue(receipt.accepted)
466:         snapshot = core.snapshot()
467:         self.assertIs(snapshot.state, State.STOPPED)
468:         self.assertIsNone(snapshot.admitted_target)
469:         self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
470:         self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
471:         self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
472: 
473:     def test_invalidated_plan_receipt_records_write_without_reviving_old_goal(self):
474:         core, station, clock = self._armed_core()
475:         first = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
476:         self.assertTrue(station.submit(first).accepted)
477:         clock.value = 0.05
478:         plan = core.prepare_refresh()
479:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
480: 
481:         replacement_joints = (
482:             JointTarget(plan.joint_targets[0].q_rad, 0.0, 0.0, 1.0, 0.1),
483:             self.valid_joints[1],
484:         )
485:         replacement = Target(
486:             2,
487:             replacement_joints,
488:             window=station.issue_window(1.0),
489:             owner=station.owner,
490:         )
491:         self.assertTrue(station.submit(replacement).accepted)
492:         self.assertIsNone(core.snapshot().prepared_plan)
493:         self.assertIsNone(core.prepare_refresh())
494: 
495:         receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
496:         self.assertTrue(receipt.accepted)
497:         snapshot = core.snapshot()
498:         self.assertIs(snapshot.admitted_target, replacement)
499:         self.assertIs(snapshot.state, State.ARMED)
500:         self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
501:         self.assertIsNone(snapshot.prepared_plan)
502: 
503:         clock.value = 0.1
504:         replacement_plan = core.prepare_refresh()
505:         self.assertIsNotNone(replacement_plan)
506:         self.assertIs(replacement_plan.target, replacement)
507: 
508:     def test_complete_write_then_bad_timeout_feedback_still_counted_actually_dispatched(self):
509:         core, station, clock = self._armed_core()
510:         w = station.issue_window(1.0)
511:         target = Target(1, self.valid_joints, window=w, owner=station.owner)
512:         self.assertTrue(station.submit(target).accepted)
513: 
514:         clock.value = 0.05
515:         plan = core.prepare_refresh()
516:         self.assertIsNotNone(plan)
517: 
518:         # Joint 0 claims and writes successfully
519:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
520:         d_res = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
521:         self.assertTrue(d_res.accepted)
522: 
523:         # Dispatched record is committed
524:         snap_after_write = core.snapshot()
525:         self.assertIsNotNone(snap_after_write.dispatched_records[0])
526:         self.assertEqual(snap_after_write.dispatched_records[0].sequence, 1)
527: 
528:         # Feedback from serial communication times out
529:         self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
530:         snap_after_failure = core.snapshot()
531:         self.assertIs(snap_after_failure.state, State.FAULT)
532:         # Dispatched record is STILL preserved despite communication failure!
533:         self.assertIsNotNone(snap_after_failure.dispatched_records[0])
534:         self.assertEqual(snap_after_failure.dispatched_records[0].sequence, 1)
535: 
536:     def test_partial_failed_write_faults(self):
537:         core, station, clock = self._armed_core()
538:         w = station.issue_window(1.0)
539:         target = Target(1, self.valid_joints, window=w, owner=station.owner)
540:         self.assertTrue(station.submit(target).accepted)
541: 
542:         clock.value = 0.05
543:         plan = core.prepare_refresh()
544:         self.assertIsNotNone(plan)
545: 
546:         # J0 claims, but write fails
547:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
548:         d_fail = core.dispatch_result(plan.plan_id, 0, WriteResult.FAILED)
549:         self.assertFalse(d_fail.accepted)
550:         self.assertEqual(d_fail.code, DecisionCode.FAULT_LATCHED)
551: 
552:         # Latches fault on joint 0
553:         snap = core.snapshot()
554:         self.assertIs(snap.state, State.FAULT)
555:         self.assertTrue(snap.fault_latched)
556:         self.assertEqual(snap.affected_joints, ("J1",))
557:         self.assertEqual(snap.faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)
558:         # Motion withdrawn, plan invalidated
559:         self.assertIsNone(snap.admitted_target)
560:         self.assertIsNone(snap.prepared_plan)
561:         # J0 was not completely written so dispatched record is None
562:         self.assertIsNone(snap.dispatched_records[0])
563:         self.assertEqual(snap.dispatch_attempts[0].result, WriteResult.FAILED)
564: 
565:     def test_partial_attempt_keeps_previous_complete_dispatched_record(self):
566:         core, station, clock = self._armed_core()
567:         first = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
568:         self.assertTrue(station.submit(first).accepted)
569:         clock.value = 0.05
570:         plan = core.prepare_refresh()
571:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
572:         self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)
573: 
574:         next_target = Target(
575:             2,
576:             (
577:                 JointTarget(plan.joint_targets[0].q_rad, 0.0, 0.0, 1.0, 0.1),
578:                 self.valid_joints[1],
579:             ),
580:             window=station.issue_window(1.0),
581:             owner=station.owner,
582:         )
583:         self.assertTrue(core.submit_target(next_target).accepted)
584:         clock.value = 0.1
585:         next_plan = core.prepare_refresh()
586:         self.assertTrue(core.claim_dispatch(next_plan.plan_id, 0))
587:         failed = core.dispatch_result(next_plan.plan_id, 0, WriteResult.PARTIAL)
588: 
589:         self.assertFalse(failed.accepted)
590:         snapshot = core.snapshot()
591:         self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
592:         self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.PARTIAL)
593:         self.assertEqual(snapshot.dispatch_attempts[0].sequence, 2)
594:         self.assertEqual(snapshot.faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)
595: 
596:     def test_complete_write_is_recorded_then_invalid_end_clock_faults_joint(self):
597:         for invalid_end_time in (math.nan, 0.5):
598:             with self.subTest(invalid_end_time=invalid_end_time):
599:                 core, station, clock = self._armed_core(DeterministicClock(1.0))
600:                 target = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
601:                 self.assertTrue(station.submit(target).accepted)
602:                 clock.value = 1.05
603:                 plan = core.prepare_refresh()
604:                 claim_time = clock.value
605: 
606:                 transaction_clock = DeterministicClock(0.0)
607:                 writes = []
608: 
609:                 class ClockFailingBus:
610:                     timeout = 0.1
611: 
612:                     def reset_input_buffer(self):
613:                         pass
614: 
615:                     def write(self, packet):
616:                         writes.append(packet)
617:                         clock.value = invalid_end_time
618:                         transaction_clock.value = 0.1
619:                         return len(packet)
620: 
621:                 with patch("im6014_serial._monotonic", transaction_clock):
622:                     with self.assertRaises(TransactionTimeoutError):
623:                         exchange(
624:                             ClockFailingBus(), b"x" * 20, 0, deadline_s=0.05,
625:                             before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
626:                             on_write=lambda result: core.dispatch_result(plan.plan_id, 0, result),
627:                         )
628:                 self.assertEqual(len(writes), 1)
629:                 with self.assertRaises(ValueError):
630:                     core.snapshot()
631: 
632:                 clock.value = claim_time
633:                 snapshot = core.snapshot()
634:                 self.assertIs(snapshot.state, State.FAULT)
635:                 self.assertEqual(snapshot.faults[0].communication_error, CommunicationFailure.CLOCK_FAILURE)
636:                 self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
637:                 self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
638:                 self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.COMPLETE)
639:                 self.assertIsNone(snapshot.admitted_target)
640:                 self.assertIsNone(snapshot.prepared_plan)
641:                 self.assertFalse(core.begin_check().accepted)
642:                 self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
643: 
644:     def test_exchange_reports_actual_write_before_enforcing_deadline(self):
645:         transaction_clock = DeterministicClock(0.0)
646:         results = []
647: 
648:         class DeadlineBus:
649:             timeout = 0.1
650: 
651:             def __init__(self, returned):
652:                 self.returned = returned
653:                 self.write_count = 0
654: 
655:             def reset_input_buffer(self):
656:                 pass
657: 
658:             def write(self, packet):
659:                 self.write_count += 1
660:                 transaction_clock.value = 0.1
661:                 return self.returned
662: 
663:         complete_bus = DeadlineBus(20)
664:         with patch("im6014_serial._monotonic", transaction_clock):
665:             with self.assertRaises(TransactionTimeoutError):
666:                 exchange(complete_bus, b"x" * 20, 0, deadline_s=0.05, on_write=results.append)
667:         self.assertEqual(complete_bus.write_count, 1)
668:         self.assertEqual(results, [WriteResult.COMPLETE])
669: 
670:         transaction_clock.value = 0.0
671:         results.clear()
672:         partial_bus = DeadlineBus(1)
673:         with patch("im6014_serial._monotonic", transaction_clock):
674:             with self.assertRaises(TransactionTimeoutError):
675:                 exchange(partial_bus, b"x" * 20, 0, deadline_s=0.05, on_write=results.append)
676:         self.assertEqual(partial_bus.write_count, 1)
677:         self.assertEqual(results, [WriteResult.PARTIAL])
678: 
679:     def test_expiry_after_successful_claim_reports_prewrite_deadline(self):
680:         core, station, clock = self._armed_core()
681:         target = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
682:         self.assertTrue(station.submit(target).accepted)
683:         clock.value = 0.05
684:         plan = core.prepare_refresh()
685: 
686:         transaction_clock = DeterministicClock(0.0)
687:         results = []
688: 
689:         class DeadlineBus:
690:             timeout = 0.1
691: 
692:             def __init__(self):
693:                 self.write_count = 0
694: 
695:             def reset_input_buffer(self):
696:                 pass
697: 
698:             def write(self, packet):
699:                 self.write_count += 1
700:                 return len(packet)
701: 
702:         def claim_then_expire():
703:             self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
704:             transaction_clock.value = 0.05
705:             return True
706: 
707:         def record_result(result):
708:             results.append(result)
709:             return core.dispatch_result(plan.plan_id, 0, result)
710: 
711:         bus = DeadlineBus()
712:         with patch("im6014_serial._monotonic", transaction_clock):
713:             with self.assertRaises(TransactionTimeoutError):
714:                 exchange(
715:                     bus, b"x" * 20, 0, deadline_s=0.05,
716:                     before_write=claim_then_expire,
717:                     on_write=record_result,
718:                 )
719: 
720:         self.assertEqual(bus.write_count, 0)
721:         self.assertEqual(results, [WriteResult.PREWRITE_DEADLINE])
722:         snapshot = core.snapshot()
723:         self.assertIs(snapshot.state, State.FAULT)
724:         self.assertEqual(snapshot.faults[0].motor_id, 0)
725:         self.assertEqual(snapshot.faults[0].communication_error, CommunicationFailure.PREWRITE_DEADLINE)
726:         self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.PREWRITE_DEADLINE)
727:         self.assertIsNone(snapshot.dispatched_records[0])
728:         self.assertIsNone(snapshot.admitted_target)
729:         self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
730: 
731:     def test_exchange_reports_raised_write_once_and_callback_failure_stops_feedback(self):
732:         results = []
733:         core, station, clock = self._armed_core()
734:         target = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
735:         self.assertTrue(station.submit(target).accepted)
736:         clock.value = 0.05
737:         plan = core.prepare_refresh()
738: 
739:         class RaisingBus:
740:             timeout = 0.1
741: 
742:             def __init__(self):
743:                 self.write_count = 0
744: 
745:             def reset_input_buffer(self):
746:                 pass
747: 
748:             def write(self, packet):
749:                 self.write_count += 1
750:                 raise OSError("driver failure")
751: 
752:         def record_result(result):
753:             results.append(result)
754:             return core.dispatch_result(plan.plan_id, 0, result)
755: 
756:         raising_bus = RaisingBus()
757:         with self.assertRaisesRegex(OSError, "driver failure"):
758:             exchange(
759:                 raising_bus, b"x" * 20, 0,
760:                 before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
761:                 on_write=record_result,
762:             )
763:         self.assertEqual(raising_bus.write_count, 1)
764:         self.assertEqual(results, [WriteResult.FAILED])
765:         self.assertIs(core.snapshot().state, State.FAULT)
766:         self.assertEqual(core.snapshot().dispatch_attempts[0].result, WriteResult.FAILED)
767:         self.assertEqual(core.snapshot().faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)
768: 
769:         class CompleteBus:
770:             timeout = 0.1
771: 
772:             def __init__(self):
773:                 self.write_count = 0
774:                 self.read_called = False
775: 
776:             def reset_input_buffer(self):
777:                 pass
778: 
779:             def write(self, packet):
780:                 self.write_count += 1
781:                 return len(packet)
782: 
783:             def read(self, size):
784:                 self.read_called = True
785:                 return b""
786: 
787:         bus = CompleteBus()
788:         callback_calls = []
789: 
790:         def broken_callback(result):
791:             callback_calls.append(result)
792:             raise RuntimeError("receipt failed")
793: 
794:         with self.assertRaisesRegex(RuntimeError, "receipt failed"):
795:             exchange(bus, b"x" * 20, 0, on_write=broken_callback)
796:         self.assertEqual(bus.write_count, 1)
797:         self.assertEqual(callback_calls, [WriteResult.COMPLETE])
798:         self.assertFalse(bus.read_called)
799: 
800:     def test_clock_regression_before_receive_cannot_replace_sample_or_timestamp(self):
801:         clock = DeterministicClock(10.0)
802:         core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
803:         self.assertTrue(core.begin_connect().accepted)
804:         self.assertTrue(core.connected(SOURCE).accepted)
805:         self.assertTrue(core.begin_check().accepted)
806: 
807:         # Valid receive at t=10.0
808:         sample_initial = JointSample(0.5, 0.0, 0.0)
809:         self.assertTrue(core.receive(0, sample_initial, HEALTHY_STOP).accepted)
810:         snap_initial = core.snapshot()
811:         self.assertEqual(snap_initial.joints[0].received_at, 10.0)
812:         self.assertEqual(snap_initial.joints[0].sample.q_rad, 0.5)
813: 
814:         # Clock regresses to 5.0
815:         clock.value = 5.0
816:         corrupt_sample = JointSample(9.9, 0.0, 0.0)
817:         with self.assertRaises(ValueError):
818:             core.receive(0, corrupt_sample, HEALTHY_STOP)
819: 
820:         # High-water mark check threw BEFORE overwriting observation
821:         # Previous observation remains uncorrupted
822:         clock.value = 10.0  # restore to valid non-regressing time for snapshot
823:         snap_after = core.snapshot()
824:         self.assertEqual(snap_after.joints[0].received_at, 10.0)
825:         self.assertEqual(snap_after.joints[0].sample.q_rad, 0.5)
826: 
827:     def test_invalid_clock_cannot_release_writes(self):
828:         core, station, clock = self._armed_core()
829:         w = station.issue_window(1.0)
830:         target = Target(1, self.valid_joints, window=w, owner=station.owner)
831:         self.assertTrue(station.submit(target).accepted)
832: 
833:         # A bad preparation clock revokes the old goal and pending authority.
834:         station.writes.clear()
835:         clock.value = math.nan
836:         with self.assertRaises(ValueError):
837:             core.prepare_refresh()
838:         clock.value = 0.1
839:         snapshot = core.snapshot()
840:         self.assertIs(snapshot.state, State.STOPPED)
841:         self.assertIsNone(snapshot.admitted_target)
842:         self.assertIsNone(snapshot.prepared_plan)
843:         self.assertIsNone(snapshot.current_owner)
844:         self.assertEqual(station.writes, [])
845:         self.assertIsNone(core.prepare_refresh())
846: 
847:         # A bad final-gate clock still raises without mutating the prepared plan.
848:         core2, station2, clock2 = self._armed_core()
849:         w2 = station2.issue_window(1.0)
850:         target2 = Target(1, self.valid_joints, window=w2, owner=station2.owner)
851:         self.assertTrue(station2.submit(target2).accepted)
852:         clock2.value = 0.1
853:         plan = core2.prepare_refresh()
854:         self.assertIsNotNone(plan)
855:         station2.writes.clear()
856: 
857:         clock2.value = 0.05  # Regressed!
858:         with self.assertRaises(ValueError):
859:             core2.claim_dispatch(plan.plan_id, 0)
860:         clock2.value = 0.1
861:         self.assertIs(core2.snapshot().prepared_plan, plan)
862:         self.assertIs(core2.snapshot().admitted_target, target2)
863:         self.assertEqual(station2.writes, [])
864: 
865:         # Stop still works even if clock fails or raises
866:         clock2.value = math.nan
867:         stop_decision = station2.stop()
868:         self.assertTrue(stop_decision.accepted)
869: 
870:     def test_max_window_s_configuration_and_monotonically_increasing_window_ids(self):
871:         clock = DeterministicClock(0.0)
872:         core = JointCore(self.specs, clock=clock, max_window_s=0.5, max_reference_gap_s=1.0)
873: 
874:         # Window exceeding max_window_s rejects
875:         with self.assertRaises(ValueError):
876:             core.issue_window(0.6)
877: 
878:         # Establish station authority before offering windows; claiming invalidates prior offers.
879:         station = FakeStation(core)
880:         self.assertTrue(station.connect().accepted)
881:         owner = station.claim("fixture")
882:         self.assertTrue(station.check().accepted)
883:         self.assertTrue(station.arm(owner).accepted)
884: 
885:         # Monotonically increasing window IDs without wrap
886:         w0 = core.issue_window(0.2)
887:         w1 = core.issue_window(0.2)
888:         w2 = core.issue_window(0.5)
889:         self.assertEqual(w0.id, 0)
890:         self.assertEqual(w1.id, 1)
891:         self.assertEqual(w2.id, 2)
892:         self.assertTrue(w0.id < w1.id < w2.id)
893: 
894:         # Older window w0 is rejected
895:         t_old = Target(1, self.valid_joints, window=w0, owner=owner)
896:         d_old = station.submit(t_old)
897:         self.assertFalse(d_old.accepted)
898:         self.assertEqual(d_old.code, DecisionCode.EXPIRED)
899: 
900:         # Latest window w2 is accepted
901:         t_latest = Target(1, self.valid_joints, window=w2, owner=owner)
902:         d_latest = station.submit(t_latest)
903:         self.assertTrue(d_latest.accepted)
904: 
905: 
906: if __name__ == "__main__":
907:     unittest.main()

## test_controller_owner.py
1: """Targeted unit and acceptance tests for C08 controller owner generations."""
2: 
3: from dataclasses import FrozenInstanceError
4: import unittest
5: 
6: from im6014_codec import command
7: from joint_contract import (
8:     CommunicationFailure,
9:     DecisionCode,
10:     JointSpec,
11:     MotorHealth,
12:     OwnerToken,
13:     SourceIdentity,
14:     State,
15:     Target,
16:     WriteResult,
17: )
18: from joint_controller import JointCore
19: from joint_mapping import JointMap, JointTarget
20: from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP, SAMPLE
21: 
22: 
23: SOURCE = SourceIdentity("fixture", "owner-test", 1)
24: 
25: 
26: class ControllerOwnerTests(unittest.TestCase):
27:     def setUp(self):
28:         self.clock = DeterministicClock(0.0)
29:         self.specs = (
30:             JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
31:             JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
32:         )
33:         self.valid_joints = (
34:             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
35:             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
36:         )
37: 
38:     def _armed_station(self, connection_id="human"):
39:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
40:         station = FakeStation(core)
41:         self.assertTrue(station.connect().accepted)
42:         owner = station.claim(connection_id)
43:         self.assertTrue(station.check().accepted)
44:         self.assertTrue(station.arm(owner).accepted)
45:         return core, station, owner
46: 
47:     def test_owner_token_validation_and_immutability(self):
48:         tok = OwnerToken("epoch-1", 1, "client-1")
49:         self.assertEqual(tok.epoch, "epoch-1")
50:         self.assertEqual(tok.generation, 1)
51:         self.assertEqual(tok.connection_id, "client-1")
52: 
53:         with self.assertRaises(FrozenInstanceError):
54:             tok.generation = 2
55:         with self.assertRaises(FrozenInstanceError):
56:             tok.epoch = "other"
57:         with self.assertRaises(FrozenInstanceError):
58:             tok.connection_id = "other"
59: 
60:         for bad_epoch in ("", "a" * 65, 123, None, True, b"epoch"):
61:             with self.subTest(bad_epoch=bad_epoch), self.assertRaises(ValueError):
62:                 OwnerToken(bad_epoch, 1, "client")
63: 
64:         for bad_gen in (-1, 0, 1 << 64, True, False, 1.5, "1", None):
65:             with self.subTest(bad_gen=bad_gen), self.assertRaises(ValueError):
66:                 OwnerToken("epoch", bad_gen, "client")
67: 
68:         for bad_conn in ("", "c" * 65, 123, None, False, b"conn"):
69:             with self.subTest(bad_conn=bad_conn), self.assertRaises(ValueError):
70:                 OwnerToken("epoch", 1, bad_conn)
71: 
72:     def test_delayed_old_generation_rejected_after_stop_and_rearm(self):
73:         core, station, old_owner = self._armed_station("conn-1")
74:         w1 = station.issue_window(1.0)
75:         t1 = Target(1, self.valid_joints, window=w1, owner=old_owner)
76:         self.assertTrue(station.submit(t1).accepted)
77:         self.assertEqual(core.snapshot().last_sequence, 1)
78: 
79:         self.assertTrue(station.stop().accepted)
80:         self.assertIs(core.snapshot().state, State.STOPPED)
81:         self.assertIsNone(core.snapshot().current_owner)
82: 
83:         new_owner = station.claim("conn-1")
84:         self.assertNotEqual(old_owner.generation, new_owner.generation)
85:         self.assertTrue(new_owner.generation > old_owner.generation)
86:         self.assertTrue(station.check().accepted)
87:         self.assertTrue(station.arm(new_owner).accepted)
88: 
89:         w2 = station.issue_window(1.0)
90:         stale_target = Target(2, self.valid_joints, window=w2, owner=old_owner)
91:         rej = station.submit(stale_target)
92:         self.assertFalse(rej.accepted)
93:         self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)
94:         self.assertEqual(core.snapshot().last_sequence, 1)
95: 
96:         valid_target = Target(2, self.valid_joints, window=w2, owner=new_owner)
97:         acc = station.submit(valid_target)
98:         self.assertTrue(acc.accepted)
99:         self.assertEqual(core.snapshot().last_sequence, 2)
100:         self.assertEqual(core.snapshot().admitted_target, valid_target)
101: 
102:     def test_wrong_epoch_and_wrong_connection_rejected(self):
103:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
104:         station = FakeStation(core)
105:         self.assertTrue(station.connect().accepted)
106:         owner = station.claim("client-A")
107:         self.assertTrue(station.check().accepted)
108:         w = station.issue_window(1.0)
109: 
110:         wrong_epoch = OwnerToken("wrong-epoch", owner.generation, owner.connection_id)
111:         wrong_conn = OwnerToken(owner.epoch, owner.generation, "client-B")
112: 
113:         rej_arm_epoch = core.arm(wrong_epoch)
114:         self.assertFalse(rej_arm_epoch.accepted)
115:         self.assertEqual(rej_arm_epoch.code, DecisionCode.INVALID_OWNER)
116: 
117:         rej_arm_conn = core.arm(wrong_conn)
118:         self.assertFalse(rej_arm_conn.accepted)
119:         self.assertEqual(rej_arm_conn.code, DecisionCode.INVALID_OWNER)
120: 
121:         self.assertTrue(station.arm(owner).accepted)
122:         rej_epoch = station.submit(Target(1, self.valid_joints, window=w, owner=wrong_epoch))
123:         self.assertFalse(rej_epoch.accepted)
124:         self.assertEqual(rej_epoch.code, DecisionCode.INVALID_OWNER)
125: 
126:         rej_conn = station.submit(Target(1, self.valid_joints, window=w, owner=wrong_conn))
127:         self.assertFalse(rej_conn.accepted)
128:         self.assertEqual(rej_conn.code, DecisionCode.INVALID_OWNER)
129: 
130:     def test_same_sequence_old_token_cannot_affect_ordering(self):
131:         core, station, owner1 = self._armed_station("conn-1")
132:         w1 = station.issue_window(1.0)
133:         t5 = Target(5, self.valid_joints, window=w1, owner=owner1)
134:         self.assertTrue(station.submit(t5).accepted)
135:         self.assertEqual(core.snapshot().last_sequence, 5)
136: 
137:         self.assertTrue(station.stop().accepted)
138:         owner2 = station.claim("conn-2")
139:         self.assertTrue(station.check().accepted)
140:         self.assertTrue(station.arm(owner2).accepted)
141: 
142:         w2 = station.issue_window(1.0)
143:         old_t5 = Target(5, self.valid_joints, window=w2, owner=owner1)
144:         rej = station.submit(old_t5)
145:         self.assertFalse(rej.accepted)
146:         self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)
147:         self.assertEqual(core.snapshot().last_sequence, 5)
148: 
149:         new_t6 = Target(6, self.valid_joints, window=w2, owner=owner2)
150:         self.assertTrue(station.submit(new_t6).accepted)
151:         self.assertEqual(core.snapshot().last_sequence, 6)
152: 
153:     def test_different_core_epoch_isolation(self):
154:         with self.assertRaises(TypeError):
155:             JointCore(self.specs, clock=self.clock, epoch="injected", max_reference_gap_s=1.0)
156: 
157:         core1 = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
158:         core2 = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
159:         station1 = FakeStation(core1)
160:         self.assertTrue(station1.connect().accepted)
161:         owner1 = station1.claim("conn-1")
162:         self.assertTrue(station1.check().accepted)
163:         self.assertTrue(station1.arm(owner1).accepted)
164: 
165:         station2 = FakeStation(core2)
166:         self.assertTrue(station2.connect().accepted)
167:         owner2 = station2.claim("conn-2")
168:         self.assertNotEqual(owner1.epoch, owner2.epoch)
169:         self.assertTrue(station2.check().accepted)
170: 
171:         cross_arm = core2.arm(owner1)
172:         self.assertFalse(cross_arm.accepted)
173:         self.assertEqual(cross_arm.code, DecisionCode.INVALID_OWNER)
174: 
175:         self.assertTrue(station2.arm(owner2).accepted)
176: 
177:         w2 = station2.issue_window(1.0)
178:         cross_target = Target(1, self.valid_joints, window=w2, owner=owner1)
179:         rej = station2.submit(cross_target)
180:         self.assertFalse(rej.accepted)
181:         self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)
182: 
183:     def test_no_owner_arm_rejected(self):
184:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
185:         self.assertTrue(core.begin_connect().accepted)
186:         self.assertTrue(core.connected(SOURCE).accepted)
187:         self.assertTrue(core.begin_check().accepted)
188:         for spec in self.specs:
189:             self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
190:         self.assertTrue(core.checked().accepted)
191:         self.assertIs(core.snapshot().state, State.READY)
192: 
193:         bogus_token = OwnerToken("fake-epoch", 1, "fake-client")
194:         rej = core.arm(bogus_token)
195:         self.assertFalse(rej.accepted)
196:         self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)
197:         self.assertIs(core.snapshot().state, State.READY)
198: 
199:         missing_owner = core.arm(None)
200:         self.assertFalse(missing_owner.accepted)
201:         self.assertEqual(missing_owner.code, DecisionCode.INVALID_OWNER)
202: 
203:         real_owner = core.claim_owner("valid-client")
204:         self.assertIs(core.snapshot().state, State.STOPPED)
205:         self.assertTrue(core.begin_check().accepted)
206:         for spec in self.specs:
207:             self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
208:         self.assertTrue(core.checked().accepted)
209:         self.assertTrue(core.arm(real_owner).accepted)
210:         self.assertIs(core.snapshot().state, State.ARMED)
211: 
212:     def test_takeover_during_vector_blocks_next_joint(self):
213:         core, station, owner_a = self._armed_station("owner-A")
214:         w = station.issue_window(1.0)
215:         target = Target(1, self.valid_joints, window=w, owner=owner_a)
216:         self.assertTrue(station.submit(target).accepted)
217: 
218:         self.clock.value += 0.05
219:         plan = core.prepare_refresh()
220:         self.assertIsNotNone(plan)
221: 
222:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
223:         d0 = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
224:         self.assertTrue(d0.accepted)
225:         self.assertIs(core.snapshot().state, State.MOVING)
226: 
227:         owner_b = core.claim_owner("owner-B")
228:         self.assertIs(core.snapshot().state, State.STOPPED)
229:         self.assertIsNone(core.snapshot().admitted_target)
230:         self.assertIsNone(core.snapshot().prepared_plan)
231:         self.assertEqual(core.snapshot().current_owner, owner_b)
232: 
233:         self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
234: 
235:     def test_receipt_after_revoke_records_actual_write_but_no_motion(self):
236:         core, station, owner = self._armed_station("owner-1")
237:         w = station.issue_window(1.0)
238:         target = Target(1, self.valid_joints, window=w, owner=owner)
239:         self.assertTrue(station.submit(target).accepted)
240: 
241:         self.clock.value += 0.05
242:         plan = core.prepare_refresh()
243:         self.assertIsNotNone(plan)
244:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
245:         claim_time = self.clock.value
246: 
247:         self.assertTrue(station.stop().accepted)
248:         self.assertIs(core.snapshot().state, State.STOPPED)
249: 
250:         receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
251:         self.assertTrue(receipt.accepted)
252: 
253:         snap = core.snapshot()
254:         self.assertIs(snap.state, State.STOPPED)
255:         self.assertIsNone(snap.admitted_target)
256:         record = snap.dispatched_records[0]
257:         self.assertIsNotNone(record)
258:         self.assertEqual(record.sequence, 1)
259:         self.assertEqual(record.owner, owner)
260:         self.assertEqual(record.dispatched_at_s, claim_time)
261:         self.assertEqual(snap.dispatch_attempts[0].owner, owner)
262: 
263:     def test_old_prepared_plan_not_revived_by_new_owner(self):
264:         core, station, owner_a = self._armed_station("owner-A")
265:         w_a = station.issue_window(1.0)
266:         target_a = Target(1, self.valid_joints, window=w_a, owner=owner_a)
267:         self.assertTrue(station.submit(target_a).accepted)
268: 
269:         self.clock.value += 0.05
270:         plan_a = core.prepare_refresh()
271:         self.assertIsNotNone(plan_a)
272: 
273:         owner_b = station.claim("owner-B")
274:         self.assertTrue(station.check().accepted)
275:         self.assertTrue(station.arm(owner_b).accepted)
276: 
277:         self.assertFalse(core.claim_dispatch(plan_a.plan_id, 0))
278:         self.assertFalse(core.dispatch_result(plan_a.plan_id, 0, WriteResult.COMPLETE).accepted)
279: 
280:         w_b = station.issue_window(1.0)
281:         target_b = Target(2, self.valid_joints, window=w_b, owner=owner_b)
282:         self.assertTrue(station.submit(target_b).accepted)
283:         self.clock.value += 0.05
284:         plan_b = core.prepare_refresh()
285:         self.assertIsNotNone(plan_b)
286:         self.assertEqual(plan_b.target, target_b)
287:         self.assertEqual(plan_b.owner, owner_b)
288: 
289:     def test_repeated_stop_reconnect_and_fault_invalidation(self):
290:         core, station, owner1 = self._armed_station("owner-1")
291:         self.assertEqual(owner1.generation, 1)
292: 
293:         self.assertTrue(station.stop().accepted)
294:         self.assertIsNone(core.snapshot().current_owner)
295: 
296:         owner2 = station.claim("owner-2")
297:         self.assertEqual(owner2.generation, 2)
298:         self.assertTrue(station.check().accepted)
299:         self.assertTrue(station.arm(owner2).accepted)
300: 
301:         self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
302:         self.assertIs(core.snapshot().state, State.FAULT)
303:         self.assertIsNone(core.snapshot().current_owner)
304: 
305:         self.assertTrue(station.disconnect().accepted)
306:         self.assertIs(core.snapshot().state, State.DISCONNECTED)
307:         self.assertIsNone(core.snapshot().current_owner)
308: 
309:         self.assertTrue(station.connect().accepted)
310:         self.assertIsNone(core.snapshot().current_owner)
311: 
312:         owner3 = station.claim("owner-3")
313:         self.assertEqual(owner3.generation, 3)
314:         self.assertTrue(station.check(acknowledge_fault=True).accepted)
315:         self.assertTrue(station.arm(owner3).accepted)
316:         self.assertIs(core.snapshot().state, State.ARMED)
317:         self.assertEqual(core.snapshot().current_owner, owner3)
318: 
319:     def test_exhausted_generation_fails_closed(self):
320:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
321:         station = FakeStation(core)
322:         self.assertTrue(station.connect().accepted)
323:         core._next_generation = (1 << 64) - 1
324:         tok_max = station.claim("client")
325:         self.assertEqual(tok_max.generation, (1 << 64) - 1)
326:         self.assertTrue(station.check().accepted)
327:         self.assertTrue(station.arm(tok_max).accepted)
328: 
329:         window = station.issue_window(1.0)
330:         target = Target(1, self.valid_joints, window=window, owner=tok_max)
331:         self.assertTrue(station.submit(target).accepted)
332:         self.clock.value += 0.05
333:         plan = core.prepare_refresh()
334:         self.assertIsNotNone(plan)
335:         self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
336:         self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)
337:         self.assertIs(core.snapshot().state, State.MOVING)
338: 
339:         with self.assertRaises(OverflowError):
340:             core.claim_owner("client-overflow")
341: 
342:         snapshot = core.snapshot()
343:         self.assertIs(snapshot.state, State.STOPPED)
344:         self.assertIsNone(snapshot.current_owner)
345:         self.assertIsNone(snapshot.admitted_target)
346:         self.assertIsNone(snapshot.prepared_plan)
347:         self.assertEqual(snapshot.latest_owner, tok_max)
348:         self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
349: 
350:     def test_invalid_high_sequence_stale_owner_preserves_healthy_current_goal(self):
351:         core, station, owner = self._armed_station("owner-1")
352:         w = station.issue_window(1.0)
353:         t5 = Target(5, self.valid_joints, window=w, owner=owner)
354:         self.assertTrue(station.submit(t5).accepted)
355:         self.assertEqual(core.snapshot().last_sequence, 5)
356:         self.assertEqual(core.snapshot().admitted_target, t5)
357: 
358:         stale_owner = OwnerToken("other-epoch", 999, "stale-client")
359:         high_target = Target(9999, self.valid_joints, window=w, owner=stale_owner)
360:         rej = station.submit(high_target)
361:         self.assertFalse(rej.accepted)
362:         self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)
363: 
364:         snap = core.snapshot()
365:         self.assertEqual(snap.last_sequence, 5)
366:         self.assertEqual(snap.admitted_target, t5)
367:         self.assertIs(snap.state, State.ARMED)
368:         self.assertEqual(snap.current_owner, owner)
369: 
370:     def test_bounded_storage_after_many_claims(self):
371:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
372:         for i in range(10_000):
373:             token = core.claim_owner(f"client-{i % 10}")
374: 
375:         snap = core.snapshot()
376:         self.assertEqual(snap.latest_owner.generation, 10_000)
377:         self.assertEqual(snap.current_owner.generation, 10_000)
378: 
379:         # Inspect internal object state to verify O(1) storage
380:         self.assertFalse(hasattr(core, "_owner_history"))
381:         self.assertFalse(hasattr(core, "_owners"))
382:         self.assertFalse(hasattr(core, "claim"))
383:         self.assertIs(core._latest_owner, snap.latest_owner)
384:         self.assertFalse(hasattr(snap, "generation"))
385:         self.assertFalse(hasattr(snap, "latest_generation"))
386:         self.assertIs(core._current_owner, snap.current_owner)
387: 
388: 
389: if __name__ == "__main__":
390:     unittest.main()

## test_controller.py
1: import unittest
2: from dataclasses import FrozenInstanceError
3: import math
4: 
5: from im6014_codec import command
6: from joint_contract import (
7:     CommunicationFailure,
8:     DecisionCode,
9:     IntentWindow,
10:     JointDispatchedRecord,
11:     JointFault,
12:     JointSpec,
13:     JointStatus,
14:     MotorHealth,
15:     OwnerToken,
16:     RefreshPlan,
17:     Snapshot,
18:     SourceIdentity,
19:     State,
20:     Target,
21:     WriteResult,
22: )
23: from joint_controller import JointCore
24: from joint_mapping import JointMap, JointSample, JointTarget
25: 
26: 
27: SAMPLE = JointSample(0.1, 0.0, 0.0)
28: HEALTHY_STOP = MotorHealth(mode=0, errors=0, warnings=0, timeout=False)
29: SOURCE = SourceIdentity("fixture", "controller-test", 1)
30: 
31: 
32: class FakeStation:
33:     def __init__(self, core):
34:         self.core = core
35:         self.writes = []
36:         self.owner = None
37: 
38:     def _write_stops(self):
39:         self.writes.extend(command(spec.motor_id, mode=0) for spec in self.core.joint_specs)
40: 
41:     def connect(self):
42:         decision = self.core.begin_connect()
43:         if not decision.accepted:
44:             return decision
45:         decision = self.core.connected(SOURCE)
46:         if decision.accepted:
47:             self._write_stops()
48:         return decision
49: 
50:     def claim(self, connection_id="human"):
51:         prior_state = self.core.snapshot().state
52:         self.owner = self.core.claim_owner(connection_id)
53:         if self.core.snapshot().state is State.STOPPED and prior_state is not State.STOPPED:
54:             self._write_stops()
55:         return self.owner
56: 
57:     def check(self, *, acknowledge_fault=False):
58:         decision = self.core.begin_check(acknowledge_fault=acknowledge_fault)
59:         if not decision.accepted:
60:             return decision
61:         self._write_stops()
62:         for spec in self.core.joint_specs:
63:             decision = self.core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP)
64:             if not decision.accepted:
65:                 return decision
66:         return self.core.checked()
67: 
68:     def arm(self, owner: OwnerToken):
69:         return self.core.arm(owner)
70: 
71:     def issue_window(self, valid_for_s=0.2):
72:         return self.core.issue_window(valid_for_s)
73: 
74:     def submit(self, target):
75:         return self.core.submit_target(target)
76: 
77:     def refresh(self):
78:         plan = self.core.prepare_refresh()
79:         if plan is None:
80:             return None
81:         for index, packet in enumerate(plan.packets):
82:             if not self.core.claim_dispatch(plan.plan_id, index):
83:                 break
84:             self.writes.append(packet)
85:             self.core.dispatch_result(plan.plan_id, index, WriteResult.COMPLETE)
86:         return plan
87: 
88:     def stop(self):
89:         decision = self.core.stop()
90:         if decision.accepted:
91:             self._write_stops()
92:         return decision
93: 
94:     def disconnect(self):
95:         return self.core.disconnect()
96: 
97: 
98: class DeterministicClock:
99:     def __init__(self, value=0.0):
100:         self.value = value
101:         self.calls = 0
102: 
103:     def __call__(self):
104:         self.calls += 1
105:         return self.value
106: 
107: 
108: class FeedbackAgeTests(unittest.TestCase):
109:     def setUp(self):
110:         self.specs = (
111:             JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
112:             JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
113:         )
114: 
115:     def _ready_station(self, clock, *, feedback_max_age_s=1.0):
116:         core = JointCore(
117:             self.specs,
118:             clock=clock,
119:             feedback_max_age_s=feedback_max_age_s,
120:             max_reference_gap_s=1.0,
121:         )
122:         station = FakeStation(core)
123:         self.assertTrue(station.connect().accepted)
124:         station.claim("fixture")
125:         self.assertTrue(station.check().accepted)
126:         return core, station
127: 
128:     def test_feedback_age_configuration_is_finite_positive_and_typed(self):
129:         for value in (True, False, 0, -1.0, math.nan, math.inf, -math.inf, 10**400, "1"):
130:             with self.subTest(value=repr(value)), self.assertRaises(ValueError):
131:                 JointCore(self.specs, feedback_max_age_s=value, max_reference_gap_s=1.0)
132:         with self.assertRaises(ValueError):
133:             JointCore(self.specs, clock=0, max_reference_gap_s=1.0)
134: 
135:     def test_zero_timestamp_and_exact_freshness_boundary(self):
136:         clock = DeterministicClock(0.0)
137:         core, station = self._ready_station(clock)
138: 
139:         received = core.snapshot()
140:         self.assertEqual(tuple(joint.received_at for joint in received.joints), (0.0, 0.0))
141:         self.assertEqual(received.feedback_ages_s, (0.0, 0.0))
142: 
143:         clock.value = 1.0
144:         at_boundary = core.snapshot()
145:         self.assertEqual(at_boundary.feedback_ages_s, (1.0, 1.0))
146:         self.assertTrue(core.arm(station.owner).accepted)
147: 
148:         with self.assertRaises(FrozenInstanceError):
149:             at_boundary.joints[0].received_at = 1.0
150:         with self.assertRaises(TypeError):
151:             at_boundary.feedback_ages_s[0] = 0.0
152: 
153:     def test_checked_rejects_feedback_older_than_limit(self):
154:         clock = DeterministicClock(0.0)
155:         core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0, max_reference_gap_s=1.0)
156:         self.assertTrue(core.begin_connect().accepted)
157:         self.assertTrue(core.connected(SOURCE).accepted)
158:         self.assertTrue(core.begin_check().accepted)
159:         for spec in self.specs:
160:             self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
161: 
162:         clock.value = 1.000001
163:         rejected = core.checked()
164:         self.assertEqual(rejected.code, DecisionCode.STALE_FEEDBACK)
165:         self.assertIs(core.snapshot().state, State.CHECKING)
166:         self.assertFalse(core.snapshot().fault_latched)
167:         self.assertTrue(core.tick().accepted)
168:         self.assertIs(core.snapshot().state, State.CHECKING)
169: 
170:     def test_bad_id_and_observation_do_not_refresh_receipt_time(self):
171:         clock = DeterministicClock(0.0)
172:         core, station = self._ready_station(clock)
173:         initial = core.snapshot()
174:         calls_before = clock.calls
175: 
176:         clock.value = 0.5
177:         self.assertEqual(
178:             core.receive(14, SAMPLE, HEALTHY_STOP).code,
179:             DecisionCode.UNKNOWN_JOINT,
180:         )
181:         self.assertEqual(
182:             core.receive(self.specs[0].motor_id, object(), HEALTHY_STOP).code,
183:             DecisionCode.INVALID_OBSERVATION,
184:         )
185:         self.assertEqual(clock.calls, calls_before)
186:         self.assertEqual(
187:             tuple(joint.received_at for joint in core.snapshot().joints),
188:             tuple(joint.received_at for joint in initial.joints),
189:         )
190: 
191:         clock.value = 1.000001
192:         self.assertEqual(core.arm(station.owner).code, DecisionCode.STALE_FEEDBACK)
193: 
194:     def test_fresh_j1_cannot_hide_stale_j2_from_arm_or_tick(self):
195:         clock = DeterministicClock(0.0)
196:         core, station = self._ready_station(clock)
197:         station.writes.clear()
198: 
199:         clock.value = 0.8
200:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
201:         clock.value = 1.000001
202:         before_writes = list(station.writes)
203:         rejected = station.arm(station.owner)
204:         self.assertEqual(rejected.code, DecisionCode.STALE_FEEDBACK)
205:         self.assertIs(core.snapshot().state, State.READY)
206:         self.assertEqual(station.writes, before_writes)
207: 
208:         clock = DeterministicClock(0.0)
209:         core, station = self._ready_station(clock)
210:         station.writes.clear()
211:         clock.value = 0.8
212:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
213:         self.assertTrue(station.arm(station.owner).accepted)
214:         clock.value = 1.000001
215:         before_writes = list(station.writes)
216:         self.assertTrue(core.tick().accepted)
217:         self.assertIs(core.snapshot().state, State.FAULT)
218:         self.assertTrue(core.snapshot().fault_latched)
219:         self.assertEqual(station.writes, before_writes)
220: 
221:     def test_disconnect_invalidates_age_and_stale_fault_needs_acknowledged_check(self):
222:         clock = DeterministicClock(0.0)
223:         core, station = self._ready_station(clock)
224:         self.assertTrue(station.arm(station.owner).accepted)
225: 
226:         clock.value = 1.1
227:         self.assertTrue(core.tick().accepted)
228:         self.assertIs(core.snapshot().state, State.FAULT)
229:         self.assertTrue(core.snapshot().fault_latched)
230:         before_disconnect = core.snapshot()
231: 
232:         self.assertTrue(station.disconnect().accepted)
233:         disconnected = core.snapshot()
234:         self.assertTrue(all(joint.received_at is None for joint in disconnected.joints))
235:         self.assertEqual(disconnected.feedback_ages_s, (None, None))
236:         self.assertEqual(before_disconnect.feedback_ages_s, (1.1, 1.1))
237:         self.assertTrue(disconnected.fault_latched)
238: 
239:         self.assertTrue(station.connect().accepted)
240:         writes_after_connect = list(station.writes)
241:         self.assertEqual(
242:             station.check().code,
243:             DecisionCode.FAULT_ACK_REQUIRED,
244:         )
245:         self.assertEqual(station.writes, writes_after_connect)
246: 
247:         station.writes.clear()
248:         self.assertTrue(station.check(acknowledge_fault=True).accepted)
249:         self.assertEqual(
250:             station.writes,
251:             [command(spec.motor_id, mode=0) for spec in self.specs],
252:         )
253:         self.assertIs(core.snapshot().state, State.READY)
254:         self.assertFalse(core.snapshot().fault_latched)
255: 
256: 
257: def core_at(test, state, clock=None):
258:     if clock is None:
259:         clock = DeterministicClock(0.0)
260:     core = JointCore(test.specs, clock=clock, max_reference_gap_s=1.0)
261:     station = FakeStation(core)
262:     if state is State.DISCONNECTED:
263:         return core
264:     if state is State.CONNECTING:
265:         test.assertTrue(core.begin_connect().accepted)
266:         return core
267: 
268:     test.assertTrue(station.connect().accepted)
269:     if state is State.CONNECTED:
270:         return core
271:     owner = station.claim("fixture")
272:     if state is State.CHECKING:
273:         test.assertTrue(core.begin_check().accepted)
274:         return core
275: 
276:     test.assertTrue(station.check().accepted)
277:     if state is State.READY:
278:         return core
279:     if state is State.ARMED:
280:         test.assertTrue(station.arm(owner).accepted)
281:         return core
282:     if state is State.MOVING:
283:         test.assertTrue(station.arm(owner).accepted)
284:         window = station.issue_window(1.0)
285:         target = Target(
286:             0,
287:             (
288:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
289:                 JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
290:             ),
291:             window=window,
292:             owner=owner,
293:         )
294:         test.assertTrue(core.submit_target(target).accepted)
295:         if hasattr(clock, "value"):
296:             clock.value += 0.05
297:         test.assertIsNotNone(station.refresh())
298:         return core
299:     if state is State.STOPPED:
300:         test.assertTrue(station.arm(owner).accepted)
301:         test.assertTrue(station.stop().accepted)
302:         return core
303:     if state is State.FAULT:
304:         test.assertTrue(station.arm(owner).accepted)
305:         test.assertTrue(core.receive(
306:             test.specs[0].motor_id,
307:             SAMPLE,
308:             MotorHealth(mode=0, errors=1, warnings=0, timeout=False),
309:         ).accepted)
310:         return core
311:     raise AssertionError(f"{state} is not reachable")
312: 
313: 
314: class ControllerStateTests(unittest.TestCase):
315:     def setUp(self):
316:         self.clock = lambda: 0.0
317:         self.specs = (
318:             JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
319:             JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
320:         )
321: 
322: 
323:     def test_joint_set_is_nonempty_unique_and_owned(self):
324:         mapping = JointMap(1, 1, 0.0)
325:         with self.assertRaises(ValueError):
326:             JointCore((), max_reference_gap_s=1.0)
327:         with self.assertRaises(ValueError):
328:             JointCore((
329:                 JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, "fixture: software position limits"),
330:                 JointSpec("J1", 1, mapping, -2.0, 2.0, 10.0, "fixture: software position limits"),
331:             ), max_reference_gap_s=1.0)
332:         with self.assertRaises(ValueError):
333:             JointCore((
334:                 JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, "fixture: software position limits"),
335:                 JointSpec("J2", 0, mapping, -2.0, 2.0, 10.0, "fixture: software position limits"),
336:             ), max_reference_gap_s=1.0)
337:         with self.assertRaises(ValueError):
338:             JointSpec("J1", True, mapping, -2.0, 2.0, 10.0, "fixture: software position limits")
339: 
340:         supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, "fixture: software position limits")]
341:         core = JointCore(supplied, clock=self.clock, max_reference_gap_s=1.0)
342:         supplied.clear()
343:         self.assertEqual(tuple(spec.name for spec in core.joint_specs), ("J1",))
344: 
345:     def test_health_and_source_records_reject_invalid_values(self):
346:         for kwargs in (
347:             dict(mode=True, errors=0, warnings=0, timeout=False),
348:             dict(mode=0, errors=True, warnings=0, timeout=False),
349:             dict(mode=0, errors=0, warnings=-1, timeout=False),
350:             dict(mode=0, errors=0, warnings=0, timeout=1),
351:         ):
352:             with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
353:                 MotorHealth(**kwargs)
354:         with self.assertRaises(ValueError):
355:             SourceIdentity("other", "x", 1)
356: 
357:     def test_fake_lifecycle_writes_only_after_accepted_actions(self):
358:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
359:         station = FakeStation(core)
360:         expected = [command(spec.motor_id, mode=0) for spec in self.specs]
361: 
362:         self.assertFalse(station.check().accepted)
363:         self.assertFalse(station.stop().accepted)
364:         self.assertEqual(station.writes, [])
365: 
366:         self.assertTrue(station.connect().accepted)
367:         self.assertEqual(station.writes, expected)
368:         station.writes.clear()
369:         self.assertFalse(station.connect().accepted)
370:         self.assertEqual(station.writes, [])
371: 
372:         owner = station.claim("fixture")
373:         self.assertTrue(station.check().accepted)
374:         self.assertEqual(station.writes, expected)
375:         self.assertIs(core.snapshot().state, State.READY)
376:         station.writes.clear()
377:         self.assertTrue(station.arm(owner).accepted)
378:         self.assertIs(core.snapshot().state, State.ARMED)
379:         self.assertTrue(station.stop().accepted)
380:         self.assertEqual(station.writes, expected)
381:         self.assertIs(core.snapshot().state, State.STOPPED)
382: 
383:     def test_arm_requires_current_stop_feedback(self):
384:         core = core_at(self, State.READY)
385:         owner = core.snapshot().latest_owner
386:         self.assertTrue(core.receive(1, SAMPLE, MotorHealth(1, 0, 0, False)))
387:         before = core.snapshot()
388:         self.assertEqual(core.arm(owner).code, DecisionCode.NOT_STOPPED)
389:         self.assertEqual(core.snapshot(), before)
390:         self.assertTrue(core.receive(1, SAMPLE, HEALTHY_STOP))
391:         self.assertTrue(core.arm(owner))
392: 
393:     def test_check_requires_every_healthy_joint_in_stop_mode(self):
394:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
395:         self.assertTrue(core.begin_connect().accepted)
396:         self.assertTrue(core.connected(SOURCE).accepted)
397:         self.assertTrue(core.begin_check().accepted)
398: 
399:         before = core.snapshot()
400:         rejected = core.checked()
401:         self.assertFalse(rejected)
402:         self.assertEqual(rejected.code, DecisionCode.OBSERVATIONS_INCOMPLETE)
403:         self.assertEqual(core.snapshot(), before)
404: 
405:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
406:         foc = MotorHealth(mode=1, errors=0, warnings=0, timeout=False)
407:         self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, foc).accepted)
408:         before = core.snapshot()
409:         self.assertEqual(core.checked().code, DecisionCode.NOT_STOPPED)
410:         self.assertEqual(core.snapshot(), before)
411: 
412:         unhealthy = MotorHealth(mode=0, errors=0, warnings=1, timeout=False)
413:         self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, unhealthy).accepted)
414:         self.assertIs(core.snapshot().state, State.FAULT)
415:         self.assertTrue(core.snapshot().fault_latched)
416:         before = core.snapshot()
417:         rejected = core.checked()
418:         self.assertFalse(rejected)
419:         self.assertEqual(rejected.code, DecisionCode.INVALID_STATE)
420:         self.assertEqual(core.snapshot(), before)
421: 
422:         self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP))
423:         self.assertIs(core.snapshot().state, State.FAULT)
424:         self.assertTrue(core.snapshot().fault_latched)
425:         self.assertTrue(core.begin_check(acknowledge_fault=True))
426:         self.assertTrue(core.snapshot().fault_latched)
427:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP))
428:         self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP).accepted)
429:         self.assertTrue(core.checked().accepted)
430:         self.assertIs(core.snapshot().state, State.READY)
431: 
432:     def test_fault_survives_stop_disconnect_reconnect_and_healthy_packets(self):
433:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
434:         station = FakeStation(core)
435:         self.assertTrue(station.connect().accepted)
436:         owner = station.claim("fixture")
437:         self.assertTrue(station.check().accepted)
438:         self.assertTrue(station.arm(owner).accepted)
439: 
440:         bad_health = MotorHealth(mode=0, errors=4, warnings=2, timeout=True)
441:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, bad_health).accepted)
442:         self.assertIs(core.snapshot().state, State.FAULT)
443:         self.assertTrue(core.snapshot().fault_latched)
444: 
445:         station.writes.clear()
446:         self.assertTrue(station.stop().accepted)
447:         self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
448:         self.assertIs(core.snapshot().state, State.FAULT)
449:         self.assertTrue(core.snapshot().fault_latched)
450: 
451:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
452:         self.assertIs(core.snapshot().state, State.FAULT)
453:         self.assertTrue(core.snapshot().fault_latched)
454: 
455:         self.assertTrue(station.disconnect().accepted)
456:         disconnected = core.snapshot()
457:         self.assertIs(disconnected.state, State.DISCONNECTED)
458:         self.assertTrue(disconnected.fault_latched)
459:         self.assertTrue(all(not joint.valid for joint in disconnected.joints))
460:         self.assertIsNone(disconnected.source)
461: 
462:         self.assertTrue(station.connect().accepted)
463:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
464:         self.assertTrue(core.snapshot().fault_latched)
465:         before = core.snapshot()
466:         self.assertEqual(core.begin_check().code, DecisionCode.FAULT_ACK_REQUIRED)
467:         self.assertEqual(core.snapshot(), before)
468: 
469:         station.writes.clear()
470:         self.assertTrue(station.check(acknowledge_fault=True).accepted)
471:         self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
472:         self.assertIs(core.snapshot().state, State.READY)
473:         self.assertFalse(core.snapshot().fault_latched)
474: 
475:     def test_disconnect_and_new_connection_invalidate_observations(self):
476:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
477:         self.assertTrue(core.begin_connect().accepted)
478:         self.assertTrue(core.connected(SOURCE).accepted)
479:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
480:         prior = core.snapshot()
481:         self.assertTrue(prior.joints[0].valid)
482: 
483:         self.assertTrue(core.disconnect().accepted)
484:         self.assertTrue(all(not joint.valid for joint in core.snapshot().joints))
485:         self.assertTrue(core.begin_connect().accepted)
486:         self.assertTrue(core.connected(SourceIdentity("fixture", "controller-test", 2)).accepted)
487:         self.assertTrue(all(not joint.valid for joint in core.snapshot().joints))
488:         self.assertTrue(prior.joints[0].valid)
489: 
490:     def test_snapshots_are_immutable_owned_values(self):
491:         core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
492:         self.assertTrue(core.begin_connect().accepted)
493:         self.assertTrue(core.connected(SOURCE).accepted)
494:         before = core.snapshot()
495:         self.assertIsInstance(before.joints, tuple)
496:         self.assertIsInstance(before.joint_names, tuple)
497:         self.assertIsInstance(before.dispatch_attempts, tuple)
498:         self.assertEqual(before.dispatch_attempts, (None, None))
499:         self.assertFalse(hasattr(core, "pending_target"))
500:         self.assertFalse(hasattr(before, "pending_target"))
501: 
502:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
503:         after = core.snapshot()
504:         self.assertFalse(before.joints[0].valid)
505:         self.assertTrue(after.joints[0].valid)
506:         with self.assertRaises(FrozenInstanceError):
507:             after.state = State.FAULT
508:         with self.assertRaises(FrozenInstanceError):
509:             after.joints[0].health = HEALTHY_STOP
510:         with self.assertRaises(TypeError):
511:             after.joints[0] = before.joints[0]
512:         with self.assertRaises(TypeError):
513:             after.dispatch_attempts[0] = before.dispatch_attempts[0]
514: 
515:     def test_invalid_transition_matrix_preserves_snapshot(self):
516:         rejected = {
517:             State.DISCONNECTED: ("connected", "begin_check", "checked", "arm", "stop"),
518:             State.CONNECTING: ("begin_connect", "begin_check", "checked", "arm", "stop"),
519:             State.CONNECTED: ("begin_connect", "connected", "checked", "arm"),
520:             State.CHECKING: ("begin_connect", "connected", "begin_check", "arm"),
521:             State.READY: ("begin_connect", "connected", "begin_check", "checked"),
522:             State.ARMED: ("begin_connect", "connected", "begin_check", "checked", "arm"),
523:             State.MOVING: ("begin_connect", "connected", "begin_check", "checked", "arm"),
524:             State.STOPPED: ("begin_connect", "connected", "checked", "arm"),
525:             State.FAULT: ("begin_connect", "connected", "begin_check", "checked", "arm"),
526:         }
527: 
528:         for state, events in rejected.items():
529:             for event in events + ("wrong_joint",):
530:                 with self.subTest(state=state, event=event):
531:                     core = core_at(self, state)
532:                     station = FakeStation(core)
533:                     before = core.snapshot()
534:                     arm_owner = core.snapshot().current_owner or OwnerToken(
535:                         "matrix-epoch", 1, "matrix-client"
536:                     )
537:                     action = {
538:                         "begin_connect": station.connect,
539:                         "connected": lambda: core.connected(SOURCE),
540:                         "begin_check": station.check,
541:                         "checked": core.checked,
542:                         "arm": lambda: core.arm(arm_owner),
543:                         "stop": station.stop,
544:                         "wrong_joint": lambda: core.receive(14, SAMPLE, HEALTHY_STOP),
545:                     }[event]
546:                     decision = action()
547:                     self.assertFalse(decision.accepted)
548:                     self.assertFalse(decision)
549:                     self.assertEqual(station.writes, [])
550:                     self.assertEqual(core.snapshot(), before)
551: 
552: 
553: class JointFaultTests(unittest.TestCase):
554:     def setUp(self):
555:         self.specs = (
556:             JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
557:             JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
558:         )
559: 
560:     def _ready_core(self, clock=None, *, feedback_max_age_s=1.0):
561:         if clock is None:
562:             clock = DeterministicClock(0.0)
563:         core = JointCore(
564:             self.specs,
565:             clock=clock,
566:             feedback_max_age_s=feedback_max_age_s,
567:             max_reference_gap_s=1.0,
568:         )
569:         self.assertTrue(core.begin_connect().accepted)
570:         self.assertTrue(core.connected(SOURCE).accepted)
571:         core.claim_owner("fixture")
572:         self.assertTrue(core.begin_check().accepted)
573:         for spec in self.specs:
574:             self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
575:         self.assertTrue(core.checked().accepted)
576:         return core
577: 
578:     def test_stale_j2_attributes_only_stale_joint_with_refreshed_j1(self):
579:         clock = DeterministicClock(0.0)
580:         core = self._ready_core(clock, feedback_max_age_s=1.0)
581:         self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)
582:         self.assertIs(core.snapshot().state, State.ARMED)
583: 
584:         clock.value = 0.8
585:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
586: 
587:         clock.value = 1.1
588:         self.assertTrue(core.tick().accepted)
589:         snap = core.snapshot()
590:         self.assertIs(snap.state, State.FAULT)
591:         self.assertTrue(snap.fault_latched)
592:         self.assertEqual(snap.affected_joints, ("J2",))
593:         self.assertEqual(len(snap.faults), 1)
594: 
595:         j2_fault = snap.faults[0]
596:         self.assertEqual(j2_fault.name, "J2")
597:         self.assertEqual(j2_fault.motor_id, 1)
598:         self.assertTrue(j2_fault.stale)
599:         self.assertEqual(j2_fault.errors, 0)
600:         self.assertEqual(j2_fault.warnings, 0)
601:         self.assertFalse(j2_fault.timeout)
602:         self.assertIsNone(j2_fault.communication_error)
603: 
604:         self.assertNotIn("J1", snap.affected_joints)
605:         self.assertEqual(snap.joints[0].received_at, 0.8)
606:         self.assertEqual(snap.joints[1].received_at, 0.0)
607: 
608:     def test_unknown_bits_and_32bit_error_mask_retained(self):
609:         clock = DeterministicClock(0.0)
610:         core = self._ready_core(clock)
611:         self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)
612: 
613:         unknown_errors = 0x80000004
614:         status = MotorHealth(mode=0, errors=unknown_errors, warnings=5, timeout=True)
615:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, status).accepted)
616: 
617:         snap = core.snapshot()
618:         self.assertIs(snap.state, State.FAULT)
619:         self.assertEqual(snap.affected_joints, ("J1",))
620:         j1_fault = snap.faults[0]
621:         self.assertEqual(j1_fault.errors, unknown_errors)
622:         self.assertEqual(j1_fault.errors & 0x80000000, 0x80000000)
623:         self.assertEqual(j1_fault.warnings, 5)
624:         self.assertTrue(j1_fault.timeout)
625:         self.assertFalse(j1_fault.stale)
626: 
627:         for kwargs in (
628:             dict(mode=0, errors=-1, warnings=0, timeout=False),
629:             dict(mode=0, errors=0x1_0000_0000, warnings=0, timeout=False),
630:             dict(mode=0, errors=0, warnings=-1, timeout=False),
631:             dict(mode=0, errors=0, warnings=8, timeout=False),
632:             dict(mode=0, errors=0, warnings=0, timeout="True"),
633:         ):
634:             with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
635:                 MotorHealth(**kwargs)
636: 
637:         for kwargs in (
638:             dict(name="J1", motor_id=0, errors=-1),
639:             dict(name="J1", motor_id=0, errors=0x1_0000_0000),
640:             dict(name="J1", motor_id=0, warnings=-1),
641:             dict(name="J1", motor_id=0, warnings=8),
642:             dict(name="J1", motor_id=0, timeout=1),
643:             dict(name="J1", motor_id=0, stale=1),
644:             dict(name="", motor_id=0),
645:             dict(name="J1", motor_id=15),
646:         ):
647:             with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
648:                 JointFault(**kwargs)
649: 
650:     def test_healthy_after_fault_preserves_latched_attribution(self):
651:         core = self._ready_core()
652:         self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)
653: 
654:         unhealthy = MotorHealth(mode=0, errors=0x02, warnings=0, timeout=False)
655:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, unhealthy).accepted)
656:         self.assertIs(core.snapshot().state, State.FAULT)
657:         self.assertEqual(core.snapshot().affected_joints, ("J1",))
658:         self.assertEqual(core.snapshot().faults[0].errors, 0x02)
659: 
660:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
661:         snap = core.snapshot()
662: 
663:         self.assertTrue(snap.joints[0].healthy)
664:         self.assertEqual(snap.joints[0].errors, 0)
665:         self.assertEqual(snap.joints[0].health.errors, 0)
666: 
667:         self.assertIs(snap.state, State.FAULT)
668:         self.assertTrue(snap.fault_latched)
669:         self.assertEqual(snap.affected_joints, ("J1",))
670:         self.assertEqual(len(snap.faults), 1)
671:         self.assertEqual(snap.faults[0].errors, 0x02)
672:         self.assertNotEqual(snap.faults[0].errors, 0)
673: 
674:     def test_multiple_faults_on_joint_preserves_prior_flags_with_bounded_storage(self):
675:         core = self._ready_core()
676: 
677:         self.assertTrue(core.receive(
678:             self.specs[0].motor_id,
679:             SAMPLE,
680:             MotorHealth(mode=0, errors=0x01, warnings=1, timeout=False),
681:         ).accepted)
682: 
683:         self.assertTrue(core.receive(
684:             self.specs[0].motor_id,
685:             SAMPLE,
686:             MotorHealth(mode=0, errors=0x04, warnings=2, timeout=True),
687:         ).accepted)
688: 
689:         self.assertTrue(core.communication_failed(
690:             self.specs[0].motor_id,
691:             CommunicationFailure.DRIVER_FAILURE,
692:         ).accepted)
693: 
694:         snap = core.snapshot()
695:         self.assertEqual(len(snap.faults), 1)
696:         j1_fault = snap.faults[0]
697:         self.assertEqual(j1_fault.name, "J1")
698:         self.assertEqual(j1_fault.errors, 0x05)
699:         self.assertEqual(j1_fault.warnings, 3)
700:         self.assertTrue(j1_fault.timeout)
701:         self.assertEqual(j1_fault.communication_error, CommunicationFailure.DRIVER_FAILURE)
702:         self.assertIn(CommunicationFailure.DRIVER_FAILURE, j1_fault.communication_errors)
703: 
704:         for _ in range(10):
705:             self.assertTrue(core.receive(
706:                 self.specs[0].motor_id,
707:                 SAMPLE,
708:                 MotorHealth(mode=0, errors=0x02, warnings=0, timeout=False),
709:             ).accepted)
710:         self.assertEqual(len(core.snapshot().faults), 1)
711:         self.assertEqual(core.snapshot().faults[0].errors, 0x07)
712: 
713:     def test_communication_failures_with_fixed_enum_codes(self):
714:         for code in (
715:             CommunicationFailure.TIMEOUT,
716:             CommunicationFailure.INVALID_FEEDBACK,
717:             CommunicationFailure.DRIVER_FAILURE,
718:         ):
719:             with self.subTest(code=code):
720:                 core = self._ready_core()
721:                 decision = core.communication_failed(self.specs[0].motor_id, code)
722:                 self.assertTrue(decision.accepted)
723:                 snap = core.snapshot()
724:                 self.assertIs(snap.state, State.FAULT)
725:                 self.assertEqual(snap.affected_joints, ("J1",))
726:                 fault = snap.faults[0]
727:                 self.assertEqual(fault.communication_error, code)
728:                 self.assertFalse(fault.timeout)
729:                 self.assertEqual(snap.joints[0].communication_error, code)
730:                 self.assertFalse(snap.joints[0].healthy)
731: 
732:         core = self._ready_core()
733:         self.assertTrue(core.communication_failed(self.specs[1].motor_id, CommunicationFailure.INVALID_FEEDBACK).accepted)
734:         self.assertEqual(core.snapshot().affected_joints, ("J2",))
735:         self.assertEqual(core.snapshot().faults[0].communication_error, CommunicationFailure.INVALID_FEEDBACK)
736: 
737:     def test_current_communication_status_clears_without_erasing_cause(self):
738:         core = self._ready_core()
739:         self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT))
740:         before = core.snapshot()
741:         self.assertTrue(core.receive(0, SAMPLE, HEALTHY_STOP))
742:         after = core.snapshot()
743:         self.assertTrue(after.joints[0].healthy)
744:         self.assertIsNone(after.joints[0].communication_error)
745:         self.assertEqual(after.faults, before.faults)
746:         self.assertIs(after.state, State.FAULT)
747: 
748:     def test_fault_record_requires_bounded_consistent_communication_codes(self):
749:         a, b = CommunicationFailure.TIMEOUT, CommunicationFailure.DRIVER_FAILURE
750:         for kwargs in (dict(communication_error=a, communication_errors=(b,)),
751:                        dict(communication_errors=(a, a)),
752:                        dict(communication_errors=(a,) * 4)):
753:             with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
754:                 JointFault("J1", 0, **kwargs)
755:         record = JointFault("J1", 0, communication_error=a, communication_errors=(a, b))
756:         self.assertIs(record.communication_error, a)
757:         self.assertEqual(record.communication_errors, (a, b))
758: 
759:     def test_unknown_ids_and_invalid_codes_reject_unchanged(self):
760:         core = self._ready_core()
761:         before = core.snapshot()
762: 
763:         self.assertEqual(core.communication_failed(0, "timeout").code,
764:                          DecisionCode.INVALID_ARGUMENT)
765:         self.assertEqual(core.snapshot(), before)
766: 
767:         rejected_id = core.communication_failed(14, CommunicationFailure.TIMEOUT)
768:         self.assertFalse(rejected_id)
769:         self.assertEqual(rejected_id.code, DecisionCode.UNKNOWN_JOINT)
770:         self.assertEqual(core.snapshot(), before)
771: 
772:         self.assertEqual(
773:             core.communication_failed(True, CommunicationFailure.TIMEOUT).code,
774:             DecisionCode.INVALID_ARGUMENT,
775:         )
776:         self.assertEqual(
777:             core.communication_failed("0", CommunicationFailure.TIMEOUT).code,
778:             DecisionCode.INVALID_ARGUMENT,
779:         )
780:         self.assertEqual(core.snapshot(), before)
781: 
782:         self.assertEqual(
783:             core.communication_failed(0, "unrecognized_failure").code,
784:             DecisionCode.INVALID_ARGUMENT,
785:         )
786:         self.assertEqual(
787:             core.communication_failed(0, RuntimeError("comm timeout")).code,
788:             DecisionCode.INVALID_ARGUMENT,
789:         )
790:         self.assertEqual(
791:             core.communication_failed(0, 999).code,
792:             DecisionCode.INVALID_ARGUMENT,
793:         )
794:         self.assertEqual(
795:             core.communication_failed(0, None).code,
796:             DecisionCode.INVALID_ARGUMENT,
797:         )
798:         self.assertEqual(core.snapshot(), before)
799: 
800:     def test_failed_recovery_retains_causes(self):
801:         clock = DeterministicClock(0.0)
802:         core = self._ready_core(clock, feedback_max_age_s=1.0)
803:         owner = core.snapshot().latest_owner
804:         self.assertTrue(core.arm(owner).accepted)
805: 
806:         self.assertTrue(core.receive(
807:             self.specs[0].motor_id,
808:             SAMPLE,
809:             MotorHealth(mode=0, errors=0x04, warnings=0, timeout=False),
810:         ).accepted)
811:         self.assertIs(core.snapshot().state, State.FAULT)
812:         self.assertEqual(core.snapshot().affected_joints, ("J1",))
813: 
814:         rejected = core.begin_check(acknowledge_fault=False)
815:         self.assertFalse(rejected)
816:         self.assertEqual(rejected.code, DecisionCode.FAULT_ACK_REQUIRED)
817:         self.assertEqual(core.snapshot().affected_joints, ("J1",))
818: 
819:         self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
820:         self.assertIs(core.snapshot().state, State.CHECKING)
821:         self.assertEqual(core.snapshot().affected_joints, ("J1",))
822: 
823:         self.assertEqual(core.checked().code, DecisionCode.OBSERVATIONS_INCOMPLETE)
824:         self.assertEqual(core.snapshot().affected_joints, ("J1",))
825: 
826:         non_stop = MotorHealth(mode=1, errors=0, warnings=0, timeout=False)
827:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, non_stop).accepted)
828:         self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP).accepted)
829:         self.assertEqual(core.checked().code, DecisionCode.NOT_STOPPED)
830:         self.assertEqual(core.snapshot().affected_joints, ("J1",))
831: 
832:         clock.value = 2.0
833:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
834:         self.assertEqual(core.checked().code, DecisionCode.STALE_FEEDBACK)
835:         self.assertEqual(core.snapshot().affected_joints, ("J1",))
836: 
837:         self.assertEqual(core.arm(owner).code, DecisionCode.INVALID_STATE)
838: 
839:     def test_successful_recovery_clears_fault_causes(self):
840:         clock = DeterministicClock(0.0)
841:         core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0, max_reference_gap_s=1.0)
842:         station = FakeStation(core)
843:         self.assertTrue(station.connect().accepted)
844:         owner = station.claim("fixture")
845:         self.assertTrue(station.check().accepted)
846:         self.assertTrue(station.arm(owner).accepted)
847: 
848:         self.assertTrue(core.communication_failed(
849:             self.specs[1].motor_id,
850:             CommunicationFailure.TIMEOUT,
851:         ).accepted)
852:         self.assertIs(core.snapshot().state, State.FAULT)
853:         self.assertEqual(core.snapshot().affected_joints, ("J2",))
854: 
855:         self.assertTrue(station.stop().accepted)
856:         self.assertIs(core.snapshot().state, State.FAULT)
857:         self.assertEqual(core.snapshot().affected_joints, ("J2",))
858: 
859:         self.assertTrue(station.disconnect().accepted)
860:         self.assertIs(core.snapshot().state, State.DISCONNECTED)
861:         self.assertTrue(core.snapshot().fault_latched)
862:         self.assertEqual(core.snapshot().affected_joints, ("J2",))
863: 
864:         self.assertTrue(station.connect().accepted)
865:         self.assertIs(core.snapshot().state, State.CONNECTED)
866:         self.assertTrue(core.snapshot().fault_latched)
867:         self.assertEqual(core.snapshot().affected_joints, ("J2",))
868: 
869:         self.assertTrue(station.check(acknowledge_fault=True).accepted)
870:         snap = core.snapshot()
871:         self.assertIs(snap.state, State.READY)
872:         self.assertFalse(snap.fault_latched)
873:         self.assertEqual(snap.faults, ())
874:         self.assertEqual(snap.affected_joints, ())
875: 
876:     def test_independent_second_core_unchanged_by_fault(self):
877:         specs2 = (
878:             JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
879:             JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
880:         )
881:         clock = DeterministicClock(0.0)
882:         core1 = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
883:         core2 = JointCore(specs2, clock=clock, max_reference_gap_s=1.0)
884: 
885:         station1 = FakeStation(core1)
886:         station2 = FakeStation(core2)
887:         self.assertTrue(station1.connect().accepted)
888:         owner1 = station1.claim("fixture-1")
889:         self.assertTrue(station1.check().accepted)
890:         self.assertTrue(station1.arm(owner1).accepted)
891: 
892:         self.assertTrue(station2.connect().accepted)
893:         owner2 = station2.claim("fixture-2")
894:         self.assertTrue(station2.check().accepted)
895:         self.assertTrue(station2.arm(owner2).accepted)
896: 
897:         self.assertTrue(core1.communication_failed(
898:             self.specs[0].motor_id,
899:             CommunicationFailure.DRIVER_FAILURE,
900:         ).accepted)
901:         snap1 = core1.snapshot()
902:         self.assertIs(snap1.state, State.FAULT)
903:         self.assertTrue(snap1.fault_latched)
904:         self.assertEqual(snap1.affected_joints, ("J1",))
905: 
906:         snap2 = core2.snapshot()
907:         self.assertIs(snap2.state, State.ARMED)
908:         self.assertFalse(snap2.fault_latched)
909:         self.assertEqual(snap2.faults, ())
910:         self.assertEqual(snap2.affected_joints, ())
911:         self.assertTrue(station2.stop().accepted)
912:         self.assertIs(core2.snapshot().state, State.STOPPED)
913: 
914:     def test_immutability_of_fault_records_and_snapshot_collections(self):
915:         fault = JointFault("J1", 0, errors=1, warnings=2, timeout=True)
916:         with self.assertRaises(FrozenInstanceError):
917:             fault.errors = 0
918:         with self.assertRaises(FrozenInstanceError):
919:             fault.name = "other"
920: 
921:         core = self._ready_core()
922:         self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
923:         snap = core.snapshot()
924: 
925:         self.assertIsInstance(snap.faults, tuple)
926:         self.assertIsInstance(snap.affected_joints, tuple)
927:         with self.assertRaises(FrozenInstanceError):
928:             snap.faults[0].timeout = False
929:         with self.assertRaises(TypeError):
930:             snap.faults[0] = fault
931:         with self.assertRaises(TypeError):
932:             snap.affected_joints[0] = "J2"
933: 
934: 
935: 
936: 
937: 
938: 
939: 
940: if __name__ == "__main__":
941:     unittest.main()

## test_controller_targets.py
1: import unittest
2: from dataclasses import FrozenInstanceError
3: import math
4: from im6014_codec import command
5: from joint_contract import (
6:     CommunicationFailure,
7:     DecisionCode,
8:     IntentWindow,
9:     JointSpec,
10:     MotorHealth,
11:     OwnerToken,
12:     State,
13:     Target,
14: )
15: from joint_controller import JointCore
16: from joint_mapping import JointMap, JointTarget
17: 
18: from test_controller import DeterministicClock, FakeStation, SAMPLE, HEALTHY_STOP, core_at
19: 
20: 
21: class LatestTargetTests(unittest.TestCase):
22:     def setUp(self):
23:         self.specs = (
24:             JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
25:             JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
26:         )
27: 
28:     def test_ten_thousand_accepted_updates_leave_one_newest_target_and_repeated_refresh(self):
29:         clock = DeterministicClock(0.0)
30:         # Keep feedback fresh beyond this one-second goal window so this test
31:         # isolates expiry instead of also triggering the default 0.5s stale fault.
32:         core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.2, max_reference_gap_s=1.2)
33:         station = FakeStation(core)
34:         self.assertTrue(station.connect().accepted)
35:         owner = station.claim("fixture")
36:         self.assertTrue(station.check().accepted)
37:         self.assertTrue(station.arm(owner).accepted)
38:         self.assertIsNone(core.snapshot().admitted_target)
39: 
40:         window = station.issue_window(1.0)
41:         last_target = None
42:         for i in range(10_000):
43:             target = Target(
44:                 i,
45:                 (
46:                     JointTarget(q_rad=i * 0.0001, dq_rad_s=0.0, tau_nm=0.0, kp=1.0, kd=0.1),
47:                     JointTarget(q_rad=-i * 0.0001, dq_rad_s=0.0, tau_nm=0.0, kp=1.0, kd=0.1),
48:                 ),
49:                 window=window,
50:                 owner=owner,
51:             )
52:             decision = station.submit(target)
53:             self.assertTrue(decision.accepted)
54:             last_target = target
55: 
56:         snap = core.snapshot()
57:         self.assertEqual(snap.admitted_target, last_target)
58:         self.assertEqual(snap.last_sequence, 9999)
59:         self.assertIs(snap.state, State.ARMED)
60: 
61:         clock.value = 0.05
62:         refreshed = station.refresh()
63:         self.assertIsNotNone(refreshed)
64:         self.assertEqual(refreshed.target, last_target)
65:         self.assertIs(core.snapshot().state, State.MOVING)
66:         self.assertEqual(core.snapshot().admitted_target, last_target)
67: 
68:         # Repeated refresh of admitted goal succeeds while within window
69:         second_refreshed = station.refresh()
70:         self.assertIsNotNone(second_refreshed)
71:         self.assertEqual(second_refreshed.target, last_target)
72:         self.assertIs(core.snapshot().state, State.MOVING)
73: 
74:         # Expiry withdraws admitted goal and disarms to STOPPED
75:         clock.value = 1.1
76:         expired_refreshed = station.refresh()
77:         self.assertIsNone(expired_refreshed)
78:         self.assertIs(core.snapshot().state, State.STOPPED)
79:         self.assertIsNone(core.snapshot().admitted_target)
80: 
81:     def test_immutable_owned_vector(self):
82:         jt1 = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
83:         jt2 = JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)
84:         window = IntentWindow(0, 0.0, 1.0)
85:         owner = OwnerToken("epoch-1", 1, "fixture")
86: 
87:         for bad_joints in (
88:             [jt1, jt2],
89:             "not a tuple",
90:             123,
91:             None,
92:             {jt1, jt2},
93:         ):
94:             with self.subTest(bad_joints=repr(bad_joints)), self.assertRaises(ValueError):
95:                 Target(0, bad_joints, window=window, owner=owner)
96: 
97:         with self.assertRaises(ValueError):
98:             Target(0, (), window=window, owner=owner)
99: 
100:         for bad_elements in (
101:             (jt1, "not a joint target"),
102:             (1, 2),
103:             (jt1, None),
104:         ):
105:             with self.subTest(bad_elements=repr(bad_elements)), self.assertRaises(ValueError):
106:                 Target(0, bad_elements, window=window, owner=owner)
107: 
108:         for bad_window in (None, "window", 123, object()):
109:             with self.subTest(bad_window=repr(bad_window)), self.assertRaises(ValueError):
110:                 Target(0, (jt1, jt2), window=bad_window, owner=owner)
111: 
112:         for bad_owner in (None, "owner", 123, object()):
113:             with self.subTest(bad_owner=repr(bad_owner)), self.assertRaises(ValueError):
114:                 Target(0, (jt1, jt2), window=window, owner=bad_owner)
115: 
116:         target = Target(0, (jt1, jt2), window=window, owner=owner)
117:         with self.assertRaises(FrozenInstanceError):
118:             target.sequence = 1
119:         with self.assertRaises(FrozenInstanceError):
120:             target.joints = (jt2, jt1)
121:         with self.assertRaises(FrozenInstanceError):
122:             target.window = window
123:         with self.assertRaises(FrozenInstanceError):
124:             target.owner = owner
125:         with self.assertRaises(TypeError):
126:             target.joints[0] = jt2
127:         with self.assertRaises(FrozenInstanceError):
128:             target.joints[0].q_rad = 99.0
129: 
130:         clock = DeterministicClock(0.0)
131:         core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
132:         station = FakeStation(core)
133:         self.assertTrue(station.connect().accepted)
134:         station_owner = station.claim("fixture")
135:         self.assertTrue(station.check().accepted)
136:         self.assertTrue(station.arm(station_owner).accepted)
137:         core_window = station.issue_window(1.0)
138:         valid_target = Target(0, (jt1, jt2), window=core_window, owner=station_owner)
139:         self.assertTrue(station.submit(valid_target).accepted)
140: 
141:         snap = core.snapshot()
142:         self.assertEqual(snap.admitted_target, valid_target)
143:         self.assertEqual(snap.last_sequence, 0)
144:         with self.assertRaises(FrozenInstanceError):
145:             snap.admitted_target = None
146:         with self.assertRaises(FrozenInstanceError):
147:             snap.last_sequence = 1
148:         with self.assertRaises(TypeError):
149:             snap.admitted_target.joints[0] = jt1
150:         with self.assertRaises(FrozenInstanceError):
151:             snap.admitted_target.joints[0].tau_nm = 0.5
152: 
153:     def test_malformed_incomplete_and_invalid_mapped_outputs_preserve_prior_target(self):
154:         clock = DeterministicClock(0.0)
155:         core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
156:         station = FakeStation(core)
157:         self.assertTrue(station.connect().accepted)
158:         owner = station.claim("fixture")
159:         self.assertTrue(station.check().accepted)
160:         self.assertTrue(station.arm(owner).accepted)
161: 
162:         jt1 = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
163:         jt2 = JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)
164:         w1 = station.issue_window(1.0)
165:         prior_target = Target(1, (jt1, jt2), window=w1, owner=owner)
166:         self.assertTrue(station.submit(prior_target).accepted)
167:         self.assertEqual(core.snapshot().admitted_target, prior_target)
168:         self.assertEqual(core.snapshot().last_sequence, 1)
169: 
170:         for malformed in (None, "target", 42, object(), [jt1, jt2]):
171:             with self.subTest(malformed=repr(malformed)):
172:                 decision = core.submit_target(malformed)
173:                 self.assertFalse(decision.accepted)
174:                 self.assertEqual(decision.code, DecisionCode.INVALID_ARGUMENT)
175:                 self.assertEqual(core.snapshot().admitted_target, prior_target)
176:                 self.assertEqual(core.snapshot().last_sequence, 1)
177: 
178:         for wrong_vector in (
179:             Target(2, (jt1,), window=w1, owner=owner),
180:             Target(2, (jt1, jt2, jt1), window=w1, owner=owner),
181:         ):
182:             with self.subTest(wrong_vector=wrong_vector):
183:                 decision = core.submit_target(wrong_vector)
184:                 self.assertFalse(decision.accepted)
185:                 self.assertEqual(decision.code, DecisionCode.INVALID_ARGUMENT)
186:                 self.assertEqual(core.snapshot().admitted_target, prior_target)
187:                 self.assertEqual(core.snapshot().last_sequence, 1)
188: 
189:         huge_speed = Target(2, (JointTarget(0.0, 1e7, 0.0, 1.0, 0.1), jt2), window=w1, owner=owner)
190:         rej = core.submit_target(huge_speed)
191:         self.assertFalse(rej.accepted)
192:         self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
193:         self.assertEqual(core.snapshot().admitted_target, prior_target)
194:         self.assertEqual(core.snapshot().last_sequence, 1)
195: 
196:         huge_kp = Target(2, (JointTarget(0.0, 0.0, 0.0, 31.0, 0.1), jt2), window=w1, owner=owner)
197:         rej = core.submit_target(huge_kp)
198:         self.assertFalse(rej.accepted)
199:         self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
200:         self.assertEqual(core.snapshot().admitted_target, prior_target)
201:         self.assertEqual(core.snapshot().last_sequence, 1)
202: 
203:         huge_kd = Target(2, (JointTarget(0.0, 0.0, 0.0, 1.0, 6.1), jt2), window=w1, owner=owner)
204:         rej = core.submit_target(huge_kd)
205:         self.assertFalse(rej.accepted)
206:         self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
207:         self.assertEqual(core.snapshot().admitted_target, prior_target)
208:         self.assertEqual(core.snapshot().last_sequence, 1)
209: 
210:         huge_pos = Target(2, (JointTarget(1e7, 0.0, 0.0, 1.0, 0.1), jt2), window=w1, owner=owner)
211:         rej = core.submit_target(huge_pos)
212:         self.assertFalse(rej.accepted)
213:         self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
214:         self.assertEqual(core.snapshot().admitted_target, prior_target)
215:         self.assertEqual(core.snapshot().last_sequence, 1)
216: 
217:     def test_each_fault_path_clears_pending_without_fake_foc_writes(self):
218:         for action in ('packet', 'communication', 'tick'):
219:             with self.subTest(action=action):
220:                 clock = DeterministicClock(0.0)
221:                 core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
222:                 station = FakeStation(core)
223:                 self.assertTrue(station.connect())
224:                 owner = station.claim("fixture")
225:                 self.assertTrue(station.check())
226:                 self.assertTrue(station.arm(owner))
227:                 w = station.issue_window(1.0)
228:                 target = Target(0, (JointTarget(0, 0, 0, 1, .1),) * 2, window=w, owner=owner)
229:                 self.assertTrue(station.submit(target))
230:                 self.assertEqual(core.snapshot().last_sequence, 0)
231:                 station.writes.clear()
232:                 if action == 'packet':
233:                     self.assertTrue(core.receive(1, SAMPLE, MotorHealth(0, 4, 0, False)))
234:                 elif action == 'communication':
235:                     self.assertTrue(core.communication_failed(1, CommunicationFailure.TIMEOUT))
236:                 else:
237:                     clock.value = .6
238:                     self.assertTrue(core.tick())
239:                 self.assertIs(core.snapshot().state, State.FAULT)
240:                 self.assertIsNone(core.snapshot().admitted_target)
241:                 self.assertEqual(core.snapshot().last_sequence, 0)
242:                 self.assertIsNone(station.refresh())
243:                 self.assertEqual(station.writes, [])
244: 
245:     def test_mapped_torque_outside_codec_bounds_rejects(self):
246:         clock = DeterministicClock(0.0)
247:         core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
248:         station = FakeStation(core)
249:         self.assertTrue(station.connect().accepted)
250:         owner = station.claim("fixture")
251:         self.assertTrue(station.check().accepted)
252:         self.assertTrue(station.arm(owner).accepted)
253: 
254:         jt1 = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
255:         jt2 = JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)
256:         w = station.issue_window(1.0)
257:         prior_target = Target(1, (jt1, jt2), window=w, owner=owner)
258:         self.assertTrue(station.submit(prior_target).accepted)
259:         self.assertEqual(core.snapshot().last_sequence, 1)
260: 
261:         too_high = Target(2, (JointTarget(0.0, 0.0, 3.501, 1.0, 0.1), jt2), window=w, owner=owner)
262:         rej = core.submit_target(too_high)
263:         self.assertFalse(rej.accepted)
264:         self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
265:         self.assertEqual(core.snapshot().admitted_target, prior_target)
266:         self.assertEqual(core.snapshot().last_sequence, 1)
267: 
268:         too_low = Target(2, (JointTarget(0.0, 0.0, -3.501, 1.0, 0.1), jt2), window=w, owner=owner)
269:         rej = core.submit_target(too_low)
270:         self.assertFalse(rej.accepted)
271:         self.assertEqual(rej.code, DecisionCode.INVALID_ARGUMENT)
272:         self.assertEqual(core.snapshot().admitted_target, prior_target)
273:         self.assertEqual(core.snapshot().last_sequence, 1)
274: 
275:         specs_ratio = (
276:             JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
277:             JointSpec("J2", 1, JointMap(reduction=1.0, direction=1, zero_output_rad=0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
278:         )
279:         core_ratio = JointCore(specs_ratio, clock=clock, max_reference_gap_s=1.0)
280:         station_ratio = FakeStation(core_ratio)
281:         self.assertTrue(station_ratio.connect().accepted)
282:         owner_ratio = station_ratio.claim("fixture-ratio")
283:         self.assertTrue(station_ratio.check().accepted)
284:         self.assertTrue(station_ratio.arm(owner_ratio).accepted)
285:         w_ratio = station_ratio.issue_window(1.0)
286: 
287:         rej_ratio = core_ratio.submit_target(
288:             Target(1, (JointTarget(0.0, 0.0, 12.0, 9.0, 0.9), jt2), window=w_ratio, owner=owner_ratio)
289:         )
290:         self.assertFalse(rej_ratio.accepted)
291:         self.assertEqual(rej_ratio.code, DecisionCode.INVALID_ARGUMENT)
292:         self.assertIsNone(core_ratio.snapshot().admitted_target)
293:         self.assertEqual(core_ratio.snapshot().last_sequence, -1)
294: 
295:     def test_successful_fake_adapter_uses_actual_codec_foc_packets_with_independent_expected_mappings(self):
296:         clock = DeterministicClock(0.0)
297:         specs = (
298:             JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25), -1e8, 1e8, 1e8, "fixture: wide test limits"),
299:             JointSpec("J2", 1, JointMap(reduction=2.0, direction=1, zero_output_rad=0.1), -1e8, 1e8, 1e8, "fixture: wide test limits"),
300:         )
301:         core = JointCore(specs, clock=clock, max_reference_gap_s=1.0)
302:         station = FakeStation(core)
303:         self.assertTrue(station.connect().accepted)
304:         owner = station.claim("fixture")
305:         self.assertTrue(station.check().accepted)
306:         self.assertTrue(station.arm(owner).accepted)
307:         station.writes.clear()
308: 
309:         jt1 = JointTarget(q_rad=0.1, dq_rad_s=1.0, tau_nm=-6.0, kp=18.0, kd=4.5)
310:         jt2 = JointTarget(q_rad=0.2, dq_rad_s=-1.0, tau_nm=3.0, kp=8.0, kd=2.0)
311:         w = station.issue_window(1.0)
312:         target = Target(1, (jt1, jt2), window=w, owner=owner)
313: 
314:         decision = station.submit(target)
315:         self.assertTrue(decision.accepted)
316:         self.assertEqual(core.snapshot().last_sequence, 1)
317:         self.assertEqual(station.writes, [])
318: 
319:         expected_pkt_1 = command(
320:             0,
321:             mode=1,
322:             rpm=-180.0 / math.tau,
323:             kd=0.5,
324:             torque=2.0,
325:             watchdog=True,
326:             position=-0.2,
327:             kp=2.0,
328:         )
329: 
330:         expected_pkt_2 = command(
331:             1,
332:             mode=1,
333:             rpm=-120.0 / math.tau,
334:             kd=0.5,
335:             torque=1.5,
336:             watchdog=True,
337:             position=0.4,
338:             kp=2.0,
339:         )
340: 
341:         clock.value += 0.05
342:         refreshed = station.refresh()
343:         self.assertIsNotNone(refreshed)
344:         self.assertEqual(refreshed.target, target)
345:         self.assertEqual(station.writes, [expected_pkt_1, expected_pkt_2])
346:         self.assertIs(core.snapshot().state, State.MOVING)
347:         self.assertEqual(core.snapshot().last_sequence, 1)
348: 
349:     def test_no_writes_on_rejection_stale_fault_stop_disconnect(self):
350:         clock = DeterministicClock(0.0)
351:         core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
352:         station = FakeStation(core)
353:         self.assertTrue(station.connect().accepted)
354:         owner = station.claim("fixture")
355:         self.assertTrue(station.check().accepted)
356:         self.assertTrue(station.arm(owner).accepted)
357:         station.writes.clear()
358: 
359:         jt1 = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
360:         jt2 = JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)
361:         w = station.issue_window(1.0)
362:         valid_target = Target(1, (jt1, jt2), window=w, owner=owner)
363: 
364:         bad_target = Target(2, (JointTarget(0.0, 0.0, 10.0, 1.0, 0.1), jt2), window=w, owner=owner)
365:         self.assertFalse(station.submit(bad_target).accepted)
366:         self.assertEqual(station.writes, [])
367: 
368:         self.assertIsNone(station.refresh())
369:         self.assertEqual(station.writes, [])
370: 
371:         self.assertTrue(station.submit(valid_target).accepted)
372:         self.assertEqual(core.snapshot().last_sequence, 1)
373:         clock.value = 1.000001
374:         w2 = station.issue_window(1.0)
375:         valid_target_newer = Target(2, (jt1, jt2), window=w2, owner=owner)
376:         self.assertEqual(station.submit(valid_target_newer).code, DecisionCode.STALE_FEEDBACK)
377:         self.assertEqual(station.writes, [])
378: 
379:         self.assertIsNone(station.refresh())
380:         self.assertEqual(station.writes, [])
381:         self.assertIs(core.snapshot().state, State.FAULT)
382:         self.assertIsNone(core.snapshot().admitted_target)
383:         self.assertEqual(core.snapshot().last_sequence, 1)
384: 
385:         w3 = station.issue_window(1.0)
386:         valid_target_3 = Target(3, (jt1, jt2), window=w3, owner=owner)
387:         self.assertEqual(station.submit(valid_target_3).code, DecisionCode.INVALID_STATE)
388:         self.assertIsNone(station.refresh())
389:         self.assertEqual(station.writes, [])
390: 
391:         station.writes.clear()
392:         owner_rec = station.claim("fixture-rec")
393:         self.assertTrue(station.check(acknowledge_fault=True).accepted)
394:         station.writes.clear()
395:         self.assertTrue(station.arm(owner_rec).accepted)
396:         self.assertEqual(core.snapshot().last_sequence, 1)
397:         w4 = station.issue_window(1.0)
398:         valid_target_4 = Target(4, (jt1, jt2), window=w4, owner=owner_rec)
399:         self.assertTrue(station.submit(valid_target_4).accepted)
400:         self.assertEqual(core.snapshot().last_sequence, 4)
401: 
402:         station.writes.clear()
403:         self.assertTrue(station.stop().accepted)
404:         self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
405:         self.assertIsNone(core.snapshot().admitted_target)
406:         self.assertEqual(core.snapshot().last_sequence, 4)
407:         station.writes.clear()
408:         self.assertIsNone(station.refresh())
409:         self.assertEqual(station.writes, [])
410: 
411:         core2 = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
412:         station2 = FakeStation(core2)
413:         self.assertTrue(station2.connect().accepted)
414:         owner2 = station2.claim("fixture-2")
415:         self.assertTrue(station2.check().accepted)
416:         self.assertTrue(station2.arm(owner2).accepted)
417:         self.assertEqual(core2.snapshot().last_sequence, -1)
418:         w5 = station2.issue_window(1.0)
419:         valid_target_5 = Target(1, (jt1, jt2), window=w5, owner=owner2)
420:         self.assertTrue(station2.submit(valid_target_5).accepted)
421:         self.assertEqual(core2.snapshot().last_sequence, 1)
422:         station2.writes.clear()
423: 
424:         self.assertTrue(station2.disconnect().accepted)
425:         self.assertEqual(station2.writes, [])
426:         self.assertIsNone(core2.snapshot().admitted_target)
427:         self.assertEqual(core2.snapshot().last_sequence, 1)
428:         self.assertIsNone(station2.refresh())
429:         self.assertEqual(station2.writes, [])
430: 
431:     def test_stale_feedback_discovered_on_refresh_clears_pending_and_latches_fault(self):
432:         clock = DeterministicClock(0.0)
433:         core = JointCore(self.specs, clock=clock, feedback_max_age_s=0.5, max_reference_gap_s=1.0)
434:         station = FakeStation(core)
435:         self.assertTrue(station.connect().accepted)
436:         owner = station.claim("fixture")
437:         self.assertTrue(station.check().accepted)
438:         self.assertTrue(station.arm(owner).accepted)
439: 
440:         w = station.issue_window(1.0)
441:         target = Target(1, (
442:             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
443:             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
444:         ), window=w, owner=owner)
445:         self.assertTrue(station.submit(target).accepted)
446:         self.assertEqual(core.snapshot().admitted_target, target)
447:         self.assertEqual(core.snapshot().last_sequence, 1)
448: 
449:         clock.value = 0.4
450:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
451: 
452:         clock.value = 0.6
453:         refreshed = station.refresh()
454:         self.assertIsNone(refreshed)
455: 
456:         snap = core.snapshot()
457:         self.assertIs(snap.state, State.FAULT)
458:         self.assertTrue(snap.fault_latched)
459:         self.assertIsNone(snap.admitted_target)
460:         self.assertEqual(snap.last_sequence, 1)
461:         self.assertEqual(snap.affected_joints, ("J2",))
462:         self.assertEqual(len(snap.faults), 1)
463:         self.assertTrue(snap.faults[0].stale)
464:         self.assertEqual(snap.faults[0].name, "J2")
465: 
466:         self.assertEqual(station.check().code, DecisionCode.FAULT_ACK_REQUIRED)
467: 
468:     def test_only_armed_and_moving_may_submit_and_refresh(self):
469:         clock = DeterministicClock(0.0)
470:         w = IntentWindow(0, 0.0, 1.0)
471:         dummy_owner = OwnerToken("epoch-dummy", 1, "human")
472:         target = Target(1, (
473:             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
474:             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
475:         ), window=w, owner=dummy_owner)
476: 
477:         rejected_states = (
478:             State.DISCONNECTED,
479:             State.CONNECTING,
480:             State.CONNECTED,
481:             State.CHECKING,
482:             State.READY,
483:             State.STOPPED,
484:             State.FAULT,
485:         )
486:         for state in rejected_states:
487:             with self.subTest(state=state):
488:                 core = core_at(self, state)
489:                 before = core.snapshot()
490:                 self.assertEqual(core.submit_target(target).code, DecisionCode.INVALID_STATE)
491:                 self.assertIsNone(core.prepare_refresh())
492:                 self.assertEqual(core.snapshot(), before)
493: 
494:         clock = DeterministicClock(0.0)
495:         core = core_at(self, State.ARMED, clock=clock)
496:         armed_station = FakeStation(core)
497:         armed_owner = core.snapshot().latest_owner
498:         w_arm = armed_station.issue_window(1.0)
499:         arm_target = Target(1, (
500:             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
501:             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
502:         ), window=w_arm, owner=armed_owner)
503:         self.assertTrue(core.submit_target(arm_target).accepted)
504:         self.assertEqual(core.snapshot().admitted_target, arm_target)
505:         self.assertEqual(core.snapshot().last_sequence, 1)
506:         clock.value += 0.05
507:         plan = armed_station.refresh()
508:         self.assertIsNotNone(plan)
509:         self.assertEqual(plan.target, arm_target)
510:         self.assertIs(core.snapshot().state, State.MOVING)
511:         self.assertEqual(core.snapshot().last_sequence, 1)
512: 
513:         w_move = armed_station.issue_window(1.0)
514:         target2 = Target(2, (
515:             JointTarget(0.3, 0.0, 0.0, 1.0, 0.1),
516:             JointTarget(0.4, 0.0, 0.0, 1.0, 0.1),
517:         ), window=w_move, owner=armed_owner)
518:         self.assertTrue(core.submit_target(target2).accepted)
519:         self.assertEqual(core.snapshot().admitted_target, target2)
520:         self.assertEqual(core.snapshot().last_sequence, 2)
521:         clock.value += 0.05
522:         plan2 = armed_station.refresh()
523:         self.assertIsNotNone(plan2)
524:         self.assertEqual(plan2.target, target2)
525:         self.assertIs(core.snapshot().state, State.MOVING)
526:         self.assertEqual(core.snapshot().last_sequence, 2)
527: 
528: 
529: class CommandSequenceTests(unittest.TestCase):
530:     def setUp(self):
531:         self.specs = (
532:             JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
533:             JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
534:         )
535:         self.valid_joints = (
536:             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
537:             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
538:         )
539: 
540:     def _armed_station(self, clock=None):
541:         if clock is None:
542:             clock = DeterministicClock(0.0)
543:         core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
544:         station = FakeStation(core)
545:         self.assertTrue(station.connect().accepted)
546:         owner = station.claim("fixture")
547:         self.assertTrue(station.check().accepted)
548:         self.assertTrue(station.arm(owner).accepted)
549:         return core, station, clock
550: 
551:     def test_actual_order_1_5_5_2_6_ends_at_6(self):
552:         core, station, clock = self._armed_station()
553:         self.assertEqual(core.snapshot().last_sequence, -1)
554:         self.assertIsNone(core.snapshot().admitted_target)
555: 
556:         w = station.issue_window(1.0)
557:         t1 = Target(1, self.valid_joints, window=w, owner=station.owner)
558:         d1 = station.submit(t1)
559:         self.assertTrue(d1.accepted)
560:         self.assertEqual(core.snapshot().last_sequence, 1)
561:         self.assertEqual(core.snapshot().admitted_target, t1)
562: 
563:         t5 = Target(5, self.valid_joints, window=w, owner=station.owner)
564:         d5 = station.submit(t5)
565:         self.assertTrue(d5.accepted)
566:         self.assertEqual(core.snapshot().last_sequence, 5)
567:         self.assertEqual(core.snapshot().admitted_target, t5)
568: 
569:         station.writes.clear()
570:         t5_dup = Target(5, self.valid_joints, window=w, owner=station.owner)
571:         d5_dup = station.submit(t5_dup)
572:         self.assertFalse(d5_dup.accepted)
573:         self.assertEqual(d5_dup.code, DecisionCode.DUPLICATE_OR_OLDER)
574:         self.assertEqual(core.snapshot().last_sequence, 5)
575:         self.assertEqual(core.snapshot().admitted_target, t5)
576:         self.assertEqual(station.writes, [])
577: 
578:         t2 = Target(2, self.valid_joints, window=w, owner=station.owner)
579:         d2 = station.submit(t2)
580:         self.assertFalse(d2.accepted)
581:         self.assertEqual(d2.code, DecisionCode.DUPLICATE_OR_OLDER)
582:         self.assertEqual(core.snapshot().last_sequence, 5)
583:         self.assertEqual(core.snapshot().admitted_target, t5)
584:         self.assertEqual(station.writes, [])
585: 
586:         t6 = Target(6, self.valid_joints, window=w, owner=station.owner)
587:         d6 = station.submit(t6)
588:         self.assertTrue(d6.accepted)
589:         self.assertEqual(core.snapshot().last_sequence, 6)
590:         self.assertEqual(core.snapshot().admitted_target, t6)
591: 
592:         station.writes.clear()
593:         clock.value += 0.05
594:         plan = station.refresh()
595:         self.assertIsNotNone(plan)
596:         self.assertEqual(plan.target, t6)
597:         self.assertIs(core.snapshot().state, State.MOVING)
598:         self.assertEqual(core.snapshot().admitted_target, t6)
599:         self.assertEqual(core.snapshot().last_sequence, 6)
600:         self.assertEqual(len(station.writes), 2)
601: 
602:     def test_boundaries_0_and_uint64max(self):
603:         core, station, _ = self._armed_station()
604:         self.assertEqual(core.snapshot().last_sequence, -1)
605: 
606:         w = station.issue_window(1.0)
607:         t0 = Target(0, self.valid_joints, window=w, owner=station.owner)
608:         self.assertTrue(station.submit(t0).accepted)
609:         self.assertEqual(core.snapshot().last_sequence, 0)
610:         self.assertEqual(core.snapshot().admitted_target, t0)
611: 
612:         d0_dup = station.submit(t0)
613:         self.assertFalse(d0_dup.accepted)
614:         self.assertEqual(d0_dup.code, DecisionCode.DUPLICATE_OR_OLDER)
615:         self.assertEqual(core.snapshot().last_sequence, 0)
616:         self.assertEqual(core.snapshot().admitted_target, t0)
617: 
618:         uint64_max = (1 << 64) - 1
619:         t_max = Target(uint64_max, self.valid_joints, window=w, owner=station.owner)
620:         self.assertTrue(station.submit(t_max).accepted)
621:         self.assertEqual(core.snapshot().last_sequence, uint64_max)
622:         self.assertEqual(core.snapshot().admitted_target, t_max)
623: 
624:         d_max_dup = station.submit(t_max)
625:         self.assertFalse(d_max_dup.accepted)
626:         self.assertEqual(d_max_dup.code, DecisionCode.DUPLICATE_OR_OLDER)
627:         self.assertEqual(core.snapshot().last_sequence, uint64_max)
628: 
629:         t_smaller = Target(uint64_max - 1, self.valid_joints, window=w, owner=station.owner)
630:         d_smaller = station.submit(t_smaller)
631:         self.assertFalse(d_smaller.accepted)
632:         self.assertEqual(d_smaller.code, DecisionCode.DUPLICATE_OR_OLDER)
633:         self.assertEqual(core.snapshot().last_sequence, uint64_max)
634: 
635:     def test_sequence_type_and_range_rejections(self):
636:         w = IntentWindow(0, 0.0, 1.0)
637:         owner = OwnerToken("epoch-1", 1, "fixture")
638:         invalid_sequences = (
639:             True,
640:             False,
641:             -1,
642:             -100,
643:             0.0,
644:             1.5,
645:             math.nan,
646:             math.inf,
647:             -math.inf,
648:             "0",
649:             "1",
650:             "100",
651:             1 << 64,
652:             (1 << 64) + 1,
653:             None,
654:             object(),
655:         )
656:         for bad_seq in invalid_sequences:
657:             with self.subTest(bad_seq=repr(bad_seq)), self.assertRaises(ValueError):
658:                 Target(bad_seq, self.valid_joints, window=w, owner=owner)
659: 
660:         target = Target(1, self.valid_joints, window=w, owner=owner)
661:         with self.assertRaises(FrozenInstanceError):
662:             target.sequence = 2
663: 
664:     def test_invalid_higher_vector_or_mapping_preserves_pending_and_watermark_and_never_blocks_smaller(self):
665:         core, station, _ = self._armed_station()
666:         w = station.issue_window(1.0)
667:         t5 = Target(5, self.valid_joints, window=w, owner=station.owner)
668:         self.assertTrue(station.submit(t5).accepted)
669:         self.assertEqual(core.snapshot().last_sequence, 5)
670:         self.assertEqual(core.snapshot().admitted_target, t5)
671: 
672:         bad_len = Target(10, (self.valid_joints[0],), window=w, owner=station.owner)
673:         d_bad_len = station.submit(bad_len)
674:         self.assertFalse(d_bad_len.accepted)
675:         self.assertEqual(d_bad_len.code, DecisionCode.INVALID_ARGUMENT)
676:         self.assertEqual(core.snapshot().last_sequence, 5)
677:         self.assertEqual(core.snapshot().admitted_target, t5)
678: 
679:         bad_map = Target(10, (JointTarget(0.0, 0.0, 10.0, 1.0, 0.1), self.valid_joints[1]), window=w, owner=station.owner)
680:         d_bad_map = station.submit(bad_map)
681:         self.assertFalse(d_bad_map.accepted)
682:         self.assertEqual(d_bad_map.code, DecisionCode.INVALID_ARGUMENT)
683:         self.assertEqual(core.snapshot().last_sequence, 5)
684:         self.assertEqual(core.snapshot().admitted_target, t5)
685: 
686:         bad_second = Target(10, (self.valid_joints[0], JointTarget(0, 0, 10, 1, .1)), window=w, owner=station.owner)
687:         before = core.snapshot()
688:         self.assertEqual(station.submit(bad_second).code, DecisionCode.INVALID_ARGUMENT)
689:         self.assertEqual(core.snapshot(), before)
690: 
691:         t7 = Target(7, self.valid_joints, window=w, owner=station.owner)
692:         d7 = station.submit(t7)
693:         self.assertTrue(d7.accepted)
694:         self.assertEqual(core.snapshot().last_sequence, 7)
695:         self.assertEqual(core.snapshot().admitted_target, t7)
696: 
697:     def test_watermark_survives_consumption_stop_fault_disconnect_reconnect_and_recovery(self):
698:         clock = DeterministicClock(0.0)
699:         core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0, max_reference_gap_s=1.0)
700:         station = FakeStation(core)
701:         self.assertTrue(station.connect().accepted)
702:         owner1 = station.claim("fixture-1")
703:         self.assertTrue(station.check().accepted)
704:         self.assertTrue(station.arm(owner1).accepted)
705: 
706:         w1 = station.issue_window(1.0)
707:         t10 = Target(10, self.valid_joints, window=w1, owner=owner1)
708:         self.assertTrue(station.submit(t10).accepted)
709:         self.assertEqual(core.snapshot().last_sequence, 10)
710: 
711:         clock.value += 0.05
712:         plan = station.refresh()
713:         self.assertIsNotNone(plan)
714:         self.assertEqual(plan.target, t10)
715:         self.assertIs(core.snapshot().state, State.MOVING)
716:         self.assertEqual(core.snapshot().last_sequence, 10)
717: 
718:         self.assertTrue(station.stop().accepted)
719:         self.assertIs(core.snapshot().state, State.STOPPED)
720:         self.assertEqual(core.snapshot().last_sequence, 10)
721: 
722:         owner2 = station.claim("fixture-2")
723:         self.assertTrue(station.check().accepted)
724:         self.assertTrue(station.arm(owner2).accepted)
725:         self.assertEqual(core.snapshot().last_sequence, 10)
726: 
727:         bad_health = MotorHealth(mode=0, errors=1, warnings=0, timeout=False)
728:         self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, bad_health).accepted)
729:         self.assertIs(core.snapshot().state, State.FAULT)
730:         self.assertEqual(core.snapshot().last_sequence, 10)
731: 
732:         self.assertTrue(station.stop().accepted)
733:         self.assertIs(core.snapshot().state, State.FAULT)
734:         self.assertEqual(core.snapshot().last_sequence, 10)
735: 
736:         self.assertTrue(station.disconnect().accepted)
737:         self.assertIs(core.snapshot().state, State.DISCONNECTED)
738:         self.assertEqual(core.snapshot().last_sequence, 10)
739: 
740:         self.assertTrue(station.connect().accepted)
741:         self.assertIs(core.snapshot().state, State.CONNECTED)
742:         self.assertEqual(core.snapshot().last_sequence, 10)
743: 
744:         owner3 = station.claim("fixture-3")
745:         self.assertTrue(station.check(acknowledge_fault=True).accepted)
746:         self.assertIs(core.snapshot().state, State.READY)
747:         self.assertEqual(core.snapshot().last_sequence, 10)
748: 
749:         self.assertTrue(station.arm(owner3).accepted)
750:         self.assertIs(core.snapshot().state, State.ARMED)
751:         self.assertEqual(core.snapshot().last_sequence, 10)
752: 
753:         w2 = station.issue_window(1.0)
754:         t10_new = Target(10, self.valid_joints, window=w2, owner=owner3)
755:         d10_dup = station.submit(t10_new)
756:         self.assertFalse(d10_dup.accepted)
757:         self.assertEqual(d10_dup.code, DecisionCode.DUPLICATE_OR_OLDER)
758:         self.assertEqual(core.snapshot().last_sequence, 10)
759: 
760:         t9 = Target(9, self.valid_joints, window=w2, owner=owner3)
761:         d9 = station.submit(t9)
762:         self.assertFalse(d9.accepted)
763:         self.assertEqual(d9.code, DecisionCode.DUPLICATE_OR_OLDER)
764:         self.assertEqual(core.snapshot().last_sequence, 10)
765: 
766:         t11 = Target(11, self.valid_joints, window=w2, owner=owner3)
767:         d11 = station.submit(t11)
768:         self.assertTrue(d11.accepted)
769:         self.assertEqual(core.snapshot().last_sequence, 11)
770:         self.assertEqual(core.snapshot().admitted_target, t11)
771: 
772:     def test_stale_submission_latches_fault_clears_goal_and_preserves_watermark(self):
773:         core, station, clock = self._armed_station()
774:         w = station.issue_window(1.0)
775:         t5 = Target(5, self.valid_joints, window=w, owner=station.owner)
776:         self.assertTrue(station.submit(t5).accepted)
777:         self.assertEqual(core.snapshot().last_sequence, 5)
778:         self.assertEqual(core.snapshot().admitted_target, t5)
779: 
780:         clock.value = 1.000001
781:         w2 = station.issue_window(1.0)
782:         t10 = Target(10, self.valid_joints, window=w2, owner=station.owner)
783:         d_stale = station.submit(t10)
784:         self.assertFalse(d_stale.accepted)
785:         self.assertEqual(d_stale.code, DecisionCode.STALE_FEEDBACK)
786:         self.assertEqual(core.snapshot().last_sequence, 5)
787:         stale_snapshot = core.snapshot()
788:         self.assertIsNone(stale_snapshot.admitted_target)
789:         self.assertIs(stale_snapshot.state, State.FAULT)
790: 
791:         rejected_states = (
792:             State.DISCONNECTED,
793:             State.CONNECTING,
794:             State.CONNECTED,
795:             State.CHECKING,
796:             State.READY,
797:             State.STOPPED,
798:             State.FAULT,
799:         )
800:         dummy_owner = OwnerToken("dummy", 1, "human")
801:         for state in rejected_states:
802:             with self.subTest(state=state):
803:                 state_core = core_at(self, state)
804:                 self.assertIs(state_core.snapshot().state, state)
805:                 self.assertEqual(state_core.snapshot().last_sequence, -1)
806:                 w_state = state_core.issue_window(1.0)
807:                 d = state_core.submit_target(Target(20, self.valid_joints, window=w_state, owner=dummy_owner))
808:                 self.assertFalse(d.accepted)
809:                 self.assertEqual(d.code, DecisionCode.INVALID_STATE)
810:                 self.assertEqual(state_core.snapshot().last_sequence, -1)
811:                 self.assertIsNone(state_core.snapshot().admitted_target)
812: 
813:     def test_new_core_starts_negative_one_and_independent_watermarks(self):
814:         core1 = JointCore(self.specs, clock=DeterministicClock(0.0), max_reference_gap_s=1.0)
815:         core2 = JointCore(self.specs, clock=DeterministicClock(0.0), max_reference_gap_s=1.0)
816:         self.assertEqual(core1.snapshot().last_sequence, -1)
817:         self.assertEqual(core2.snapshot().last_sequence, -1)
818: 
819:         station1 = FakeStation(core1)
820:         self.assertTrue(station1.connect().accepted)
821:         owner1 = station1.claim("fixture-1")
822:         self.assertTrue(station1.check().accepted)
823:         self.assertTrue(station1.arm(owner1).accepted)
824: 
825:         w = station1.issue_window(1.0)
826:         t10 = Target(10, self.valid_joints, window=w, owner=owner1)
827:         self.assertTrue(station1.submit(t10).accepted)
828:         self.assertEqual(core1.snapshot().last_sequence, 10)
829:         self.assertEqual(core2.snapshot().last_sequence, -1)
830: 
831: 
832: if __name__ == "__main__":
833:     unittest.main()

## docs/controller-limits-design.md
1: # Controller limits and station design
2: 
3: ## Problem and usage
4: 
5: C07-C16 extend the verified transport-free core with expiring ownership-bound requests, joint/reference limits, measured faults and timing. A separate fixture station owns the managed PTY lease independently of its client. Existing bench GUI/CLI remain functional. Physical motor execution remains blocked by the unanswered timeout acknowledgment; fixture thresholds cannot establish production readiness.
6: 
7: The station issues a monotonic intent window before client computation. A client submits a complete vector with that window, sequence and (from C08) current owner token. Arrival never renews the deadline. Connect/check/claim/arm stay explicit. A submit receipt means admitted, not written or moved. The adapter prepares one full vector, validates all packets, then checks the core gate beside each actual write and records complete/partial/failed write independently of feedback.
8: 
9: ```python
10: # Final C16 client; clients never open a motor port or supply telemetry/time.
11: with StationClient(socket_path) as client:
12:     owner = client.claim("human")       # revokes prior generation, stops
13:     client.check(acknowledge_fault=False)
14:     client.arm(owner)
15:     window, snapshot = client.observe(valid_for_s=0.2)
16:     decision = client.submit(owner, window.id, sequence=42, joints=targets)
17:     client.stop()
18: ```
19: 
20: ```python
21: # One station thread, illustrated in domain terms.
22: plan = core.prepare_refresh()
23: if plan is not None:
24:     packets = encode_complete(plan, core.joint_specs)
25:     for index, packet in enumerate(packets):
26:         reply = exchange(bus, packet, core.joint_specs[index].motor_id,
27:             before_write=lambda: service_priority_and_claim(core, plan, index),
28:             on_write=lambda result: core.dispatch_result(plan.id, index, result))
29:         core.receive(reply.id, mapped_sample(reply), mapped_health(reply))
30: ```
31: 
32: The final implementation must resolve closure binding explicitly. The adapter aborts remaining mode-1 writes after any rejection/failure and schedules Stops. Serial writes across joints cannot be physically atomic; each actual partial/full write is separately recorded. Stop cannot interrupt an already-running synchronous driver call.
33: 
34: ## Selection and synthesis
35: 
36: Both main candidates converged on core-owned goals with a separate station shell. Sol also supplied a structurally distinct immutable reducer alternative; Gemini considered a separate safety middleware. Parent selected Sol's stateful core: existing lifecycle calls are recognizable and one authority owns motion. The reducer would require a larger event/effect coordination surface. Middleware was rejected because a direct core call could bypass it or duplicate reference state.
37: 
38: | Criterion | Parent Sol | Parent Gemini | Muse Sol | Muse Gemini |
39: | --- | --- | --- | --- | --- |
40: | Final dispatch gate and ownership | 5 | 2 | 5 | 2 |
41: | Combined reference constraints | 4 | 2 | 5 | 2 |
42: | Interface depth and maintenance | 3 | 3 | 4 | 3 |
43: | Station independence | 4 | 3 | 5 | 2 |
44: | Testability and actual evidence | 5 | 3 | 5 | 2 |
45: | Verifiable unit sequence | 4 | 3 | 5 | 3 |
46: 
47: Muse chose the same base. Parent scored lower where sketches still need executable proof, and did not accept the judge's claim that the full analytic mathematics was already proven. Parent grafted Gemini's readable decision codes, selectors-based nonblocking process shell and snapshot/timing client view. Neither score is physical validation.
48: 
49: Parent simplified Sol's virtual trapezoidal trajectory/braking mathematics into the explicitly discrete contract below. The milestones require samplewise reference velocity and acceleration bounds, not a continuous physical trajectory. Parent replaced fixed 2048-byte binary packing with bounded JSON packets over Linux Unix SOCK_SEQPACKET: OS message boundaries plus fixed byte/count limits avoid incremental parser state and a broad packing taxonomy. No unbounded streams/queues, JSON NaN, arbitrary object deserialization or client-controlled health/time are allowed. Retain Sol's intent windows, opaque plan IDs, final write gate, epoch/generation/connection binding, partial dispatch records and PTY-only executable.
50: 
51: ## Modules and types
52: 
53: - joint_controller.py owns lifecycle, checked clock high-water mark, one admitted complete goal, one prepared plan, ownership/window authority, per-joint reference and dispatch records, measured observations and fault union. Split frozen records to joint_contract.py only if needed to keep the core cohesive; migrate imports rather than maintain aliases.
54: - joint_reference.py owns pure feasible-interval/reference and effort calculation. It owns no clock, observations, mutable reference or transport.
55: - im6014_serial.py keeps bench exchange behavior and adds optional before_write/on_write hooks. The final gate runs after reset/timeout setup directly before write. False cancels with no write. Actual write result is reported even if later feedback times out.
56: - station_timing.py owns bounded actual loop/transaction measurements. C15 first proves it through a fake adapter; it does not depend on an unfinished C16 daemon.
57: - joint_station.py and station_protocol.py own the C16 single-thread fixture process/lease and bounded client IPC respectively. No physical executable or D01 profile schema is introduced.
58: 
59: ```python
60: @dataclass(frozen=True)
61: class IntentWindow:
62:     id: int
63:     created_at_s: float
64:     expires_at_s: float
65: 
66: @dataclass(frozen=True)
67: class Target:
68:     sequence: int
69:     joints: tuple[JointTarget, ...]
70:     window: IntentWindow
71:     # C08 adds required OwnerToken, with epoch, generation, connection ID.
72: 
73: class JointCore:
74:     def issue_window(self, valid_for_s: float) -> IntentWindow: ...
75:     def submit_target(self, target: Target) -> Decision: ...
76:     def prepare_refresh(self) -> RefreshPlan | None: ...
77:     def claim_dispatch(self, plan_id: int, index: int) -> bool: ...
78:     def dispatch_result(self, plan_id: int, index: int, result: WriteResult) -> Decision: ...
79:     # Existing lifecycle and snapshot; consume_target is deleted.
80: ```
81: 
82: Sketch bodies remain unimplemented in this document. Per-family types become required only in their milestone, with all callers migrated in that unit. No default unbounded limits or guessed physical thresholds. Explicit fixture configurations supply values. Configuration/build/observation metadata can be retained as fixture identifiers; D01 profile parsing remains later work.
83: 
84: ## Time, admission and authority
85: 
86: Retain the existing floating-point monotonic clock API for compatibility with deterministic fixtures. Track its maximum observed valid time globally; reject invalid/regressing time before overwriting observations or releasing motion. Preserve finite-clock errors in snapshots rather than fabricate fresh ages. Station catches a clock failure, records it and Stops. A later valid clock must be at least the previous high-water mark.
87: 
88: Windows have finite positive bounded lifetime, station-issued ID and exact creation/expiry. Equality with expiry is expired. The core stores only the latest offered window and the admitted goal's immutable window. Issuing a newer window invalidates older incoming responses but does not renew/erase the already admitted goal. Expiry of an admitted goal withdraws motion and Stops; an invalid incoming replacement preserves an otherwise valid goal and watermark. Required safety housekeeping still expires/faults old goals. Recheck expiry at preparation and before every mode-1 write, not only admission.
89: 
90: C08 ownership adds a fresh core/process epoch, monotonic uint64 generation and server-generated connection identity. Stop, fault, disconnection, takeover and reconnect withdraw goal/plans and revoke authority; no automatic rearm. Old generation/epoch/connection requests reject. Sequence watermark remains globally increasing across those transitions and never wraps/resets; clients learn it from snapshots. Exhaustion rejects motion until a fresh core/epoch. A client cannot manufacture another connection's authority through JSON fields.
91: 
92: All admission checks happen before replacing the complete goal/watermark: domain types/count/order, window/owner, full mapped codec representability, inclusive position limits and later requested lead/effort checks. Rejected high sequences cannot consume ordering. Prepared plans are complete and bounded; replacement/revocation invalidates them. A complete write commits only that joint's actual reference record. Partial/unknown write faults and requires explicit fresh Stop recovery. Logical MOVING requires a confirmed mode-1 write; neither a prepared plan nor an admission is dispatched evidence.
93: 
94: ## Discrete reference and effort contract
95: 
96: Initialize reference position from fresh healthy checked Stop measurement and reference velocity zero. For positive elapsed h since the previous reference step, choose endpoint velocity v in the closed intersection:
97: 
98:     [-V, V] intersection [v_prev-A*h, v_prev+A*h]
99:     intersection [(q_min-q_prev)/h, (q_max-q_prev)/h]
100:     intersection [(q_measured-lead-q_prev)/h, (q_measured+lead-q_prev)/h]
101: 
102: Then q_next=q_prev+position_step_velocity*h, where position_step_velocity is the exact rational decoded emitted-position difference divided by the actual float cadence h. The independently quantized encoded command velocity is a separate quantity. Apply speed and acceleration bounds to both streams using their respective confirmed prior values. Never use encoded velocity as the position-step velocity. Project the desired position/velocity objective into that interval; define the selected objective in the API docs. Position request limits reject outside inclusive bounds. Requested lead outside its documented bound rejects, while the actual reference also stays bounded at each preparation/final gate. C10 adds V; C11 adds acceleration interval; C12 adds measured lead. At zero elapsed time, only the same admitted joint goal may replay the exact cached packet, decoded target and full reference history; a fresh Stop anchor has no packet to replay, and a changed goal is rejected. Excessive elapsed gap withdraws motion instead of allowing unlimited catch-up. Reversal preserves previous velocity and crosses zero under the same acceleration bound. Empty intervals/unsafe finite arithmetic generate no reference and latch an attributed constraint fault with Stop. Never clamp q after choosing v or silently relax a bound.
103: 
104: These are samplewise software reference constraints. They establish no continuous motor trajectory, physical acceleration or certified braking. Timing and actual write records remain separate.
105: 
106: Before any write, validate every shaped mapped packet through the canonical codec. Codec quantization can cross a closed position or effort bound. Keep codec scales in the codec; expose decoded encoded-command values there if necessary, map back once and check actual encoded endpoints/effort against inclusive limits. Choose an inward representable value when possible, otherwise withdraw motion. Do not disguise a quantization overshoot with an arbitrary safety tolerance or copy codec scales into the limiter. Recheck fresh measurement, expiry, owner and limits at final gate. No source caller can bypass constraints via the deleted consume API.
107: 
108: Predict tau_ff+kp*(q_ref-q_measured)+kd*(dq_ref-dq_measured), including gains after encoded-command quantization. Preserve requested/admitted, shaped accepted, confirmed dispatched and measured records distinctly. Monitor measured joint effort independently. C13 trips configured peak effort; C14 adds continuous-effort dwell, explicit driver/winding temperature trip/reset bounds and attributed fault union. No defaults claim physical protection. Recovery requires explicit acknowledgment followed by complete fresh healthy Stop telemetry below recovery thresholds for the configured dwell; new targets, reconnect and healthy packets alone cannot clear latches. Missing temperature telemetry never proves healthy recovery.
109: 
110: ## Station and timing
111: 
112: The C16 executable accepts explicit validated /dev/pts endpoints only, with deterministic fixture actuator semantics. It opens through the existing fixed managed lease namespace and retains the lease until confirmed close. Unconfirmed closure leaves a retryable shutdown with owner held. Clients never launch/restart it automatically. One active connection owns motion; a bounded priority control request can Stop/take over. Serve Stop/takeover/EOF/liveness before targets and each write gate, with bounded reads/accepts per iteration. Packet size/joint count/depth are fixed and oversized/truncated/malformed messages reject before mutation. Directory/socket permissions restrict to the same user. Slow clients/backpressure cannot block refresh; disconnect revokes and Stops.
113: 
114: Client crash must leave the station alive with its lease, Stop state and no rearm. A second cooperating opener fails. Restart uses a fresh epoch, fresh Stop checks and explicit arm. The existing bench GUI remains a separate legacy bench path; C16 tests a dashboard/client process against the new fixture station, and the managed lease excludes that bench opening the same PTY. UI migration is later E-series work, not a fabricated production feature.
115: 
116: Report actual start-to-start period, per-joint transaction start/end duration/outcome, completion overrun/missed slots, feedback age and sampling skew. Skip missed slots instead of bursting. Records/counters stay bounded. Nominal period is configuration, not measured rate. C15 deterministic tests validate arithmetic; parent real-clock fixture runs (five repeats) provide separate observed timing with work/error counts and host-load context. PTY/fake timing is not physical RS485 throughput.
117: 
118: ## Verifiable units
119: 
120: One fresh Gemini writer per C07-C16 milestone, serialized from the accepted parent tip. Parent reads full diff/output/receipt, runs targeted and affected regression tests, records hashes/logs and commits before the next unit. Scope and test entry points are registered in check_milestone, the offline copyset/startup fingerprint and CI as each module appears. C15 fake timing works before C16 process integration. Final panel reviews, full offline/UI checks and nonwriter independent verification precede the private PR and guarded merge. All model outputs/receipts and parent selection notes are retained with requested-route evidence, not independent provider identity claims.
121: 
122: ## Quantization decision after executable sketches
123: 
124: Choose emitted targets with two named velocity streams. Retain actual decoded emitted JointTarget, exact rational position_step_velocity and preparation sample time per joint only after its full write. Retain actual claim time separately. Initialize a fresh healthy Stop anchor with zero velocities; it is not a dispatched record. Codec owns raw grids, canonical decoding and bounded inward projection. Cache validated canonical bytes and send them unchanged; no decode/re-encode drift. Certificates use exact rational values of stored finite floats, without arbitrary epsilon.
125: 
126: Sol's pure grid proof passed parent execution; Gemini's draft proof failed its own overshoot assertion. Parent separately checked its false noninteger-ratio inference and reproduced 100 unchanged samples with a too-small acceleration interval. Evidence is in evidence/control-limits/quantization. Neither model's self-report established execution.
127: 
128: For h>0, if a nonzero motion objective cannot make a representable position step under all closed constraints, Stop with an attributed constraint reason. Do not repeatedly commit unchanged writes and imply progress, hide fractional virtual motion, accumulate elapsed time contrary to actual write history, or relax bounds. A deliberate hold and h=0 refresh remain distinct. C10-C12 must prove useful progression at feasible fixture cadence and conservative Stop for infeasible cadence. There is no physical trajectory guarantee.

## docs/joint-api.md
1: # Joint mapping
2: 
3: The bench GUI and CLI use actuator output units. The mapping API converts external joint units before packet encoding. It does not open a serial port.
4: 
5: ```python
6: from joint_mapping import JointMap, JointTarget, OutputSample
7: 
8: mapping = JointMap(reduction=3, direction=-1, zero_output_rad=0.25)
9: output = mapping.to_output(JointTarget(-0.5, 2, 12, 36, 9))
10: joint = mapping.from_output(OutputSample(output.q_rad, output.rpm, output.tau_nm))
11: ```
12: 
13: This example produces an output position of 1.75 rad, speed of about -57.2958 rpm, torque of -4 Nm, Kp of 4 and Kd of 1. Reverse conversion recovers the original position, speed and torque. The resulting torque exceeds the bench encoder's ±3.5 Nm policy, so encoding it rejects the command. Mapping never clips a value to make it pass.
14: 
15: `JointTarget` uses rad, rad/s and Nm. `OutputTarget` uses rad, rpm and Nm. The offset is in actuator output radians. The internal motor reduction stays inside the codec. Ideal gain conversion assumes compatible stiffness and damping definitions. Friction, backlash, efficiency and physical calibration remain unmeasured.
16: 
17: Run a single offline acceptance check from the repository root:
18: 
19: ```sh
20: .venv/bin/python -B scripts/check_milestone.py B11
21: ```
22: 
23: The command prints the path to its receipt and raw logs under `evidence/runs`. The test checks ratios 1, 3 and 6 in both directions, nonzero offsets, independent numeric anchors and invalid values.
24: 
25: ## Passive port inspection
26: 
27: ```python
28: from im6014_port import PortConfig, inspect_port
29: from spin_5rpm import PORT
30: 
31: report = inspect_port(PortConfig(PORT, 6_000_000), ports=())
32: ```
33: 
34: `ports=()` makes this example use only the configured by-id basename. The report names its evidence source and does not establish communication with the motor. Normal inspection can also read passive OS enumeration metadata. Known wrong serial numbers or interfaces reject with expected and observed values. Unknown metadata stays explicitly unverified.
35: 
36: For an alternate adapter route, set both `expected_serial=None` and `expected_channel=None`. This removes the FTDI identity assertion. It does not bypass later device ownership checks or establish motor communication. The bench GUI and CLI default to the recorded FTDI serial and interface 3.
37: 
38: ## Diagnostic capture
39: 
40: `PacketCapture` holds at most 256 records by default. Each record contains capped packet prefixes, allowlisted decoded fields, a fixed outcome code, and explicit source and connection metadata. Exported snapshots own their lists and dictionaries. Exception messages, environment values and arbitrary serial-object fields are excluded. An unavailable or regressing capture end clock exports `ended_s=None` and preserves the exchange result or original error. An invalid start clock rejects before exchange.
41: 
42: The GUI includes its ring in the existing JSON snapshot. The CLI enables it in `main`; direct `run(bus, args, log)` callers retain the original uncaptured behavior. Tests opt in with `fixture` provenance. A `physical` label records the caller's declaration and does not independently prove device identity.
43: 
44: ## Cooperating bus ownership
45: 
46: Both real bench open sites use `open_managed_port(PortConfig(...), serial_factory=...)`. It checks passive identity before device acquisition and construction. A successful result owns `bus`; call `close()` and inspect its boolean result. `False` means ownership remains held because closure was not confirmed. Retry cleanup before reconnecting. A context manager raises `PortCloseError` on an otherwise normal exit with unconfirmed close; its `managed_port` remains available for cleanup.
47: 
48: This API opens hardware when given a motor path. Its acceptance tests use Linux PTYs exclusively. The device lease coordinates these workbench clients; it cannot exclude a raw client that ignores the lock.
49: 
50: When passive identity metadata is incomplete, the default route reports it as unverified and still permits device acquisition; known mismatches reject. The serial factory must expose the pyserial `is_open` status for confirmed cleanup. A missing status retains the lease. Neither passive inspection nor opening establishes CRC-valid motor communication.
51: 
52: ## Controller lifecycle and freshness
53: 
54: `JointCore` owns a fixed ordered set of unique `JointSpec` names and motor IDs. Its states and immutable `Snapshot` are transport-free; `connected(SourceIdentity(...))` records a declaration and never opens hardware. `Decision` evaluates to its `accepted` value.
55: 
56: Connect, check, and arm are distinct steps. `receive(id, JointSample(...), MotorHealth(...))` stamps each valid observation with the core's monotonic clock. `checked()` needs fresh healthy Stop-mode feedback from every active joint. `arm()` requires fresh healthy Stop-mode feedback. The configurable maximum age defaults to 0.5 seconds; this software policy is not a measured loop-rate guarantee. Snapshot `feedback_ages_s` preserves joint order and uses `None` before receipt. Timestamp zero is valid. Unknown IDs and invalid records do not refresh timestamps.
57: 
58: Call `tick()` to fault READY, ARMED, or MOVING when feedback ages out. Stop, disconnect/reconnect, and healthy packets do not clear a fault latch. Recovery requires `begin_check(acknowledge_fault=True)` followed by fresh healthy Stop feedback and successful `checked()`. The check clears observations first. Target dispatch, attributed fault records and command ordering are the next milestones.
59: 
60: ## Attributed faults
61: 
62: `Snapshot.faults` holds immutable `JointFault` records in configured joint order. `affected_joints` derives their names. Error and warning masks accumulate by bitwise OR, and watchdog timeout and stale flags latch. Communication codes are fixed `CommunicationFailure` enum values; they do not imply an actuator watchdog timeout. Current healthy feedback clears the current communication observation while the cause remains latched. Stop and reconnect retain causes. Only an explicitly acknowledged, complete, fresh, healthy Stop check clears them. Each core stores at most one record per configured joint and a unique first-occurrence union of fixed communication codes; its size is bounded by the finite enum. `communication_error` is the most recent cause; `communication_errors` is not a chronological event history. A supplied most-recent code must belong to that union.
63: 
64: When opening fails and cleanup cannot confirm closure, `open_managed_port` raises `PortCloseError` with `managed_port` for retry and the original error as `__cause__`. Context exit uses the same exception when closure fails, retaining any body exception as its cause. If cleanup succeeds, the original exception propagates normally.
65: 
66: ## Latest target and command expiry
67: 
68: `Target(sequence, joints, window, owner)` contains an immutable complete tuple of `JointTarget` values in configured order, a required station-issued `IntentWindow(id, created_at_s, expires_at_s)`, and the current `OwnerToken`. `JointCore.issue_window(valid_for_s)` issues the latest offered window with a monotonic ID and bounded duration (`max_window_s`, default 1.0s). `submit_target` first expires or faults an existing goal as needed, then checks the full owner token, validates the incoming window against the latest offered window, checks expiry (exact equality with expiry is expired), checks mapped output codec representability, and enforces monotonic command sequence ordering before admitting the goal. A rejected replacement keeps an existing goal only while that goal remains valid.
69: 
70: `consume_target` is deleted in favor of explicit refresh lifecycle: `prepare_refresh()`, `claim_dispatch(plan_id, index)`, and `dispatch_result(plan_id, index, result)`. An admitted goal is refreshed repeatedly until its window expires. Preparing a plan proposes a refresh vector without dispatching. Each `RefreshPlan` contains an exact-count tuple of immutable, validated canonical packet bytes; the adapter writes those bytes unchanged. `joint_targets` records the actual full joint reference decoded from those packets, while `target` preserves the admitted request. `claim_dispatch` verifies freshness, health, goal expiry, and ordered joint index immediately before each write. Only one claim may await an outcome; the core blocks another joint claim, plan preparation, and reconnect until the station reports that claim's actual transport result. Stop, expiry, target replacement, disconnect, or fault can invalidate the plan without discarding that in-flight receipt. `exchange` reports the write result once after the driver outcome; successful returns are deadline-checked before feedback. If the deadline expires after the pre-write hook grants a claim but before `bus.write`, it reports `WriteResult.PREWRITE_DEADLINE`: the software made no write call for that claim. This does not establish motor state or physical protection. `WriteResult.PARTIAL` means the driver returned a positive short count. `WriteResult.FAILED` means the driver raised or returned an invalid count, so byte delivery may be unknown. `Snapshot.dispatch_attempts` holds the latest outcome per joint. `dispatch_result` commits a dispatched record only for a complete write. A dispatched record's `dispatched_at_s` is the valid claim/write start time, not a fabricated completion timestamp. A complete write followed by invalid or regressing core time preserves the complete record and attempt, then faults with `CommunicationFailure.CLOCK_FAILURE` without restoring motion. `WriteResult.PREWRITE_DEADLINE` faults with `CommunicationFailure.PREWRITE_DEADLINE`; `PARTIAL` and `FAILED` fault with `DRIVER_FAILURE`, preserving any prior complete record. A late receipt for an invalidated plan is recorded but cannot restore motion or change `DISCONNECTED`; once it settles, an explicit reconnect is allowed. Reconnect still requires a new owner, acknowledged fresh healthy Stop check, and explicit arm. When an admitted goal expires, housekeeping withdraws it, invalidates pending plans, and disarms the core to `STOPPED` (latched fault preserved), requiring a new check and arm cycle. Sequence watermarks survive consumption, stop, fault, and disconnect.
71: 
72: ### Offline controller example
73: 
74: ```python
75: from joint_contract import IntentWindow, JointSpec, MotorHealth, OwnerToken, SourceIdentity, State, Target, WriteResult
76: from joint_controller import JointCore
77: from joint_mapping import JointMap, JointSample, JointTarget
78: 
79: clock_time = [0.0]
80: core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
81: assert core.begin_connect()
82: assert core.connected(SourceIdentity("fixture", "example", 1))
83: owner = core.claim_owner("example-client")
84: assert core.begin_check()
85: assert core.receive(0, JointSample(0, 0, 0), MotorHealth(0, 0, 0, False))
86: assert core.checked()
87: assert core.arm(owner)
88: window = core.issue_window(0.5)
89: target = Target(6, (JointTarget(.1, 1, -6, 18, 4.5),), window=window, owner=owner)
90: assert core.submit_target(target)
91: clock_time[0] += 0.05
92: plan = core.prepare_refresh()
93: assert plan is not None
94: assert core.claim_dispatch(plan.plan_id, 0)
95: assert core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
96: assert core.snapshot().state is State.MOVING
97: assert core.snapshot().dispatched_records[0].sequence == 6
98: assert core.stop()
99: assert core.snapshot().last_sequence == 6
100: ```
101: 
102: This example performs no serial operations. A station adapter must validate its own physical setup and own packet transmission when later milestones add one.
103: 
104: ## Core and ownership limits
105: 
106: The injected core clock must be finite and monotonic. Invalid or regressing time rejects operations that need a fresh gate; snapshots also require that clock contract. If a complete write receipt arrives after its end clock becomes invalid, the core preserves that known write and claim timestamp, then latches `CommunicationFailure.CLOCK_FAILURE` and withdraws motion until acknowledged recovery. The default clock is `time.monotonic`. Sequence `2**64 - 1` exhausts that core's stream. Start a new core for a new stream; reconnecting or acknowledging a fault never resets ordering.
107: 
108: ### Owner generations
109: 
110: `JointCore` generates a fresh unpredictable random 16-byte hex epoch per instance/process via `secrets.token_hex(16)` with no persisted global state. A monotonic generation counter starts at 1 and ranges through uint64. `claim_owner(connection_id)` returns a frozen `OwnerToken(epoch, generation, connection_id)`. `connection_id` is an immutable non-empty string bounded to 64 characters and identifies the client connection; `SourceIdentity` separately identifies the motor connection. The core assumes trusted station callers; the station/server binds its actual client connection identity rather than trusting unverified JSON payload attributes, with no authentication claims beyond that boundary.
111: 
112: `arm(owner)` and `Target` require an exact `OwnerToken` class and matching immutable epoch, generation, and connection ID fields. Token-bearing boundary records reject subclasses. An owner mismatch returns `DecisionCode.INVALID_OWNER` after lifecycle state checks. Stop, any latched joint fault, disconnect, expired goals, and explicit takeover revoke active authority (`current_owner` becomes `None`), withdraw pending goals/plans and offered windows, and never auto-rearm. A claim during checking, ready, armed, or moving state, or a takeover of an existing owner on a connected core, places the core in `STOPPED` (while preserving `FAULT` and `DISCONNECTED`), requiring a fresh stop check and explicit arm call with the new token. Reconnecting requires claiming a fresh generation. Fault recovery also requires a new claim before checking and arming.
113: 
114: Durable attempt and dispatched records retain the original `OwnerToken` stamped at plan creation; an in-flight receipt completing after authority revocation preserves the actual write record with its original owner attribution without transitioning the core to `MOVING`. `Snapshot.latest_owner` retains the most recently issued token after revocation, while `Snapshot.current_owner` is `None` unless that token currently has authority. Bounded O(1) storage retains only these two tokens. When the uint64 generation space is exhausted, a new claim revokes authority, stops the core (or preserves `FAULT`/`DISCONNECTED`), and raises `OverflowError` without wrapping; start a fresh core to obtain a new epoch.
115: 
116: The fixed per-user lock namespace under `/tmp` coordinates cooperating processes. A hostile local user can pre-create the name and deny access; validation fails closed. An administrator must remove a foreign-owned obstruction. Lockfiles persist to preserve flock inode identity, including after device-number reuse. Do not delete them while clients may be running. No automatic pruning or hostile-local-user availability guarantee is supplied.
117: 
118: ## Joint Position Limits
119: 
120: Every `JointSpec` requires explicit, immutable, finite position bounds `q_min_rad <= q_max_rad` and non-empty `limits_provenance` documenting the software threshold origin. These are fixture software limits, not physical calibration. Position requests are evaluated against inclusive bounds: exact lower and upper endpoints are accepted. Requests outside them return `DecisionCode.POSITION_OUT_OF_BOUNDS` and preserve any still-valid admitted goal, sequence watermark, owner, and window. Mapped requests must first pass the ordinary canonical codec; an unencodable mapped request returns `INVALID_ARGUMENT` and is never clamped into range. A fresh measured position outside the bounds, including during `CHECKING`, latches the attributed `JointFault.position_limit` cause and faults the core before motion. Simultaneous motor-health causes remain in the same joint fault record. `claim_dispatch` rechecks every fresh measured position and the actual prepared reference before each write. Recovery requires a new owner and an explicitly acknowledged fresh healthy Stop check with every measured position within the inclusive bounds; incoming targets cannot clear a fault. The codec owns the bounded raw position grid search through a monotonic decoded-domain callback and direction. It selects an inward representable endpoint, serializes that exact raw integer without float re-encoding, and decodes the complete canonical packet to populate actual position, velocity, feedforward, and gain reference fields. Stop packets are valid decoder inputs; mode, ID, watchdog, reserved byte, header, and CRC are checked. Repeated refreshes write the cached packet bytes unchanged.
121: 
122: ## Speed-bounded trajectory reference and gap policy
123: 
124: Every `JointSpec` requires an explicit, finite positive maximum reference speed `v_max_rad_s`. `JointCore` requires an explicit, finite positive `max_reference_gap_s` policy. Both values describe software fixture policy unless calibrated separately.
125: 
126: Upon a successful healthy checked Stop, the controller initializes an unemitted trajectory reference for each joint with position equal to the checked feedback sample, zero exact velocity derivative, and timestamp equal to the sample time (`is_emitted=False`). The anchor has no cached command and cannot dispatch at $h=0$.
127: 
128: Preparing a refresh plan does not advance confirmed history. A `RefreshPlan` always carries one proposed reference, decoded command target, and immutable canonical packet per joint. Only a complete actual write commits that joint's proposed reference. Failed or partial writes leave its prior reference unchanged. Reference `sample_time_s` is the preparation time; `JointDispatchedRecord.dispatched_at_s` remains the actual claim/write start time.
129: 
130: For $h=0$, a previously emitted reference can refresh only when the admitted joint goal is unchanged. The core reuses that reference, decoded target, and exact packet bytes, including its prior position-step derivative and feedforward values; it does not encode the values again or advance their sample time. A changed goal at $h=0$ is rejected with an attributed constraint fault. If $h > \text{max\_reference\_gap\_s}$, motion is withdrawn and the controller drops to `STOPPED` (`REFERENCE_GAP_EXCEEDED`).
131: 
132: For $h>0$, the pure reference step intersects the speed interval $[-V,V]$ and position interval $[(q_{\min}-q_{\text{prev}})/h,(q_{\max}-q_{\text{prev}})/h]$. It projects the one-step objective $v_{\text{desired}} = (q_{\text{goal}}-q_{\text{prev}})/h + \dot{q}_{\text{goal}}$ into that intersection. The objective combines the requested position correction over this sample with velocity feedforward; it is not a continuous trajectory law.
133: 
134: The selected endpoint is projected inward to a representable point on the canonical codec grid. Position-step velocity is the exact rational $(q_{\text{emitted,next}}-q_{\text{emitted,prev}})/h$, where the stored finite float values and computed float difference $h$ are interpreted exactly. The independently decoded wire velocity feedforward has its own history and must also satisfy $|v|\leq V$. Neither stream is substituted for the other, and wire velocity is not used in position algebra.
135: 
136: An exactly zero objective is a stationary reference request even when position and feedforward terms cancel. For a nonzero objective, if no representable position step satisfies the closed bounds, the controller produces no mode-1 write and Stops with `DecisionCode.CONSTRAINT_VIOLATION`, attributed to each joint whose shaping failed. It does not carry hidden fractional motion or relax a bound. These are samplewise software reference limits; they do not promise a continuous motor trajectory, physical acceleration, or certified braking.
