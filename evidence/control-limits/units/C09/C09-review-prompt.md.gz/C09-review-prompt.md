Read-only C09 additional review, immutable commit efb398f174e1f75e158590c0828dba8933b0891e. Review ONLY supplied source; no tools/shell/repository access/network/agents. Parent checks each finding. Complete sources below, final unitreview not finalC07-C16verification. Find concrete bugs/counterexamples in canonical rawposition projection, decoder encoder endpointimage, decodedactualreferences, required inclusive limits, attributedcauseunion, exactownercontract and late DISCONNECTED receipts. Preserveunknown in-flight claim until actual stationoutcome; never propose clearingunknown claim to unblock lifecycle. Required C10-C16 shaping/timing/station features remainfuture scope; no "missingfuturefeature" findings. No physical protectionclaim. Return JSON array of findings with id,severity,file,line,whatBreaks,repro,smallestFix; ordinary complete final, no toolrequest. If nofindings emptyarray.

FILE joint_contract.py
```
"""Frozen domain records and status types for joint control.

All records are immutable (frozen) data contracts with no transport or clock ownership.
"""

from dataclasses import dataclass
from enum import Enum
import math
from typing import Literal

from im6014_codec import decode_command
from joint_mapping import JointMap, JointSample, JointTarget


class State(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    CHECKING = "checking"
    READY = "ready"
    ARMED = "armed"
    MOVING = "moving"
    STOPPED = "stopped"
    FAULT = "fault"


class DecisionCode(str, Enum):
    ACCEPTED = "accepted"
    INVALID_STATE = "invalid_state"
    INVALID_ARGUMENT = "invalid_argument"
    INVALID_OWNER = "invalid_owner"
    INVALID_SOURCE = "invalid_source"
    UNKNOWN_JOINT = "unknown_joint"
    INVALID_OBSERVATION = "invalid_observation"
    FAULT_ACK_REQUIRED = "fault_ack_required"
    FAULT_LATCHED = "fault_latched"
    OBSERVATIONS_INCOMPLETE = "observations_incomplete"
    STALE_FEEDBACK = "stale_feedback"
    UNHEALTHY = "unhealthy"
    NOT_STOPPED = "not_stopped"
    DUPLICATE_OR_OLDER = "duplicate_or_older"
    EXPIRED = "expired"
    POSITION_OUT_OF_BOUNDS = "position_out_of_bounds"


class CommunicationFailure(str, Enum):
    TIMEOUT = "timeout"
    INVALID_FEEDBACK = "invalid_feedback"
    DRIVER_FAILURE = "driver_failure"
    CLOCK_FAILURE = "clock_failure"
    PREWRITE_DEADLINE = "prewrite_deadline"


class WriteResult(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    PREWRITE_DEADLINE = "prewrite_deadline"


@dataclass(frozen=True)
class Decision:
    accepted: bool
    code: DecisionCode

    def __post_init__(self) -> None:
        if type(self.accepted) is not bool:
            raise ValueError("accepted must be a bool")
        if not isinstance(self.code, DecisionCode):
            raise ValueError("code must be a DecisionCode")
        if self.accepted != (self.code is DecisionCode.ACCEPTED):
            raise ValueError("accepted must match the decision code")

    def __bool__(self) -> bool:
        return self.accepted


@dataclass(frozen=True)
class JointSpec:
    name: str
    motor_id: int
    mapping: JointMap
    q_min_rad: float
    q_max_rad: float
    limits_provenance: str

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if not isinstance(self.mapping, JointMap):
            raise ValueError("mapping must be a JointMap")

        if isinstance(self.q_min_rad, bool) or not isinstance(self.q_min_rad, (int, float)):
            raise ValueError("q_min_rad must be a finite real number")
        if isinstance(self.q_max_rad, bool) or not isinstance(self.q_max_rad, (int, float)):
            raise ValueError("q_max_rad must be a finite real number")
        try:
            min_val = float(self.q_min_rad)
            max_val = float(self.q_max_rad)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("position limits must be finite") from exc
        if not math.isfinite(min_val) or not math.isfinite(max_val):
            raise ValueError("position limits must be finite")
        if min_val > max_val:
            raise ValueError("q_min_rad must be less than or equal to q_max_rad")

        if (
            type(self.limits_provenance) is not str
            or not self.limits_provenance.strip()
            or len(self.limits_provenance) > 256
        ):
            raise ValueError("limits_provenance must be a bounded non-empty string")

        object.__setattr__(self, "q_min_rad", min_val)
        object.__setattr__(self, "q_max_rad", max_val)


@dataclass(frozen=True)
class JointFault:
    name: str
    motor_id: int
    errors: int = 0
    warnings: int = 0
    timeout: bool = False
    communication_error: CommunicationFailure | None = None
    stale: bool = False
    communication_errors: tuple[CommunicationFailure, ...] = ()
    position_limit: bool = False

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if type(self.stale) is not bool:
            raise ValueError("stale must be a bool")
        if type(self.communication_errors) is not tuple or any(
            not isinstance(c, CommunicationFailure) for c in self.communication_errors
        ):
            raise ValueError("communication_errors must be a tuple of CommunicationFailure")
        if type(self.position_limit) is not bool:
            raise ValueError("position_limit must be a bool")

        if len(self.communication_errors) != len(set(self.communication_errors)):
            raise ValueError("communication_errors must contain unique codes")
        if self.communication_error is not None and self.communication_errors and (
            self.communication_error not in self.communication_errors
        ):
            raise ValueError("communication_error must belong to communication_errors")

        if self.communication_error is not None and not self.communication_errors:
            object.__setattr__(self, "communication_errors", (self.communication_error,))
        elif self.communication_errors and self.communication_error is None:
            object.__setattr__(self, "communication_error", self.communication_errors[-1])


@dataclass(frozen=True)
class MotorHealth:
    mode: int
    errors: int
    warnings: int
    timeout: bool

    def __post_init__(self) -> None:
        if type(self.mode) is not int or self.mode not in (0, 1):
            raise ValueError("mode must be the integer 0 or 1")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")

    @property
    def healthy(self) -> bool:
        return self.errors == 0 and self.warnings == 0 and not self.timeout


@dataclass(frozen=True)
class SourceIdentity:
    backend: Literal["physical", "demo", "fixture"]
    identity: str
    connection: int

    def __post_init__(self) -> None:
        if type(self.backend) is not str or self.backend not in ("physical", "demo", "fixture"):
            raise ValueError("backend must be physical, demo, or fixture")
        if type(self.identity) is not str or not self.identity.strip():
            raise ValueError("identity must be a non-empty string")
        if type(self.connection) is not int or self.connection < 0:
            raise ValueError("connection must be a nonnegative integer")


@dataclass(frozen=True)
class JointStatus:
    sample: JointSample | None = None
    health: MotorHealth | None = None
    received_at: float | None = None
    communication_error: CommunicationFailure | None = None

    def __post_init__(self) -> None:
        if (self.sample is None) != (self.health is None):
            raise ValueError("sample and health must both be present or both be absent")
        if self.sample is not None and not isinstance(self.sample, JointSample):
            raise ValueError("sample must be a JointSample")
        if self.health is not None and not isinstance(self.health, MotorHealth):
            raise ValueError("health must be MotorHealth")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if self.valid and self.received_at is None:
            raise ValueError("a valid observation requires received_at")
        if self.received_at is not None:
            if isinstance(self.received_at, bool) or not isinstance(self.received_at, (int, float)):
                raise ValueError("received_at must be a finite real number or None")
            try:
                received_at = float(self.received_at)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("received_at must be finite") from exc
            if not math.isfinite(received_at):
                raise ValueError("received_at must be finite")
            if not self.valid:
                raise ValueError("received_at requires a valid observation")
            object.__setattr__(self, "received_at", received_at)

    @property
    def valid(self) -> bool:
        return self.sample is not None and self.health is not None

    @property
    def healthy(self) -> bool:
        return self.valid and self.health.healthy and self.communication_error is None

    @property
    def errors(self) -> int:
        return self.health.errors if self.health is not None else 0

    @property
    def warnings(self) -> int:
        return self.health.warnings if self.health is not None else 0

    @property
    def timeout(self) -> bool:
        return self.health.timeout if self.health is not None else False


@dataclass(frozen=True)
class OwnerToken:
    epoch: str
    generation: int
    connection_id: str

    def __post_init__(self) -> None:
        if type(self.epoch) is not str or not self.epoch.strip() or len(self.epoch) > 64:
            raise ValueError("epoch must be a bounded non-empty string")
        if type(self.generation) is not int or not (1 <= self.generation <= (1 << 64) - 1):
            raise ValueError("generation must be an integer from 1 to 2**64 - 1")
        if type(self.connection_id) is not str or not self.connection_id.strip() or len(self.connection_id) > 64:
            raise ValueError("connection_id must be a bounded non-empty string")


def owner_tokens_match(candidate: object, current: object) -> bool:
    return (
        type(candidate) is OwnerToken
        and type(current) is OwnerToken
        and candidate.epoch == current.epoch
        and candidate.generation == current.generation
        and candidate.connection_id == current.connection_id
    )


@dataclass(frozen=True)
class IntentWindow:
    id: int
    created_at_s: float
    expires_at_s: float

    def __post_init__(self) -> None:
        if type(self.id) is not int or not (0 <= self.id <= (1 << 64) - 1):
            raise ValueError("window ID must be an integer from 0 to 2**64 - 1")
        if isinstance(self.created_at_s, bool) or not isinstance(self.created_at_s, (int, float)):
            raise ValueError("created_at_s must be a finite real number")
        if isinstance(self.expires_at_s, bool) or not isinstance(self.expires_at_s, (int, float)):
            raise ValueError("expires_at_s must be a finite real number")
        try:
            created = float(self.created_at_s)
            expires = float(self.expires_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("window timestamps must be finite") from exc
        if not math.isfinite(created) or not math.isfinite(expires):
            raise ValueError("window timestamps must be finite")
        if expires <= created:
            raise ValueError("expires_at_s must be strictly greater than created_at_s")
        object.__setattr__(self, "created_at_s", created)
        object.__setattr__(self, "expires_at_s", expires)


@dataclass(frozen=True)
class Target:
    sequence: int
    joints: tuple[JointTarget, ...]
    window: IntentWindow
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if type(self.joints) is not tuple:
            raise ValueError("joints must be a tuple of JointTarget")
        if not self.joints:
            raise ValueError("joints must be a non-empty tuple")
        if any(not isinstance(joint, JointTarget) for joint in self.joints):
            raise ValueError("every joint target must be a JointTarget")
        if not isinstance(self.window, IntentWindow):
            raise ValueError("window must be an IntentWindow")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")


@dataclass(frozen=True)
class RefreshPlan:
    plan_id: int
    target: Target
    prepared_at_s: float
    joint_targets: tuple[JointTarget, ...]
    packets: tuple[bytes, ...]

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, Target):
            raise ValueError("target must be a Target")
        if isinstance(self.prepared_at_s, bool) or not isinstance(self.prepared_at_s, (int, float)):
            raise ValueError("prepared_at_s must be a finite real number")
        try:
            prepared = float(self.prepared_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("prepared_at_s must be finite") from exc
        if not math.isfinite(prepared):
            raise ValueError("prepared_at_s must be finite")
        object.__setattr__(self, "prepared_at_s", prepared)
        if type(self.joint_targets) is not tuple or not self.joint_targets:
            raise ValueError("joint_targets must be a non-empty tuple")
        if any(not isinstance(jt, JointTarget) for jt in self.joint_targets):
            raise ValueError("every joint target must be a JointTarget")
        if type(self.packets) is not tuple or len(self.packets) != len(self.joint_targets):
            raise ValueError("packets must be a tuple matching joint_targets")
        for packet in self.packets:
            if type(packet) is not bytes:
                raise ValueError("packets must contain immutable bytes")
            try:
                decoded = decode_command(packet)
            except ValueError as exc:
                raise ValueError("packets must contain canonical commands") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("refresh packets must be watchdog-enabled FOC commands")

    @property
    def window(self) -> IntentWindow:
        return self.target.window

    @property
    def owner(self) -> OwnerToken:
        return self.target.owner


@dataclass(frozen=True)
class JointDispatchedRecord:
    sequence: int
    target: JointTarget
    dispatched_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.dispatched_at_s, bool) or not isinstance(self.dispatched_at_s, (int, float)):
            raise ValueError("dispatched_at_s must be a finite real number")
        try:
            dispatched = float(self.dispatched_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("dispatched_at_s must be finite") from exc
        if not math.isfinite(dispatched):
            raise ValueError("dispatched_at_s must be finite")
        object.__setattr__(self, "dispatched_at_s", dispatched)


@dataclass(frozen=True)
class JointDispatchAttempt:
    plan_id: int
    sequence: int
    target: JointTarget
    result: WriteResult
    started_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if not isinstance(self.result, WriteResult):
            raise ValueError("result must be a WriteResult")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.started_at_s, bool) or not isinstance(self.started_at_s, (int, float)):
            raise ValueError("started_at_s must be a finite real number")
        try:
            started = float(self.started_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("started_at_s must be finite") from exc
        if not math.isfinite(started):
            raise ValueError("started_at_s must be finite")
        object.__setattr__(self, "started_at_s", started)


@dataclass(frozen=True)
class Snapshot:
    state: State
    joint_names: tuple[str, ...]
    joints: tuple[JointStatus, ...]
    source: SourceIdentity | None
    fault_latched: bool
    feedback_ages_s: tuple[float | None, ...]
    faults: tuple[JointFault, ...] = ()
    admitted_target: Target | None = None
    prepared_plan: RefreshPlan | None = None
    dispatched_records: tuple[JointDispatchedRecord | None, ...] = ()
    last_sequence: int = -1
    dispatch_attempts: tuple[JointDispatchAttempt | None, ...] = ()
    latest_owner: OwnerToken | None = None
    current_owner: OwnerToken | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.state, State):
            raise ValueError("state must be a State")
        if type(self.joint_names) is not tuple or any(type(name) is not str for name in self.joint_names):
            raise ValueError("joint_names must be a tuple of strings")
        if type(self.joints) is not tuple or any(not isinstance(joint, JointStatus) for joint in self.joints):
            raise ValueError("joints must be a tuple of JointStatus")
        if type(self.feedback_ages_s) is not tuple:
            raise ValueError("feedback_ages_s must be a tuple")
        if len(self.joint_names) != len(self.joints):
            raise ValueError("joint names and statuses must have equal lengths")
        if len(self.feedback_ages_s) != len(self.joints):
            raise ValueError("feedback ages and joint statuses must have equal lengths")
        normalized_ages: list[float | None] = []
        for joint, age in zip(self.joints, self.feedback_ages_s):
            if joint.received_at is None:
                if age is not None:
                    raise ValueError("feedback age must be None before a joint is received")
                normalized_ages.append(None)
                continue
            if isinstance(age, bool) or not isinstance(age, (int, float)):
                raise ValueError("feedback age must be a finite nonnegative number")
            try:
                age_value = float(age)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("feedback age must be finite") from exc
            if not math.isfinite(age_value) or age_value < 0.0:
                raise ValueError("feedback age must be finite and nonnegative")
            normalized_ages.append(age_value)
        object.__setattr__(self, "feedback_ages_s", tuple(normalized_ages))
        if self.source is not None and not isinstance(self.source, SourceIdentity):
            raise ValueError("source must be a SourceIdentity or None")
        if type(self.fault_latched) is not bool:
            raise ValueError("fault_latched must be a bool")
        if type(self.faults) is not tuple or any(not isinstance(f, JointFault) for f in self.faults):
            raise ValueError("faults must be a tuple of JointFault")
        if self.admitted_target is not None and not isinstance(self.admitted_target, Target):
            raise ValueError("admitted_target must be a Target or None")
        if self.prepared_plan is not None and not isinstance(self.prepared_plan, RefreshPlan):
            raise ValueError("prepared_plan must be a RefreshPlan or None")
        if not self.dispatched_records:
            object.__setattr__(self, "dispatched_records", tuple(None for _ in self.joints))
        else:
            if type(self.dispatched_records) is not tuple or len(self.dispatched_records) != len(self.joints):
                raise ValueError("dispatched_records must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchedRecord) for r in self.dispatched_records):
                raise ValueError("every dispatched record must be a JointDispatchedRecord or None")
        if not self.dispatch_attempts:
            object.__setattr__(self, "dispatch_attempts", tuple(None for _ in self.joints))
        else:
            if type(self.dispatch_attempts) is not tuple or len(self.dispatch_attempts) != len(self.joints):
                raise ValueError("dispatch_attempts must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchAttempt) for r in self.dispatch_attempts):
                raise ValueError("every dispatch attempt must be a JointDispatchAttempt or None")
        if type(self.last_sequence) is not int or not (-1 <= self.last_sequence <= (1 << 64) - 1):
            raise ValueError("last_sequence must be an integer from -1 to 2**64 - 1")
        if self.latest_owner is not None and type(self.latest_owner) is not OwnerToken:
            raise ValueError("latest_owner must be an OwnerToken or None")
        if self.current_owner is not None and type(self.current_owner) is not OwnerToken:
            raise ValueError("current_owner must be an OwnerToken or None")

    @property
    def affected_joints(self) -> tuple[str, ...]:
        return tuple(fault.name for fault in self.faults)

```

FILE joint_mapping.py
```
from dataclasses import dataclass
import math


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a real int or float")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def _result(value, name, nonzero_inputs=None):
    if not math.isfinite(value):
        raise ValueError(f"{name} result must be finite")
    if nonzero_inputs and value == 0.0 and all(item != 0.0 for item in nonzero_inputs):
        raise ValueError(f"{name} result underflowed")
    return value


def _multiply(name, *values):
    result = 1.0
    for index, value in enumerate(values):
        result *= value
        _result(result, name, values[:index + 1])
    return result


def _divide(numerator, denominator, name):
    try:
        result = numerator / denominator
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError(f"{name} result is not representable") from exc
    return _result(result, name, (numerator,))


def _add(left, right, name):
    return _result(left + right, name)


def _subtract(left, right, name):
    return _result(left - right, name)


@dataclass(frozen=True)
class JointMap:
    reduction: float
    direction: int
    zero_output_rad: float

    def __post_init__(self):
        reduction = _finite(self.reduction, "reduction")
        if reduction <= 0.0:
            raise ValueError("reduction must be positive")
        if type(self.direction) is not int or self.direction not in (-1, 1):
            raise ValueError("direction must be the integer -1 or 1")
        object.__setattr__(self, "reduction", reduction)
        object.__setattr__(self, "zero_output_rad", _finite(self.zero_output_rad, "zero_output_rad"))

    def to_output(self, target: "JointTarget") -> "OutputTarget":
        if not isinstance(target, JointTarget):
            raise ValueError("target must be a JointTarget")

        signed_reduction = _multiply("signed reduction", float(self.direction), self.reduction)
        q_rad = _add(
            self.zero_output_rad,
            _multiply("output position", signed_reduction, target.q_rad),
            "output position",
        )
        output_rad_s = _multiply("output velocity", signed_reduction, target.dq_rad_s)
        rpm = _divide(_multiply("output speed", output_rad_s, 60.0), math.tau, "output speed")
        tau_nm = _divide(
            _multiply("output torque", float(self.direction), target.tau_nm),
            self.reduction,
            "output torque",
        )
        kp = _divide(_divide(target.kp, self.reduction, "output kp"), self.reduction, "output kp")
        kd = _divide(_divide(target.kd, self.reduction, "output kd"), self.reduction, "output kd")
        return OutputTarget(q_rad=q_rad, rpm=rpm, tau_nm=tau_nm, kp=kp, kd=kd)

    def from_output(self, sample: "OutputSample") -> "JointSample":
        if not isinstance(sample, OutputSample):
            raise ValueError("sample must be an OutputSample")

        q_delta = _subtract(sample.q_rad, self.zero_output_rad, "joint position")
        q_rad = _divide(
            _multiply("joint position", float(self.direction), q_delta),
            self.reduction,
            "joint position",
        )
        output_rad_s = _divide(
            _multiply("joint velocity", sample.rpm, math.tau),
            60.0,
            "joint velocity",
        )
        dq_rad_s = _divide(
            _multiply("joint velocity", float(self.direction), output_rad_s),
            self.reduction,
            "joint velocity",
        )
        tau_nm = _multiply("joint torque", float(self.direction), self.reduction, sample.tau_nm)
        return JointSample(q_rad=q_rad, dq_rad_s=dq_rad_s, tau_nm=tau_nm)


@dataclass(frozen=True)
class JointTarget:
    q_rad: float
    dq_rad_s: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputTarget:
    q_rad: float
    rpm: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputSample:
    q_rad: float
    rpm: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))


@dataclass(frozen=True)
class JointSample:
    q_rad: float
    dq_rad_s: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))

```

FILE im6014_codec.py
```
import math
import struct
from collections.abc import Callable

RATIO = 38 / 3
RPM_MIN = -32768 / 64 / RATIO * 60
RPM_MAX = 32767 / 64 / RATIO * 60
POSITION_MIN = -2147483648 / 32768 / RATIO * math.tau
POSITION_MAX = 2147483647 / 32768 / RATIO * math.tau
RAW_POSITION_MIN = -2147483648
RAW_POSITION_MAX = 2147483647


def raw_to_position(raw_position):
    if type(raw_position) is not int or not RAW_POSITION_MIN <= raw_position <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return raw_position / 32768 / RATIO * math.tau


def position_to_raw(position):
    position = _finite_control(position, 'Position')
    return _signed_raw(position / math.tau * RATIO * 32768,
                       RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')


def _motor_id(value, name='Individual ID'):
    if type(value) is not int or not 0 <= value <= 14:
        raise ValueError(f'{name} must be an integer from 0 to 14')
    return value


def _finite_control(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f'{name} must be a finite int or float')
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError(f'{name} must be finite') from error
    if not math.isfinite(result):
        raise ValueError(f'{name} must be finite')
    return result


def _signed_raw(value, minimum, maximum, name):
    raw = round(value)
    if not minimum <= raw <= maximum:
        raise ValueError(f'{name} cannot be represented by the motor protocol')
    return raw


def _torque_raw(value):
    return _signed_raw(value / RATIO * 2560, -32768, 32767, 'Feedforward torque')


def _kp_raw(value):
    return _signed_raw(value / RATIO ** 2 * 12800, -32768, 32767, 'Kp')


def _kd_raw(value):
    return _signed_raw(value / RATIO ** 2 * 51200, -32768, 32767, 'Kd')


def _raw_position(value):
    if type(value) is not int or not RAW_POSITION_MIN <= value <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return value


def crc32(data):
    if len(data) % 4:
        raise ValueError('CRC input must contain complete four-byte words')
    crc = 0xFFFFFFFF
    for start in range(0, len(data), 4):
        for byte in data[start:start + 4][::-1]:
            crc ^= byte << 24
            for _ in range(8):
                crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    return crc


def command(motor_id, mode=0, rpm=0, kd=0, torque=0, watchdog=True, position=0, kp=0):
    position = _finite_control(position, 'Position')
    if not POSITION_MIN <= position <= POSITION_MAX:
        raise ValueError('Position cannot be encoded in the motor protocol')
    if mode == 0 and position != 0.0:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    position_raw = _signed_raw(position / math.tau * RATIO * 32768,
                               RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')
    return command_with_raw_position(
        motor_id,
        position_raw,
        mode=mode,
        rpm=rpm,
        kd=kd,
        torque=torque,
        watchdog=watchdog,
        kp=kp,
    )


def command_with_raw_position(
    motor_id, raw_position, mode=0, rpm=0, kd=0, torque=0, watchdog=True, kp=0
):
    """Encode a command while preserving an already selected position grid code."""
    motor_id = _motor_id(motor_id)
    raw_position = _raw_position(raw_position)
    if type(mode) is not int or mode not in (0, 1):
        raise ValueError('Individual ID 0–14 and Stop/FOC modes only')
    if type(watchdog) is not bool:
        raise ValueError('Watchdog must be a bool')
    rpm, kd, torque, kp = (
        _finite_control(value, name) for value, name in
        ((rpm, 'Speed'), (kd, 'Kd'), (torque, 'Feedforward torque'),
         (kp, 'Kp'))
    )
    if not RPM_MIN <= rpm <= RPM_MAX:
        raise ValueError('Speed cannot be encoded in the motor protocol; this is not a rated-speed limit')
    if not 0 <= kd <= 6 or not 0 <= kp <= 30 or not -3.5 <= torque <= 3.5:
        raise ValueError('Bench limits: Kd 0–6, Kp 0–30, feedforward torque ±3.5 Nm')
    torque_raw = _torque_raw(torque)
    rpm_raw = _signed_raw(rpm / 60 * RATIO * 64, -32768, 32767, 'Speed')
    kp_raw = _kp_raw(kp)
    kd_raw = _kd_raw(kd)
    if mode == 0 and (rpm or kd or torque or raw_position or kp) or mode == 1 and not watchdog:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    raw = b'\xfe\xee' + bytes([motor_id | mode << 4 | int(watchdog) << 7, 0])
    raw += struct.pack('<hhihh', torque_raw, rpm_raw, raw_position, kp_raw, kd_raw)
    return raw + struct.pack('<I', crc32(raw))


def project_position_raw(
    wanted_q,
    q_min,
    q_max,
    map_decoded_position: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw position whose mapped decoded value is in bounds.

    ``map_decoded_position`` maps decoded actuator radians to the caller's
    position domain. ``direction`` declares whether that mapping increases or
    decreases as the raw position code increases. Bounds are closed.
    """
    wanted_q = _finite_control(wanted_q, 'Wanted position')
    q_min = _finite_control(q_min, 'Minimum position')
    q_max = _finite_control(q_max, 'Maximum position')
    if q_min > q_max:
        raise ValueError('Minimum position must not exceed maximum position')
    if not callable(map_decoded_position):
        raise ValueError('Position mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Position mapping direction must be -1 or 1')

    ordered_min = direction * (q_min if direction == 1 else q_max)
    ordered_max = direction * (q_max if direction == 1 else q_min)
    ordered_wanted = direction * wanted_q

    def mapped(raw_position):
        decoded = raw_to_position(raw_position)
        try:
            result = map_decoded_position(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Position mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped position')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_POSITION_MIN
        right = RAW_POSITION_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_POSITION_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def feedback(raw, motor_id):
    motor_id = _motor_id(motor_id, 'Expected motor ID')
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Feedback frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Feedback frame must be a bytes-like buffer') from error
    if len(raw) != 26 or raw[:2] != b'\xfc\xee':
        raise RuntimeError('Invalid feedback length/header')
    if struct.unpack('<I', raw[22:])[0] != crc32(raw[2:22]):
        raise RuntimeError('Feedback CRC mismatch')
    m, td, tw, v, tq, sp, pos, err, flags, _, _ = struct.unpack('<BbBBhhiIHBB', raw[2:22])
    if m & 15 != motor_id or (m >> 4) & 7 not in (0, 1):
        raise RuntimeError('Feedback ID/mode mismatch')
    return dict(id=m & 15, mode=(m >> 4) & 7, timeout=m >> 7,
                driver_c=td, winding_c=tw, voltage=v / 2,
                torque_nm=tq / 2560 * RATIO, rpm=sp / 64 / RATIO * 60,
                position_rad=pos / 32768 / RATIO * math.tau,
                errors=err, warnings=(flags >> 13) & 7, raw=raw.hex())


def decode_command(raw):
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Command frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Command frame must be a bytes-like buffer') from error
    if len(raw) != 20 or raw[:2] != b'\xfe\xee':
        raise ValueError('Invalid command length/header')
    if struct.unpack('<I', raw[16:])[0] != crc32(raw[:16]):
        raise ValueError('Command CRC mismatch')
    m = raw[2]
    motor_id = m & 0x0F
    mode = (m >> 4) & 0x07
    watchdog = bool(m & 0x80)
    if motor_id > 14 or mode not in (0, 1) or raw[3] != 0:
        raise ValueError('Invalid command ID, mode, or reserved byte')
    if mode == 1 and not watchdog:
        raise ValueError('FOC command requires watchdog')
    tq, sp, pos, kp, kd = struct.unpack('<hhihh', raw[4:16])
    if mode == 0 and (tq or sp or pos or kp or kd):
        raise ValueError('Stop command must have zero targets')
    decoded = dict(
        motor_id=motor_id,
        mode=mode,
        watchdog=watchdog,
        raw_torque=tq,
        raw_rpm=sp,
        raw_position=pos,
        raw_kp=kp,
        raw_kd=kd,
        torque_nm=tq / 2560 * RATIO,
        rpm=sp / 64 / RATIO * 60,
        position_rad=pos / 32768 / RATIO * math.tau,
        kp=kp * (RATIO ** 2) / 12800,
        kd=kd * (RATIO ** 2) / 51200,
        raw=raw.hex(),
    )
    if not _torque_raw(-3.5) <= tq <= _torque_raw(3.5):
        raise ValueError('Feedforward torque is outside the canonical command range')
    if not 0 <= kp <= _kp_raw(30.0) or not 0 <= kd <= _kd_raw(6.0):
        raise ValueError('Gain is outside the canonical command range')
    return decoded

```

FILE joint_reference.py
```
"""Pure joint reference validation and canonical packet preparation."""

from im6014_codec import command, command_with_raw_position, decode_command, project_position_raw
from joint_contract import DecisionCode, JointSpec, Target
from joint_mapping import JointTarget, OutputSample

__all__ = ("prepare_reference_joint", "prepare_complete_reference")


def prepare_reference_joint(
    spec: JointSpec, target: JointTarget
) -> tuple[DecisionCode | None, JointTarget | None, bytes | None]:
    """Validate a request and bind its actual decoded command to canonical bytes."""
    if not isinstance(spec, JointSpec) or not isinstance(target, JointTarget):
        return DecisionCode.INVALID_ARGUMENT, None, None
    if target.q_rad < spec.q_min_rad or target.q_rad > spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None

    try:
        output = spec.mapping.to_output(target)
        # Validate the original mapped request through the ordinary codec before
        # projecting its position onto an inward representable grid point.
        command(
            spec.motor_id,
            mode=1,
            rpm=output.rpm,
            kd=output.kd,
            torque=output.tau_nm,
            watchdog=True,
            position=output.q_rad,
            kp=output.kp,
        )
        raw_position = project_position_raw(
            target.q_rad,
            spec.q_min_rad,
            spec.q_max_rad,
            lambda output_q: spec.mapping.from_output(
                OutputSample(output_q, 0.0, 0.0)
            ).q_rad,
            spec.mapping.direction,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.INVALID_ARGUMENT, None, None
    if raw_position is None:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None

    try:
        packet = command_with_raw_position(
            spec.motor_id,
            raw_position,
            mode=1,
            rpm=output.rpm,
            kd=output.kd,
            torque=output.tau_nm,
            watchdog=True,
            kp=output.kp,
        )
        decoded = decode_command(packet)
        actual_output = spec.mapping.from_output(
            OutputSample(
                decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
            )
        )
        gain_scale = spec.mapping.reduction ** 2
        actual_target = JointTarget(
            q_rad=actual_output.q_rad,
            dq_rad_s=actual_output.dq_rad_s,
            tau_nm=actual_output.tau_nm,
            kp=decoded["kp"] * gain_scale,
            kd=decoded["kd"] * gain_scale,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.INVALID_ARGUMENT, None, None

    if not spec.q_min_rad <= actual_target.q_rad <= spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
    return None, actual_target, packet


def prepare_complete_reference(
    specs: tuple[JointSpec, ...], target: Target
) -> tuple[DecisionCode | None, tuple[JointTarget, ...] | None, tuple[bytes, ...] | None]:
    """Validate and prepare references and canonical packets for all joints atomically."""
    if not isinstance(target, Target) or len(target.joints) != len(specs):
        return DecisionCode.INVALID_ARGUMENT, None, None

    actual_targets: list[JointTarget] = []
    packets: list[bytes] = []

    for spec, joint_target in zip(specs, target.joints):
        code, actual_target, packet = prepare_reference_joint(spec, joint_target)
        if code is not None or actual_target is None or packet is None:
            return code or DecisionCode.INVALID_ARGUMENT, None, None
        actual_targets.append(actual_target)
        packets.append(packet)

    return None, tuple(actual_targets), tuple(packets)

```

FILE joint_controller.py
```
"""Transport-free lifecycle and health state for an ordered joint set.

All methods on a JointCore belong to one calling thread. The core owns no
transport and all externally visible records are immutable snapshots.
"""

from collections.abc import Iterable
from dataclasses import dataclass
import math
import secrets
import time

from joint_contract import (
    CommunicationFailure,
    Decision,
    DecisionCode,
    IntentWindow,
    JointDispatchAttempt,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
    owner_tokens_match,
)
from joint_mapping import JointSample
from joint_reference import prepare_complete_reference, prepare_reference_joint

__all__ = ("JointCore",)


@dataclass(frozen=True)
class _DispatchClaim:
    plan: RefreshPlan
    index: int
    started_at_s: float


class JointCore:
    """Thread-confined state machine for one fixed, ordered set of joints.

    The core public API assumes trusted station callers; C16 server binds its
    actual connection identity rather than trusting client-supplied JSON fields.
    No authentication claims are made beyond that boundary.
    """

    def __init__(
        self,
        joints: Iterable[JointSpec],
        *,
        feedback_max_age_s: float = 0.5,
        max_window_s: float = 1.0,
        clock=None,
    ):
        if isinstance(feedback_max_age_s, bool) or not isinstance(feedback_max_age_s, (int, float)):
            raise ValueError("feedback_max_age_s must be a finite positive real number")
        try:
            feedback_max_age_s = float(feedback_max_age_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("feedback_max_age_s must be finite") from exc
        if not math.isfinite(feedback_max_age_s) or feedback_max_age_s <= 0.0:
            raise ValueError("feedback_max_age_s must be finite and positive")

        if isinstance(max_window_s, bool) or not isinstance(max_window_s, (int, float)):
            raise ValueError("max_window_s must be a finite positive real number")
        try:
            max_window_s = float(max_window_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_window_s must be finite") from exc
        if not math.isfinite(max_window_s) or max_window_s <= 0.0:
            raise ValueError("max_window_s must be finite and positive")

        if clock is None:
            clock = time.monotonic
        if not callable(clock):
            raise ValueError("clock must be callable")

        self._epoch = secrets.token_hex(16)

        try:
            specs = tuple(joints)
        except TypeError as exc:
            raise ValueError("joints must be an iterable of JointSpec") from exc
        if not specs:
            raise ValueError("at least one active joint is required")
        if any(not isinstance(spec, JointSpec) for spec in specs):
            raise ValueError("every joint must be a JointSpec")
        if len({spec.name for spec in specs}) != len(specs):
            raise ValueError("joint names must be unique")
        if len({spec.motor_id for spec in specs}) != len(specs):
            raise ValueError("motor IDs must be unique")

        self._specs: tuple[JointSpec, ...] = specs
        self._id_to_index: dict[int, int] = {
            spec.motor_id: index for index, spec in enumerate(specs)
        }
        self._state: State = State.DISCONNECTED
        self._observations: list[JointStatus] = [JointStatus() for _ in specs]
        self._source: SourceIdentity | None = None
        self._feedback_max_age_s = feedback_max_age_s
        self._max_window_s = max_window_s
        self._clock = clock
        self._now_high_water_s: float | None = None
        self._next_window_id: int = 0
        self._offered_window: IntentWindow | None = None
        self._next_generation: int = 1
        self._latest_owner: OwnerToken | None = None
        self._current_owner: OwnerToken | None = None
        self._admitted_target: Target | None = None
        self._prepared_plan: RefreshPlan | None = None
        self._next_plan_id: int = 0
        self._next_dispatch_index: int = 0
        self._dispatch_claim: _DispatchClaim | None = None
        self._dispatched_records: list[JointDispatchedRecord | None] = [None for _ in specs]
        self._dispatch_attempts: list[JointDispatchAttempt | None] = [None for _ in specs]
        self._faults: dict[str, JointFault] = {}
        self._last_sequence: int = -1

    @property
    def joint_specs(self) -> tuple[JointSpec, ...]:
        return self._specs

    @property
    def admitted_target(self) -> Target | None:
        return self._admitted_target

    @staticmethod
    def _accepted() -> Decision:
        return Decision(True, DecisionCode.ACCEPTED)

    @staticmethod
    def _rejected(code: DecisionCode) -> Decision:
        return Decision(False, code)

    def _clear_observations(self) -> None:
        self._observations = [JointStatus() for _ in self._specs]

    def _invalidate_plan(self) -> None:
        self._prepared_plan = None
        self._next_dispatch_index = 0

    def _revoke_authority(self) -> None:
        self._current_owner = None
        self._offered_window = None
        self._admitted_target = None
        self._invalidate_plan()

    def claim_owner(self, connection_id: str) -> OwnerToken:
        """Issue and claim owner authority for a trusted station caller.

        The core public API assumes trusted station callers; C16 server binds its
        actual connection identity rather than trusting client-supplied JSON fields.
        No authentication claims are made beyond that boundary.
        """
        if (
            type(connection_id) is not str
            or not connection_id.strip()
            or len(connection_id) > 64
        ):
            raise ValueError("connection_id must be a bounded non-empty string")
        was_owned = self._current_owner is not None
        stop_for_claim = self._state in (
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
        ) or (was_owned and self._state not in (State.DISCONNECTED, State.CONNECTING))
        self._revoke_authority()
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            pass
        elif self._state is State.FAULT or self._faults:
            self._state = State.FAULT
        elif stop_for_claim:
            self._state = State.STOPPED

        if self._next_generation > (1 << 64) - 1:
            raise OverflowError("owner generation sequence exhausted")

        generation = self._next_generation
        self._next_generation += 1
        token = OwnerToken(
            epoch=self._epoch,
            generation=generation,
            connection_id=connection_id,
        )
        self._current_owner = token
        self._latest_owner = token
        return token

    def _record_dispatch_failure(
        self, index: int, cause: CommunicationFailure
    ) -> None:
        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            spec.motor_id,
            communication_error=cause,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample,
            joint.health,
            joint.received_at,
            cause,
        )

    def _latch_joint_fault(
        self,
        name: str,
        motor_id: int,
        *,
        errors: int = 0,
        warnings: int = 0,
        timeout: bool = False,
        communication_error: CommunicationFailure | None = None,
        stale: bool = False,
        position_limit: bool = False,
    ) -> None:
        existing = self._faults.get(name) or JointFault(name, motor_id)
        communication_errors = existing.communication_errors
        if communication_error is not None and communication_error not in communication_errors:
            communication_errors += (communication_error,)
        fault = JointFault(
            name, motor_id,
            errors=existing.errors | errors,
            warnings=existing.warnings | warnings,
            timeout=existing.timeout or timeout,
            stale=existing.stale or stale,
            communication_error=communication_error or existing.communication_error,
            communication_errors=communication_errors,
            position_limit=existing.position_limit or position_limit,
        )
        self._faults[name] = fault
        if self._state is not State.DISCONNECTED:
            self._state = State.FAULT
        self._revoke_authority()

    def _withdraw_expired_goal(self) -> None:
        self._revoke_authority()
        if self._faults:
            self._state = State.FAULT
        elif self._state in (State.ARMED, State.MOVING):
            self._state = State.STOPPED

    def _now(self) -> float:
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("clock must return a finite real number")
        try:
            result = float(value)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("clock must return a finite real number") from exc
        if not math.isfinite(result):
            raise ValueError("clock must return a finite real number")
        if self._now_high_water_s is not None and result < self._now_high_water_s:
            raise ValueError(
                f"clock regressed from {self._now_high_water_s} to {result}"
            )
        self._now_high_water_s = result
        return result

    @staticmethod
    def _age(received_at: float, now: float) -> float:
        age = now - received_at
        if not math.isfinite(age) or age < 0.0:
            raise ValueError("clock must be monotonic and feedback age finite")
        return age

    def _all_fresh(self, now: float) -> bool:
        return all(
            joint.valid
            and joint.received_at is not None
            and self._age(joint.received_at, now) <= self._feedback_max_age_s
            for joint in self._observations
        )

    def _housekeeping(self, now: float) -> DecisionCode | None:
        if self._state in (State.READY, State.ARMED, State.MOVING):
            stale_by_joint: list[bool] = []
            outside_by_joint: list[bool] = []
            for spec, joint in zip(self._specs, self._observations):
                stale_by_joint.append(
                    not joint.valid
                    or joint.received_at is None
                    or self._age(joint.received_at, now) > self._feedback_max_age_s
                )
                outside_by_joint.append(
                    joint.valid
                    and joint.sample is not None
                    and (joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad)
                )
            for spec, stale, outside in zip(self._specs, stale_by_joint, outside_by_joint):
                if stale or outside:
                    self._latch_joint_fault(
                        spec.name,
                        spec.motor_id,
                        stale=stale,
                        position_limit=outside,
                    )
            if any(stale_by_joint):
                return DecisionCode.STALE_FEEDBACK
            if any(outside_by_joint):
                return DecisionCode.POSITION_OUT_OF_BOUNDS
        if (
            self._admitted_target is not None
            and now >= self._admitted_target.window.expires_at_s
        ):
            self._withdraw_expired_goal()
            return DecisionCode.EXPIRED
        return None

    def issue_window(self, valid_for_s: float) -> IntentWindow:
        if isinstance(valid_for_s, bool) or not isinstance(valid_for_s, (int, float)):
            raise ValueError("valid_for_s must be a finite positive real number")
        try:
            valid_for_s = float(valid_for_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("valid_for_s must be finite") from exc
        if not math.isfinite(valid_for_s) or valid_for_s <= 0.0:
            raise ValueError("valid_for_s must be finite and positive")
        if valid_for_s > self._max_window_s:
            raise ValueError(
                f"valid_for_s ({valid_for_s}) exceeds configured maximum window ({self._max_window_s})"
            )
        now = self._now()
        window_id = self._next_window_id
        if window_id > (1 << 64) - 1:
            raise OverflowError("window ID sequence exhausted")
        self._next_window_id += 1
        window = IntentWindow(
            id=window_id,
            created_at_s=now,
            expires_at_s=now + valid_for_s,
        )
        self._offered_window = window
        return window

    def begin_connect(self) -> Decision:
        if self._state is not State.DISCONNECTED or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        self._state = State.CONNECTING
        return self._accepted()

    def connected(self, source: SourceIdentity) -> Decision:
        if self._state is not State.CONNECTING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not isinstance(source, SourceIdentity):
            return self._rejected(DecisionCode.INVALID_SOURCE)
        self._clear_observations()
        self._source = source
        self._state = State.CONNECTED
        return self._accepted()

    def begin_check(self, *, acknowledge_fault: bool = False) -> Decision:
        if type(acknowledge_fault) is not bool:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._state not in (State.CONNECTED, State.STOPPED, State.FAULT) or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        if bool(self._faults) and not acknowledge_fault:
            return self._rejected(DecisionCode.FAULT_ACK_REQUIRED)
        self._clear_observations()
        self._admitted_target = None
        self._invalidate_plan()
        self._state = State.CHECKING
        return self._accepted()

    def receive(
        self, motor_id: int, sample: JointSample, status: MotorHealth
    ) -> Decision:
        if self._state not in (
            State.CONNECTED,
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
            State.STOPPED,
            State.FAULT,
        ):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)
        if not isinstance(sample, JointSample) or not isinstance(status, MotorHealth):
            return self._rejected(DecisionCode.INVALID_OBSERVATION)

        now = self._now()
        self._observations[index] = JointStatus(sample, status, now)
        spec = self._specs[index]
        position_limit = (
            sample.q_rad < spec.q_min_rad or sample.q_rad > spec.q_max_rad
        )
        if not status.healthy or position_limit:
            self._latch_joint_fault(
                spec.name,
                motor_id,
                errors=status.errors,
                warnings=status.warnings,
                timeout=status.timeout,
                position_limit=position_limit,
            )
        if position_limit:
            return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
        return self._accepted()

    def communication_failed(
        self, motor_id: int, code: CommunicationFailure
    ) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)

        if not isinstance(code, CommunicationFailure):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        failure_code = code

        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            motor_id,
            communication_error=failure_code,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample, joint.health, joint.received_at, failure_code
        )
        return self._accepted()

    def checked(self) -> Decision:
        if self._state is not State.CHECKING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
        ]
        if out_of_bounds:
            for spec in out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)

        self._state = State.READY
        self._faults.clear()
        return self._accepted()

    def arm(self, owner: OwnerToken) -> Decision:
        if self._state is not State.READY:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not owner_tokens_match(owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)
        if bool(self._faults):
            return self._rejected(DecisionCode.FAULT_LATCHED)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
        ]
        if out_of_bounds:
            for spec in out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)

        self._state = State.ARMED
        return self._accepted()

    def tick(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        self._housekeeping(now)
        return self._accepted()

    def submit_target(self, target: Target) -> Decision:
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        housekeeping = self._housekeeping(now)
        if housekeeping is not None:
            return self._rejected(housekeeping)
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)

        if not isinstance(target, Target) or len(target.joints) != len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        if not owner_tokens_match(target.owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)

        if not isinstance(target.window, IntentWindow):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._offered_window is None:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if target.window.id < self._offered_window.id:
            return self._rejected(DecisionCode.EXPIRED)
        if target.window.id != self._offered_window.id:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if (
            target.window.created_at_s != self._offered_window.created_at_s
            or target.window.expires_at_s != self._offered_window.expires_at_s
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if now >= target.window.expires_at_s:
            return self._rejected(DecisionCode.EXPIRED)

        code, _, _ = prepare_complete_reference(self._specs, target)
        if code is not None:
            return self._rejected(code)

        if target.sequence <= self._last_sequence:
            return self._rejected(DecisionCode.DUPLICATE_OR_OLDER)

        self._admitted_target = target
        self._last_sequence = target.sequence
        self._invalidate_plan()
        return self._accepted()

    def prepare_refresh(self) -> RefreshPlan | None:
        if self._dispatch_claim is not None:
            return None
        if self._state not in (State.ARMED, State.MOVING):
            return None
        if self._state is State.FAULT or bool(self._faults):
            return None
        now = self._now()
        if self._housekeeping(now) is not None:
            return None
        if any(not joint.healthy for joint in self._observations):
            return None
        if self._admitted_target is None:
            return None
        if not owner_tokens_match(self._admitted_target.owner, self._current_owner):
            return None

        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid or joint.sample is None or (
                joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
            ):
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
                self.stop()
                return None

        code, actual_joint_targets, packets = prepare_complete_reference(
            self._specs, self._admitted_target
        )
        if code is not None or actual_joint_targets is None or packets is None:
            if code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                for spec, target_joint in zip(self._specs, self._admitted_target.joints):
                    joint_code, _, _ = prepare_reference_joint(spec, target_joint)
                    if joint_code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                        self._latch_joint_fault(
                            spec.name, spec.motor_id, position_limit=True
                        )
            self.stop()
            return None

        plan_id = self._next_plan_id
        if plan_id > (1 << 64) - 1:
            raise OverflowError("plan ID sequence exhausted")
        self._next_plan_id += 1

        plan = RefreshPlan(
            plan_id=plan_id,
            target=self._admitted_target,
            prepared_at_s=now,
            joint_targets=actual_joint_targets,
            packets=packets,
        )
        self._prepared_plan = plan
        self._next_dispatch_index = 0
        return plan

    def claim_dispatch(self, plan_id: int, index: int) -> bool:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return False
        if self._dispatch_claim is not None:
            return False
        if self._prepared_plan is None or self._prepared_plan.plan_id != plan_id:
            return False
        if self._state not in (State.ARMED, State.MOVING):
            return False
        if self._state is State.FAULT or bool(self._faults):
            return False
        if index < 0 or index >= len(self._specs):
            return False
        if index != self._next_dispatch_index:
            return False

        now = self._now()
        if self._housekeeping(now) is not None:
            return False
        if self._admitted_target is None or self._prepared_plan is None:
            return False
        if not owner_tokens_match(self._prepared_plan.target.owner, self._current_owner):
            return False
        if any(not joint.healthy for joint in self._observations):
            return False

        if not self._all_fresh(now):
            return False
        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid or joint.sample is None or (
                joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
            ):
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
                self.stop()
                return False

        plan_joint = self._prepared_plan.joint_targets[index]
        spec = self._specs[index]
        if plan_joint.q_rad < spec.q_min_rad or plan_joint.q_rad > spec.q_max_rad:
            self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            self.stop()
            return False

        self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
        return True

    def dispatch_result(
        self, plan_id: int, index: int, result: WriteResult
    ) -> Decision:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if not isinstance(result, WriteResult):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        claim = self._dispatch_claim
        if claim is None or claim.plan.plan_id != plan_id or claim.index != index:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if index < 0 or index >= len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        plan = claim.plan
        joint_target = plan.joint_targets[index]
        self._dispatch_attempts[index] = JointDispatchAttempt(
            plan_id=plan.plan_id,
            sequence=plan.target.sequence,
            target=joint_target,
            result=result,
            started_at_s=claim.started_at_s,
            owner=plan.target.owner,
        )
        if result is WriteResult.COMPLETE:
            record = JointDispatchedRecord(
                sequence=plan.target.sequence,
                target=joint_target,
                dispatched_at_s=claim.started_at_s,
                owner=plan.target.owner,
            )
            self._dispatched_records[index] = record
            try:
                now = self._now()
            except Exception:
                self._record_dispatch_failure(index, CommunicationFailure.CLOCK_FAILURE)
                self._dispatch_claim = None
                return self._rejected(DecisionCode.FAULT_LATCHED)

            housekeeping = self._housekeeping(now)
            still_current = (
                self._prepared_plan is plan
                and self._admitted_target is plan.target
                and self._state in (State.ARMED, State.MOVING)
                and not self._faults
                and owner_tokens_match(self._current_owner, plan.target.owner)
            )
            if still_current and housekeeping is None:
                self._next_dispatch_index = index + 1
                self._state = State.MOVING
            self._dispatch_claim = None
            return self._accepted()

        cause = (
            CommunicationFailure.PREWRITE_DEADLINE
            if result is WriteResult.PREWRITE_DEADLINE
            else CommunicationFailure.DRIVER_FAILURE
        )
        self._record_dispatch_failure(index, cause)
        self._dispatch_claim = None
        return self._rejected(DecisionCode.FAULT_LATCHED)

    def stop(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        self._revoke_authority()
        if self._state is State.FAULT or bool(self._faults):
            self._state = State.FAULT
        else:
            self._state = State.STOPPED
        return self._accepted()

    def disconnect(self) -> Decision:
        self._state = State.DISCONNECTED
        self._source = None
        self._clear_observations()
        self._revoke_authority()
        return self._accepted()

    def snapshot(self) -> Snapshot:
        received = [joint.received_at for joint in self._observations]
        now = self._now() if any(value is not None for value in received) else None
        ages = tuple(
            None if value is None else self._age(value, now)
            for value in received
        )
        faults = tuple(self._faults[spec.name] for spec in self._specs
                       if spec.name in self._faults)
        return Snapshot(
            state=self._state,
            joint_names=tuple(spec.name for spec in self._specs),
            joints=tuple(self._observations),
            source=self._source,
            fault_latched=bool(self._faults),
            feedback_ages_s=ages,
            faults=faults,
            admitted_target=self._admitted_target,
            prepared_plan=self._prepared_plan,
            dispatched_records=tuple(self._dispatched_records),
            dispatch_attempts=tuple(self._dispatch_attempts),
            last_sequence=self._last_sequence,
            latest_owner=self._latest_owner,
            current_owner=self._current_owner,
        )

```

FILE im6014_serial.py
```
from collections import deque
from dataclasses import dataclass
import math
import threading
import time

from im6014_codec import feedback
from joint_contract import WriteResult

_monotonic = time.monotonic

_REQUEST_BYTES = 20
_REPLY_BYTES = 26
_CAPTURE_CAPACITY = 256
_IDENTITY_CHARS = 96
_PORT_CHARS = 160
_TAIL_BYTES = 25
_OUTCOMES = frozenset(('OK', 'TIMEOUT', 'INVALID_FEEDBACK', 'DRIVER_FAILURE'))
_DECODED_INTEGER_LIMITS = {
    'id': (0, 14), 'mode': (0, 1), 'timeout': (0, 1),
    'driver_c': (-128, 127), 'winding_c': (0, 255),
    'errors': (0, 0xFFFFFFFF), 'warnings': (0, 7),
}
_DECODED_FLOAT_FIELDS = ('voltage', 'torque_nm', 'rpm', 'position_rad')


def _bounded_count(value):
    if type(value) is not int or value < 0:
        return 0
    return min(value, 0x7FFFFFFF)


def _bounded_tail(value):
    if isinstance(value, bytes):
        return value[-_TAIL_BYTES:]
    if isinstance(value, bytearray):
        return bytes(value[-_TAIL_BYTES:])
    if isinstance(value, memoryview):
        try:
            return value.cast('B')[-_TAIL_BYTES:].tobytes()
        except (TypeError, ValueError):
            return b''
    return b''


class TransactionTimeoutError(RuntimeError):
    """The bounded transaction expired; diagnostics contain no exception text."""

    def __init__(self, message, *, rejected=0, crc_rejected=0, tail=b''):
        super().__init__(message)
        self.rejected_frames = _bounded_count(rejected)
        self.crc_rejected_frames = min(_bounded_count(crc_rejected), self.rejected_frames)
        self.tail = _bounded_tail(tail)


class InvalidFeedbackError(TransactionTimeoutError):
    """The transaction expired after rejecting one or more candidate frames."""


class WriteCancelledError(RuntimeError):
    """The serial write was cancelled before transmission by the pre-write hook."""


@dataclass(frozen=True)
class _PacketRecord:
    source: str
    identity: str
    connection: int
    port: str
    baud: int
    requested_motor_id: int
    started_s: float
    ended_s: float | None
    request_hex: str
    reply_hex: str
    decoded_fields: tuple
    outcome: str
    rejected_frames: int
    crc_rejected_frames: int
    tail_hex: str


class PacketCapture:
    """A copy-out, fixed-capacity ring of allowlisted packet diagnostics."""

    def __init__(self, capacity=_CAPTURE_CAPACITY, *, clock=None):
        if type(capacity) is not int or not 1 <= capacity <= _CAPTURE_CAPACITY:
            raise ValueError('Capture capacity must be an integer from 1 to 256')
        if clock is not None and not callable(clock):
            raise ValueError('Capture clock must be callable')
        self.capacity = capacity
        self._clock = time.monotonic if clock is None else clock
        self._records = deque(maxlen=capacity)
        self._dropped = 0
        self._lock = threading.Lock()

    def _now(self):
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError('Capture clock must return a finite monotonic number')
        try:
            value = float(value)
        except (OverflowError, TypeError, ValueError) as error:
            raise ValueError('Capture clock must return a finite monotonic number') from error
        if not math.isfinite(value) or not 0 <= value <= 1e12:
            raise ValueError('Capture clock must return a finite monotonic number')
        return value

    def _append(self, record):
        with self._lock:
            if len(self._records) == self.capacity:
                self._dropped = min(self._dropped + 1, 0x7FFFFFFFFFFFFFFF)
            self._records.append(record)

    def snapshot(self):
        with self._lock:
            records = self._records.copy()
            dropped = self._dropped
        return {
            'capacity': self.capacity,
            'dropped': dropped,
            'records': [
                {
                    'source': item.source,
                    'identity': item.identity,
                    'connection': item.connection,
                    'port': item.port,
                    'baud': item.baud,
                    'requested_motor_id': item.requested_motor_id,
                    'started_s': item.started_s,
                    'ended_s': item.ended_s,
                    'request_hex': item.request_hex,
                    'reply_hex': item.reply_hex,
                    'decoded_fields': dict(item.decoded_fields),
                    'outcome': item.outcome,
                    'rejected_frames': item.rejected_frames,
                    'crc_rejected_frames': item.crc_rejected_frames,
                    'tail_hex': item.tail_hex,
                }
                for item in records
            ],
        }


def _capture_metadata(source, identity, connection, port, baud, motor_id):
    if type(source) is not str or source not in ('physical', 'demo', 'fixture'):
        raise ValueError('Capture source must be physical, demo, or fixture')
    if type(identity) is not str or not identity:
        raise ValueError('Capture identity must be a nonempty string')
    if type(port) is not str:
        raise ValueError('Capture port must be a string')
    if source == 'physical' and not port:
        raise ValueError('Physical capture requires an explicit port')
    if type(connection) is not int or not 0 <= connection <= 0x7FFFFFFF:
        raise ValueError('Capture connection must be a nonnegative integer')
    if type(baud) is not int or baud not in (4000000, 6000000):
        raise ValueError('Capture baud must be 4000000 or 6000000')
    if type(motor_id) is not int or not 0 <= motor_id <= 14:
        raise ValueError('Capture motor ID must be an integer from 0 to 14')
    return source, identity[:_IDENTITY_CHARS], connection, port[:_PORT_CHARS], baud, motor_id


def _packet_prefix(value, limit):
    if isinstance(value, bytes):
        return value[:limit]
    if isinstance(value, bytearray):
        return bytes(value[:limit])
    if isinstance(value, memoryview):
        try:
            return value.cast('B')[:limit].tobytes()
        except (TypeError, ValueError):
            return b''
    return b''


def _reply_prefix(result):
    if type(result) is not dict:
        return b''
    raw = result.get('raw')
    if isinstance(raw, bytes):
        return raw[:_REPLY_BYTES]
    if isinstance(raw, bytearray):
        return bytes(raw[:_REPLY_BYTES])
    if isinstance(raw, memoryview):
        try:
            return raw.cast('B')[:_REPLY_BYTES].tobytes()
        except (TypeError, ValueError):
            return b''
    if type(raw) is str:
        raw = raw[:_REPLY_BYTES * 2]
        raw = raw[:len(raw) - len(raw) % 2]
        try:
            return bytes.fromhex(raw)[:_REPLY_BYTES]
        except ValueError:
            return b''
    return b''


def _decoded_fields(result):
    if type(result) is not dict:
        return ()
    fields = []
    for name, (minimum, maximum) in _DECODED_INTEGER_LIMITS.items():
        value = result.get(name)
        if type(value) is int and minimum <= value <= maximum:
            fields.append((name, value))
    for name in _DECODED_FLOAT_FIELDS:
        value = result.get(name)
        if type(value) in (int, float):
            try:
                value = float(value)
            except (OverflowError, TypeError, ValueError):
                continue
            if math.isfinite(value) and abs(value) <= 1e6:
                fields.append((name, value))
    return tuple(fields)


def _outcome(error):
    if isinstance(error, InvalidFeedbackError):
        return 'INVALID_FEEDBACK'
    if isinstance(error, (TransactionTimeoutError, TimeoutError)):
        return 'TIMEOUT'
    return 'DRIVER_FAILURE'


def capture_exchange(capture, exchange_fn, bus, packet, motor_id, *,
                     source, identity, connection, port, baud,
                     before_write=None, on_write=None):
    """Call the current caller's three-argument exchange and retain one safe record."""
    if not isinstance(capture, PacketCapture):
        raise ValueError('Capture must be a PacketCapture')
    if not callable(exchange_fn):
        raise ValueError('Capture exchange function must be callable')
    context = _capture_metadata(source, identity, connection, port, baud, motor_id)
    source, identity, connection, port, baud, motor_id = context
    request = _packet_prefix(packet, _REQUEST_BYTES)
    started = capture._now()
    reply = b''
    decoded = ()
    outcome = 'DRIVER_FAILURE'
    rejected = 0
    crc_rejected = 0
    tail = b''
    kwargs = {}
    if before_write is not None:
        kwargs['before_write'] = before_write
    if on_write is not None:
        kwargs['on_write'] = on_write
    try:
        if kwargs:
            result = exchange_fn(bus, packet, motor_id, **kwargs)
        else:
            result = exchange_fn(bus, packet, motor_id)
        reply = _reply_prefix(result)
        decoded = _decoded_fields(result)
        outcome = 'OK'
        return result
    except Exception as error:
        outcome = _outcome(error)
        if isinstance(error, TransactionTimeoutError):
            rejected = _bounded_count(error.rejected_frames)
            crc_rejected = min(_bounded_count(error.crc_rejected_frames), rejected)
            tail = _bounded_tail(error.tail)
        raise
    finally:
        try:
            ended = capture._now()
        except Exception:
            ended = None
        if ended is not None and ended < started:
            ended = None
        if outcome not in _OUTCOMES:
            outcome = 'DRIVER_FAILURE'
        capture._append(_PacketRecord(
            source, identity, connection, port, baud, motor_id, started, ended,
            request.hex(), reply.hex(), decoded, outcome, rejected, crc_rejected, tail.hex(),
        ))


def _remaining(deadline):
    remaining = deadline - _monotonic()
    if remaining <= 0:
        raise TransactionTimeoutError('No validated motor feedback within deadline')
    return remaining


def _bounded_timeout(original, remaining, writing=False):
    if original is None or writing and original == 0:
        return remaining
    return min(original, remaining)


def _receive(bus, motor_id, deadline, original_timeout):
    data = bytearray()
    rejected = 0
    crc_rejected = 0
    last_error = ''
    try:
        while True:
            bus.timeout = _bounded_timeout(original_timeout, _remaining(deadline))
            _remaining(deadline)
            size = min(26, max(1, bus.in_waiting))
            _remaining(deadline)
            data.extend(bus.read(size))
            _remaining(deadline)
            while True:
                _remaining(deadline)
                start = data.find(b'\xfc\xee')
                if start < 0:
                    data[:] = b'\xfc' if data.endswith(b'\xfc') else b''
                    break
                del data[:start]
                if len(data) < 26:
                    break
                try:
                    result = feedback(bytes(data[:26]), motor_id)
                except RuntimeError as error:
                    rejected += 1
                    last_error = str(error)
                    crc_rejected += int("CRC" in last_error)
                    del data[:1]
                else:
                    _remaining(deadline)
                    return result
    except TransactionTimeoutError as error:
        crc_detail = f'CRC rejected {crc_rejected}; ' if crc_rejected else ''
        message = (f'No validated motor feedback within deadline; rejected {rejected}; '
                   f'{crc_detail}{last_error}; tail {data[-25:].hex()}')
        error_type = InvalidFeedbackError if rejected else TransactionTimeoutError
        raise error_type(message, rejected=rejected, crc_rejected=crc_rejected,
                         tail=data[-25:]) from error


def exchange(bus, packet, motor_id, deadline_s=0.05, *, before_write=None, on_write=None):
    """Reset once, write once, and return requested feedback before expiry.

    The bus has one owner. Its timeout setters, reset and I/O must obey their
    driver contract. Objects without write_timeout must write immediately.
    Synchronous driver calls and cleanup cannot be forcibly interrupted.
    Read/write settings are restored before any validated result is returned.
    If the final deadline check expires after before_write allows dispatch,
    on_write receives PREWRITE_DEADLINE even though bus.write was never called.
    """
    if type(motor_id) is not int or not 0 <= motor_id <= 14:
        raise ValueError('Expected motor ID must be an integer from 0 to 14')
    if isinstance(deadline_s, bool) or not isinstance(deadline_s, (int, float)):
        raise ValueError('Transaction deadline must be a finite positive int or float')
    try:
        deadline_s = float(deadline_s)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError('Transaction deadline must be finite and positive') from error
    if not math.isfinite(deadline_s) or deadline_s <= 0:
        raise ValueError('Transaction deadline must be finite and positive')
    if before_write is not None and not callable(before_write):
        raise ValueError('before_write hook must be callable')
    if on_write is not None and not callable(on_write):
        raise ValueError('on_write hook must be callable')
    deadline = _monotonic() + deadline_s
    if not math.isfinite(deadline):
        raise ValueError('Transaction deadline is not representable')
    original_timeout = bus.timeout
    has_write_timeout = hasattr(bus, 'write_timeout')
    original_write_timeout = bus.write_timeout if has_write_timeout else None
    failure = None
    try:
        _remaining(deadline)
        bus.reset_input_buffer()
        _remaining(deadline)
        if has_write_timeout:
            bus.write_timeout = _bounded_timeout(original_write_timeout, _remaining(deadline), writing=True)
        _remaining(deadline)
        if before_write is not None:
            allowed = before_write()
            if not allowed:
                raise WriteCancelledError('Serial write cancelled by pre-write hook')
        try:
            _remaining(deadline)
        except TransactionTimeoutError:
            if on_write is not None:
                on_write(WriteResult.PREWRITE_DEADLINE)
            raise
        try:
            written = bus.write(packet)
        except Exception:
            if on_write is not None:
                try:
                    on_write(WriteResult.FAILED)
                except Exception:
                    pass
            raise
        if type(written) is int and written == len(packet):
            write_result = WriteResult.COMPLETE
        elif type(written) is int and 0 < written < len(packet):
            write_result = WriteResult.PARTIAL
        else:
            write_result = WriteResult.FAILED
        if on_write is not None:
            on_write(write_result)
        _remaining(deadline)
        if write_result is not WriteResult.COMPLETE:
            raise RuntimeError('Incomplete serial write')
        result = _receive(bus, motor_id, deadline, original_timeout)
    except ValueError as error:
        failure = error
        raise RuntimeError('Serial timeout configuration failed') from error
    except Exception as error:
        failure = error
        raise
    finally:
        restore_errors = []
        for name, value in [('timeout', original_timeout), *(
                [('write_timeout', original_write_timeout)] if has_write_timeout else [])]:
            try:
                setattr(bus, name, value)
            except Exception as error:
                restore_errors.append((name, error))
        if restore_errors:
            names = ', '.join(name for name, _ in restore_errors)
            detail = f'; transaction also failed: {failure}' if failure else ''
            raise RuntimeError(f'Cannot restore serial timeout settings: {names}{detail}') from restore_errors[0][1]
    _remaining(deadline)
    return result

```

FILE test_controller_limits.py
```
"""Targeted unit and acceptance tests for C09 inclusive joint position bounds."""

import math
import random
import struct
import unittest
from dataclasses import replace
from unittest.mock import patch

from im6014_codec import (
    POSITION_MAX,
    POSITION_MIN,
    RAW_POSITION_MAX,
    RAW_POSITION_MIN,
    RATIO,
    RPM_MAX,
    RPM_MIN,
    command,
    command_with_raw_position,
    crc32,
    decode_command,
    position_to_raw,
    project_position_raw,
    raw_to_position,
)
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    IntentWindow,
    JointDispatchAttempt,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
    owner_tokens_match,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget, OutputSample
from joint_reference import prepare_reference_joint
from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP, SAMPLE

SOURCE = SourceIdentity("fixture", "limits-test", 1)


def _with_command_crc(packet):
    return packet[:16] + struct.pack("<I", crc32(packet[:16]))


class PositionLimitTests(unittest.TestCase):
    def setUp(self):
        self.clock = DeterministicClock(0.0)
        self.specs = (
            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1.0, 2.0, "fixture: software position limits J1"),
            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -0.5, 0.5, "fixture: software position limits J2"),
        )
        self.valid_sample_j1 = JointSample(0.1, 0.0, 0.0)
        self.valid_sample_j2 = JointSample(0.0, 0.0, 0.0)

    def _armed_station(self, connection_id="tester"):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim(connection_id)
        # Check with valid within-bounds observations
        self.assertTrue(core.begin_check().accepted)
        self.assertTrue(core.receive(0, self.valid_sample_j1, HEALTHY_STOP).accepted)
        self.assertTrue(core.receive(1, self.valid_sample_j2, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertTrue(station.arm(owner).accepted)
        return core, station, owner

    @staticmethod
    def _project(spec, wanted_q):
        return project_position_raw(
            wanted_q,
            spec.q_min_rad,
            spec.q_max_rad,
            lambda output_q: spec.mapping.from_output(
                OutputSample(output_q, 0.0, 0.0)
            ).q_rad,
            spec.mapping.direction,
        )

    def test_exact_lower_and_upper_requests_accepted(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        # Exact lower on J1 (-1.0), exact upper on J2 (0.5)
        t1 = Target(
            1,
            (
                JointTarget(-1.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.5, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        dec1 = station.submit(t1)
        self.assertTrue(dec1.accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)

        station.writes.clear()
        plan = station.refresh()
        self.assertIsNotNone(plan)
        self.assertEqual(len(station.writes), 2)
        self.assertEqual(station.writes, list(plan.packets))
        self.assertIs(core.snapshot().state, State.MOVING)

        # Exact upper on J1 (2.0), exact lower on J2 (-0.5)
        t2 = Target(
            2,
            (
                JointTarget(2.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(-0.5, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        dec2 = station.submit(t2)
        self.assertTrue(dec2.accepted)
        self.assertEqual(core.snapshot().last_sequence, 2)

    def test_one_representable_step_outside_bounds_rejected(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        prior_target = Target(
            1,
            (
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        self.assertTrue(station.submit(prior_target).accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)

        # One step below lower bound on J1 (-1.0001 < -1.0)
        below = Target(
            2,
            (
                JointTarget(-1.0001, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        dec_below = station.submit(below)
        self.assertFalse(dec_below.accepted)
        self.assertEqual(dec_below.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

        # One step above upper bound on J2 (0.5001 > 0.5)
        above = Target(
            3,
            (
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.5001, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        dec_above = station.submit(above)
        self.assertFalse(dec_above.accepted)
        self.assertEqual(dec_above.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

    def test_negative_direction_and_nonzero_zero_reduction_map(self):
        specs_mapped = (
            JointSpec(
                "J1",
                0,
                JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25),
                -1.0,
                1.0,
                "fixture: software limits negative direction",
            ),
            JointSpec(
                "J2",
                1,
                JointMap(reduction=2.0, direction=1, zero_output_rad=-0.1),
                -0.5,
                0.5,
                "fixture: software limits positive direction",
            ),
        )
        core = JointCore(specs_mapped, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("mapped-client")
        self.assertTrue(core.begin_check().accepted)
        self.assertTrue(core.receive(0, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
        self.assertTrue(core.receive(1, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertTrue(station.arm(owner).accepted)

        window = station.issue_window(1.0)
        # Exact lower on J1 (-1.0), exact upper on J2 (0.5)
        target = Target(
            1,
            (
                JointTarget(-1.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.5, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        self.assertTrue(station.submit(target).accepted)
        station.writes.clear()
        plan = station.refresh()
        self.assertIsNotNone(plan)
        self.assertEqual(len(station.writes), 2)
        self.assertEqual(station.writes, list(plan.packets))

        # Verify decoded command positions stay within bounds
        dec_pkt_0 = decode_command(station.writes[0])
        decoded_sample_0 = specs_mapped[0].mapping.from_output(
            OutputSample(dec_pkt_0["position_rad"], 0.0, 0.0)
        )
        self.assertGreaterEqual(decoded_sample_0.q_rad, specs_mapped[0].q_min_rad)
        self.assertLessEqual(decoded_sample_0.q_rad, specs_mapped[0].q_max_rad)

        # Target outside bounds with negative direction is rejected
        outside = Target(
            2,
            (
                JointTarget(1.05, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        rej = station.submit(outside)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.POSITION_OUT_OF_BOUNDS)

    def test_zero_width_interval_and_no_representable_safe_command(self):
        # Case A: zero-width interval on exact representable grid point
        raw_code = 1000
        grid_pos = raw_to_position(raw_code)
        spec_zero_width = JointSpec(
            "J1",
            0,
            JointMap(1.0, 1, 0.0),
            grid_pos,
            grid_pos,
            "fixture: exact grid point interval",
        )
        found_code = self._project(spec_zero_width, grid_pos)
        self.assertEqual(found_code, raw_code)

        # Case B: interval strictly between two representable grid points
        raw0 = 2000
        raw1 = 2001
        pos0 = raw_to_position(raw0)
        pos1 = raw_to_position(raw1)
        mid = (pos0 + pos1) / 2.0
        # Interval narrower than one raw step containing no integer code
        spec_empty_grid = JointSpec(
            "J1",
            0,
            JointMap(1.0, 1, 0.0),
            mid - 1e-9,
            mid + 1e-9,
            "fixture: empty grid interval",
        )
        found_none = self._project(spec_empty_grid, mid)
        self.assertIsNone(found_none)

        # Submission on spec with no representable command is rejected
        core = JointCore((spec_empty_grid,), clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("zero-client")
        self.assertTrue(core.begin_check().accepted)
        self.assertTrue(core.receive(0, JointSample(mid, 0.0, 0.0), HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertTrue(station.arm(owner).accepted)

        w = station.issue_window(1.0)
        t = Target(1, (JointTarget(mid, 0.0, 0.0, 1.0, 0.1),), window=w, owner=owner)
        dec = station.submit(t)
        self.assertFalse(dec.accepted)
        self.assertEqual(dec.code, DecisionCode.POSITION_OUT_OF_BOUNDS)

    def test_malformed_spec_and_fault_config_rejected(self):
        mapping = JointMap(1.0, 1, 0.0)

        # q_min_rad > q_max_rad
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, 1.0, 0.0, "fixture: invalid min max")

        # non-numeric / bool types
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, True, 1.0, "fixture: bool min")
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, 0.0, False, "fixture: bool max")
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, "0.0", 1.0, "fixture: str min")

        # infinite / NaN
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, float("-inf"), 1.0, "fixture: neg inf min")
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, 0.0, float("inf"), "fixture: inf max")
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, float("nan"), 1.0, "fixture: nan min")
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, 0, 10**400, "fixture: overflowing max")

        # invalid provenance
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, -1.0, 1.0, "")
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, -1.0, 1.0, "   ")
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, -1.0, 1.0, 123)
        with self.assertRaises(ValueError):
            JointSpec("J1", 0, mapping, -1.0, 1.0, "x" * 257)

        with self.assertRaises(TypeError):
            JointSpec("J1", 0, mapping, -1.0, 1.0)
        with self.assertRaises(TypeError):
            JointSpec("J1", 0, mapping, -1.0, 1.0, provenance="legacy alias")

        # JointFault position_limit type validation
        with self.assertRaises(ValueError):
            JointFault("J1", 0, position_limit="bad")
        jf = JointFault("J1", 0, position_limit=True)
        self.assertTrue(jf.position_limit)
        self.assertFalse(hasattr(jf, "position_out_of_bounds"))

    def test_multi_joint_invalid_last_joint_cannot_replace_goal_or_watermark(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        prior_target = Target(
            1,
            (
                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        self.assertTrue(station.submit(prior_target).accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)

        # Target 2: Joint 0 valid (0.2 within [-1.0, 2.0]), Joint 1 invalid (10.0 outside [-0.5, 0.5])
        invalid_target = Target(
            2,
            (
                JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
                JointTarget(10.0, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        decision = station.submit(invalid_target)
        self.assertFalse(decision.accepted)
        self.assertEqual(decision.code, DecisionCode.POSITION_OUT_OF_BOUNDS)

        # Atomically preserves admitted target and watermark sequence
        self.assertEqual(core.snapshot().admitted_target, prior_target)
        self.assertEqual(core.snapshot().last_sequence, 1)

    def test_measured_outside_bounds_at_admission_and_final_write_gate(self):
        # 1. Measured outside at receive during checking latches fault
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)
        # J1 upper bound is 2.0; receive 2.5
        rej = core.receive(0, JointSample(2.5, 0.0, 0.0), HEALTHY_STOP)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
        self.assertTrue(core.snapshot().faults[0].position_limit)
        self.assertIs(core.snapshot().state, State.FAULT)

        # 2. Final write gate rechecks current measured bounds
        core2, station2, owner2 = self._armed_station("gate-client")
        w2 = station2.issue_window(1.0)
        t2 = Target(
            1,
            (
                JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            ),
            window=w2,
            owner=owner2,
        )
        self.assertTrue(station2.submit(t2).accepted)
        plan = core2.prepare_refresh()
        self.assertIsNotNone(plan)

        # Before claim_dispatch, feedback reports J2 position exceeds upper limit 0.5
        core2.receive(1, JointSample(0.6, 0.0, 0.0), HEALTHY_STOP)
        # claim_dispatch must fail, latch position_limit fault, and deny write
        claimed = core2.claim_dispatch(plan.plan_id, 0)
        self.assertFalse(claimed)
        joint2_fault = next(
            fault for fault in core2.snapshot().faults if fault.motor_id == self.specs[1].motor_id
        )
        self.assertTrue(joint2_fault.position_limit)
        self.assertIs(core2.snapshot().state, State.FAULT)

    def test_unhealthy_outside_feedback_preserves_both_fault_causes(self):
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)
        unhealthy = MotorHealth(mode=0, errors=0x04, warnings=2, timeout=True)

        decision = core.receive(0, JointSample(2.5, 0.0, 0.0), unhealthy)

        self.assertEqual(decision.code, DecisionCode.POSITION_OUT_OF_BOUNDS)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))
        fault = core.snapshot().faults[0]
        self.assertEqual(fault.errors, 0x04)
        self.assertEqual(fault.warnings, 2)
        self.assertTrue(fault.timeout)
        self.assertTrue(fault.position_limit)

    def test_attributed_fault_and_recovery(self):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("recovery-tester")
        self.assertTrue(core.begin_check().accepted)
        # Induce position_limit fault on J1
        core.receive(0, JointSample(3.0, 0.0, 0.0), HEALTHY_STOP)
        self.assertTrue(core.snapshot().faults[0].position_limit)
        self.assertFalse(hasattr(core.snapshot().faults[0], "position_out_of_bounds"))

        # Submitting new target does NOT clear fault
        w = station.issue_window(1.0)
        t = Target(1, (JointTarget(0.0, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)), window=w, owner=owner)
        dec = station.submit(t)
        self.assertFalse(dec.accepted)
        self.assertTrue(core.snapshot().faults[0].position_limit)

        # arm fails while faulted
        self.assertFalse(station.arm(owner).accepted)

        # Recovery attempt with measured position still out of bounds fails
        self.assertTrue(station.stop().accepted)
        owner2 = station.claim("recovery-tester-2")
        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
        self.assertFalse(core.receive(0, JointSample(3.0, 0.0, 0.0), HEALTHY_STOP).accepted)
        self.assertFalse(core.checked().accepted)

        # Proper recovery with acknowledged stop check inside bounds succeeds
        self.assertTrue(station.stop().accepted)
        owner3 = station.claim("recovery-tester-3")
        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
        self.assertTrue(core.receive(0, self.valid_sample_j1, HEALTHY_STOP).accepted)
        self.assertTrue(core.receive(
            1, JointSample(self.specs[1].q_max_rad, 0.0, 0.0), HEALTHY_STOP
        ).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertTrue(station.arm(owner3).accepted)
        self.assertEqual(core.snapshot().faults, ())
        self.assertFalse(core.snapshot().fault_latched)

    def test_codec_rounding_overshoot_produces_inward_actual_safe_endpoint(self):
        spec = JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -0.1, 0.1, "fixture: rounding overshoot test")
        target = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)

        requested_output = spec.mapping.to_output(target)
        requested_raw = position_to_raw(requested_output.q_rad)
        self.assertEqual(requested_raw, 6606)
        self.assertGreater(raw_to_position(requested_raw), spec.q_max_rad)

        code, actual_target, packet = prepare_reference_joint(spec, target)
        self.assertIsNone(code)
        self.assertIsNotNone(actual_target)
        self.assertIsNotNone(packet)

        # Actual reference must be strictly <= spec.q_max_rad
        self.assertLessEqual(actual_target.q_rad, spec.q_max_rad)
        self.assertGreaterEqual(actual_target.q_rad, spec.q_min_rad)

        dec = decode_command(packet)
        self.assertEqual(dec["raw_position"], 6605)
        self.assertLess(raw_to_position(dec["raw_position"]), spec.q_max_rad)
        self.assertEqual(dec["position_rad"], raw_to_position(dec["raw_position"]))

        requested = decode_command(command(
            spec.motor_id,
            mode=1,
            rpm=requested_output.rpm,
            kd=requested_output.kd,
            torque=requested_output.tau_nm,
            watchdog=True,
            position=requested_output.q_rad,
            kp=requested_output.kp,
        ))
        for field in ("raw_rpm", "raw_torque", "raw_kp", "raw_kd"):
            self.assertEqual(dec[field], requested[field])
        self.assertEqual(actual_target.q_rad, spec.mapping.from_output(
            OutputSample(dec["position_rad"], dec["rpm"], dec["torque_nm"])
        ).q_rad)
        self.assertEqual(packet, command_with_raw_position(
            spec.motor_id,
            6605,
            mode=1,
            rpm=requested_output.rpm,
            kd=requested_output.kd,
            torque=requested_output.tau_nm,
            watchdog=True,
            kp=requested_output.kp,
        ))

    def test_repeated_safe_refresh_preserves_canonical_packets_and_inward_reference(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)
        target = Target(
            1,
            (
                JointTarget(1.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.4, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        self.assertTrue(station.submit(target).accepted)

        # Multiple refreshes within window emit canonical packets consistently
        for step in range(5):
            self.clock.value += 0.01
            station.writes.clear()
            plan = station.refresh()
            self.assertIsNotNone(plan)
            self.assertEqual(len(station.writes), 2)
            self.assertEqual(station.writes, list(plan.packets))
            self.assertEqual(core.snapshot().last_sequence, 1)
            self.assertIs(core.snapshot().state, State.MOVING)

    def test_im6014_codec_decode_command_and_helpers(self):
        pkt = command(
            2,
            mode=1,
            position=1.5,
            rpm=10.0,
            torque=0.5,
            kp=5.0,
            kd=1.0,
            watchdog=True,
        )
        dec = decode_command(pkt)
        self.assertEqual(dec["motor_id"], 2)
        self.assertEqual(dec["mode"], 1)
        self.assertTrue(dec["watchdog"])
        self.assertEqual(dec["raw_position"], position_to_raw(1.5))
        self.assertAlmostEqual(dec["position_rad"], 1.5, delta=1e-4)
        self.assertEqual(dec["raw_rpm"], 135)
        self.assertEqual(dec["rpm"], 135 / 64 / RATIO * 60)
        self.assertEqual(dec["raw_torque"], 101)
        self.assertEqual(dec["torque_nm"], 101 / 2560 * RATIO)

        # Corrupt CRC
        corrupt = bytearray(pkt)
        corrupt[-1] ^= 0xFF
        with self.assertRaises(ValueError):
            decode_command(bytes(corrupt))

        # Invalid length
        with self.assertRaises(ValueError):
            decode_command(pkt[:19])

        # Stop commands are valid canonical packets.
        stop_pkt = command(2, mode=0)
        decoded_stop = decode_command(stop_pkt)
        self.assertEqual(decoded_stop["mode"], 0)
        self.assertEqual(decoded_stop["raw_position"], 0)
        no_watchdog_stop = decode_command(command(2, mode=0, watchdog=False))
        self.assertEqual(no_watchdog_stop["mode"], 0)
        self.assertFalse(no_watchdog_stop["watchdog"])

        for byte_index, value in ((0, 0), (1, 0), (3, 1)):
            malformed = bytearray(pkt)
            malformed[byte_index] = value
            with self.subTest(byte_index=byte_index), self.assertRaises(ValueError):
                decode_command(_with_command_crc(malformed))

        for field, update in (
            ("reserved mode bits", lambda raw: raw.__setitem__(2, raw[2] | 0x20)),
            ("invalid individual ID", lambda raw: raw.__setitem__(2, (raw[2] & 0xF0) | 0x0F)),
            ("missing FOC watchdog", lambda raw: raw.__setitem__(2, raw[2] & 0x7F)),
        ):
            malformed = bytearray(pkt)
            update(malformed)
            with self.subTest(field=field), self.assertRaises(ValueError):
                decode_command(_with_command_crc(malformed))

        malformed_stop = bytearray(stop_pkt)
        malformed_stop[4] = 1
        with self.assertRaises(ValueError):
            decode_command(_with_command_crc(malformed_stop))

        # Raw conversions
        self.assertEqual(position_to_raw(raw_to_position(0)), 0)
        self.assertEqual(position_to_raw(raw_to_position(100)), 100)
        self.assertEqual(position_to_raw(raw_to_position(-100)), -100)
        self.assertEqual(position_to_raw(raw_to_position(RAW_POSITION_MAX)), RAW_POSITION_MAX)
        self.assertEqual(position_to_raw(raw_to_position(RAW_POSITION_MIN)), RAW_POSITION_MIN)

    def test_decoder_accepts_canonical_input_endpoints_and_rejects_raw_values_outside_them(self):
        for position, rpm, torque, kp, kd in (
            (POSITION_MIN, RPM_MIN, -3.5, 0.0, 0.0),
            (POSITION_MAX, RPM_MAX, 3.5, 30.0, 6.0),
        ):
            with self.subTest(position=position, rpm=rpm, torque=torque, kp=kp, kd=kd):
                packet = command(
                    0, mode=1, position=position, rpm=rpm,
                    torque=torque, kp=kp, kd=kd, watchdog=True,
                )
                decoded = decode_command(packet)
                self.assertEqual(decoded["raw"], packet.hex())
                expected_position_raw = RAW_POSITION_MIN if position == POSITION_MIN else RAW_POSITION_MAX
                expected_rpm_raw = -32768 if rpm == RPM_MIN else 32767
                self.assertEqual(decoded["raw_position"], expected_position_raw)
                self.assertEqual(decoded["raw_rpm"], expected_rpm_raw)
                if kd == 6.0:
                    self.assertGreater(decoded["kd"], 6.0)

        endpoint_fields = (
            ("feedforward", 4, command(0, mode=1, torque=-3.5), command(0, mode=1, torque=3.5)),
            ("kp", 12, command(0, mode=1, kp=0.0), command(0, mode=1, kp=30.0)),
            ("kd", 14, command(0, mode=1, kd=0.0), command(0, mode=1, kd=6.0)),
        )
        for field, offset, low_packet, high_packet in endpoint_fields:
            low_raw = struct.unpack_from("<h", low_packet, offset)[0]
            high_raw = struct.unpack_from("<h", high_packet, offset)[0]
            invalid_raw_values = (
                (f"{field} below image", low_raw - 1),
                (f"{field} at raw minimum", -32768),
                (f"{field} above image", high_raw + 1),
                (f"{field} at raw maximum", 32767),
            )
            for name, raw_value in invalid_raw_values:
                malformed = bytearray(command(0, mode=1))
                struct.pack_into("<h", malformed, offset, raw_value)
                with self.subTest(name=name), self.assertRaises(ValueError):
                    decode_command(_with_command_crc(malformed))

    def test_actual_reference_matches_every_canonical_wire_field(self):
        mapping = JointMap(3.0, -1, 0.25)
        spec = JointSpec(
            "J1", 0, mapping, -2.0, 2.0, "fixture: canonical reference test"
        )
        requested = JointTarget(0.321, 0.123, 0.321, 1.234, 0.123)

        code, actual, packet = prepare_reference_joint(spec, requested)

        self.assertIsNone(code)
        self.assertIsNotNone(actual)
        decoded = decode_command(packet)
        expected = mapping.from_output(OutputSample(
            decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
        ))
        self.assertEqual(actual.q_rad, expected.q_rad)
        self.assertEqual(actual.dq_rad_s, expected.dq_rad_s)
        self.assertEqual(actual.tau_nm, expected.tau_nm)
        self.assertEqual(actual.kp, decoded["kp"] * mapping.reduction ** 2)
        self.assertEqual(actual.kd, decoded["kd"] * mapping.reduction ** 2)

    def test_unencodable_mapped_request_is_invalid_not_projected_into_range(self):
        spec = JointSpec(
            "J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8,
            "fixture: wide software position limits",
        )
        code, actual, packet = prepare_reference_joint(
            spec, JointTarget(1e7, 0.0, 0.0, 1.0, 0.1)
        )
        self.assertIs(code, DecisionCode.INVALID_ARGUMENT)
        self.assertIsNone(actual)
        self.assertIsNone(packet)

    def test_mapping_overflow_is_invalid_argument(self):
        spec = JointSpec(
            "J1", 0, JointMap(1e-308, 1, 0.0), -1.0, 1.0,
            "fixture: mapping overflow limits",
        )
        code, actual, packet = prepare_reference_joint(
            spec, JointTarget(0.0, 0.0, 0.0, 0.0, 0.0)
        )
        self.assertIs(code, DecisionCode.INVALID_ARGUMENT)
        self.assertIsNone(actual)
        self.assertIsNone(packet)

    def test_refresh_plan_requires_exact_count_canonical_packet_bytes(self):
        core, station, owner = self._armed_station()
        target = Target(
            1,
            (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)),
            window=station.issue_window(1.0),
            owner=owner,
        )
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)
        self.assertEqual(len(plan.packets), len(plan.joint_targets))
        self.assertTrue(all(type(packet) is bytes for packet in plan.packets))

        with self.assertRaises(TypeError):
            RefreshPlan(
                plan.plan_id, target, plan.prepared_at_s, plan.joint_targets
            )
        with self.assertRaises(ValueError):
            replace(plan, packets=plan.packets[:-1])
        with self.assertRaises(ValueError):
            replace(plan, packets=list(plan.packets))
        with self.assertRaises(ValueError):
            replace(
                plan,
                packets=tuple(command(spec.motor_id, mode=0) for spec in self.specs),
            )

    def test_prepare_failure_only_attributes_the_joint_with_position_failure(self):
        core, station, owner = self._armed_station()
        target = Target(
            1,
            (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)),
            window=station.issue_window(1.0),
            owner=owner,
        )
        self.assertTrue(station.submit(target).accepted)

        def only_second_joint_outside(spec, joint_target):
            if spec.motor_id == 1:
                return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
            return None, joint_target, b"unused"

        with patch(
            "joint_controller.prepare_complete_reference",
            return_value=(DecisionCode.POSITION_OUT_OF_BOUNDS, None, None),
        ), patch(
            "joint_controller.prepare_reference_joint",
            side_effect=only_second_joint_outside,
        ):
            self.assertIsNone(core.prepare_refresh())

        snapshot = core.snapshot()
        self.assertEqual(snapshot.affected_joints, ("J2",))
        self.assertTrue(snapshot.faults[0].position_limit)

    def test_generic_prepare_failure_does_not_mislabel_every_joint_position_limited(self):
        core, station, owner = self._armed_station()
        target = Target(
            1,
            (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
             JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)),
            window=station.issue_window(1.0),
            owner=owner,
        )
        self.assertTrue(station.submit(target).accepted)

        with patch(
            "joint_controller.prepare_complete_reference",
            return_value=(DecisionCode.INVALID_ARGUMENT, None, None),
        ):
            self.assertIsNone(core.prepare_refresh())

        snapshot = core.snapshot()
        self.assertEqual(snapshot.state, State.STOPPED)
        self.assertFalse(snapshot.fault_latched)
        self.assertEqual(snapshot.faults, ())
        self.assertIsNone(snapshot.admitted_target)

    def test_owner_matching_uses_exact_type_and_boundary_records_reject_subclasses(self):
        class EqualAnyOwner(OwnerToken):
            def __eq__(self, other):
                return True

        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("owner-test")
        self.assertTrue(station.check().accepted)
        impostor = EqualAnyOwner("wrong-epoch", owner.generation, "other-client")

        self.assertTrue(owner_tokens_match(owner, OwnerToken(
            owner.epoch, owner.generation, owner.connection_id
        )))
        self.assertFalse(owner_tokens_match(impostor, owner))
        self.assertEqual(core.arm(impostor).code, DecisionCode.INVALID_OWNER)

        valid_joint = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
        window = IntentWindow(1, 0.0, 1.0)
        with self.assertRaises(ValueError):
            Target(1, (valid_joint,), window, impostor)
        with self.assertRaises(ValueError):
            JointDispatchedRecord(1, valid_joint, 0.0, impostor)
        with self.assertRaises(ValueError):
            JointDispatchAttempt(
                1, 1, valid_joint, WriteResult.COMPLETE, 0.0, impostor
            )

        for field in ("latest_owner", "current_owner"):
            with self.subTest(field=field), self.assertRaises(ValueError):
                Snapshot(
                    State.DISCONNECTED,
                    ("J1",),
                    (JointStatus(),),
                    None,
                    False,
                    (None,),
                    **{field: impostor},
                )

        fresh = JointCore(self.specs, clock=self.clock)
        self.assertEqual(fresh.arm(impostor).code, DecisionCode.INVALID_STATE)

    def test_late_failed_outcomes_settle_after_disconnect_and_allow_new_check(self):
        for result in (
            WriteResult.FAILED,
            WriteResult.PARTIAL,
            WriteResult.PREWRITE_DEADLINE,
        ):
            with self.subTest(result=result):
                clock = DeterministicClock(0.0)
                spec = JointSpec(
                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0,
                    "fixture: late receipt limits",
                )
                core = JointCore((spec,), clock=clock)
                station = FakeStation(core)
                self.assertTrue(station.connect().accepted)
                owner = station.claim("late-receipt")
                self.assertTrue(station.check().accepted)
                self.assertTrue(station.arm(owner).accepted)

                first = Target(
                    1,
                    (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),),
                    station.issue_window(1.0),
                    owner,
                )
                self.assertTrue(station.submit(first).accepted)
                first_plan = core.prepare_refresh()
                self.assertTrue(core.claim_dispatch(first_plan.plan_id, 0))
                self.assertTrue(core.dispatch_result(
                    first_plan.plan_id, 0, WriteResult.COMPLETE
                ).accepted)

                second = Target(
                    2,
                    (JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),),
                    station.issue_window(1.0),
                    owner,
                )
                self.assertTrue(station.submit(second).accepted)
                second_plan = core.prepare_refresh()
                self.assertTrue(core.claim_dispatch(second_plan.plan_id, 0))
                self.assertTrue(core.disconnect().accepted)
                self.assertFalse(core.begin_connect().accepted)

                receipt = core.dispatch_result(second_plan.plan_id, 0, result)
                self.assertFalse(receipt.accepted)
                snapshot = core.snapshot()
                self.assertIs(snapshot.state, State.DISCONNECTED)
                self.assertIsNone(snapshot.source)
                self.assertIsNone(snapshot.current_owner)
                self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
                self.assertEqual(snapshot.dispatch_attempts[0].sequence, 2)
                self.assertIs(snapshot.dispatch_attempts[0].result, result)
                self.assertTrue(snapshot.fault_latched)

                self.assertTrue(station.connect().accepted)
                new_owner = station.claim("new-owner")
                self.assertNotEqual(owner.generation, new_owner.generation)
                self.assertTrue(station.check(acknowledge_fault=True).accepted)
                self.assertTrue(station.arm(new_owner).accepted)
                self.assertIs(core.snapshot().state, State.ARMED)

    def test_complete_write_with_bad_end_clock_after_disconnect_keeps_full_record(self):
        class EndClock(DeterministicClock):
            fail = False

            def __call__(self):
                self.calls += 1
                return math.nan if self.fail else self.value

        clock = EndClock(0.0)
        spec = JointSpec(
            "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0,
            "fixture: late complete limits",
        )
        core = JointCore((spec,), clock=clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("late-complete")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner).accepted)
        target = Target(
            1,
            (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),),
            station.issue_window(1.0),
            owner,
        )
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        self.assertTrue(core.disconnect().accepted)

        clock.fail = True
        receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertFalse(receipt.accepted)
        clock.fail = False
        snapshot = core.snapshot()
        self.assertIs(snapshot.state, State.DISCONNECTED)
        self.assertIsNone(snapshot.source)
        self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.COMPLETE)
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertEqual(
            snapshot.faults[0].communication_error, CommunicationFailure.CLOCK_FAILURE
        )

        self.assertTrue(station.connect().accepted)
        new_owner = station.claim("late-complete-new-owner")
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertTrue(station.arm(new_owner).accepted)
        self.assertIs(core.snapshot().state, State.ARMED)

    def test_seeded_extreme_mappings_keep_reference_and_packet_congruent(self):
        rng = random.Random(9009)
        for index in range(40):
            reduction = 10 ** rng.uniform(-6, 6)
            direction = rng.choice((-1, 1))
            zero = rng.uniform(-2.5, 2.5)
            output_q = rng.uniform(-1.0, 1.0)
            q = direction * (output_q - zero) / reduction
            half_width = abs(raw_to_position(4)) / reduction
            spec = JointSpec(
                f"J{index}",
                index % 15,
                JointMap(reduction, direction, zero),
                q - half_width,
                q + half_width,
                "fixture: seeded software limits",
            )
            output_velocity = rng.uniform(-0.5, 0.5)
            output_torque = rng.uniform(-0.1, 0.1)
            requested = JointTarget(
                q,
                direction * output_velocity / reduction,
                direction * output_torque * reduction,
                2.0 * reduction ** 2,
                0.3 * reduction ** 2,
            )

            code, actual, packet = prepare_reference_joint(spec, requested)

            with self.subTest(index=index, reduction=reduction, direction=direction):
                self.assertIsNone(code)
                self.assertIsNotNone(actual)
                self.assertIsNotNone(packet)
                decoded = decode_command(packet)
                self.assertGreaterEqual(actual.q_rad, spec.q_min_rad)
                self.assertLessEqual(actual.q_rad, spec.q_max_rad)
                expected = spec.mapping.from_output(OutputSample(
                    decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
                ))
                self.assertEqual(actual.q_rad, expected.q_rad)
                self.assertEqual(actual.dq_rad_s, expected.dq_rad_s)
                self.assertEqual(actual.tau_nm, expected.tau_nm)
                self.assertEqual(actual.kp, decoded["kp"] * reduction ** 2)
                self.assertEqual(actual.kd, decoded["kd"] * reduction ** 2)
                self.assertEqual(
                    decoded["raw_position"], self._project(spec, requested.q_rad)
                )

                mapped = spec.mapping.to_output(requested)
                request_decoded = decode_command(command(
                    spec.motor_id,
                    mode=1,
                    rpm=mapped.rpm,
                    kd=mapped.kd,
                    torque=mapped.tau_nm,
                    watchdog=True,
                    position=mapped.q_rad,
                    kp=mapped.kp,
                ))
                for field in ("raw_rpm", "raw_torque", "raw_kp", "raw_kd"):
                    self.assertEqual(decoded[field], request_decoded[field])


if __name__ == "__main__":
    unittest.main()

```

FILE test_controller_owner.py
```
"""Targeted unit and acceptance tests for C08 controller owner generations."""

from dataclasses import FrozenInstanceError
import unittest

from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    JointSpec,
    MotorHealth,
    OwnerToken,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointTarget
from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP, SAMPLE


SOURCE = SourceIdentity("fixture", "owner-test", 1)


class ControllerOwnerTests(unittest.TestCase):
    def setUp(self):
        self.clock = DeterministicClock(0.0)
        self.specs = (
            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
        )
        self.valid_joints = (
            JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
        )

    def _armed_station(self, connection_id="human"):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim(connection_id)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner).accepted)
        return core, station, owner

    def test_owner_token_validation_and_immutability(self):
        tok = OwnerToken("epoch-1", 1, "client-1")
        self.assertEqual(tok.epoch, "epoch-1")
        self.assertEqual(tok.generation, 1)
        self.assertEqual(tok.connection_id, "client-1")

        with self.assertRaises(FrozenInstanceError):
            tok.generation = 2
        with self.assertRaises(FrozenInstanceError):
            tok.epoch = "other"
        with self.assertRaises(FrozenInstanceError):
            tok.connection_id = "other"

        for bad_epoch in ("", "a" * 65, 123, None, True, b"epoch"):
            with self.subTest(bad_epoch=bad_epoch), self.assertRaises(ValueError):
                OwnerToken(bad_epoch, 1, "client")

        for bad_gen in (-1, 0, 1 << 64, True, False, 1.5, "1", None):
            with self.subTest(bad_gen=bad_gen), self.assertRaises(ValueError):
                OwnerToken("epoch", bad_gen, "client")

        for bad_conn in ("", "c" * 65, 123, None, False, b"conn"):
            with self.subTest(bad_conn=bad_conn), self.assertRaises(ValueError):
                OwnerToken("epoch", 1, bad_conn)

    def test_delayed_old_generation_rejected_after_stop_and_rearm(self):
        core, station, old_owner = self._armed_station("conn-1")
        w1 = station.issue_window(1.0)
        t1 = Target(1, self.valid_joints, window=w1, owner=old_owner)
        self.assertTrue(station.submit(t1).accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)

        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().current_owner)

        new_owner = station.claim("conn-1")
        self.assertNotEqual(old_owner.generation, new_owner.generation)
        self.assertTrue(new_owner.generation > old_owner.generation)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(new_owner).accepted)

        w2 = station.issue_window(1.0)
        stale_target = Target(2, self.valid_joints, window=w2, owner=old_owner)
        rej = station.submit(stale_target)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)
        self.assertEqual(core.snapshot().last_sequence, 1)

        valid_target = Target(2, self.valid_joints, window=w2, owner=new_owner)
        acc = station.submit(valid_target)
        self.assertTrue(acc.accepted)
        self.assertEqual(core.snapshot().last_sequence, 2)
        self.assertEqual(core.snapshot().admitted_target, valid_target)

    def test_wrong_epoch_and_wrong_connection_rejected(self):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("client-A")
        self.assertTrue(station.check().accepted)
        w = station.issue_window(1.0)

        wrong_epoch = OwnerToken("wrong-epoch", owner.generation, owner.connection_id)
        wrong_conn = OwnerToken(owner.epoch, owner.generation, "client-B")

        rej_arm_epoch = core.arm(wrong_epoch)
        self.assertFalse(rej_arm_epoch.accepted)
        self.assertEqual(rej_arm_epoch.code, DecisionCode.INVALID_OWNER)

        rej_arm_conn = core.arm(wrong_conn)
        self.assertFalse(rej_arm_conn.accepted)
        self.assertEqual(rej_arm_conn.code, DecisionCode.INVALID_OWNER)

        self.assertTrue(station.arm(owner).accepted)
        rej_epoch = station.submit(Target(1, self.valid_joints, window=w, owner=wrong_epoch))
        self.assertFalse(rej_epoch.accepted)
        self.assertEqual(rej_epoch.code, DecisionCode.INVALID_OWNER)

        rej_conn = station.submit(Target(1, self.valid_joints, window=w, owner=wrong_conn))
        self.assertFalse(rej_conn.accepted)
        self.assertEqual(rej_conn.code, DecisionCode.INVALID_OWNER)

    def test_same_sequence_old_token_cannot_affect_ordering(self):
        core, station, owner1 = self._armed_station("conn-1")
        w1 = station.issue_window(1.0)
        t5 = Target(5, self.valid_joints, window=w1, owner=owner1)
        self.assertTrue(station.submit(t5).accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)

        self.assertTrue(station.stop().accepted)
        owner2 = station.claim("conn-2")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner2).accepted)

        w2 = station.issue_window(1.0)
        old_t5 = Target(5, self.valid_joints, window=w2, owner=owner1)
        rej = station.submit(old_t5)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)
        self.assertEqual(core.snapshot().last_sequence, 5)

        new_t6 = Target(6, self.valid_joints, window=w2, owner=owner2)
        self.assertTrue(station.submit(new_t6).accepted)
        self.assertEqual(core.snapshot().last_sequence, 6)

    def test_different_core_epoch_isolation(self):
        with self.assertRaises(TypeError):
            JointCore(self.specs, clock=self.clock, epoch="injected")

        core1 = JointCore(self.specs, clock=self.clock)
        core2 = JointCore(self.specs, clock=self.clock)
        station1 = FakeStation(core1)
        self.assertTrue(station1.connect().accepted)
        owner1 = station1.claim("conn-1")
        self.assertTrue(station1.check().accepted)
        self.assertTrue(station1.arm(owner1).accepted)

        station2 = FakeStation(core2)
        self.assertTrue(station2.connect().accepted)
        owner2 = station2.claim("conn-2")
        self.assertNotEqual(owner1.epoch, owner2.epoch)
        self.assertTrue(station2.check().accepted)

        cross_arm = core2.arm(owner1)
        self.assertFalse(cross_arm.accepted)
        self.assertEqual(cross_arm.code, DecisionCode.INVALID_OWNER)

        self.assertTrue(station2.arm(owner2).accepted)

        w2 = station2.issue_window(1.0)
        cross_target = Target(1, self.valid_joints, window=w2, owner=owner1)
        rej = station2.submit(cross_target)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)

    def test_no_owner_arm_rejected(self):
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)
        for spec in self.specs:
            self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertIs(core.snapshot().state, State.READY)

        bogus_token = OwnerToken("fake-epoch", 1, "fake-client")
        rej = core.arm(bogus_token)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)
        self.assertIs(core.snapshot().state, State.READY)

        missing_owner = core.arm(None)
        self.assertFalse(missing_owner.accepted)
        self.assertEqual(missing_owner.code, DecisionCode.INVALID_OWNER)

        real_owner = core.claim_owner("valid-client")
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertTrue(core.begin_check().accepted)
        for spec in self.specs:
            self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertTrue(core.arm(real_owner).accepted)
        self.assertIs(core.snapshot().state, State.ARMED)

    def test_takeover_during_vector_blocks_next_joint(self):
        core, station, owner_a = self._armed_station("owner-A")
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w, owner=owner_a)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        d0 = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertTrue(d0.accepted)
        self.assertIs(core.snapshot().state, State.MOVING)

        owner_b = core.claim_owner("owner-B")
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertEqual(core.snapshot().current_owner, owner_b)

        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))

    def test_receipt_after_revoke_records_actual_write_but_no_motion(self):
        core, station, owner = self._armed_station("owner-1")
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w, owner=owner)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        claim_time = self.clock.value

        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.STOPPED)

        receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertTrue(receipt.accepted)

        snap = core.snapshot()
        self.assertIs(snap.state, State.STOPPED)
        self.assertIsNone(snap.admitted_target)
        record = snap.dispatched_records[0]
        self.assertIsNotNone(record)
        self.assertEqual(record.sequence, 1)
        self.assertEqual(record.owner, owner)
        self.assertEqual(record.dispatched_at_s, claim_time)
        self.assertEqual(snap.dispatch_attempts[0].owner, owner)

    def test_old_prepared_plan_not_revived_by_new_owner(self):
        core, station, owner_a = self._armed_station("owner-A")
        w_a = station.issue_window(1.0)
        target_a = Target(1, self.valid_joints, window=w_a, owner=owner_a)
        self.assertTrue(station.submit(target_a).accepted)

        plan_a = core.prepare_refresh()
        self.assertIsNotNone(plan_a)

        owner_b = station.claim("owner-B")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner_b).accepted)

        self.assertFalse(core.claim_dispatch(plan_a.plan_id, 0))
        self.assertFalse(core.dispatch_result(plan_a.plan_id, 0, WriteResult.COMPLETE).accepted)

        w_b = station.issue_window(1.0)
        target_b = Target(2, self.valid_joints, window=w_b, owner=owner_b)
        self.assertTrue(station.submit(target_b).accepted)
        plan_b = core.prepare_refresh()
        self.assertIsNotNone(plan_b)
        self.assertEqual(plan_b.target, target_b)
        self.assertEqual(plan_b.owner, owner_b)

    def test_repeated_stop_reconnect_and_fault_invalidation(self):
        core, station, owner1 = self._armed_station("owner-1")
        self.assertEqual(owner1.generation, 1)

        self.assertTrue(station.stop().accepted)
        self.assertIsNone(core.snapshot().current_owner)

        owner2 = station.claim("owner-2")
        self.assertEqual(owner2.generation, 2)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner2).accepted)

        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertIsNone(core.snapshot().current_owner)

        self.assertTrue(station.disconnect().accepted)
        self.assertIs(core.snapshot().state, State.DISCONNECTED)
        self.assertIsNone(core.snapshot().current_owner)

        self.assertTrue(station.connect().accepted)
        self.assertIsNone(core.snapshot().current_owner)

        owner3 = station.claim("owner-3")
        self.assertEqual(owner3.generation, 3)
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertTrue(station.arm(owner3).accepted)
        self.assertIs(core.snapshot().state, State.ARMED)
        self.assertEqual(core.snapshot().current_owner, owner3)

    def test_exhausted_generation_fails_closed(self):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        core._next_generation = (1 << 64) - 1
        tok_max = station.claim("client")
        self.assertEqual(tok_max.generation, (1 << 64) - 1)
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(tok_max).accepted)

        window = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=window, owner=tok_max)
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)
        self.assertIs(core.snapshot().state, State.MOVING)

        with self.assertRaises(OverflowError):
            core.claim_owner("client-overflow")

        snapshot = core.snapshot()
        self.assertIs(snapshot.state, State.STOPPED)
        self.assertIsNone(snapshot.current_owner)
        self.assertIsNone(snapshot.admitted_target)
        self.assertIsNone(snapshot.prepared_plan)
        self.assertEqual(snapshot.latest_owner, tok_max)
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))

    def test_invalid_high_sequence_stale_owner_preserves_healthy_current_goal(self):
        core, station, owner = self._armed_station("owner-1")
        w = station.issue_window(1.0)
        t5 = Target(5, self.valid_joints, window=w, owner=owner)
        self.assertTrue(station.submit(t5).accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        stale_owner = OwnerToken("other-epoch", 999, "stale-client")
        high_target = Target(9999, self.valid_joints, window=w, owner=stale_owner)
        rej = station.submit(high_target)
        self.assertFalse(rej.accepted)
        self.assertEqual(rej.code, DecisionCode.INVALID_OWNER)

        snap = core.snapshot()
        self.assertEqual(snap.last_sequence, 5)
        self.assertEqual(snap.admitted_target, t5)
        self.assertIs(snap.state, State.ARMED)
        self.assertEqual(snap.current_owner, owner)

    def test_bounded_storage_after_many_claims(self):
        core = JointCore(self.specs, clock=self.clock)
        for i in range(10_000):
            token = core.claim_owner(f"client-{i % 10}")

        snap = core.snapshot()
        self.assertEqual(snap.latest_owner.generation, 10_000)
        self.assertEqual(snap.current_owner.generation, 10_000)

        # Inspect internal object state to verify O(1) storage
        self.assertFalse(hasattr(core, "_owner_history"))
        self.assertFalse(hasattr(core, "_owners"))
        self.assertFalse(hasattr(core, "claim"))
        self.assertIs(core._latest_owner, snap.latest_owner)
        self.assertFalse(hasattr(snap, "generation"))
        self.assertFalse(hasattr(snap, "latest_generation"))
        self.assertIs(core._current_owner, snap.current_owner)


if __name__ == "__main__":
    unittest.main()

```

FILE test_controller_expiry.py
```
"""Acceptance tests for C07 command expiry, window authority, and refresh dispatch."""

import math
import unittest
from unittest.mock import patch

from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    IntentWindow,
    JointSpec,
    MotorHealth,
    OwnerToken,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget
from im6014_serial import TransactionTimeoutError, WriteCancelledError, exchange
from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP


SOURCE = SourceIdentity("fixture", "expiry-test", 1)


class ControllerExpiryTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
        )
        self.valid_joints = (
            JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
            JointTarget(0.2, 0.0, 0.0, 1.0, 0.1),
        )

    def _armed_core(self, clock=None, *, feedback_max_age_s=1.0, max_window_s=1.0):
        if clock is None:
            clock = DeterministicClock(0.0)
        core = JointCore(
            self.specs,
            clock=clock,
            feedback_max_age_s=feedback_max_age_s,
            max_window_s=max_window_s,
        )
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("fixture")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner).accepted)
        return core, station, clock

    def test_expired_incoming_and_equality_boundary_reject_without_watermark_corruption(self):
        core, station, clock = self._armed_core()
        self.assertEqual(core.snapshot().last_sequence, -1)

        # Submit valid initial target to establish watermark at 5
        w0 = station.issue_window(0.5)
        t0 = Target(5, self.valid_joints, window=w0, owner=station.owner)
        self.assertTrue(station.submit(t0).accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t0)

        # Issue window valid for 0.4s (expires at 0.4s)
        w1 = station.issue_window(0.4)
        self.assertEqual(w1.created_at_s, 0.0)
        self.assertEqual(w1.expires_at_s, 0.4)

        # Exact equality boundary: now == expires_at_s is expired
        clock.value = 0.4
        t_boundary = Target(6, self.valid_joints, window=w1, owner=station.owner)
        d_boundary = station.submit(t_boundary)
        self.assertFalse(d_boundary.accepted)
        self.assertEqual(d_boundary.code, DecisionCode.EXPIRED)
        # Watermark and valid goal preserved
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t0)

        # Strictly past expiry: now > expires_at_s is expired
        clock.value = 0.40001
        t_past = Target(7, self.valid_joints, window=w1, owner=station.owner)
        d_past = station.submit(t_past)
        self.assertFalse(d_past.accepted)
        self.assertEqual(d_past.code, DecisionCode.EXPIRED)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t0)

    def test_delayed_computation_cannot_get_new_arrival_ttl(self):
        core, station, clock = self._armed_core()
        # Client requests window at time 0.0 valid for 0.2s
        w1 = station.issue_window(0.2)
        self.assertEqual(w1.expires_at_s, 0.2)

        # Client computation takes 0.3s (now is 0.3)
        clock.value = 0.3
        target1 = Target(1, self.valid_joints, window=w1, owner=station.owner)
        # Arrival at core does NOT grant new TTL; rejects as EXPIRED
        decision = station.submit(target1)
        self.assertFalse(decision.accepted)
        self.assertEqual(decision.code, DecisionCode.EXPIRED)
        self.assertEqual(core.snapshot().last_sequence, -1)
        self.assertIsNone(core.snapshot().admitted_target)

        # Client cannot forge a window with extended expiry
        forged_window = IntentWindow(w1.id, w1.created_at_s, 0.9)
        forged_target = Target(1, self.valid_joints, window=forged_window, owner=station.owner)
        d_forged = station.submit(forged_target)
        self.assertFalse(d_forged.accepted)
        self.assertEqual(d_forged.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().last_sequence, -1)

        # If station issues a new window w2, client cannot submit old computation with w1
        w2 = station.issue_window(0.2)
        d_old = station.submit(target1)
        self.assertFalse(d_old.accepted)
        self.assertEqual(d_old.code, DecisionCode.EXPIRED)

    def test_new_submission_cannot_revive_expired_moving_goal(self):
        core, station, clock = self._armed_core()
        first_window = station.issue_window(0.2)
        first = Target(5, self.valid_joints, window=first_window, owner=station.owner)
        self.assertTrue(station.submit(first).accepted)
        self.assertIsNotNone(station.refresh())
        self.assertIs(core.snapshot().state, State.MOVING)

        clock.value = first_window.expires_at_s
        fresh_window = station.issue_window(0.2)
        replacement = Target(6, self.valid_joints, window=fresh_window, owner=station.owner)
        decision = station.submit(replacement)

        self.assertFalse(decision.accepted)
        self.assertEqual(decision.code, DecisionCode.EXPIRED)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertEqual(core.snapshot().last_sequence, 5)

    def test_invalid_replacement_preserves_only_a_still_valid_goal(self):
        core, station, clock = self._armed_core()
        window = station.issue_window(0.2)
        current = Target(5, self.valid_joints, window=window, owner=station.owner)
        self.assertTrue(station.submit(current).accepted)

        invalid = Target(9, (self.valid_joints[0],), window=window, owner=station.owner)
        decision = station.submit(invalid)
        self.assertFalse(decision.accepted)
        self.assertEqual(decision.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().admitted_target, current)
        self.assertEqual(core.snapshot().last_sequence, 5)

        clock.value = window.expires_at_s
        fresh_window = station.issue_window(0.2)
        invalid_after_expiry = Target(10, (self.valid_joints[0],), window=fresh_window, owner=station.owner)
        expired_decision = station.submit(invalid_after_expiry)
        self.assertFalse(expired_decision.accepted)
        self.assertEqual(expired_decision.code, DecisionCode.EXPIRED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertEqual(core.snapshot().last_sequence, 5)

    def test_goal_expires_after_admission_and_before_prepare_or_actual_write(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)
        self.assertEqual(core.snapshot().admitted_target, target)

        # Goal expires after admission: clock moves to 0.55 before prepare_refresh
        clock.value = 0.55
        plan = core.prepare_refresh()
        self.assertIsNone(plan)
        # Goal is withdrawn and core disarms to STOPPED
        snap = core.snapshot()
        self.assertIsNone(snap.admitted_target)
        self.assertIsNone(snap.prepared_plan)
        self.assertIs(snap.state, State.STOPPED)

    def test_two_joint_first_write_then_expiry_or_revoke_blocks_second_and_records_only_first(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Joint 0 claim and complete write
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        d0 = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertTrue(d0.accepted)
        self.assertIs(core.snapshot().state, State.MOVING)

        # Check J0 record is stored, J1 is still None
        records_after_j0 = core.snapshot().dispatched_records
        self.assertIsNotNone(records_after_j0[0])
        self.assertEqual(records_after_j0[0].sequence, 1)
        self.assertEqual(records_after_j0[0].target, plan.joint_targets[0])
        self.assertIsNone(records_after_j0[1])

        # Expiry occurs before Joint 1 write
        clock.value = 0.55
        # Joint 1 claim fails due to expiry
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))

        # Core disarms to STOPPED, goal withdrawn, J0 record preserved, J1 remained unwritten
        snap = core.snapshot()
        self.assertIs(snap.state, State.STOPPED)
        self.assertIsNone(snap.admitted_target)
        self.assertIsNone(snap.prepared_plan)
        self.assertIsNotNone(snap.dispatched_records[0])
        self.assertIsNone(snap.dispatched_records[1])

    def test_reset_input_buffer_advancing_clock_causes_final_gate_cancellation_with_zero_mode1_write(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Fake bus where reset_input_buffer takes enough time to advance the clock past expiry
        written_packets = []

        class TimeAdvancingBus:
            def __init__(self):
                self.timeout = 0.1
                self.in_waiting = 0

            def reset_input_buffer(self):
                clock.value = 0.6  # Past window expiry of 0.5s!

            def write(self, packet):
                written_packets.append(packet)
                return len(packet)

            def read(self, size):
                return b""

        bus = TimeAdvancingBus()
        pkt = command(0, mode=1)

        with self.assertRaises(WriteCancelledError):
            exchange(
                bus,
                pkt,
                motor_id=0,
                deadline_s=0.2,
                before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
                on_write=lambda res: core.dispatch_result(plan.plan_id, 0, res),
            )

        # Zero mode-1 packets were written to the bus!
        self.assertEqual(written_packets, [])
        # Final gate cancellation disarmed core to STOPPED and withdrew goal
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)

    def test_expiry_during_feedback_wait_causes_no_later_write(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # First joint writes successfully
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)

        # Feedback wait takes long time, crossing expiry
        clock.value = 0.55

        # Attempting second joint write: claim fails because goal has expired
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
        # Core is disarmed to STOPPED
        self.assertIs(core.snapshot().state, State.STOPPED)

    def test_repeated_refresh_bounded_until_expiry(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(0.5)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)

        # At t=0.1, refresh succeeds
        clock.value = 0.1
        plan1 = station.refresh()
        self.assertIsNotNone(plan1)
        self.assertEqual(plan1.target, target)
        self.assertIs(core.snapshot().state, State.MOVING)

        # At t=0.2, second refresh succeeds with the same admitted goal
        clock.value = 0.2
        plan2 = station.refresh()
        self.assertIsNotNone(plan2)
        self.assertEqual(plan2.target, target)

        # At t=0.4, third refresh succeeds
        clock.value = 0.4
        plan3 = station.refresh()
        self.assertIsNotNone(plan3)

        # At t=0.5, window expires: refresh returns None and disarms to STOPPED
        clock.value = 0.5
        plan_expired = station.refresh()
        self.assertIsNone(plan_expired)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)

    def test_invalid_higher_seq_preserves_valid_goal(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        t5 = Target(5, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(t5).accepted)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        # High sequence with invalid joint target count
        bad_high = Target(100, (self.valid_joints[0],), window=w, owner=station.owner)
        d_bad = station.submit(bad_high)
        self.assertFalse(d_bad.accepted)
        self.assertEqual(d_bad.code, DecisionCode.INVALID_ARGUMENT)

        # Watermark is still 5, admitted goal is still t5
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

        # High sequence with out-of-range torque
        bad_torque = Target(100, (JointTarget(0, 0, 10.0, 1, .1), self.valid_joints[1]), window=w, owner=station.owner)
        d_torque = station.submit(bad_torque)
        self.assertFalse(d_torque.accepted)
        self.assertEqual(d_torque.code, DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot().last_sequence, 5)
        self.assertEqual(core.snapshot().admitted_target, t5)

    def test_stop_fault_disconnect_invalidate_plans_but_retain_sequence(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(10, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)
        self.assertEqual(core.snapshot().last_sequence, 10)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)
        self.assertEqual(core.snapshot().prepared_plan, plan)

        # Stop invalidates plan and goal, retains sequence watermark
        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.STOPPED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertEqual(core.snapshot().last_sequence, 10)

        # Re-arm and set up new target
        owner2 = station.claim("fixture-2")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner2).accepted)
        w2 = station.issue_window(1.0)
        target2 = Target(12, self.valid_joints, window=w2, owner=owner2)
        self.assertTrue(station.submit(target2).accepted)
        plan2 = core.prepare_refresh()
        self.assertIsNotNone(plan2)

        # Fault invalidates plan and goal, retains sequence
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertEqual(core.snapshot().last_sequence, 12)

        # Disconnect invalidates plan and goal, retains sequence
        self.assertTrue(station.disconnect().accepted)
        self.assertIs(core.snapshot().state, State.DISCONNECTED)
        self.assertIsNone(core.snapshot().admitted_target)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertEqual(core.snapshot().last_sequence, 12)

    def test_wrong_duplicate_out_of_order_claims_reject(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Wrong plan ID rejects
        self.assertFalse(core.claim_dispatch(plan.plan_id + 99, 0))

        # Out-of-order joint index rejects (index 1 before index 0)
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))

        # Correct claim of index 0
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))

        # Duplicate claim of index 0 rejects
        self.assertFalse(core.claim_dispatch(plan.plan_id, 0))

        # Out-of-bounds index rejects
        self.assertFalse(core.claim_dispatch(plan.plan_id, 5))
        self.assertFalse(core.claim_dispatch(plan.plan_id, -1))

        # One unresolved write blocks both reprepare and the next joint.
        self.assertIsNone(core.prepare_refresh())
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))
        self.assertFalse(core.dispatch_result(plan.plan_id + 99, 0, WriteResult.COMPLETE).accepted)
        self.assertFalse(core.dispatch_result(plan.plan_id, 1, WriteResult.COMPLETE).accepted)
        self.assertFalse(core.dispatch_result(plan.plan_id, 0, None).accepted)
        self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)

        # Joint 1 is claimable only after joint 0's outcome arrives.
        self.assertTrue(core.claim_dispatch(plan.plan_id, 1))
        self.assertTrue(core.dispatch_result(plan.plan_id, 1, WriteResult.COMPLETE).accepted)

    def test_stop_after_claim_preserves_completed_receipt_without_rearming(self):
        core, station, clock = self._armed_core()
        target = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        claim_time = clock.value

        self.assertTrue(core.stop().accepted)
        receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)

        self.assertTrue(receipt.accepted)
        snapshot = core.snapshot()
        self.assertIs(snapshot.state, State.STOPPED)
        self.assertIsNone(snapshot.admitted_target)
        self.assertIsNone(snapshot.prepared_plan)
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
        self.assertIsNone(core.prepare_refresh())
        self.assertFalse(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)

    def test_expiry_after_claim_preserves_completed_receipt_without_moving(self):
        core, station, clock = self._armed_core()
        window = station.issue_window(0.2)
        target = Target(1, self.valid_joints, window=window, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        claim_time = clock.value

        clock.value = window.expires_at_s
        receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)

        self.assertTrue(receipt.accepted)
        snapshot = core.snapshot()
        self.assertIs(snapshot.state, State.STOPPED)
        self.assertIsNone(snapshot.admitted_target)
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
        self.assertFalse(core.claim_dispatch(plan.plan_id, 1))

    def test_invalidated_plan_receipt_records_write_without_reviving_old_goal(self):
        core, station, clock = self._armed_core()
        first = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
        self.assertTrue(station.submit(first).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))

        replacement = Target(2, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
        self.assertTrue(station.submit(replacement).accepted)
        self.assertIsNone(core.snapshot().prepared_plan)
        self.assertIsNone(core.prepare_refresh())

        receipt = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertTrue(receipt.accepted)
        snapshot = core.snapshot()
        self.assertIs(snapshot.admitted_target, replacement)
        self.assertIs(snapshot.state, State.ARMED)
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertIsNone(snapshot.prepared_plan)

        replacement_plan = core.prepare_refresh()
        self.assertIsNotNone(replacement_plan)
        self.assertIs(replacement_plan.target, replacement)

    def test_complete_write_then_bad_timeout_feedback_still_counted_actually_dispatched(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Joint 0 claims and writes successfully
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        d_res = core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
        self.assertTrue(d_res.accepted)

        # Dispatched record is committed
        snap_after_write = core.snapshot()
        self.assertIsNotNone(snap_after_write.dispatched_records[0])
        self.assertEqual(snap_after_write.dispatched_records[0].sequence, 1)

        # Feedback from serial communication times out
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
        snap_after_failure = core.snapshot()
        self.assertIs(snap_after_failure.state, State.FAULT)
        # Dispatched record is STILL preserved despite communication failure!
        self.assertIsNotNone(snap_after_failure.dispatched_records[0])
        self.assertEqual(snap_after_failure.dispatched_records[0].sequence, 1)

    def test_partial_failed_write_faults(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)

        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # J0 claims, but write fails
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        d_fail = core.dispatch_result(plan.plan_id, 0, WriteResult.FAILED)
        self.assertFalse(d_fail.accepted)
        self.assertEqual(d_fail.code, DecisionCode.FAULT_LATCHED)

        # Latches fault on joint 0
        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.affected_joints, ("J1",))
        self.assertEqual(snap.faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)
        # Motion withdrawn, plan invalidated
        self.assertIsNone(snap.admitted_target)
        self.assertIsNone(snap.prepared_plan)
        # J0 was not completely written so dispatched record is None
        self.assertIsNone(snap.dispatched_records[0])
        self.assertEqual(snap.dispatch_attempts[0].result, WriteResult.FAILED)

    def test_partial_attempt_keeps_previous_complete_dispatched_record(self):
        core, station, clock = self._armed_core()
        first = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
        self.assertTrue(station.submit(first).accepted)
        plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
        self.assertTrue(core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE).accepted)

        next_target = Target(2, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
        self.assertTrue(core.submit_target(next_target).accepted)
        next_plan = core.prepare_refresh()
        self.assertTrue(core.claim_dispatch(next_plan.plan_id, 0))
        failed = core.dispatch_result(next_plan.plan_id, 0, WriteResult.PARTIAL)

        self.assertFalse(failed.accepted)
        snapshot = core.snapshot()
        self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
        self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.PARTIAL)
        self.assertEqual(snapshot.dispatch_attempts[0].sequence, 2)
        self.assertEqual(snapshot.faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)

    def test_complete_write_is_recorded_then_invalid_end_clock_faults_joint(self):
        for invalid_end_time in (math.nan, 0.5):
            with self.subTest(invalid_end_time=invalid_end_time):
                core, station, clock = self._armed_core(DeterministicClock(1.0))
                target = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
                self.assertTrue(station.submit(target).accepted)
                plan = core.prepare_refresh()
                claim_time = clock.value

                transaction_clock = DeterministicClock(0.0)
                writes = []

                class ClockFailingBus:
                    timeout = 0.1

                    def reset_input_buffer(self):
                        pass

                    def write(self, packet):
                        writes.append(packet)
                        clock.value = invalid_end_time
                        transaction_clock.value = 0.1
                        return len(packet)

                with patch("im6014_serial._monotonic", transaction_clock):
                    with self.assertRaises(TransactionTimeoutError):
                        exchange(
                            ClockFailingBus(), b"x" * 20, 0, deadline_s=0.05,
                            before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
                            on_write=lambda result: core.dispatch_result(plan.plan_id, 0, result),
                        )
                self.assertEqual(len(writes), 1)
                with self.assertRaises(ValueError):
                    core.snapshot()

                clock.value = claim_time
                snapshot = core.snapshot()
                self.assertIs(snapshot.state, State.FAULT)
                self.assertEqual(snapshot.faults[0].communication_error, CommunicationFailure.CLOCK_FAILURE)
                self.assertEqual(snapshot.dispatched_records[0].sequence, 1)
                self.assertEqual(snapshot.dispatched_records[0].dispatched_at_s, claim_time)
                self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.COMPLETE)
                self.assertIsNone(snapshot.admitted_target)
                self.assertIsNone(snapshot.prepared_plan)
                self.assertFalse(core.begin_check().accepted)
                self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)

    def test_exchange_reports_actual_write_before_enforcing_deadline(self):
        transaction_clock = DeterministicClock(0.0)
        results = []

        class DeadlineBus:
            timeout = 0.1

            def __init__(self, returned):
                self.returned = returned
                self.write_count = 0

            def reset_input_buffer(self):
                pass

            def write(self, packet):
                self.write_count += 1
                transaction_clock.value = 0.1
                return self.returned

        complete_bus = DeadlineBus(20)
        with patch("im6014_serial._monotonic", transaction_clock):
            with self.assertRaises(TransactionTimeoutError):
                exchange(complete_bus, b"x" * 20, 0, deadline_s=0.05, on_write=results.append)
        self.assertEqual(complete_bus.write_count, 1)
        self.assertEqual(results, [WriteResult.COMPLETE])

        transaction_clock.value = 0.0
        results.clear()
        partial_bus = DeadlineBus(1)
        with patch("im6014_serial._monotonic", transaction_clock):
            with self.assertRaises(TransactionTimeoutError):
                exchange(partial_bus, b"x" * 20, 0, deadline_s=0.05, on_write=results.append)
        self.assertEqual(partial_bus.write_count, 1)
        self.assertEqual(results, [WriteResult.PARTIAL])

    def test_expiry_after_successful_claim_reports_prewrite_deadline(self):
        core, station, _ = self._armed_core()
        target = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()

        transaction_clock = DeterministicClock(0.0)
        results = []

        class DeadlineBus:
            timeout = 0.1

            def __init__(self):
                self.write_count = 0

            def reset_input_buffer(self):
                pass

            def write(self, packet):
                self.write_count += 1
                return len(packet)

        def claim_then_expire():
            self.assertTrue(core.claim_dispatch(plan.plan_id, 0))
            transaction_clock.value = 0.05
            return True

        def record_result(result):
            results.append(result)
            return core.dispatch_result(plan.plan_id, 0, result)

        bus = DeadlineBus()
        with patch("im6014_serial._monotonic", transaction_clock):
            with self.assertRaises(TransactionTimeoutError):
                exchange(
                    bus, b"x" * 20, 0, deadline_s=0.05,
                    before_write=claim_then_expire,
                    on_write=record_result,
                )

        self.assertEqual(bus.write_count, 0)
        self.assertEqual(results, [WriteResult.PREWRITE_DEADLINE])
        snapshot = core.snapshot()
        self.assertIs(snapshot.state, State.FAULT)
        self.assertEqual(snapshot.faults[0].motor_id, 0)
        self.assertEqual(snapshot.faults[0].communication_error, CommunicationFailure.PREWRITE_DEADLINE)
        self.assertEqual(snapshot.dispatch_attempts[0].result, WriteResult.PREWRITE_DEADLINE)
        self.assertIsNone(snapshot.dispatched_records[0])
        self.assertIsNone(snapshot.admitted_target)
        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)

    def test_exchange_reports_raised_write_once_and_callback_failure_stops_feedback(self):
        results = []
        core, station, _ = self._armed_core()
        target = Target(1, self.valid_joints, window=station.issue_window(1.0), owner=station.owner)
        self.assertTrue(station.submit(target).accepted)
        plan = core.prepare_refresh()

        class RaisingBus:
            timeout = 0.1

            def __init__(self):
                self.write_count = 0

            def reset_input_buffer(self):
                pass

            def write(self, packet):
                self.write_count += 1
                raise OSError("driver failure")

        def record_result(result):
            results.append(result)
            return core.dispatch_result(plan.plan_id, 0, result)

        raising_bus = RaisingBus()
        with self.assertRaisesRegex(OSError, "driver failure"):
            exchange(
                raising_bus, b"x" * 20, 0,
                before_write=lambda: core.claim_dispatch(plan.plan_id, 0),
                on_write=record_result,
            )
        self.assertEqual(raising_bus.write_count, 1)
        self.assertEqual(results, [WriteResult.FAILED])
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().dispatch_attempts[0].result, WriteResult.FAILED)
        self.assertEqual(core.snapshot().faults[0].communication_error, CommunicationFailure.DRIVER_FAILURE)

        class CompleteBus:
            timeout = 0.1

            def __init__(self):
                self.write_count = 0
                self.read_called = False

            def reset_input_buffer(self):
                pass

            def write(self, packet):
                self.write_count += 1
                return len(packet)

            def read(self, size):
                self.read_called = True
                return b""

        bus = CompleteBus()
        callback_calls = []

        def broken_callback(result):
            callback_calls.append(result)
            raise RuntimeError("receipt failed")

        with self.assertRaisesRegex(RuntimeError, "receipt failed"):
            exchange(bus, b"x" * 20, 0, on_write=broken_callback)
        self.assertEqual(bus.write_count, 1)
        self.assertEqual(callback_calls, [WriteResult.COMPLETE])
        self.assertFalse(bus.read_called)

    def test_clock_regression_before_receive_cannot_replace_sample_or_timestamp(self):
        clock = DeterministicClock(10.0)
        core = JointCore(self.specs, clock=clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)

        # Valid receive at t=10.0
        sample_initial = JointSample(0.5, 0.0, 0.0)
        self.assertTrue(core.receive(0, sample_initial, HEALTHY_STOP).accepted)
        snap_initial = core.snapshot()
        self.assertEqual(snap_initial.joints[0].received_at, 10.0)
        self.assertEqual(snap_initial.joints[0].sample.q_rad, 0.5)

        # Clock regresses to 5.0
        clock.value = 5.0
        corrupt_sample = JointSample(9.9, 0.0, 0.0)
        with self.assertRaises(ValueError):
            core.receive(0, corrupt_sample, HEALTHY_STOP)

        # High-water mark check threw BEFORE overwriting observation
        # Previous observation remains uncorrupted
        clock.value = 10.0  # restore to valid non-regressing time for snapshot
        snap_after = core.snapshot()
        self.assertEqual(snap_after.joints[0].received_at, 10.0)
        self.assertEqual(snap_after.joints[0].sample.q_rad, 0.5)

    def test_invalid_clock_cannot_release_writes(self):
        core, station, clock = self._armed_core()
        w = station.issue_window(1.0)
        target = Target(1, self.valid_joints, window=w, owner=station.owner)
        self.assertTrue(station.submit(target).accepted)

        # Non-finite clock raises before prepare_refresh releases any plan
        clock.value = math.nan
        with self.assertRaises(ValueError):
            core.prepare_refresh()

        clock.value = 0.1
        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Regressing clock raises before claim_dispatch releases write
        clock.value = 0.05  # Regressed!
        with self.assertRaises(ValueError):
            core.claim_dispatch(plan.plan_id, 0)

        # Stop still works even if clock fails or raises
        clock.value = math.nan
        stop_decision = station.stop()
        self.assertTrue(stop_decision.accepted)

    def test_max_window_s_configuration_and_monotonically_increasing_window_ids(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, max_window_s=0.5)

        # Window exceeding max_window_s rejects
        with self.assertRaises(ValueError):
            core.issue_window(0.6)

        # Establish station authority before offering windows; claiming invalidates prior offers.
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("fixture")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner).accepted)

        # Monotonically increasing window IDs without wrap
        w0 = core.issue_window(0.2)
        w1 = core.issue_window(0.2)
        w2 = core.issue_window(0.5)
        self.assertEqual(w0.id, 0)
        self.assertEqual(w1.id, 1)
        self.assertEqual(w2.id, 2)
        self.assertTrue(w0.id < w1.id < w2.id)

        # Older window w0 is rejected
        t_old = Target(1, self.valid_joints, window=w0, owner=owner)
        d_old = station.submit(t_old)
        self.assertFalse(d_old.accepted)
        self.assertEqual(d_old.code, DecisionCode.EXPIRED)

        # Latest window w2 is accepted
        t_latest = Target(1, self.valid_joints, window=w2, owner=owner)
        d_latest = station.submit(t_latest)
        self.assertTrue(d_latest.accepted)


if __name__ == "__main__":
    unittest.main()

```

FILE test_controller.py
```
import unittest
from dataclasses import FrozenInstanceError
import math

from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    IntentWindow,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget


SAMPLE = JointSample(0.1, 0.0, 0.0)
HEALTHY_STOP = MotorHealth(mode=0, errors=0, warnings=0, timeout=False)
SOURCE = SourceIdentity("fixture", "controller-test", 1)


class FakeStation:
    def __init__(self, core):
        self.core = core
        self.writes = []
        self.owner = None

    def _write_stops(self):
        self.writes.extend(command(spec.motor_id, mode=0) for spec in self.core.joint_specs)

    def connect(self):
        decision = self.core.begin_connect()
        if not decision.accepted:
            return decision
        decision = self.core.connected(SOURCE)
        if decision.accepted:
            self._write_stops()
        return decision

    def claim(self, connection_id="human"):
        prior_state = self.core.snapshot().state
        self.owner = self.core.claim_owner(connection_id)
        if self.core.snapshot().state is State.STOPPED and prior_state is not State.STOPPED:
            self._write_stops()
        return self.owner

    def check(self, *, acknowledge_fault=False):
        decision = self.core.begin_check(acknowledge_fault=acknowledge_fault)
        if not decision.accepted:
            return decision
        self._write_stops()
        for spec in self.core.joint_specs:
            decision = self.core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP)
            if not decision.accepted:
                return decision
        return self.core.checked()

    def arm(self, owner: OwnerToken):
        return self.core.arm(owner)

    def issue_window(self, valid_for_s=0.2):
        return self.core.issue_window(valid_for_s)

    def submit(self, target):
        return self.core.submit_target(target)

    def refresh(self):
        plan = self.core.prepare_refresh()
        if plan is None:
            return None
        for index, packet in enumerate(plan.packets):
            if not self.core.claim_dispatch(plan.plan_id, index):
                break
            self.writes.append(packet)
            self.core.dispatch_result(plan.plan_id, index, WriteResult.COMPLETE)
        return plan

    def stop(self):
        decision = self.core.stop()
        if decision.accepted:
            self._write_stops()
        return decision

    def disconnect(self):
        return self.core.disconnect()


class DeterministicClock:
    def __init__(self, value=0.0):
        self.value = value
        self.calls = 0

    def __call__(self):
        self.calls += 1
        return self.value


class FeedbackAgeTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
        )

    def _ready_station(self, clock, *, feedback_max_age_s=1.0):
        core = JointCore(
            self.specs,
            clock=clock,
            feedback_max_age_s=feedback_max_age_s,
        )
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        station.claim("fixture")
        self.assertTrue(station.check().accepted)
        return core, station

    def test_feedback_age_configuration_is_finite_positive_and_typed(self):
        for value in (True, False, 0, -1.0, math.nan, math.inf, -math.inf, 10**400, "1"):
            with self.subTest(value=repr(value)), self.assertRaises(ValueError):
                JointCore(self.specs, feedback_max_age_s=value)
        with self.assertRaises(ValueError):
            JointCore(self.specs, clock=0)

    def test_zero_timestamp_and_exact_freshness_boundary(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)

        received = core.snapshot()
        self.assertEqual(tuple(joint.received_at for joint in received.joints), (0.0, 0.0))
        self.assertEqual(received.feedback_ages_s, (0.0, 0.0))

        clock.value = 1.0
        at_boundary = core.snapshot()
        self.assertEqual(at_boundary.feedback_ages_s, (1.0, 1.0))
        self.assertTrue(core.arm(station.owner).accepted)

        with self.assertRaises(FrozenInstanceError):
            at_boundary.joints[0].received_at = 1.0
        with self.assertRaises(TypeError):
            at_boundary.feedback_ages_s[0] = 0.0

    def test_checked_rejects_feedback_older_than_limit(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)
        for spec in self.specs:
            self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)

        clock.value = 1.000001
        rejected = core.checked()
        self.assertEqual(rejected.code, DecisionCode.STALE_FEEDBACK)
        self.assertIs(core.snapshot().state, State.CHECKING)
        self.assertFalse(core.snapshot().fault_latched)
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.CHECKING)

    def test_bad_id_and_observation_do_not_refresh_receipt_time(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        initial = core.snapshot()
        calls_before = clock.calls

        clock.value = 0.5
        self.assertEqual(
            core.receive(14, SAMPLE, HEALTHY_STOP).code,
            DecisionCode.UNKNOWN_JOINT,
        )
        self.assertEqual(
            core.receive(self.specs[0].motor_id, object(), HEALTHY_STOP).code,
            DecisionCode.INVALID_OBSERVATION,
        )
        self.assertEqual(clock.calls, calls_before)
        self.assertEqual(
            tuple(joint.received_at for joint in core.snapshot().joints),
            tuple(joint.received_at for joint in initial.joints),
        )

        clock.value = 1.000001
        self.assertEqual(core.arm(station.owner).code, DecisionCode.STALE_FEEDBACK)

    def test_fresh_j1_cannot_hide_stale_j2_from_arm_or_tick(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        station.writes.clear()

        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        clock.value = 1.000001
        before_writes = list(station.writes)
        rejected = station.arm(station.owner)
        self.assertEqual(rejected.code, DecisionCode.STALE_FEEDBACK)
        self.assertIs(core.snapshot().state, State.READY)
        self.assertEqual(station.writes, before_writes)

        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        station.writes.clear()
        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(station.arm(station.owner).accepted)
        clock.value = 1.000001
        before_writes = list(station.writes)
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(station.writes, before_writes)

    def test_disconnect_invalidates_age_and_stale_fault_needs_acknowledged_check(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        self.assertTrue(station.arm(station.owner).accepted)

        clock.value = 1.1
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        before_disconnect = core.snapshot()

        self.assertTrue(station.disconnect().accepted)
        disconnected = core.snapshot()
        self.assertTrue(all(joint.received_at is None for joint in disconnected.joints))
        self.assertEqual(disconnected.feedback_ages_s, (None, None))
        self.assertEqual(before_disconnect.feedback_ages_s, (1.1, 1.1))
        self.assertTrue(disconnected.fault_latched)

        self.assertTrue(station.connect().accepted)
        writes_after_connect = list(station.writes)
        self.assertEqual(
            station.check().code,
            DecisionCode.FAULT_ACK_REQUIRED,
        )
        self.assertEqual(station.writes, writes_after_connect)

        station.writes.clear()
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertEqual(
            station.writes,
            [command(spec.motor_id, mode=0) for spec in self.specs],
        )
        self.assertIs(core.snapshot().state, State.READY)
        self.assertFalse(core.snapshot().fault_latched)


def core_at(test, state, clock=None):
    if clock is None:
        clock = DeterministicClock(0.0)
    core = JointCore(test.specs, clock=clock)
    station = FakeStation(core)
    if state is State.DISCONNECTED:
        return core
    if state is State.CONNECTING:
        test.assertTrue(core.begin_connect().accepted)
        return core

    test.assertTrue(station.connect().accepted)
    if state is State.CONNECTED:
        return core
    owner = station.claim("fixture")
    if state is State.CHECKING:
        test.assertTrue(core.begin_check().accepted)
        return core

    test.assertTrue(station.check().accepted)
    if state is State.READY:
        return core
    if state is State.ARMED:
        test.assertTrue(station.arm(owner).accepted)
        return core
    if state is State.MOVING:
        test.assertTrue(station.arm(owner).accepted)
        window = station.issue_window(1.0)
        target = Target(
            0,
            (
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        test.assertTrue(core.submit_target(target).accepted)
        test.assertIsNotNone(station.refresh())
        return core
    if state is State.STOPPED:
        test.assertTrue(station.arm(owner).accepted)
        test.assertTrue(station.stop().accepted)
        return core
    if state is State.FAULT:
        test.assertTrue(station.arm(owner).accepted)
        test.assertTrue(core.receive(
            test.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=1, warnings=0, timeout=False),
        ).accepted)
        return core
    raise AssertionError(f"{state} is not reachable")


class ControllerStateTests(unittest.TestCase):
    def setUp(self):
        self.clock = lambda: 0.0
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
        )


    def test_joint_set_is_nonempty_unique_and_owned(self):
        mapping = JointMap(1, 1, 0.0)
        with self.assertRaises(ValueError):
            JointCore(())
        with self.assertRaises(ValueError):
            JointCore((
                JointSpec("J1", 0, mapping, -2.0, 2.0, "fixture: software position limits"),
                JointSpec("J1", 1, mapping, -2.0, 2.0, "fixture: software position limits"),
            ))
        with self.assertRaises(ValueError):
            JointCore((
                JointSpec("J1", 0, mapping, -2.0, 2.0, "fixture: software position limits"),
                JointSpec("J2", 0, mapping, -2.0, 2.0, "fixture: software position limits"),
            ))
        with self.assertRaises(ValueError):
            JointSpec("J1", True, mapping, -2.0, 2.0, "fixture: software position limits")

        supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, "fixture: software position limits")]
        core = JointCore(supplied, clock=self.clock)
        supplied.clear()
        self.assertEqual(tuple(spec.name for spec in core.joint_specs), ("J1",))

    def test_health_and_source_records_reject_invalid_values(self):
        for kwargs in (
            dict(mode=True, errors=0, warnings=0, timeout=False),
            dict(mode=0, errors=True, warnings=0, timeout=False),
            dict(mode=0, errors=0, warnings=-1, timeout=False),
            dict(mode=0, errors=0, warnings=0, timeout=1),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                MotorHealth(**kwargs)
        with self.assertRaises(ValueError):
            SourceIdentity("other", "x", 1)

    def test_fake_lifecycle_writes_only_after_accepted_actions(self):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        expected = [command(spec.motor_id, mode=0) for spec in self.specs]

        self.assertFalse(station.check().accepted)
        self.assertFalse(station.stop().accepted)
        self.assertEqual(station.writes, [])

        self.assertTrue(station.connect().accepted)
        self.assertEqual(station.writes, expected)
        station.writes.clear()
        self.assertFalse(station.connect().accepted)
        self.assertEqual(station.writes, [])

        owner = station.claim("fixture")
        self.assertTrue(station.check().accepted)
        self.assertEqual(station.writes, expected)
        self.assertIs(core.snapshot().state, State.READY)
        station.writes.clear()
        self.assertTrue(station.arm(owner).accepted)
        self.assertIs(core.snapshot().state, State.ARMED)
        self.assertTrue(station.stop().accepted)
        self.assertEqual(station.writes, expected)
        self.assertIs(core.snapshot().state, State.STOPPED)

    def test_arm_requires_current_stop_feedback(self):
        core = core_at(self, State.READY)
        owner = core.snapshot().latest_owner
        self.assertTrue(core.receive(1, SAMPLE, MotorHealth(1, 0, 0, False)))
        before = core.snapshot()
        self.assertEqual(core.arm(owner).code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot(), before)
        self.assertTrue(core.receive(1, SAMPLE, HEALTHY_STOP))
        self.assertTrue(core.arm(owner))

    def test_check_requires_every_healthy_joint_in_stop_mode(self):
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)

        before = core.snapshot()
        rejected = core.checked()
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.OBSERVATIONS_INCOMPLETE)
        self.assertEqual(core.snapshot(), before)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        foc = MotorHealth(mode=1, errors=0, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, foc).accepted)
        before = core.snapshot()
        self.assertEqual(core.checked().code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot(), before)

        unhealthy = MotorHealth(mode=0, errors=0, warnings=1, timeout=False)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, unhealthy).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        before = core.snapshot()
        rejected = core.checked()
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.INVALID_STATE)
        self.assertEqual(core.snapshot(), before)

        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP))
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertTrue(core.begin_check(acknowledge_fault=True))
        self.assertTrue(core.snapshot().fault_latched)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP))
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertIs(core.snapshot().state, State.READY)

    def test_fault_survives_stop_disconnect_reconnect_and_healthy_packets(self):
        core = JointCore(self.specs, clock=self.clock)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("fixture")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner).accepted)

        bad_health = MotorHealth(mode=0, errors=4, warnings=2, timeout=True)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, bad_health).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        station.writes.clear()
        self.assertTrue(station.stop().accepted)
        self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        self.assertTrue(station.disconnect().accepted)
        disconnected = core.snapshot()
        self.assertIs(disconnected.state, State.DISCONNECTED)
        self.assertTrue(disconnected.fault_latched)
        self.assertTrue(all(not joint.valid for joint in disconnected.joints))
        self.assertIsNone(disconnected.source)

        self.assertTrue(station.connect().accepted)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.snapshot().fault_latched)
        before = core.snapshot()
        self.assertEqual(core.begin_check().code, DecisionCode.FAULT_ACK_REQUIRED)
        self.assertEqual(core.snapshot(), before)

        station.writes.clear()
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
        self.assertIs(core.snapshot().state, State.READY)
        self.assertFalse(core.snapshot().fault_latched)

    def test_disconnect_and_new_connection_invalidate_observations(self):
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        prior = core.snapshot()
        self.assertTrue(prior.joints[0].valid)

        self.assertTrue(core.disconnect().accepted)
        self.assertTrue(all(not joint.valid for joint in core.snapshot().joints))
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SourceIdentity("fixture", "controller-test", 2)).accepted)
        self.assertTrue(all(not joint.valid for joint in core.snapshot().joints))
        self.assertTrue(prior.joints[0].valid)

    def test_snapshots_are_immutable_owned_values(self):
        core = JointCore(self.specs, clock=self.clock)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        before = core.snapshot()
        self.assertIsInstance(before.joints, tuple)
        self.assertIsInstance(before.joint_names, tuple)
        self.assertIsInstance(before.dispatch_attempts, tuple)
        self.assertEqual(before.dispatch_attempts, (None, None))
        self.assertFalse(hasattr(core, "pending_target"))
        self.assertFalse(hasattr(before, "pending_target"))

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        after = core.snapshot()
        self.assertFalse(before.joints[0].valid)
        self.assertTrue(after.joints[0].valid)
        with self.assertRaises(FrozenInstanceError):
            after.state = State.FAULT
        with self.assertRaises(FrozenInstanceError):
            after.joints[0].health = HEALTHY_STOP
        with self.assertRaises(TypeError):
            after.joints[0] = before.joints[0]
        with self.assertRaises(TypeError):
            after.dispatch_attempts[0] = before.dispatch_attempts[0]

    def test_invalid_transition_matrix_preserves_snapshot(self):
        rejected = {
            State.DISCONNECTED: ("connected", "begin_check", "checked", "arm", "stop"),
            State.CONNECTING: ("begin_connect", "begin_check", "checked", "arm", "stop"),
            State.CONNECTED: ("begin_connect", "connected", "checked", "arm"),
            State.CHECKING: ("begin_connect", "connected", "begin_check", "arm"),
            State.READY: ("begin_connect", "connected", "begin_check", "checked"),
            State.ARMED: ("begin_connect", "connected", "begin_check", "checked", "arm"),
            State.MOVING: ("begin_connect", "connected", "begin_check", "checked", "arm"),
            State.STOPPED: ("begin_connect", "connected", "checked", "arm"),
            State.FAULT: ("begin_connect", "connected", "begin_check", "checked", "arm"),
        }

        for state, events in rejected.items():
            for event in events + ("wrong_joint",):
                with self.subTest(state=state, event=event):
                    core = core_at(self, state)
                    station = FakeStation(core)
                    before = core.snapshot()
                    arm_owner = core.snapshot().current_owner or OwnerToken(
                        "matrix-epoch", 1, "matrix-client"
                    )
                    action = {
                        "begin_connect": station.connect,
                        "connected": lambda: core.connected(SOURCE),
                        "begin_check": station.check,
                        "checked": core.checked,
                        "arm": lambda: core.arm(arm_owner),
                        "stop": station.stop,
                        "wrong_joint": lambda: core.receive(14, SAMPLE, HEALTHY_STOP),
                    }[event]
                    decision = action()
                    self.assertFalse(decision.accepted)
                    self.assertFalse(decision)
                    self.assertEqual(station.writes, [])
                    self.assertEqual(core.snapshot(), before)


class JointFaultTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
        )

    def _ready_core(self, clock=None, *, feedback_max_age_s=1.0):
        if clock is None:
            clock = DeterministicClock(0.0)
        core = JointCore(
            self.specs,
            clock=clock,
            feedback_max_age_s=feedback_max_age_s,
        )
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        core.claim_owner("fixture")
        self.assertTrue(core.begin_check().accepted)
        for spec in self.specs:
            self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        return core

    def test_stale_j2_attributes_only_stale_joint_with_refreshed_j1(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock, feedback_max_age_s=1.0)
        self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)
        self.assertIs(core.snapshot().state, State.ARMED)

        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)

        clock.value = 1.1
        self.assertTrue(core.tick().accepted)
        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.affected_joints, ("J2",))
        self.assertEqual(len(snap.faults), 1)

        j2_fault = snap.faults[0]
        self.assertEqual(j2_fault.name, "J2")
        self.assertEqual(j2_fault.motor_id, 1)
        self.assertTrue(j2_fault.stale)
        self.assertEqual(j2_fault.errors, 0)
        self.assertEqual(j2_fault.warnings, 0)
        self.assertFalse(j2_fault.timeout)
        self.assertIsNone(j2_fault.communication_error)

        self.assertNotIn("J1", snap.affected_joints)
        self.assertEqual(snap.joints[0].received_at, 0.8)
        self.assertEqual(snap.joints[1].received_at, 0.0)

    def test_unknown_bits_and_32bit_error_mask_retained(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock)
        self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)

        unknown_errors = 0x80000004
        status = MotorHealth(mode=0, errors=unknown_errors, warnings=5, timeout=True)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, status).accepted)

        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertEqual(snap.affected_joints, ("J1",))
        j1_fault = snap.faults[0]
        self.assertEqual(j1_fault.errors, unknown_errors)
        self.assertEqual(j1_fault.errors & 0x80000000, 0x80000000)
        self.assertEqual(j1_fault.warnings, 5)
        self.assertTrue(j1_fault.timeout)
        self.assertFalse(j1_fault.stale)

        for kwargs in (
            dict(mode=0, errors=-1, warnings=0, timeout=False),
            dict(mode=0, errors=0x1_0000_0000, warnings=0, timeout=False),
            dict(mode=0, errors=0, warnings=-1, timeout=False),
            dict(mode=0, errors=0, warnings=8, timeout=False),
            dict(mode=0, errors=0, warnings=0, timeout="True"),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                MotorHealth(**kwargs)

        for kwargs in (
            dict(name="J1", motor_id=0, errors=-1),
            dict(name="J1", motor_id=0, errors=0x1_0000_0000),
            dict(name="J1", motor_id=0, warnings=-1),
            dict(name="J1", motor_id=0, warnings=8),
            dict(name="J1", motor_id=0, timeout=1),
            dict(name="J1", motor_id=0, stale=1),
            dict(name="", motor_id=0),
            dict(name="J1", motor_id=15),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                JointFault(**kwargs)

    def test_healthy_after_fault_preserves_latched_attribution(self):
        core = self._ready_core()
        self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)

        unhealthy = MotorHealth(mode=0, errors=0x02, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, unhealthy).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))
        self.assertEqual(core.snapshot().faults[0].errors, 0x02)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        snap = core.snapshot()

        self.assertTrue(snap.joints[0].healthy)
        self.assertEqual(snap.joints[0].errors, 0)
        self.assertEqual(snap.joints[0].health.errors, 0)

        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.affected_joints, ("J1",))
        self.assertEqual(len(snap.faults), 1)
        self.assertEqual(snap.faults[0].errors, 0x02)
        self.assertNotEqual(snap.faults[0].errors, 0)

    def test_multiple_faults_on_joint_preserves_prior_flags_with_bounded_storage(self):
        core = self._ready_core()

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x01, warnings=1, timeout=False),
        ).accepted)

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x04, warnings=2, timeout=True),
        ).accepted)

        self.assertTrue(core.communication_failed(
            self.specs[0].motor_id,
            CommunicationFailure.DRIVER_FAILURE,
        ).accepted)

        snap = core.snapshot()
        self.assertEqual(len(snap.faults), 1)
        j1_fault = snap.faults[0]
        self.assertEqual(j1_fault.name, "J1")
        self.assertEqual(j1_fault.errors, 0x05)
        self.assertEqual(j1_fault.warnings, 3)
        self.assertTrue(j1_fault.timeout)
        self.assertEqual(j1_fault.communication_error, CommunicationFailure.DRIVER_FAILURE)
        self.assertIn(CommunicationFailure.DRIVER_FAILURE, j1_fault.communication_errors)

        for _ in range(10):
            self.assertTrue(core.receive(
                self.specs[0].motor_id,
                SAMPLE,
                MotorHealth(mode=0, errors=0x02, warnings=0, timeout=False),
            ).accepted)
        self.assertEqual(len(core.snapshot().faults), 1)
        self.assertEqual(core.snapshot().faults[0].errors, 0x07)

    def test_communication_failures_with_fixed_enum_codes(self):
        for code in (
            CommunicationFailure.TIMEOUT,
            CommunicationFailure.INVALID_FEEDBACK,
            CommunicationFailure.DRIVER_FAILURE,
        ):
            with self.subTest(code=code):
                core = self._ready_core()
                decision = core.communication_failed(self.specs[0].motor_id, code)
                self.assertTrue(decision.accepted)
                snap = core.snapshot()
                self.assertIs(snap.state, State.FAULT)
                self.assertEqual(snap.affected_joints, ("J1",))
                fault = snap.faults[0]
                self.assertEqual(fault.communication_error, code)
                self.assertFalse(fault.timeout)
                self.assertEqual(snap.joints[0].communication_error, code)
                self.assertFalse(snap.joints[0].healthy)

        core = self._ready_core()
        self.assertTrue(core.communication_failed(self.specs[1].motor_id, CommunicationFailure.INVALID_FEEDBACK).accepted)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))
        self.assertEqual(core.snapshot().faults[0].communication_error, CommunicationFailure.INVALID_FEEDBACK)

    def test_current_communication_status_clears_without_erasing_cause(self):
        core = self._ready_core()
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT))
        before = core.snapshot()
        self.assertTrue(core.receive(0, SAMPLE, HEALTHY_STOP))
        after = core.snapshot()
        self.assertTrue(after.joints[0].healthy)
        self.assertIsNone(after.joints[0].communication_error)
        self.assertEqual(after.faults, before.faults)
        self.assertIs(after.state, State.FAULT)

    def test_fault_record_requires_bounded_consistent_communication_codes(self):
        a, b = CommunicationFailure.TIMEOUT, CommunicationFailure.DRIVER_FAILURE
        for kwargs in (dict(communication_error=a, communication_errors=(b,)),
                       dict(communication_errors=(a, a)),
                       dict(communication_errors=(a,) * 4)):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                JointFault("J1", 0, **kwargs)
        record = JointFault("J1", 0, communication_error=a, communication_errors=(a, b))
        self.assertIs(record.communication_error, a)
        self.assertEqual(record.communication_errors, (a, b))

    def test_unknown_ids_and_invalid_codes_reject_unchanged(self):
        core = self._ready_core()
        before = core.snapshot()

        self.assertEqual(core.communication_failed(0, "timeout").code,
                         DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot(), before)

        rejected_id = core.communication_failed(14, CommunicationFailure.TIMEOUT)
        self.assertFalse(rejected_id)
        self.assertEqual(rejected_id.code, DecisionCode.UNKNOWN_JOINT)
        self.assertEqual(core.snapshot(), before)

        self.assertEqual(
            core.communication_failed(True, CommunicationFailure.TIMEOUT).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed("0", CommunicationFailure.TIMEOUT).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(core.snapshot(), before)

        self.assertEqual(
            core.communication_failed(0, "unrecognized_failure").code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, RuntimeError("comm timeout")).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, 999).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, None).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(core.snapshot(), before)

    def test_failed_recovery_retains_causes(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock, feedback_max_age_s=1.0)
        owner = core.snapshot().latest_owner
        self.assertTrue(core.arm(owner).accepted)

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x04, warnings=0, timeout=False),
        ).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        rejected = core.begin_check(acknowledge_fault=False)
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.FAULT_ACK_REQUIRED)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
        self.assertIs(core.snapshot().state, State.CHECKING)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertEqual(core.checked().code, DecisionCode.OBSERVATIONS_INCOMPLETE)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        non_stop = MotorHealth(mode=1, errors=0, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, non_stop).accepted)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertEqual(core.checked().code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        clock.value = 2.0
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertEqual(core.checked().code, DecisionCode.STALE_FEEDBACK)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertEqual(core.arm(owner).code, DecisionCode.INVALID_STATE)

    def test_successful_recovery_clears_fault_causes(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("fixture")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner).accepted)

        self.assertTrue(core.communication_failed(
            self.specs[1].motor_id,
            CommunicationFailure.TIMEOUT,
        ).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.disconnect().accepted)
        self.assertIs(core.snapshot().state, State.DISCONNECTED)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.connect().accepted)
        self.assertIs(core.snapshot().state, State.CONNECTED)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        snap = core.snapshot()
        self.assertIs(snap.state, State.READY)
        self.assertFalse(snap.fault_latched)
        self.assertEqual(snap.faults, ())
        self.assertEqual(snap.affected_joints, ())

    def test_independent_second_core_unchanged_by_fault(self):
        specs2 = (
            JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
            JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, "fixture: software position limits"),
        )
        clock = DeterministicClock(0.0)
        core1 = JointCore(self.specs, clock=clock)
        core2 = JointCore(specs2, clock=clock)

        station1 = FakeStation(core1)
        station2 = FakeStation(core2)
        self.assertTrue(station1.connect().accepted)
        owner1 = station1.claim("fixture-1")
        self.assertTrue(station1.check().accepted)
        self.assertTrue(station1.arm(owner1).accepted)

        self.assertTrue(station2.connect().accepted)
        owner2 = station2.claim("fixture-2")
        self.assertTrue(station2.check().accepted)
        self.assertTrue(station2.arm(owner2).accepted)

        self.assertTrue(core1.communication_failed(
            self.specs[0].motor_id,
            CommunicationFailure.DRIVER_FAILURE,
        ).accepted)
        snap1 = core1.snapshot()
        self.assertIs(snap1.state, State.FAULT)
        self.assertTrue(snap1.fault_latched)
        self.assertEqual(snap1.affected_joints, ("J1",))

        snap2 = core2.snapshot()
        self.assertIs(snap2.state, State.ARMED)
        self.assertFalse(snap2.fault_latched)
        self.assertEqual(snap2.faults, ())
        self.assertEqual(snap2.affected_joints, ())
        self.assertTrue(station2.stop().accepted)
        self.assertIs(core2.snapshot().state, State.STOPPED)

    def test_immutability_of_fault_records_and_snapshot_collections(self):
        fault = JointFault("J1", 0, errors=1, warnings=2, timeout=True)
        with self.assertRaises(FrozenInstanceError):
            fault.errors = 0
        with self.assertRaises(FrozenInstanceError):
            fault.name = "other"

        core = self._ready_core()
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
        snap = core.snapshot()

        self.assertIsInstance(snap.faults, tuple)
        self.assertIsInstance(snap.affected_joints, tuple)
        with self.assertRaises(FrozenInstanceError):
            snap.faults[0].timeout = False
        with self.assertRaises(TypeError):
            snap.faults[0] = fault
        with self.assertRaises(TypeError):
            snap.affected_joints[0] = "J2"







if __name__ == "__main__":
    unittest.main()

```

FILE docs/joint-api.md
```
# Joint mapping

The bench GUI and CLI use actuator output units. The mapping API converts external joint units before packet encoding. It does not open a serial port.

```python
from joint_mapping import JointMap, JointTarget, OutputSample

mapping = JointMap(reduction=3, direction=-1, zero_output_rad=0.25)
output = mapping.to_output(JointTarget(-0.5, 2, 12, 36, 9))
joint = mapping.from_output(OutputSample(output.q_rad, output.rpm, output.tau_nm))
```

This example produces an output position of 1.75 rad, speed of about -57.2958 rpm, torque of -4 Nm, Kp of 4 and Kd of 1. Reverse conversion recovers the original position, speed and torque. The resulting torque exceeds the bench encoder's ±3.5 Nm policy, so encoding it rejects the command. Mapping never clips a value to make it pass.

`JointTarget` uses rad, rad/s and Nm. `OutputTarget` uses rad, rpm and Nm. The offset is in actuator output radians. The internal motor reduction stays inside the codec. Ideal gain conversion assumes compatible stiffness and damping definitions. Friction, backlash, efficiency and physical calibration remain unmeasured.

Run a single offline acceptance check from the repository root:

```sh
.venv/bin/python -B scripts/check_milestone.py B11
```

The command prints the path to its receipt and raw logs under `evidence/runs`. The test checks ratios 1, 3 and 6 in both directions, nonzero offsets, independent numeric anchors and invalid values.

## Passive port inspection

```python
from im6014_port import PortConfig, inspect_port
from spin_5rpm import PORT

report = inspect_port(PortConfig(PORT, 6_000_000), ports=())
```

`ports=()` makes this example use only the configured by-id basename. The report names its evidence source and does not establish communication with the motor. Normal inspection can also read passive OS enumeration metadata. Known wrong serial numbers or interfaces reject with expected and observed values. Unknown metadata stays explicitly unverified.

For an alternate adapter route, set both `expected_serial=None` and `expected_channel=None`. This removes the FTDI identity assertion. It does not bypass later device ownership checks or establish motor communication. The bench GUI and CLI default to the recorded FTDI serial and interface 3.

## Diagnostic capture

`PacketCapture` holds at most 256 records by default. Each record contains capped packet prefixes, allowlisted decoded fields, a fixed outcome code, and explicit source and connection metadata. Exported snapshots own their lists and dictionaries. Exception messages, environment values and arbitrary serial-object fields are excluded. An unavailable or regressing capture end clock exports `ended_s=None` and preserves the exchange result or original error. An invalid start clock rejects before exchange.

The GUI includes its ring in the existing JSON snapshot. The CLI enables it in `main`; direct `run(bus, args, log)` callers retain the original uncaptured behavior. Tests opt in with `fixture` provenance. A `physical` label records the caller's declaration and does not independently prove device identity.

## Cooperating bus ownership

Both real bench open sites use `open_managed_port(PortConfig(...), serial_factory=...)`. It checks passive identity before device acquisition and construction. A successful result owns `bus`; call `close()` and inspect its boolean result. `False` means ownership remains held because closure was not confirmed. Retry cleanup before reconnecting. A context manager raises `PortCloseError` on an otherwise normal exit with unconfirmed close; its `managed_port` remains available for cleanup.

This API opens hardware when given a motor path. Its acceptance tests use Linux PTYs exclusively. The device lease coordinates these workbench clients; it cannot exclude a raw client that ignores the lock.

When passive identity metadata is incomplete, the default route reports it as unverified and still permits device acquisition; known mismatches reject. The serial factory must expose the pyserial `is_open` status for confirmed cleanup. A missing status retains the lease. Neither passive inspection nor opening establishes CRC-valid motor communication.

## Controller lifecycle and freshness

`JointCore` owns a fixed ordered set of unique `JointSpec` names and motor IDs. Its states and immutable `Snapshot` are transport-free; `connected(SourceIdentity(...))` records a declaration and never opens hardware. `Decision` evaluates to its `accepted` value.

Connect, check, and arm are distinct steps. `receive(id, JointSample(...), MotorHealth(...))` stamps each valid observation with the core's monotonic clock. `checked()` needs fresh healthy Stop-mode feedback from every active joint. `arm()` requires fresh healthy Stop-mode feedback. The configurable maximum age defaults to 0.5 seconds; this software policy is not a measured loop-rate guarantee. Snapshot `feedback_ages_s` preserves joint order and uses `None` before receipt. Timestamp zero is valid. Unknown IDs and invalid records do not refresh timestamps.

Call `tick()` to fault READY, ARMED, or MOVING when feedback ages out. Stop, disconnect/reconnect, and healthy packets do not clear a fault latch. Recovery requires `begin_check(acknowledge_fault=True)` followed by fresh healthy Stop feedback and successful `checked()`. The check clears observations first. Target dispatch, attributed fault records and command ordering are the next milestones.

## Attributed faults

`Snapshot.faults` holds immutable `JointFault` records in configured joint order. `affected_joints` derives their names. Error and warning masks accumulate by bitwise OR, and watchdog timeout and stale flags latch. Communication codes are fixed `CommunicationFailure` enum values; they do not imply an actuator watchdog timeout. Current healthy feedback clears the current communication observation while the cause remains latched. Stop and reconnect retain causes. Only an explicitly acknowledged, complete, fresh, healthy Stop check clears them. Each core stores at most one record per configured joint and a unique first-occurrence union of fixed communication codes; its size is bounded by the finite enum. `communication_error` is the most recent cause; `communication_errors` is not a chronological event history. A supplied most-recent code must belong to that union.

When opening fails and cleanup cannot confirm closure, `open_managed_port` raises `PortCloseError` with `managed_port` for retry and the original error as `__cause__`. Context exit uses the same exception when closure fails, retaining any body exception as its cause. If cleanup succeeds, the original exception propagates normally.

## Latest target and command expiry

`Target(sequence, joints, window, owner)` contains an immutable complete tuple of `JointTarget` values in configured order, a required station-issued `IntentWindow(id, created_at_s, expires_at_s)`, and the current `OwnerToken`. `JointCore.issue_window(valid_for_s)` issues the latest offered window with a monotonic ID and bounded duration (`max_window_s`, default 1.0s). `submit_target` first expires or faults an existing goal as needed, then checks the full owner token, validates the incoming window against the latest offered window, checks expiry (exact equality with expiry is expired), checks mapped output codec representability, and enforces monotonic command sequence ordering before admitting the goal. A rejected replacement keeps an existing goal only while that goal remains valid.

`consume_target` is deleted in favor of explicit refresh lifecycle: `prepare_refresh()`, `claim_dispatch(plan_id, index)`, and `dispatch_result(plan_id, index, result)`. An admitted goal is refreshed repeatedly until its window expires. Preparing a plan proposes a refresh vector without dispatching. Each `RefreshPlan` contains an exact-count tuple of immutable, validated canonical packet bytes; the adapter writes those bytes unchanged. `joint_targets` records the actual full joint reference decoded from those packets, while `target` preserves the admitted request. `claim_dispatch` verifies freshness, health, goal expiry, and ordered joint index immediately before each write. Only one claim may await an outcome; the core blocks another joint claim, plan preparation, and reconnect until the station reports that claim's actual transport result. Stop, expiry, target replacement, disconnect, or fault can invalidate the plan without discarding that in-flight receipt. `exchange` reports the write result once after the driver outcome; successful returns are deadline-checked before feedback. If the deadline expires after the pre-write hook grants a claim but before `bus.write`, it reports `WriteResult.PREWRITE_DEADLINE`: the software made no write call for that claim. This does not establish motor state or physical protection. `WriteResult.PARTIAL` means the driver returned a positive short count. `WriteResult.FAILED` means the driver raised or returned an invalid count, so byte delivery may be unknown. `Snapshot.dispatch_attempts` holds the latest outcome per joint. `dispatch_result` commits a dispatched record only for a complete write. A dispatched record's `dispatched_at_s` is the valid claim/write start time, not a fabricated completion timestamp. A complete write followed by invalid or regressing core time preserves the complete record and attempt, then faults with `CommunicationFailure.CLOCK_FAILURE` without restoring motion. `WriteResult.PREWRITE_DEADLINE` faults with `CommunicationFailure.PREWRITE_DEADLINE`; `PARTIAL` and `FAILED` fault with `DRIVER_FAILURE`, preserving any prior complete record. A late receipt for an invalidated plan is recorded but cannot restore motion or change `DISCONNECTED`; once it settles, an explicit reconnect is allowed. Reconnect still requires a new owner, acknowledged fresh healthy Stop check, and explicit arm. When an admitted goal expires, housekeeping withdraws it, invalidates pending plans, and disarms the core to `STOPPED` (latched fault preserved), requiring a new check and arm cycle. Sequence watermarks survive consumption, stop, fault, and disconnect.

### Offline controller example

```python
from joint_contract import IntentWindow, JointSpec, MotorHealth, OwnerToken, SourceIdentity, State, Target, WriteResult
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget

core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, "fixture: software position limits"),), clock=lambda: 0.0)
assert core.begin_connect()
assert core.connected(SourceIdentity("fixture", "example", 1))
owner = core.claim_owner("example-client")
assert core.begin_check()
assert core.receive(0, JointSample(0, 0, 0), MotorHealth(0, 0, 0, False))
assert core.checked()
assert core.arm(owner)
window = core.issue_window(0.5)
target = Target(6, (JointTarget(.1, 1, -6, 18, 4.5),), window=window, owner=owner)
assert core.submit_target(target)
plan = core.prepare_refresh()
assert plan is not None
assert core.claim_dispatch(plan.plan_id, 0)
assert core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
assert core.snapshot().state is State.MOVING
assert core.snapshot().dispatched_records[0].sequence == 6
assert core.stop()
assert core.snapshot().last_sequence == 6
```

This example performs no serial operations. A station adapter must validate its own physical setup and own packet transmission when later milestones add one.

## Core and ownership limits

The injected core clock must be finite and monotonic. Invalid or regressing time rejects operations that need a fresh gate; snapshots also require that clock contract. If a complete write receipt arrives after its end clock becomes invalid, the core preserves that known write and claim timestamp, then latches `CommunicationFailure.CLOCK_FAILURE` and withdraws motion until acknowledged recovery. The default clock is `time.monotonic`. Sequence `2**64 - 1` exhausts that core's stream. Start a new core for a new stream; reconnecting or acknowledging a fault never resets ordering.

### Owner generations

`JointCore` generates a fresh unpredictable random 16-byte hex epoch per instance/process via `secrets.token_hex(16)` with no persisted global state. A monotonic generation counter starts at 1 and ranges through uint64. `claim_owner(connection_id)` returns a frozen `OwnerToken(epoch, generation, connection_id)`. `connection_id` is an immutable non-empty string bounded to 64 characters and identifies the client connection; `SourceIdentity` separately identifies the motor connection. The core assumes trusted station callers; the station/server binds its actual client connection identity rather than trusting unverified JSON payload attributes, with no authentication claims beyond that boundary.

`arm(owner)` and `Target` require an exact `OwnerToken` class and matching immutable epoch, generation, and connection ID fields. Token-bearing boundary records reject subclasses. An owner mismatch returns `DecisionCode.INVALID_OWNER` after lifecycle state checks. Stop, any latched joint fault, disconnect, expired goals, and explicit takeover revoke active authority (`current_owner` becomes `None`), withdraw pending goals/plans and offered windows, and never auto-rearm. A claim during checking, ready, armed, or moving state, or a takeover of an existing owner on a connected core, places the core in `STOPPED` (while preserving `FAULT` and `DISCONNECTED`), requiring a fresh stop check and explicit arm call with the new token. Reconnecting requires claiming a fresh generation. Fault recovery also requires a new claim before checking and arming.

Durable attempt and dispatched records retain the original `OwnerToken` stamped at plan creation; an in-flight receipt completing after authority revocation preserves the actual write record with its original owner attribution without transitioning the core to `MOVING`. `Snapshot.latest_owner` retains the most recently issued token after revocation, while `Snapshot.current_owner` is `None` unless that token currently has authority. Bounded O(1) storage retains only these two tokens. When the uint64 generation space is exhausted, a new claim revokes authority, stops the core (or preserves `FAULT`/`DISCONNECTED`), and raises `OverflowError` without wrapping; start a fresh core to obtain a new epoch.

The fixed per-user lock namespace under `/tmp` coordinates cooperating processes. A hostile local user can pre-create the name and deny access; validation fails closed. An administrator must remove a foreign-owned obstruction. Lockfiles persist to preserve flock inode identity, including after device-number reuse. Do not delete them while clients may be running. No automatic pruning or hostile-local-user availability guarantee is supplied.

## Joint Position Limits

Every `JointSpec` requires explicit, immutable, finite position bounds `q_min_rad <= q_max_rad` and non-empty `limits_provenance` documenting the software threshold origin. These are fixture software limits, not physical calibration. Position requests are evaluated against inclusive bounds: exact lower and upper endpoints are accepted. Requests outside them return `DecisionCode.POSITION_OUT_OF_BOUNDS` and preserve any still-valid admitted goal, sequence watermark, owner, and window. Mapped requests must first pass the ordinary canonical codec; an unencodable mapped request returns `INVALID_ARGUMENT` and is never clamped into range. A fresh measured position outside the bounds, including during `CHECKING`, latches the attributed `JointFault.position_limit` cause and faults the core before motion. Simultaneous motor-health causes remain in the same joint fault record. `claim_dispatch` rechecks every fresh measured position and the actual prepared reference before each write. Recovery requires a new owner and an explicitly acknowledged fresh healthy Stop check with every measured position within the inclusive bounds; incoming targets cannot clear a fault. The codec owns the bounded raw position grid search through a monotonic decoded-domain callback and direction. It selects an inward representable endpoint, serializes that exact raw integer without float re-encoding, and decodes the complete canonical packet to populate actual position, velocity, feedforward, and gain reference fields. Stop packets are valid decoder inputs; mode, ID, watchdog, reserved byte, header, and CRC are checked. Repeated refreshes write the cached packet bytes unchanged.

```

FILE docs/controller-limits-design.md
```
# Controller limits and station design

## Problem and usage

C07-C16 extend the verified transport-free core with expiring ownership-bound requests, joint/reference limits, measured faults and timing. A separate fixture station owns the managed PTY lease independently of its client. Existing bench GUI/CLI remain functional. Physical motor execution remains blocked by the unanswered timeout acknowledgment; fixture thresholds cannot establish production readiness.

The station issues a monotonic intent window before client computation. A client submits a complete vector with that window, sequence and (from C08) current owner token. Arrival never renews the deadline. Connect/check/claim/arm stay explicit. A submit receipt means admitted, not written or moved. The adapter prepares one full vector, validates all packets, then checks the core gate beside each actual write and records complete/partial/failed write independently of feedback.

```python
# Final C16 client; clients never open a motor port or supply telemetry/time.
with StationClient(socket_path) as client:
    owner = client.claim("human")       # revokes prior generation, stops
    client.check(acknowledge_fault=False)
    client.arm(owner)
    window, snapshot = client.observe(valid_for_s=0.2)
    decision = client.submit(owner, window.id, sequence=42, joints=targets)
    client.stop()
```

```python
# One station thread, illustrated in domain terms.
plan = core.prepare_refresh()
if plan is not None:
    packets = encode_complete(plan, core.joint_specs)
    for index, packet in enumerate(packets):
        reply = exchange(bus, packet, core.joint_specs[index].motor_id,
            before_write=lambda: service_priority_and_claim(core, plan, index),
            on_write=lambda result: core.dispatch_result(plan.id, index, result))
        core.receive(reply.id, mapped_sample(reply), mapped_health(reply))
```

The final implementation must resolve closure binding explicitly. The adapter aborts remaining mode-1 writes after any rejection/failure and schedules Stops. Serial writes across joints cannot be physically atomic; each actual partial/full write is separately recorded. Stop cannot interrupt an already-running synchronous driver call.

## Selection and synthesis

Both main candidates converged on core-owned goals with a separate station shell. Sol also supplied a structurally distinct immutable reducer alternative; Gemini considered a separate safety middleware. Parent selected Sol's stateful core: existing lifecycle calls are recognizable and one authority owns motion. The reducer would require a larger event/effect coordination surface. Middleware was rejected because a direct core call could bypass it or duplicate reference state.

| Criterion | Parent Sol | Parent Gemini | Muse Sol | Muse Gemini |
| --- | --- | --- | --- | --- |
| Final dispatch gate and ownership | 5 | 2 | 5 | 2 |
| Combined reference constraints | 4 | 2 | 5 | 2 |
| Interface depth and maintenance | 3 | 3 | 4 | 3 |
| Station independence | 4 | 3 | 5 | 2 |
| Testability and actual evidence | 5 | 3 | 5 | 2 |
| Verifiable unit sequence | 4 | 3 | 5 | 3 |

Muse chose the same base. Parent scored lower where sketches still need executable proof, and did not accept the judge's claim that the full analytic mathematics was already proven. Parent grafted Gemini's readable decision codes, selectors-based nonblocking process shell and snapshot/timing client view. Neither score is physical validation.

Parent simplified Sol's virtual trapezoidal trajectory/braking mathematics into the explicitly discrete contract below. The milestones require samplewise reference velocity and acceleration bounds, not a continuous physical trajectory. Parent replaced fixed 2048-byte binary packing with bounded JSON packets over Linux Unix SOCK_SEQPACKET: OS message boundaries plus fixed byte/count limits avoid incremental parser state and a broad packing taxonomy. No unbounded streams/queues, JSON NaN, arbitrary object deserialization or client-controlled health/time are allowed. Retain Sol's intent windows, opaque plan IDs, final write gate, epoch/generation/connection binding, partial dispatch records and PTY-only executable.

## Modules and types

- joint_controller.py owns lifecycle, checked clock high-water mark, one admitted complete goal, one prepared plan, ownership/window authority, per-joint reference and dispatch records, measured observations and fault union. Split frozen records to joint_contract.py only if needed to keep the core cohesive; migrate imports rather than maintain aliases.
- joint_reference.py owns pure feasible-interval/reference and effort calculation. It owns no clock, observations, mutable reference or transport.
- im6014_serial.py keeps bench exchange behavior and adds optional before_write/on_write hooks. The final gate runs after reset/timeout setup directly before write. False cancels with no write. Actual write result is reported even if later feedback times out.
- station_timing.py owns bounded actual loop/transaction measurements. C15 first proves it through a fake adapter; it does not depend on an unfinished C16 daemon.
- joint_station.py and station_protocol.py own the C16 single-thread fixture process/lease and bounded client IPC respectively. No physical executable or D01 profile schema is introduced.

```python
@dataclass(frozen=True)
class IntentWindow:
    id: int
    created_at_s: float
    expires_at_s: float

@dataclass(frozen=True)
class Target:
    sequence: int
    joints: tuple[JointTarget, ...]
    window: IntentWindow
    # C08 adds required OwnerToken, with epoch, generation, connection ID.

class JointCore:
    def issue_window(self, valid_for_s: float) -> IntentWindow: ...
    def submit_target(self, target: Target) -> Decision: ...
    def prepare_refresh(self) -> RefreshPlan | None: ...
    def claim_dispatch(self, plan_id: int, index: int) -> bool: ...
    def dispatch_result(self, plan_id: int, index: int, result: WriteResult) -> Decision: ...
    # Existing lifecycle and snapshot; consume_target is deleted.
```

Sketch bodies remain unimplemented in this document. Per-family types become required only in their milestone, with all callers migrated in that unit. No default unbounded limits or guessed physical thresholds. Explicit fixture configurations supply values. Configuration/build/observation metadata can be retained as fixture identifiers; D01 profile parsing remains later work.

## Time, admission and authority

Retain the existing floating-point monotonic clock API for compatibility with deterministic fixtures. Track its maximum observed valid time globally; reject invalid/regressing time before overwriting observations or releasing motion. Preserve finite-clock errors in snapshots rather than fabricate fresh ages. Station catches a clock failure, records it and Stops. A later valid clock must be at least the previous high-water mark.

Windows have finite positive bounded lifetime, station-issued ID and exact creation/expiry. Equality with expiry is expired. The core stores only the latest offered window and the admitted goal's immutable window. Issuing a newer window invalidates older incoming responses but does not renew/erase the already admitted goal. Expiry of an admitted goal withdraws motion and Stops; an invalid incoming replacement preserves an otherwise valid goal and watermark. Required safety housekeeping still expires/faults old goals. Recheck expiry at preparation and before every mode-1 write, not only admission.

C08 ownership adds a fresh core/process epoch, monotonic uint64 generation and server-generated connection identity. Stop, fault, disconnection, takeover and reconnect withdraw goal/plans and revoke authority; no automatic rearm. Old generation/epoch/connection requests reject. Sequence watermark remains globally increasing across those transitions and never wraps/resets; clients learn it from snapshots. Exhaustion rejects motion until a fresh core/epoch. A client cannot manufacture another connection's authority through JSON fields.

All admission checks happen before replacing the complete goal/watermark: domain types/count/order, window/owner, full mapped codec representability, inclusive position limits and later requested lead/effort checks. Rejected high sequences cannot consume ordering. Prepared plans are complete and bounded; replacement/revocation invalidates them. A complete write commits only that joint's actual reference record. Partial/unknown write faults and requires explicit fresh Stop recovery. Logical MOVING requires a confirmed mode-1 write; neither a prepared plan nor an admission is dispatched evidence.

## Discrete reference and effort contract

Initialize reference position from fresh healthy checked Stop measurement and reference velocity zero. For positive elapsed h since the previous reference step, choose endpoint velocity v in the closed intersection:

    [-V, V] intersection [v_prev-A*h, v_prev+A*h]
    intersection [(q_min-q_prev)/h, (q_max-q_prev)/h]
    intersection [(q_measured-lead-q_prev)/h, (q_measured+lead-q_prev)/h]

Then q_next=q_prev+position_step_velocity*h, where position_step_velocity is derived from the decoded emitted position difference divided by h. The independently quantized encoded command velocity is a separate quantity. Apply speed and acceleration bounds to both streams using their respective confirmed prior values. Never use encoded velocity as the position-step velocity. Project the desired position/velocity objective into that interval; define the selected objective in the API docs. Position request limits reject outside inclusive bounds. Requested lead outside its documented bound rejects, while the actual reference also stays bounded at each preparation/final gate. C10 adds V; C11 adds acceleration interval; C12 adds measured lead. During zero elapsed time only an unchanged reference may refresh. Excessive elapsed gap withdraws motion instead of allowing unlimited catch-up. Reversal preserves previous velocity and crosses zero under the same acceleration bound. Empty intervals/unsafe finite arithmetic generate no reference and latch an attributed constraint fault with Stop. Never clamp q after choosing v or silently relax a bound.

These are samplewise software reference constraints. They establish no continuous motor trajectory, physical acceleration or certified braking. Timing and actual write records remain separate.

Before any write, validate every shaped mapped packet through the canonical codec. Codec quantization can cross a closed position or effort bound. Keep codec scales in the codec; expose decoded encoded-command values there if necessary, map back once and check actual encoded endpoints/effort against inclusive limits. Choose an inward representable value when possible, otherwise withdraw motion. Do not disguise a quantization overshoot with an arbitrary safety tolerance or copy codec scales into the limiter. Recheck fresh measurement, expiry, owner and limits at final gate. No source caller can bypass constraints via the deleted consume API.

Predict tau_ff+kp*(q_ref-q_measured)+kd*(dq_ref-dq_measured), including gains after encoded-command quantization. Preserve requested/admitted, shaped accepted, confirmed dispatched and measured records distinctly. Monitor measured joint effort independently. C13 trips configured peak effort; C14 adds continuous-effort dwell, explicit driver/winding temperature trip/reset bounds and attributed fault union. No defaults claim physical protection. Recovery requires explicit acknowledgment followed by complete fresh healthy Stop telemetry below recovery thresholds for the configured dwell; new targets, reconnect and healthy packets alone cannot clear latches. Missing temperature telemetry never proves healthy recovery.

## Station and timing

The C16 executable accepts explicit validated /dev/pts endpoints only, with deterministic fixture actuator semantics. It opens through the existing fixed managed lease namespace and retains the lease until confirmed close. Unconfirmed closure leaves a retryable shutdown with owner held. Clients never launch/restart it automatically. One active connection owns motion; a bounded priority control request can Stop/take over. Serve Stop/takeover/EOF/liveness before targets and each write gate, with bounded reads/accepts per iteration. Packet size/joint count/depth are fixed and oversized/truncated/malformed messages reject before mutation. Directory/socket permissions restrict to the same user. Slow clients/backpressure cannot block refresh; disconnect revokes and Stops.

Client crash must leave the station alive with its lease, Stop state and no rearm. A second cooperating opener fails. Restart uses a fresh epoch, fresh Stop checks and explicit arm. The existing bench GUI remains a separate legacy bench path; C16 tests a dashboard/client process against the new fixture station, and the managed lease excludes that bench opening the same PTY. UI migration is later E-series work, not a fabricated production feature.

Report actual start-to-start period, per-joint transaction start/end duration/outcome, completion overrun/missed slots, feedback age and sampling skew. Skip missed slots instead of bursting. Records/counters stay bounded. Nominal period is configuration, not measured rate. C15 deterministic tests validate arithmetic; parent real-clock fixture runs (five repeats) provide separate observed timing with work/error counts and host-load context. PTY/fake timing is not physical RS485 throughput.

## Verifiable units

One fresh Gemini writer per C07-C16 milestone, serialized from the accepted parent tip. Parent reads full diff/output/receipt, runs targeted and affected regression tests, records hashes/logs and commits before the next unit. Scope and test entry points are registered in check_milestone, the offline copyset/startup fingerprint and CI as each module appears. C15 fake timing works before C16 process integration. Final panel reviews, full offline/UI checks and nonwriter independent verification precede the private PR and guarded merge. All model outputs/receipts and parent selection notes are retained with requested-route evidence, not independent provider identity claims.

## Quantization decision after executable sketches

Choose emitted targets with two named velocity streams. Retain actual decoded emitted JointTarget, exact rational position_step_velocity and preparation sample time per joint only after its full write. Retain actual claim time separately. Initialize a fresh healthy Stop anchor with zero velocities; it is not a dispatched record. Codec owns raw grids, canonical decoding and bounded inward projection. Cache validated canonical bytes and send them unchanged; no decode/re-encode drift. Certificates use exact rational values of stored finite floats, without arbitrary epsilon.

Sol's pure grid proof passed parent execution; Gemini's draft proof failed its own overshoot assertion. Parent separately checked its false noninteger-ratio inference and reproduced 100 unchanged samples with a too-small acceleration interval. Evidence is in evidence/control-limits/quantization. Neither model's self-report established execution.

For h>0, if a nonzero motion objective cannot make a representable position step under all closed constraints, Stop with an attributed constraint reason. Do not repeatedly commit unchanged writes and imply progress, hide fractional virtual motion, accumulate elapsed time contrary to actual write history, or relax bounds. A deliberate hold and h=0 refresh remain distinct. C10-C12 must prove useful progression at feasible fixture cadence and conservative Stop for infeasible cadence. There is no physical trajectory guarantee.

```

PARENT CHECKS {
  "baselineGroups": 9,
  "counts": {
    "protocol-tests": 24,
    "serial-deadline-tests": 11,
    "milestone-tests": 168,
    "startup-verifier-tests": 5
  },
  "dashboardGroups": 18,
  "sourceHashesMatch": true,
  "dashboardMotorIO": false,
  "visualInspection": "parent must inspect four captures separately"
}

23focused and5parent reprotests pass; fourimagesinspected; exacthashesmapped. Allfreshbug drafts/failedchecks retained separately. This panel cannot itself attest tests or physicalresults.
