Use ONLY supplied complete inline text. No tools, reads, filesystem, shell, MCP, networking, permissions or subagents. This is a TEXT REVIEW assignment. Return JSON array with file/function/line/severity/finding/evidence/fix or [] if no actionable new findings.

Intent: C12 adds required explicit finitepositive measuredlead, exactclosedrequested admission/reference/writegate checks preserving all speed/acceleration/position, canonical cachedpacket and actualwrite history, global ordering/owner/expiry/fault guarantees. Original draft NOT accepted; parent is repairing alreadyknown float roundedlead admission/h0 bugs, h0 reusedsequence, stalehousekeeping contradictory preservation, forbidden2swindow/outsidelead goal, invalid emittedreference metadata/nominalh inseededtest. Do not report these again unless a distinct actualrootcause. Parent positivecadence independent768V/A/lead decodedcertificates+768h0cache and preceding gateconsistencyrepro passeddraft. Parent firstleadrepro harnessmistakes retained andcorrected2actualfailures supplied. Look for other actualruntime/verification defects and concrete simplifications. C13effort/C14thermal/C15timing/C16PTYstation are subsequentunits, do not invent their currentpresence. No physical motor claims.

## joint_contract.py complete
```
"""Frozen domain records and status types for joint control.

All records are immutable (frozen) data contracts with no transport or clock ownership.
"""

from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
import math
from typing import Literal

from im6014_codec import decode_command
from joint_mapping import JointMap, JointSample, JointTarget


class State(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    CHECKING = "checking"
    READY = "ready"
    ARMED = "armed"
    MOVING = "moving"
    STOPPED = "stopped"
    FAULT = "fault"


class DecisionCode(str, Enum):
    ACCEPTED = "accepted"
    INVALID_STATE = "invalid_state"
    INVALID_ARGUMENT = "invalid_argument"
    INVALID_OWNER = "invalid_owner"
    INVALID_SOURCE = "invalid_source"
    UNKNOWN_JOINT = "unknown_joint"
    INVALID_OBSERVATION = "invalid_observation"
    FAULT_ACK_REQUIRED = "fault_ack_required"
    FAULT_LATCHED = "fault_latched"
    OBSERVATIONS_INCOMPLETE = "observations_incomplete"
    STALE_FEEDBACK = "stale_feedback"
    UNHEALTHY = "unhealthy"
    NOT_STOPPED = "not_stopped"
    DUPLICATE_OR_OLDER = "duplicate_or_older"
    EXPIRED = "expired"
    POSITION_OUT_OF_BOUNDS = "position_out_of_bounds"
    SPEED_OUT_OF_BOUNDS = "speed_out_of_bounds"
    LEAD_OUT_OF_BOUNDS = "lead_out_of_bounds"
    REFERENCE_GAP_EXCEEDED = "reference_gap_exceeded"
    CONSTRAINT_VIOLATION = "constraint_violation"


class CommunicationFailure(str, Enum):
    TIMEOUT = "timeout"
    INVALID_FEEDBACK = "invalid_feedback"
    DRIVER_FAILURE = "driver_failure"
    CLOCK_FAILURE = "clock_failure"
    PREWRITE_DEADLINE = "prewrite_deadline"


class WriteResult(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    PREWRITE_DEADLINE = "prewrite_deadline"


@dataclass(frozen=True)
class Decision:
    accepted: bool
    code: DecisionCode

    def __post_init__(self) -> None:
        if type(self.accepted) is not bool:
            raise ValueError("accepted must be a bool")
        if not isinstance(self.code, DecisionCode):
            raise ValueError("code must be a DecisionCode")
        if self.accepted != (self.code is DecisionCode.ACCEPTED):
            raise ValueError("accepted must match the decision code")

    def __bool__(self) -> bool:
        return self.accepted


@dataclass(frozen=True)
class JointSpec:
    name: str
    motor_id: int
    mapping: JointMap
    q_min_rad: float
    q_max_rad: float
    v_max_rad_s: float
    a_max_rad_s2: float
    max_lead_rad: float
    limits_provenance: str

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if not isinstance(self.mapping, JointMap):
            raise ValueError("mapping must be a JointMap")

        if isinstance(self.q_min_rad, bool) or not isinstance(self.q_min_rad, (int, float)):
            raise ValueError("q_min_rad must be a finite real number")
        if isinstance(self.q_max_rad, bool) or not isinstance(self.q_max_rad, (int, float)):
            raise ValueError("q_max_rad must be a finite real number")
        try:
            min_val = float(self.q_min_rad)
            max_val = float(self.q_max_rad)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("position limits must be finite") from exc
        if not math.isfinite(min_val) or not math.isfinite(max_val):
            raise ValueError("position limits must be finite")
        if min_val > max_val:
            raise ValueError("q_min_rad must be less than or equal to q_max_rad")

        if isinstance(self.v_max_rad_s, bool) or not isinstance(self.v_max_rad_s, (int, float)):
            raise ValueError("v_max_rad_s must be a finite positive real number")
        try:
            v_max_val = float(self.v_max_rad_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("speed limit must be finite") from exc
        if not math.isfinite(v_max_val) or v_max_val <= 0.0:
            raise ValueError("v_max_rad_s must be finite and positive")

        if isinstance(self.a_max_rad_s2, bool) or not isinstance(self.a_max_rad_s2, (int, float)):
            raise ValueError("a_max_rad_s2 must be a finite positive real number")
        try:
            a_max_val = float(self.a_max_rad_s2)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("acceleration limit must be finite") from exc
        if not math.isfinite(a_max_val) or a_max_val <= 0.0:
            raise ValueError("a_max_rad_s2 must be finite and positive")

        if isinstance(self.max_lead_rad, bool) or not isinstance(self.max_lead_rad, (int, float)):
            raise ValueError("max_lead_rad must be a finite positive real number")
        try:
            max_lead_val = float(self.max_lead_rad)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_lead_rad must be finite") from exc
        if not math.isfinite(max_lead_val) or max_lead_val <= 0.0:
            raise ValueError("max_lead_rad must be finite and positive")

        if (
            type(self.limits_provenance) is not str
            or not self.limits_provenance.strip()
            or len(self.limits_provenance) > 256
        ):
            raise ValueError("limits_provenance must be a bounded non-empty string")

        object.__setattr__(self, "q_min_rad", min_val)
        object.__setattr__(self, "q_max_rad", max_val)
        object.__setattr__(self, "v_max_rad_s", v_max_val)
        object.__setattr__(self, "a_max_rad_s2", a_max_val)
        object.__setattr__(self, "max_lead_rad", max_lead_val)

@dataclass(frozen=True)
class JointFault:
    name: str
    motor_id: int
    errors: int = 0
    warnings: int = 0
    timeout: bool = False
    communication_error: CommunicationFailure | None = None
    stale: bool = False
    communication_errors: tuple[CommunicationFailure, ...] = ()
    position_limit: bool = False
    speed_limit: bool = False
    constraint_fault: bool = False

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if type(self.stale) is not bool:
            raise ValueError("stale must be a bool")
        if type(self.communication_errors) is not tuple or any(
            not isinstance(c, CommunicationFailure) for c in self.communication_errors
        ):
            raise ValueError("communication_errors must be a tuple of CommunicationFailure")
        if type(self.position_limit) is not bool:
            raise ValueError("position_limit must be a bool")
        if type(self.speed_limit) is not bool:
            raise ValueError("speed_limit must be a bool")
        if type(self.constraint_fault) is not bool:
            raise ValueError("constraint_fault must be a bool")

        if len(self.communication_errors) != len(set(self.communication_errors)):
            raise ValueError("communication_errors must contain unique codes")
        if self.communication_error is not None and self.communication_errors and (
            self.communication_error not in self.communication_errors
        ):
            raise ValueError("communication_error must belong to communication_errors")

        if self.communication_error is not None and not self.communication_errors:
            object.__setattr__(self, "communication_errors", (self.communication_error,))
        elif self.communication_errors and self.communication_error is None:
            object.__setattr__(self, "communication_error", self.communication_errors[-1])


@dataclass(frozen=True)
class MotorHealth:
    mode: int
    errors: int
    warnings: int
    timeout: bool

    def __post_init__(self) -> None:
        if type(self.mode) is not int or self.mode not in (0, 1):
            raise ValueError("mode must be the integer 0 or 1")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")

    @property
    def healthy(self) -> bool:
        return self.errors == 0 and self.warnings == 0 and not self.timeout


@dataclass(frozen=True)
class SourceIdentity:
    backend: Literal["physical", "demo", "fixture"]
    identity: str
    connection: int

    def __post_init__(self) -> None:
        if type(self.backend) is not str or self.backend not in ("physical", "demo", "fixture"):
            raise ValueError("backend must be physical, demo, or fixture")
        if type(self.identity) is not str or not self.identity.strip():
            raise ValueError("identity must be a non-empty string")
        if type(self.connection) is not int or self.connection < 0:
            raise ValueError("connection must be a nonnegative integer")


@dataclass(frozen=True)
class JointStatus:
    sample: JointSample | None = None
    health: MotorHealth | None = None
    received_at: float | None = None
    communication_error: CommunicationFailure | None = None

    def __post_init__(self) -> None:
        if (self.sample is None) != (self.health is None):
            raise ValueError("sample and health must both be present or both be absent")
        if self.sample is not None and not isinstance(self.sample, JointSample):
            raise ValueError("sample must be a JointSample")
        if self.health is not None and not isinstance(self.health, MotorHealth):
            raise ValueError("health must be MotorHealth")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if self.valid and self.received_at is None:
            raise ValueError("a valid observation requires received_at")
        if self.received_at is not None:
            if isinstance(self.received_at, bool) or not isinstance(self.received_at, (int, float)):
                raise ValueError("received_at must be a finite real number or None")
            try:
                received_at = float(self.received_at)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("received_at must be finite") from exc
            if not math.isfinite(received_at):
                raise ValueError("received_at must be finite")
            if not self.valid:
                raise ValueError("received_at requires a valid observation")
            object.__setattr__(self, "received_at", received_at)

    @property
    def valid(self) -> bool:
        return self.sample is not None and self.health is not None

    @property
    def healthy(self) -> bool:
        return self.valid and self.health.healthy and self.communication_error is None

    @property
    def errors(self) -> int:
        return self.health.errors if self.health is not None else 0

    @property
    def warnings(self) -> int:
        return self.health.warnings if self.health is not None else 0

    @property
    def timeout(self) -> bool:
        return self.health.timeout if self.health is not None else False


@dataclass(frozen=True)
class OwnerToken:
    epoch: str
    generation: int
    connection_id: str

    def __post_init__(self) -> None:
        if type(self.epoch) is not str or not self.epoch.strip() or len(self.epoch) > 64:
            raise ValueError("epoch must be a bounded non-empty string")
        if type(self.generation) is not int or not (1 <= self.generation <= (1 << 64) - 1):
            raise ValueError("generation must be an integer from 1 to 2**64 - 1")
        if type(self.connection_id) is not str or not self.connection_id.strip() or len(self.connection_id) > 64:
            raise ValueError("connection_id must be a bounded non-empty string")


def owner_tokens_match(candidate: object, current: object) -> bool:
    return (
        type(candidate) is OwnerToken
        and type(current) is OwnerToken
        and candidate.epoch == current.epoch
        and candidate.generation == current.generation
        and candidate.connection_id == current.connection_id
    )


@dataclass(frozen=True)
class IntentWindow:
    id: int
    created_at_s: float
    expires_at_s: float

    def __post_init__(self) -> None:
        if type(self.id) is not int or not (0 <= self.id <= (1 << 64) - 1):
            raise ValueError("window ID must be an integer from 0 to 2**64 - 1")
        if isinstance(self.created_at_s, bool) or not isinstance(self.created_at_s, (int, float)):
            raise ValueError("created_at_s must be a finite real number")
        if isinstance(self.expires_at_s, bool) or not isinstance(self.expires_at_s, (int, float)):
            raise ValueError("expires_at_s must be a finite real number")
        try:
            created = float(self.created_at_s)
            expires = float(self.expires_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("window timestamps must be finite") from exc
        if not math.isfinite(created) or not math.isfinite(expires):
            raise ValueError("window timestamps must be finite")
        if expires <= created:
            raise ValueError("expires_at_s must be strictly greater than created_at_s")
        object.__setattr__(self, "created_at_s", created)
        object.__setattr__(self, "expires_at_s", expires)


@dataclass(frozen=True)
class Target:
    sequence: int
    joints: tuple[JointTarget, ...]
    window: IntentWindow
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if type(self.joints) is not tuple:
            raise ValueError("joints must be a tuple of JointTarget")
        if not self.joints:
            raise ValueError("joints must be a non-empty tuple")
        if any(not isinstance(joint, JointTarget) for joint in self.joints):
            raise ValueError("every joint target must be a JointTarget")
        if not isinstance(self.window, IntentWindow):
            raise ValueError("window must be an IntentWindow")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")


@dataclass(frozen=True)
class JointTrajectoryReference:
    q_rad: float
    position_step_velocity_rad_s: Fraction
    encoded_velocity_rad_s: float
    sample_time_s: float
    is_emitted: bool = False
    requested_goal: JointTarget | None = None
    emitted_target: JointTarget | None = None
    packet: bytes | None = None

    def __post_init__(self) -> None:
        for name, val in (("q_rad", self.q_rad),
                          ("encoded_velocity_rad_s", self.encoded_velocity_rad_s),
                          ("sample_time_s", self.sample_time_s)):
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                raise ValueError(f"{name} must be a finite real number")
            try:
                v = float(val)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError(f"{name} must be finite") from exc
            if not math.isfinite(v):
                raise ValueError(f"{name} must be finite")
            object.__setattr__(self, name, v)

        derivative = self.position_step_velocity_rad_s
        if isinstance(derivative, bool) or not isinstance(derivative, (int, float, Fraction)):
            raise ValueError("position_step_velocity_rad_s must be an exact finite rational")
        if isinstance(derivative, Fraction):
            exact_derivative = derivative
        else:
            try:
                as_float = float(derivative)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("position_step_velocity_rad_s must be finite") from exc
            if not math.isfinite(as_float):
                raise ValueError("position_step_velocity_rad_s must be finite")
            exact_derivative = Fraction(as_float)
        object.__setattr__(self, "position_step_velocity_rad_s", exact_derivative)

        if type(self.is_emitted) is not bool:
            raise ValueError("is_emitted must be a bool")
        if self.is_emitted:
            if not isinstance(self.requested_goal, JointTarget):
                raise ValueError("an emitted reference requires its requested goal")
            if not isinstance(self.emitted_target, JointTarget):
                raise ValueError("an emitted reference requires its decoded target")
            if type(self.packet) is not bytes:
                raise ValueError("an emitted reference requires immutable packet bytes")
            try:
                decoded = decode_command(self.packet)
            except ValueError as exc:
                raise ValueError("an emitted reference requires a canonical command") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("an emitted reference requires a watchdog-enabled FOC command")
            if self.q_rad != self.emitted_target.q_rad:
                raise ValueError("reference position must match its decoded target")
            if self.encoded_velocity_rad_s != self.emitted_target.dq_rad_s:
                raise ValueError("encoded velocity must match its decoded target")
        else:
            if (
                self.requested_goal is not None
                or self.emitted_target is not None
                or self.packet is not None
            ):
                raise ValueError("an unemitted Stop anchor cannot contain an emitted command")
            if exact_derivative != 0 or self.encoded_velocity_rad_s != 0.0:
                raise ValueError("an unemitted Stop anchor must have zero velocity history")


@dataclass(frozen=True)
class RefreshPlan:
    plan_id: int
    target: Target
    prepared_at_s: float
    joint_targets: tuple[JointTarget, ...]
    packets: tuple[bytes, ...]
    proposed_references: tuple[JointTrajectoryReference, ...]

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, Target):
            raise ValueError("target must be a Target")
        if isinstance(self.prepared_at_s, bool) or not isinstance(self.prepared_at_s, (int, float)):
            raise ValueError("prepared_at_s must be a finite real number")
        try:
            prepared = float(self.prepared_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("prepared_at_s must be finite") from exc
        if not math.isfinite(prepared):
            raise ValueError("prepared_at_s must be finite")
        object.__setattr__(self, "prepared_at_s", prepared)
        if type(self.joint_targets) is not tuple or not self.joint_targets:
            raise ValueError("joint_targets must be a non-empty tuple")
        if any(not isinstance(jt, JointTarget) for jt in self.joint_targets):
            raise ValueError("every joint target must be a JointTarget")
        if len(self.target.joints) != len(self.joint_targets):
            raise ValueError("joint_targets must match the complete target vector")
        if type(self.packets) is not tuple or len(self.packets) != len(self.joint_targets):
            raise ValueError("packets must be a tuple matching joint_targets")
        for packet in self.packets:
            if type(packet) is not bytes:
                raise ValueError("packets must contain immutable bytes")
            try:
                decoded = decode_command(packet)
            except ValueError as exc:
                raise ValueError("packets must contain canonical commands") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("refresh packets must be watchdog-enabled FOC commands")
        if (
            type(self.proposed_references) is not tuple
            or len(self.proposed_references) != len(self.joint_targets)
        ):
            raise ValueError("proposed_references must match joint_targets length")
        for goal, target, packet, reference in zip(
            self.target.joints,
            self.joint_targets,
            self.packets,
            self.proposed_references,
        ):
            if not isinstance(reference, JointTrajectoryReference) or not reference.is_emitted:
                raise ValueError("every plan requires a complete emitted reference")
            if reference.requested_goal != goal:
                raise ValueError("reference goal must match the admitted joint goal")
            if reference.emitted_target != target or reference.packet != packet:
                raise ValueError("reference target and packet must match the prepared command")
            if reference.sample_time_s > prepared:
                raise ValueError("reference sample time cannot follow plan preparation")

    @property
    def window(self) -> IntentWindow:
        return self.target.window

    @property
    def owner(self) -> OwnerToken:
        return self.target.owner


@dataclass(frozen=True)
class JointDispatchedRecord:
    sequence: int
    target: JointTarget
    dispatched_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.dispatched_at_s, bool) or not isinstance(self.dispatched_at_s, (int, float)):
            raise ValueError("dispatched_at_s must be a finite real number")
        try:
            dispatched = float(self.dispatched_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("dispatched_at_s must be finite") from exc
        if not math.isfinite(dispatched):
            raise ValueError("dispatched_at_s must be finite")
        object.__setattr__(self, "dispatched_at_s", dispatched)


@dataclass(frozen=True)
class JointDispatchAttempt:
    plan_id: int
    sequence: int
    target: JointTarget
    result: WriteResult
    started_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if not isinstance(self.result, WriteResult):
            raise ValueError("result must be a WriteResult")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.started_at_s, bool) or not isinstance(self.started_at_s, (int, float)):
            raise ValueError("started_at_s must be a finite real number")
        try:
            started = float(self.started_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("started_at_s must be finite") from exc
        if not math.isfinite(started):
            raise ValueError("started_at_s must be finite")
        object.__setattr__(self, "started_at_s", started)


@dataclass(frozen=True)
class Snapshot:
    state: State
    joint_names: tuple[str, ...]
    joints: tuple[JointStatus, ...]
    source: SourceIdentity | None
    fault_latched: bool
    feedback_ages_s: tuple[float | None, ...]
    faults: tuple[JointFault, ...] = ()
    admitted_target: Target | None = None
    prepared_plan: RefreshPlan | None = None
    dispatched_records: tuple[JointDispatchedRecord | None, ...] = ()
    last_sequence: int = -1
    dispatch_attempts: tuple[JointDispatchAttempt | None, ...] = ()
    latest_owner: OwnerToken | None = None
    current_owner: OwnerToken | None = None
    confirmed_references: tuple[JointTrajectoryReference | None, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.state, State):
            raise ValueError("state must be a State")
        if type(self.joint_names) is not tuple or any(type(name) is not str for name in self.joint_names):
            raise ValueError("joint_names must be a tuple of strings")
        if type(self.joints) is not tuple or any(not isinstance(joint, JointStatus) for joint in self.joints):
            raise ValueError("joints must be a tuple of JointStatus")
        if type(self.feedback_ages_s) is not tuple:
            raise ValueError("feedback_ages_s must be a tuple")
        if len(self.joint_names) != len(self.joints):
            raise ValueError("joint names and statuses must have equal lengths")
        if len(self.feedback_ages_s) != len(self.joints):
            raise ValueError("feedback ages and joint statuses must have equal lengths")
        normalized_ages: list[float | None] = []
        for joint, age in zip(self.joints, self.feedback_ages_s):
            if joint.received_at is None:
                if age is not None:
                    raise ValueError("feedback age must be None before a joint is received")
                normalized_ages.append(None)
                continue
            if isinstance(age, bool) or not isinstance(age, (int, float)):
                raise ValueError("feedback age must be a finite nonnegative number")
            try:
                age_value = float(age)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("feedback age must be finite") from exc
            if not math.isfinite(age_value) or age_value < 0.0:
                raise ValueError("feedback age must be finite and nonnegative")
            normalized_ages.append(age_value)
        object.__setattr__(self, "feedback_ages_s", tuple(normalized_ages))
        if self.source is not None and not isinstance(self.source, SourceIdentity):
            raise ValueError("source must be a SourceIdentity or None")
        if type(self.fault_latched) is not bool:
            raise ValueError("fault_latched must be a bool")
        if type(self.faults) is not tuple or any(not isinstance(f, JointFault) for f in self.faults):
            raise ValueError("faults must be a tuple of JointFault")
        if self.admitted_target is not None and not isinstance(self.admitted_target, Target):
            raise ValueError("admitted_target must be a Target or None")
        if self.prepared_plan is not None and not isinstance(self.prepared_plan, RefreshPlan):
            raise ValueError("prepared_plan must be a RefreshPlan or None")
        if not self.dispatched_records:
            object.__setattr__(self, "dispatched_records", tuple(None for _ in self.joints))
        else:
            if type(self.dispatched_records) is not tuple or len(self.dispatched_records) != len(self.joints):
                raise ValueError("dispatched_records must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchedRecord) for r in self.dispatched_records):
                raise ValueError("every dispatched record must be a JointDispatchedRecord or None")
        if not self.dispatch_attempts:
            object.__setattr__(self, "dispatch_attempts", tuple(None for _ in self.joints))
        else:
            if type(self.dispatch_attempts) is not tuple or len(self.dispatch_attempts) != len(self.joints):
                raise ValueError("dispatch_attempts must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchAttempt) for r in self.dispatch_attempts):
                raise ValueError("every dispatch attempt must be a JointDispatchAttempt or None")
        if type(self.last_sequence) is not int or not (-1 <= self.last_sequence <= (1 << 64) - 1):
            raise ValueError("last_sequence must be an integer from -1 to 2**64 - 1")
        if self.latest_owner is not None and type(self.latest_owner) is not OwnerToken:
            raise ValueError("latest_owner must be an OwnerToken or None")
        if self.current_owner is not None and type(self.current_owner) is not OwnerToken:
            raise ValueError("current_owner must be an OwnerToken or None")
        if not self.confirmed_references:
            object.__setattr__(self, "confirmed_references", tuple(None for _ in self.joints))
        else:
            if type(self.confirmed_references) is not tuple or len(self.confirmed_references) != len(self.joints):
                raise ValueError("confirmed_references must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointTrajectoryReference) for r in self.confirmed_references):
                raise ValueError("every confirmed reference must be a JointTrajectoryReference or None")

    @property
    def affected_joints(self) -> tuple[str, ...]:
        return tuple(fault.name for fault in self.faults)

```

## joint_controller.py complete
```
"""Transport-free lifecycle and health state for an ordered joint set.

All methods on a JointCore belong to one calling thread. The core owns no
transport and all externally visible records are immutable snapshots.
"""

from collections.abc import Iterable
from dataclasses import dataclass
import math
import secrets
import time

from joint_contract import (
    CommunicationFailure,
    Decision,
    DecisionCode,
    IntentWindow,
    JointDispatchAttempt,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    JointTrajectoryReference,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
    owner_tokens_match,
)
from joint_mapping import JointSample
from joint_reference import (
    prepare_complete_reference,
    validate_target_vector,
    verify_dispatch_claim,
)

__all__ = ("JointCore",)


@dataclass(frozen=True)
class _DispatchClaim:
    plan: RefreshPlan
    index: int
    started_at_s: float


class JointCore:
    """Thread-confined state machine for one fixed, ordered set of joints.

    The core public API assumes trusted station callers; C16 server binds its
    actual connection identity rather than trusting client-supplied JSON fields.
    No authentication claims are made beyond that boundary.
    """

    def __init__(
        self,
        joints: Iterable[JointSpec],
        *,
        max_reference_gap_s: float,
        feedback_max_age_s: float = 0.5,
        max_window_s: float = 1.0,
        clock=None,
    ):
        if isinstance(max_reference_gap_s, bool) or not isinstance(max_reference_gap_s, (int, float)):
            raise ValueError("max_reference_gap_s must be a finite positive real number")
        try:
            max_reference_gap_s = float(max_reference_gap_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_reference_gap_s must be finite") from exc
        if not math.isfinite(max_reference_gap_s) or max_reference_gap_s <= 0.0:
            raise ValueError("max_reference_gap_s must be finite and positive")

        if isinstance(feedback_max_age_s, bool) or not isinstance(feedback_max_age_s, (int, float)):
            raise ValueError("feedback_max_age_s must be a finite positive real number")
        try:
            feedback_max_age_s = float(feedback_max_age_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("feedback_max_age_s must be finite") from exc
        if not math.isfinite(feedback_max_age_s) or feedback_max_age_s <= 0.0:
            raise ValueError("feedback_max_age_s must be finite and positive")

        if isinstance(max_window_s, bool) or not isinstance(max_window_s, (int, float)):
            raise ValueError("max_window_s must be a finite positive real number")
        try:
            max_window_s = float(max_window_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_window_s must be finite") from exc
        if not math.isfinite(max_window_s) or max_window_s <= 0.0:
            raise ValueError("max_window_s must be finite and positive")

        if clock is None:
            clock = time.monotonic
        if not callable(clock):
            raise ValueError("clock must be callable")

        self._epoch = secrets.token_hex(16)

        try:
            specs = tuple(joints)
        except TypeError as exc:
            raise ValueError("joints must be an iterable of JointSpec") from exc
        if not specs:
            raise ValueError("at least one active joint is required")
        if any(not isinstance(spec, JointSpec) for spec in specs):
            raise ValueError("every joint must be a JointSpec")
        if len({spec.name for spec in specs}) != len(specs):
            raise ValueError("joint names must be unique")
        if len({spec.motor_id for spec in specs}) != len(specs):
            raise ValueError("motor IDs must be unique")

        self._specs: tuple[JointSpec, ...] = specs
        self._id_to_index: dict[int, int] = {
            spec.motor_id: index for index, spec in enumerate(specs)
        }
        self._state: State = State.DISCONNECTED
        self._observations: list[JointStatus] = [JointStatus() for _ in specs]
        self._source: SourceIdentity | None = None
        self._max_reference_gap_s = max_reference_gap_s
        self._feedback_max_age_s = feedback_max_age_s
        self._max_window_s = max_window_s
        self._clock = clock
        self._now_high_water_s: float | None = None
        self._next_window_id: int = 0
        self._offered_window: IntentWindow | None = None
        self._next_generation: int = 1
        self._latest_owner: OwnerToken | None = None
        self._current_owner: OwnerToken | None = None
        self._admitted_target: Target | None = None
        self._prepared_plan: RefreshPlan | None = None
        self._next_plan_id: int = 0
        self._next_dispatch_index: int = 0
        self._dispatch_claim: _DispatchClaim | None = None
        self._dispatched_records: list[JointDispatchedRecord | None] = [None for _ in specs]
        self._dispatch_attempts: list[JointDispatchAttempt | None] = [None for _ in specs]
        self._confirmed_references: list[JointTrajectoryReference | None] = [None for _ in specs]
        self._faults: dict[str, JointFault] = {}
        self._last_sequence: int = -1

    @property
    def max_reference_gap_s(self) -> float:
        return self._max_reference_gap_s

    @property
    def joint_specs(self) -> tuple[JointSpec, ...]:
        return self._specs

    @property
    def admitted_target(self) -> Target | None:
        return self._admitted_target

    @staticmethod
    def _accepted() -> Decision:
        return Decision(True, DecisionCode.ACCEPTED)

    @staticmethod
    def _rejected(code: DecisionCode) -> Decision:
        return Decision(False, code)

    def _clear_observations(self) -> None:
        self._observations = [JointStatus() for _ in self._specs]

    def _invalidate_plan(self) -> None:
        self._prepared_plan = None
        self._next_dispatch_index = 0

    def _revoke_authority(self) -> None:
        self._current_owner = None
        self._offered_window = None
        self._admitted_target = None
        self._invalidate_plan()

    def claim_owner(self, connection_id: str) -> OwnerToken:
        """Issue and claim owner authority for a trusted station caller.

        The core public API assumes trusted station callers; C16 server binds its
        actual connection identity rather than trusting client-supplied JSON fields.
        No authentication claims are made beyond that boundary.
        """
        if (
            type(connection_id) is not str
            or not connection_id.strip()
            or len(connection_id) > 64
        ):
            raise ValueError("connection_id must be a bounded non-empty string")
        was_owned = self._current_owner is not None
        stop_for_claim = self._state in (
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
        ) or (was_owned and self._state not in (State.DISCONNECTED, State.CONNECTING))
        self._revoke_authority()
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            pass
        elif self._state is State.FAULT or self._faults:
            self._state = State.FAULT
        elif stop_for_claim:
            self._state = State.STOPPED

        if self._next_generation > (1 << 64) - 1:
            raise OverflowError("owner generation sequence exhausted")

        generation = self._next_generation
        self._next_generation += 1
        token = OwnerToken(
            epoch=self._epoch,
            generation=generation,
            connection_id=connection_id,
        )
        self._current_owner = token
        self._latest_owner = token
        return token

    def _record_dispatch_failure(
        self, index: int, cause: CommunicationFailure
    ) -> None:
        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            spec.motor_id,
            communication_error=cause,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample,
            joint.health,
            joint.received_at,
            cause,
        )

    def _latch_joint_fault(
        self,
        name: str,
        motor_id: int,
        *,
        errors: int = 0,
        warnings: int = 0,
        timeout: bool = False,
        communication_error: CommunicationFailure | None = None,
        stale: bool = False,
        position_limit: bool = False,
        speed_limit: bool = False,
        constraint_fault: bool = False,
    ) -> None:
        existing = self._faults.get(name) or JointFault(name, motor_id)
        communication_errors = existing.communication_errors
        if communication_error is not None and communication_error not in communication_errors:
            communication_errors += (communication_error,)
        fault = JointFault(
            name, motor_id,
            errors=existing.errors | errors,
            warnings=existing.warnings | warnings,
            timeout=existing.timeout or timeout,
            stale=existing.stale or stale,
            communication_error=communication_error or existing.communication_error,
            communication_errors=communication_errors,
            position_limit=existing.position_limit or position_limit,
            speed_limit=existing.speed_limit or speed_limit,
            constraint_fault=existing.constraint_fault or constraint_fault,
        )
        self._faults[name] = fault
        if self._state is not State.DISCONNECTED:
            self._state = State.FAULT
        self._revoke_authority()

    def _withdraw_expired_goal(self) -> None:
        self._revoke_authority()
        if self._faults:
            self._state = State.FAULT
        elif self._state in (State.ARMED, State.MOVING):
            self._state = State.STOPPED

    def _now(self) -> float:
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("clock must return a finite real number")
        try:
            result = float(value)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("clock must return a finite real number") from exc
        if not math.isfinite(result):
            raise ValueError("clock must return a finite real number")
        if self._now_high_water_s is not None and result < self._now_high_water_s:
            raise ValueError(
                f"clock regressed from {self._now_high_water_s} to {result}"
            )
        self._now_high_water_s = result
        return result

    @staticmethod
    def _age(received_at: float, now: float) -> float:
        age = now - received_at
        if not math.isfinite(age) or age < 0.0:
            raise ValueError("clock must be monotonic and feedback age finite")
        return age

    def _all_fresh(self, now: float) -> bool:
        return all(
            joint.valid
            and joint.received_at is not None
            and self._age(joint.received_at, now) <= self._feedback_max_age_s
            for joint in self._observations
        )

    def _housekeeping(self, now: float) -> DecisionCode | None:
        if self._state in (State.READY, State.ARMED, State.MOVING):
            stale_by_joint: list[bool] = []
            pos_outside_by_joint: list[bool] = []
            speed_outside_by_joint: list[bool] = []
            for spec, joint in zip(self._specs, self._observations):
                stale_by_joint.append(
                    not joint.valid
                    or joint.received_at is None
                    or self._age(joint.received_at, now) > self._feedback_max_age_s
                )
                pos_outside_by_joint.append(
                    joint.valid
                    and joint.sample is not None
                    and (joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad)
                )
                speed_outside_by_joint.append(
                    joint.valid
                    and joint.sample is not None
                    and (abs(joint.sample.dq_rad_s) > spec.v_max_rad_s)
                )
            for spec, stale, pos_out, speed_out in zip(
                self._specs, stale_by_joint, pos_outside_by_joint, speed_outside_by_joint
            ):
                if stale or pos_out or speed_out:
                    self._latch_joint_fault(
                        spec.name,
                        spec.motor_id,
                        stale=stale,
                        position_limit=pos_out,
                        speed_limit=speed_out,
                    )
            if any(stale_by_joint):
                return DecisionCode.STALE_FEEDBACK
            if any(pos_outside_by_joint):
                return DecisionCode.POSITION_OUT_OF_BOUNDS
            if any(speed_outside_by_joint):
                return DecisionCode.SPEED_OUT_OF_BOUNDS
        if (
            self._admitted_target is not None
            and now >= self._admitted_target.window.expires_at_s
        ):
            self._withdraw_expired_goal()
            return DecisionCode.EXPIRED
        return None

    def issue_window(self, valid_for_s: float) -> IntentWindow:
        if isinstance(valid_for_s, bool) or not isinstance(valid_for_s, (int, float)):
            raise ValueError("valid_for_s must be a finite positive real number")
        try:
            valid_for_s = float(valid_for_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("valid_for_s must be finite") from exc
        if not math.isfinite(valid_for_s) or valid_for_s <= 0.0:
            raise ValueError("valid_for_s must be finite and positive")
        if valid_for_s > self._max_window_s:
            raise ValueError(
                f"valid_for_s ({valid_for_s}) exceeds configured maximum window ({self._max_window_s})"
            )
        now = self._now()
        window_id = self._next_window_id
        if window_id > (1 << 64) - 1:
            raise OverflowError("window ID sequence exhausted")
        self._next_window_id += 1
        window = IntentWindow(
            id=window_id,
            created_at_s=now,
            expires_at_s=now + valid_for_s,
        )
        self._offered_window = window
        return window

    def begin_connect(self) -> Decision:
        if self._state is not State.DISCONNECTED or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        self._state = State.CONNECTING
        return self._accepted()

    def connected(self, source: SourceIdentity) -> Decision:
        if self._state is not State.CONNECTING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not isinstance(source, SourceIdentity):
            return self._rejected(DecisionCode.INVALID_SOURCE)
        self._clear_observations()
        self._source = source
        self._state = State.CONNECTED
        return self._accepted()

    def begin_check(self, *, acknowledge_fault: bool = False) -> Decision:
        if type(acknowledge_fault) is not bool:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._state not in (State.CONNECTED, State.STOPPED, State.FAULT) or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        if bool(self._faults) and not acknowledge_fault:
            return self._rejected(DecisionCode.FAULT_ACK_REQUIRED)
        self._clear_observations()
        self._admitted_target = None
        self._confirmed_references = [None for _ in self._specs]
        self._invalidate_plan()
        self._state = State.CHECKING
        return self._accepted()

    def receive(
        self, motor_id: int, sample: JointSample, status: MotorHealth
    ) -> Decision:
        if self._state not in (
            State.CONNECTED,
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
            State.STOPPED,
            State.FAULT,
        ):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)
        if not isinstance(sample, JointSample) or not isinstance(status, MotorHealth):
            return self._rejected(DecisionCode.INVALID_OBSERVATION)

        now = self._now()
        self._observations[index] = JointStatus(sample, status, now)
        spec = self._specs[index]
        position_limit = (
            sample.q_rad < spec.q_min_rad or sample.q_rad > spec.q_max_rad
        )
        speed_limit = (
            abs(sample.dq_rad_s) > spec.v_max_rad_s
        )
        if not status.healthy or position_limit or speed_limit:
            self._latch_joint_fault(
                spec.name,
                motor_id,
                errors=status.errors,
                warnings=status.warnings,
                timeout=status.timeout,
                position_limit=position_limit,
                speed_limit=speed_limit,
            )
        if position_limit:
            return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
        if speed_limit:
            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
        return self._accepted()

    def communication_failed(
        self, motor_id: int, code: CommunicationFailure
    ) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)

        if not isinstance(code, CommunicationFailure):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        failure_code = code

        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            motor_id,
            communication_error=failure_code,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample, joint.health, joint.received_at, failure_code
        )
        return self._accepted()

    def checked(self) -> Decision:
        if self._state is not State.CHECKING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        pos_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
        ]
        speed_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
        ]
        if pos_out_of_bounds or speed_out_of_bounds:
            for spec in pos_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            for spec in speed_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            if pos_out_of_bounds:
                return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)

        self._state = State.READY
        self._faults.clear()
        self._confirmed_references = [
            JointTrajectoryReference(
                q_rad=joint.sample.q_rad,
                position_step_velocity_rad_s=0.0,
                encoded_velocity_rad_s=0.0,
                sample_time_s=joint.received_at,
                is_emitted=False,
            )
            for joint in self._observations
        ]
        return self._accepted()

    def arm(self, owner: OwnerToken) -> Decision:
        if self._state is not State.READY:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not owner_tokens_match(owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)
        if bool(self._faults):
            return self._rejected(DecisionCode.FAULT_LATCHED)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        pos_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
        ]
        speed_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
        ]
        if pos_out_of_bounds or speed_out_of_bounds:
            for spec in pos_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            for spec in speed_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            if pos_out_of_bounds:
                return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)

        self._state = State.ARMED
        return self._accepted()

    def tick(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        self._housekeeping(now)
        return self._accepted()

    def submit_target(self, target: Target) -> Decision:
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        housekeeping = self._housekeeping(now)
        if housekeeping is not None:
            return self._rejected(housekeeping)
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)

        if not isinstance(target, Target) or len(target.joints) != len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        if not owner_tokens_match(target.owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)

        if not isinstance(target.window, IntentWindow):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._offered_window is None:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if target.window.id < self._offered_window.id:
            return self._rejected(DecisionCode.EXPIRED)
        if target.window.id != self._offered_window.id:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if (
            target.window.created_at_s != self._offered_window.created_at_s
            or target.window.expires_at_s != self._offered_window.expires_at_s
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if now >= target.window.expires_at_s:
            return self._rejected(DecisionCode.EXPIRED)

        if not self._all_fresh(now) or any(
            not joint.valid or joint.sample is None for joint in self._observations
        ):
            return self._rejected(DecisionCode.STALE_FEEDBACK)

        validation_failures = validate_target_vector(
            self._specs,
            target,
            tuple(joint.sample.q_rad for joint in self._observations),
        )
        if validation_failures:
            return self._rejected(validation_failures[0].code)

        if target.sequence <= self._last_sequence:
            return self._rejected(DecisionCode.DUPLICATE_OR_OLDER)

        self._admitted_target = target
        self._last_sequence = target.sequence
        self._invalidate_plan()
        return self._accepted()

    def prepare_refresh(self) -> RefreshPlan | None:
        if self._dispatch_claim is not None:
            return None
        if self._state not in (State.ARMED, State.MOVING):
            return None
        if self._state is State.FAULT or bool(self._faults):
            return None
        try:
            now = self._now()
        except ValueError:
            self.stop()
            raise
        if self._housekeeping(now) is not None:
            return None
        if any(not joint.healthy for joint in self._observations):
            return None
        if self._admitted_target is None:
            return None
        if not owner_tokens_match(self._admitted_target.owner, self._current_owner):
            return None

        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid or joint.sample is None:
                return None
            pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
            speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
            if pos_out or speed_out:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=pos_out, speed_limit=speed_out)
                self.stop()
                return None

        for spec, conf_ref in zip(self._specs, self._confirmed_references):
            if conf_ref is None:
                return None
            gap = now - conf_ref.sample_time_s
            if not math.isfinite(gap) or gap < 0.0:
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
                self.stop()
                return None
            if gap > self._max_reference_gap_s:
                self.stop()
                return None

        prepared = prepare_complete_reference(
            self._specs,
            self._admitted_target,
            tuple(self._confirmed_references),
            tuple(joint.sample.q_rad for joint in self._observations),
            now,
            self._max_reference_gap_s,
        )
        if not prepared.ready:
            for failure in prepared.failures:
                if failure.joint_index is None:
                    continue
                spec = self._specs[failure.joint_index]
                if failure.code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, position_limit=True
                    )
                elif failure.code is DecisionCode.SPEED_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, speed_limit=True
                    )
                else:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, constraint_fault=True
                    )
            self.stop()
            return None

        plan_id = self._next_plan_id
        if plan_id > (1 << 64) - 1:
            raise OverflowError("plan ID sequence exhausted")
        self._next_plan_id += 1

        plan = RefreshPlan(
            plan_id=plan_id,
            target=self._admitted_target,
            prepared_at_s=now,
            joint_targets=prepared.joint_targets,
            packets=prepared.packets,
            proposed_references=prepared.proposed_references,
        )
        self._prepared_plan = plan
        self._next_dispatch_index = 0
        return plan

    def claim_dispatch(self, plan_id: int, index: int) -> bool:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return False
        if self._dispatch_claim is not None:
            return False
        if self._prepared_plan is None or self._prepared_plan.plan_id != plan_id:
            return False
        if self._state not in (State.ARMED, State.MOVING):
            return False
        if self._state is State.FAULT or bool(self._faults):
            return False
        if index < 0 or index >= len(self._specs):
            return False
        if index != self._next_dispatch_index:
            return False

        now = self._now()
        if self._housekeeping(now) is not None:
            return False
        if self._admitted_target is None or self._prepared_plan is None:
            return False
        if not owner_tokens_match(self._prepared_plan.target.owner, self._current_owner):
            return False
        if any(not joint.healthy for joint in self._observations):
            return False

        if not self._all_fresh(now):
            return False
        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid or joint.sample is None:
                return False
            pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
            speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
            if pos_out or speed_out:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=pos_out, speed_limit=speed_out)
                self.stop()
                return False

        conf_ref = self._confirmed_references[index]
        if conf_ref is not None:
            gap = now - conf_ref.sample_time_s
            if not math.isfinite(gap) or gap < 0.0 or gap > self._max_reference_gap_s:
                self.stop()
                return False

        plan_joint = self._prepared_plan.joint_targets[index]
        spec = self._specs[index]
        prop_ref = self._prepared_plan.proposed_references[index]
        failure_code = verify_dispatch_claim(
            spec=spec,
            prop_ref=prop_ref,
            conf_ref=conf_ref,
            plan_joint=plan_joint,
            packet=self._prepared_plan.packets[index],
            goal=self._prepared_plan.target.joints[index],
            q_meas=self._observations[index].sample.q_rad,
            prepared_at_s=self._prepared_plan.prepared_at_s,
        )
        if failure_code is not None:
            if failure_code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            elif failure_code is DecisionCode.SPEED_OUT_OF_BOUNDS:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            else:
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
            self.stop()
            return False

        self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
        return True

    def dispatch_result(
        self, plan_id: int, index: int, result: WriteResult
    ) -> Decision:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if not isinstance(result, WriteResult):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        claim = self._dispatch_claim
        if claim is None or claim.plan.plan_id != plan_id or claim.index != index:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if index < 0 or index >= len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        plan = claim.plan
        joint_target = plan.joint_targets[index]
        self._dispatch_attempts[index] = JointDispatchAttempt(
            plan_id=plan.plan_id,
            sequence=plan.target.sequence,
            target=joint_target,
            result=result,
            started_at_s=claim.started_at_s,
            owner=plan.target.owner,
        )
        if result is WriteResult.COMPLETE:
            record = JointDispatchedRecord(
                sequence=plan.target.sequence,
                target=joint_target,
                dispatched_at_s=claim.started_at_s,
                owner=plan.target.owner,
            )
            self._dispatched_records[index] = record
            self._confirmed_references[index] = plan.proposed_references[index]
            try:
                now = self._now()
            except Exception:
                self._record_dispatch_failure(index, CommunicationFailure.CLOCK_FAILURE)
                self._dispatch_claim = None
                return self._rejected(DecisionCode.FAULT_LATCHED)

            housekeeping = self._housekeeping(now)
            still_current = (
                self._prepared_plan is plan
                and self._admitted_target is plan.target
                and self._state in (State.ARMED, State.MOVING)
                and not self._faults
                and owner_tokens_match(self._current_owner, plan.target.owner)
            )
            if still_current and housekeeping is None:
                self._next_dispatch_index = index + 1
                self._state = State.MOVING
            self._dispatch_claim = None
            return self._accepted()

        cause = (
            CommunicationFailure.PREWRITE_DEADLINE
            if result is WriteResult.PREWRITE_DEADLINE
            else CommunicationFailure.DRIVER_FAILURE
        )
        self._record_dispatch_failure(index, cause)
        self._dispatch_claim = None
        return self._rejected(DecisionCode.FAULT_LATCHED)

    def stop(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        self._revoke_authority()
        if self._state is State.FAULT or bool(self._faults):
            self._state = State.FAULT
        else:
            self._state = State.STOPPED
        return self._accepted()

    def disconnect(self) -> Decision:
        self._state = State.DISCONNECTED
        self._source = None
        self._clear_observations()
        self._confirmed_references = [None for _ in self._specs]
        self._revoke_authority()
        return self._accepted()

    def snapshot(self) -> Snapshot:
        received = [joint.received_at for joint in self._observations]
        now = self._now() if any(value is not None for value in received) else None
        ages = tuple(
            None if value is None else self._age(value, now)
            for value in received
        )
        faults = tuple(self._faults[spec.name] for spec in self._specs
                       if spec.name in self._faults)
        return Snapshot(
            state=self._state,
            joint_names=tuple(spec.name for spec in self._specs),
            joints=tuple(self._observations),
            source=self._source,
            fault_latched=bool(self._faults),
            feedback_ages_s=ages,
            faults=faults,
            admitted_target=self._admitted_target,
            prepared_plan=self._prepared_plan,
            dispatched_records=tuple(self._dispatched_records),
            dispatch_attempts=tuple(self._dispatch_attempts),
            last_sequence=self._last_sequence,
            latest_owner=self._latest_owner,
            current_owner=self._current_owner,
            confirmed_references=tuple(self._confirmed_references),
        )

```

## joint_reference.py complete
```
"""Pure joint reference validation and canonical packet preparation."""

from dataclasses import dataclass
from fractions import Fraction
import math
from im6014_codec import (
    command,
    command_with_raw_position,
    decode_command,
    project_position_raw,
    project_speed_raw,
    raw_to_position,
    raw_to_rpm,
)
from joint_contract import (
    DecisionCode,
    JointSpec,
    JointTrajectoryReference,
    Target,
)
from joint_mapping import JointTarget, OutputSample

__all__ = (
    "prepare_reference_joint",
    "shape_reference_joint",
    "prepare_complete_reference",
    "validate_target_vector",
    "verify_dispatch_claim",
    "ReferenceFailure",
    "ReferenceBatchResult",
)


@dataclass(frozen=True)
class ReferenceFailure:
    code: DecisionCode
    joint_index: int | None

    def __post_init__(self) -> None:
        if not isinstance(self.code, DecisionCode):
            raise ValueError("reference failure code must be a DecisionCode")
        if self.joint_index is not None and (
            type(self.joint_index) is not int or self.joint_index < 0
        ):
            raise ValueError("joint_index must be a nonnegative integer or None")


@dataclass(frozen=True)
class ReferenceBatchResult:
    joint_targets: tuple[JointTarget, ...] | None
    packets: tuple[bytes, ...] | None
    proposed_references: tuple[JointTrajectoryReference, ...] | None
    failures: tuple[ReferenceFailure, ...]

    def __post_init__(self) -> None:
        if type(self.failures) is not tuple or any(
            not isinstance(failure, ReferenceFailure) for failure in self.failures
        ):
            raise ValueError("failures must be a tuple of ReferenceFailure")
        if self.failures:
            if any(
                value is not None
                for value in (self.joint_targets, self.packets, self.proposed_references)
            ):
                raise ValueError("a failed batch cannot expose a partial plan")
            indices = [failure.joint_index for failure in self.failures]
            if len(indices) != len(set(indices)):
                raise ValueError("a batch can report at most one failure per joint")
            return

        if (
            type(self.joint_targets) is not tuple
            or type(self.packets) is not tuple
            or type(self.proposed_references) is not tuple
            or not self.joint_targets
            or len(self.joint_targets) != len(self.packets)
            or len(self.joint_targets) != len(self.proposed_references)
        ):
            raise ValueError("a successful batch requires complete parallel tuples")
        if any(not isinstance(target, JointTarget) for target in self.joint_targets):
            raise ValueError("every batch target must be a JointTarget")
        if any(type(packet) is not bytes for packet in self.packets):
            raise ValueError("every batch packet must be immutable bytes")
        if any(not isinstance(ref, JointTrajectoryReference) for ref in self.proposed_references):
            raise ValueError("every batch reference must be a JointTrajectoryReference")

    @property
    def ready(self) -> bool:
        return not self.failures


def prepare_reference_joint(
    spec: JointSpec, target: JointTarget
) -> tuple[DecisionCode | None, JointTarget | None, bytes | None]:
    """Validate a request and bind its actual decoded command to canonical bytes."""
    if not isinstance(spec, JointSpec) or not isinstance(target, JointTarget):
        return DecisionCode.INVALID_ARGUMENT, None, None
    if target.q_rad < spec.q_min_rad or target.q_rad > spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
    if abs(target.dq_rad_s) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None

    try:
        output = spec.mapping.to_output(target)
        # Validate the original mapped request through the ordinary codec before
        # projecting its position onto an inward representable grid point.
        command(
            spec.motor_id,
            mode=1,
            rpm=output.rpm,
            kd=output.kd,
            torque=output.tau_nm,
            watchdog=True,
            position=output.q_rad,
            kp=output.kp,
        )
        raw_position = project_position_raw(
            target.q_rad,
            spec.q_min_rad,
            spec.q_max_rad,
            lambda output_q: spec.mapping.from_output(
                OutputSample(output_q, 0.0, 0.0)
            ).q_rad,
            spec.mapping.direction,
        )
        if raw_position is None:
            return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None

        raw_rpm = project_speed_raw(
            target.dq_rad_s,
            -spec.v_max_rad_s,
            spec.v_max_rad_s,
            lambda output_rpm: spec.mapping.from_output(
                OutputSample(0.0, output_rpm, 0.0)
            ).dq_rad_s,
            spec.mapping.direction,
        )
        if raw_rpm is None:
            return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.INVALID_ARGUMENT, None, None

    try:
        packet = command_with_raw_position(
            spec.motor_id,
            raw_position,
            mode=1,
            rpm=output.rpm,
            kd=output.kd,
            torque=output.tau_nm,
            watchdog=True,
            kp=output.kp,
            raw_rpm=raw_rpm,
        )
        decoded = decode_command(packet)
        actual_output = spec.mapping.from_output(
            OutputSample(
                decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
            )
        )
        gain_scale = spec.mapping.reduction ** 2
        actual_target = JointTarget(
            q_rad=actual_output.q_rad,
            dq_rad_s=actual_output.dq_rad_s,
            tau_nm=actual_output.tau_nm,
            kp=decoded["kp"] * gain_scale,
            kd=decoded["kd"] * gain_scale,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.INVALID_ARGUMENT, None, None

    if not spec.q_min_rad <= actual_target.q_rad <= spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
    if abs(actual_target.dq_rad_s) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
    return None, actual_target, packet


def validate_target_vector(
    specs: tuple[JointSpec, ...],
    target: Target,
    measured_positions: tuple[float, ...],
) -> tuple[ReferenceFailure, ...]:
    """Validate every admitted joint request before replacing the current goal."""
    if (
        not isinstance(target, Target)
        or len(target.joints) != len(specs)
        or len(measured_positions) != len(specs)
    ):
        return (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)

    failures: list[ReferenceFailure] = []
    for index, (spec, joint_target, q_meas) in enumerate(
        zip(specs, target.joints, measured_positions)
    ):
        code, _, _ = prepare_reference_joint(spec, joint_target)
        if code is not None:
            failures.append(ReferenceFailure(code, index))
            continue
        if isinstance(q_meas, bool) or not isinstance(q_meas, (int, float)):
            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
            continue
        try:
            q_meas_float = float(q_meas)
        except (OverflowError, TypeError, ValueError):
            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
            continue
        if not math.isfinite(q_meas_float):
            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
            continue
        if (
            joint_target.q_rad < q_meas_float - spec.max_lead_rad
            or joint_target.q_rad > q_meas_float + spec.max_lead_rad
        ):
            failures.append(ReferenceFailure(DecisionCode.LEAD_OUT_OF_BOUNDS, index))
    return tuple(failures)


def shape_reference_joint(
    spec: JointSpec,
    target: JointTarget,
    confirmed_ref: JointTrajectoryReference,
    q_meas: float,
    now: float,
    max_reference_gap_s: float,
) -> tuple[
    DecisionCode | None,
    JointTarget | None,
    JointTrajectoryReference | None,
    bytes | None,
]:
    """Shape one discrete reference point and retain its exact emitted command."""
    if (
        not isinstance(spec, JointSpec)
        or not isinstance(target, JointTarget)
        or not isinstance(confirmed_ref, JointTrajectoryReference)
    ):
        return DecisionCode.INVALID_ARGUMENT, None, None, None

    normalized: list[float] = []
    for val in (
        target.q_rad,
        target.dq_rad_s,
        target.tau_nm,
        target.kp,
        target.kd,
        q_meas,
        now,
        max_reference_gap_s,
    ):
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        try:
            numeric = float(val)
        except (OverflowError, TypeError, ValueError):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        if not math.isfinite(numeric):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        normalized.append(numeric)
    (
        goal_q,
        goal_dq,
        goal_tau,
        goal_kp,
        goal_kd,
        q_meas_val,
        now,
        max_reference_gap_s,
    ) = normalized
    if max_reference_gap_s <= 0.0:
        return DecisionCode.INVALID_ARGUMENT, None, None, None

    if goal_q < spec.q_min_rad or goal_q > spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
    if abs(goal_dq) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None, None

    h = now - confirmed_ref.sample_time_s
    if not math.isfinite(h) or h < 0.0:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if h > max_reference_gap_s:
        return DecisionCode.REFERENCE_GAP_EXCEEDED, None, None, None

    if h == 0.0:
        if not confirmed_ref.is_emitted:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if target != confirmed_ref.requested_goal:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if (
            confirmed_ref.emitted_target is None
            or confirmed_ref.packet is None
        ):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if (
            confirmed_ref.q_rad < spec.q_min_rad
            or confirmed_ref.q_rad > spec.q_max_rad
        ):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if (
            confirmed_ref.q_rad < q_meas_val - spec.max_lead_rad
            or confirmed_ref.q_rad > q_meas_val + spec.max_lead_rad
        ):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if abs(confirmed_ref.encoded_velocity_rad_s) > spec.v_max_rad_s:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if abs(confirmed_ref.position_step_velocity_rad_s) > Fraction(spec.v_max_rad_s):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        return (
            None,
            confirmed_ref.emitted_target,
            confirmed_ref,
            confirmed_ref.packet,
        )

    # Use exact rational arithmetic over the stored finite float-domain values.
    # The sample cadence is the actual float subtraction above, not a decimal
    # interpretation of either timestamp.
    try:
        h_exact = Fraction(h)
        q_prev_exact = Fraction(confirmed_ref.q_rad)
        v_prev_pos_exact = Fraction(confirmed_ref.position_step_velocity_rad_s)
        v_prev_enc_exact = Fraction(confirmed_ref.encoded_velocity_rad_s)
        q_min_exact = Fraction(spec.q_min_rad)
        q_max_exact = Fraction(spec.q_max_rad)
        v_max_exact = Fraction(spec.v_max_rad_s)
        a_max_exact = Fraction(spec.a_max_rad_s2)
        lead_exact = Fraction(spec.max_lead_rad)
        q_meas_exact = Fraction(q_meas_val)

        v_pos_lo = (q_min_exact - q_prev_exact) / h_exact
        v_pos_hi = (q_max_exact - q_prev_exact) / h_exact
        v_acc_lo = v_prev_pos_exact - a_max_exact * h_exact
        v_acc_hi = v_prev_pos_exact + a_max_exact * h_exact
        v_lead_lo = (q_meas_exact - lead_exact - q_prev_exact) / h_exact
        v_lead_hi = (q_meas_exact + lead_exact - q_prev_exact) / h_exact

        v_lo = max(-v_max_exact, v_pos_lo, v_acc_lo, v_lead_lo)
        v_hi = min(v_max_exact, v_pos_hi, v_acc_hi, v_lead_hi)
        if v_lo > v_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        # q and dq jointly define a one-step objective; q does not replace dq.
        v_desired = (Fraction(goal_q) - q_prev_exact) / h_exact + Fraction(goal_dq)
        v_projected = max(v_lo, min(v_hi, v_desired))
        q_continuous = q_prev_exact + v_projected * h_exact
        q_next_lo = q_prev_exact + v_lo * h_exact
        q_next_hi = q_prev_exact + v_hi * h_exact
        if q_next_lo > q_next_hi or not q_next_lo <= q_continuous <= q_next_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        q_wanted = float(q_continuous)
        q_lower = float(q_next_lo)
        q_upper = float(q_next_hi)
        if not all(math.isfinite(value) for value in (q_wanted, q_lower, q_upper)):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        v_enc_lo = max(-v_max_exact, v_prev_enc_exact - a_max_exact * h_exact)
        v_enc_hi = min(v_max_exact, v_prev_enc_exact + a_max_exact * h_exact)
        if v_enc_lo > v_enc_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        v_enc_desired = Fraction(goal_dq)
        v_enc_projected = max(v_enc_lo, min(v_enc_hi, v_enc_desired))
        v_enc_wanted = float(v_enc_projected)
        v_enc_lower = float(v_enc_lo)
        v_enc_upper = float(v_enc_hi)
        if not all(math.isfinite(value) for value in (v_enc_wanted, v_enc_lower, v_enc_upper)):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        output_req = spec.mapping.to_output(
            JointTarget(goal_q, goal_dq, goal_tau, goal_kp, goal_kd)
        )
        command(
            spec.motor_id,
            mode=1,
            rpm=output_req.rpm,
            kd=output_req.kd,
            torque=output_req.tau_nm,
            watchdog=True,
            position=output_req.q_rad,
            kp=output_req.kp,
        )
        raw_pos = project_position_raw(
            q_wanted,
            q_lower,
            q_upper,
            lambda out_q: spec.mapping.from_output(OutputSample(out_q, 0.0, 0.0)).q_rad,
            spec.mapping.direction,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    if raw_pos is None:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    def mapped_position(raw_position: int) -> float:
        return spec.mapping.from_output(
            OutputSample(raw_to_position(raw_position), 0.0, 0.0)
        ).q_rad

    try:
        q_emitted = mapped_position(raw_pos)
        q_emitted_exact = Fraction(q_emitted)
        position_step_velocity = (q_emitted_exact - q_prev_exact) / h_exact
        safe_position = (
            q_min_exact <= q_emitted_exact <= q_max_exact
            and (q_meas_exact - lead_exact) <= q_emitted_exact <= (q_meas_exact + lead_exact)
            and q_next_lo <= q_emitted_exact <= q_next_hi
        )
        safe_step = (
            abs(position_step_velocity) <= v_max_exact
            and abs(position_step_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
        )
        if not safe_position or not safe_step:
            if q_emitted_exact < q_next_lo or position_step_velocity < v_lo:
                raw_step = spec.mapping.direction
            elif q_emitted_exact > q_next_hi or position_step_velocity > v_hi:
                raw_step = -spec.mapping.direction
            else:
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_candidate = raw_pos + raw_step
            candidate_q = mapped_position(raw_candidate)
            candidate_q_exact = Fraction(candidate_q)
            candidate_velocity = (candidate_q_exact - q_prev_exact) / h_exact
            if not (
                q_min_exact <= candidate_q_exact <= q_max_exact
                and (q_meas_exact - lead_exact) <= candidate_q_exact <= (q_meas_exact + lead_exact)
                and q_next_lo <= candidate_q_exact <= q_next_hi
                and abs(candidate_velocity) <= v_max_exact
                and abs(candidate_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
            ):
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_pos = raw_candidate
            q_emitted = candidate_q
            q_emitted_exact = candidate_q_exact
            position_step_velocity = candidate_velocity
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        raw_rpm = project_speed_raw(
            v_enc_wanted,
            v_enc_lower,
            v_enc_upper,
            lambda out_rpm: spec.mapping.from_output(OutputSample(0.0, out_rpm, 0.0)).dq_rad_s,
            spec.mapping.direction,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    if raw_rpm is None:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    def mapped_speed(raw_s: int) -> float:
        return spec.mapping.from_output(
            OutputSample(0.0, raw_to_rpm(raw_s), 0.0)
        ).dq_rad_s

    try:
        v_emitted_enc = mapped_speed(raw_rpm)
        v_emitted_enc_exact = Fraction(v_emitted_enc)
        safe_enc = (
            abs(v_emitted_enc_exact) <= v_max_exact
            and abs(v_emitted_enc_exact - v_prev_enc_exact) <= a_max_exact * h_exact
            and v_enc_lo <= v_emitted_enc_exact <= v_enc_hi
        )
        if not safe_enc:
            if v_emitted_enc_exact < v_enc_lo:
                raw_rpm_step = spec.mapping.direction
            elif v_emitted_enc_exact > v_enc_hi:
                raw_rpm_step = -spec.mapping.direction
            else:
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_rpm_cand = raw_rpm + raw_rpm_step
            cand_v_enc = mapped_speed(raw_rpm_cand)
            cand_v_enc_exact = Fraction(cand_v_enc)
            if not (
                abs(cand_v_enc_exact) <= v_max_exact
                and abs(cand_v_enc_exact - v_prev_enc_exact) <= a_max_exact * h_exact
                and v_enc_lo <= cand_v_enc_exact <= v_enc_hi
            ):
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_rpm = raw_rpm_cand
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        packet = command_with_raw_position(
            spec.motor_id,
            raw_pos,
            mode=1,
            kd=output_req.kd,
            torque=output_req.tau_nm,
            watchdog=True,
            kp=output_req.kp,
            raw_rpm=raw_rpm,
        )
        decoded = decode_command(packet)
        actual_output = spec.mapping.from_output(
            OutputSample(decoded["position_rad"], decoded["rpm"], decoded["torque_nm"])
        )
        gain_scale = spec.mapping.reduction ** 2
        actual_target = JointTarget(
            q_rad=actual_output.q_rad,
            dq_rad_s=actual_output.dq_rad_s,
            tau_nm=actual_output.tau_nm,
            kp=decoded["kp"] * gain_scale,
            kd=decoded["kd"] * gain_scale,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    actual_q_exact = Fraction(actual_target.q_rad)
    actual_position_step_velocity = (actual_q_exact - q_prev_exact) / h_exact
    actual_v_enc_exact = Fraction(actual_target.dq_rad_s)
    if not q_min_exact <= actual_q_exact <= q_max_exact:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
    if not (q_meas_exact - lead_exact <= actual_q_exact <= q_meas_exact + lead_exact):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if not q_next_lo <= actual_q_exact <= q_next_hi:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if v_desired != 0 and actual_target.q_rad == confirmed_ref.q_rad:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_v_enc_exact) > v_max_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_v_enc_exact - v_prev_enc_exact) > a_max_exact * h_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_position_step_velocity) > v_max_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_position_step_velocity - v_prev_pos_exact) > a_max_exact * h_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    proposed_ref = JointTrajectoryReference(
        q_rad=actual_target.q_rad,
        position_step_velocity_rad_s=actual_position_step_velocity,
        encoded_velocity_rad_s=actual_target.dq_rad_s,
        sample_time_s=now,
        is_emitted=True,
        requested_goal=JointTarget(goal_q, goal_dq, goal_tau, goal_kp, goal_kd),
        emitted_target=actual_target,
        packet=packet,
    )
    return None, actual_target, proposed_ref, packet


def prepare_complete_reference(
    specs: tuple[JointSpec, ...],
    target: Target,
    confirmed_references: tuple[JointTrajectoryReference, ...],
    measured_positions: tuple[float, ...],
    now: float,
    max_reference_gap_s: float,
) -> ReferenceBatchResult:
    """Shape all joints and report every failed index without exposing a partial plan."""
    if (
        type(specs) is not tuple
        or not specs
        or any(not isinstance(spec, JointSpec) for spec in specs)
        or not isinstance(target, Target)
        or len(target.joints) != len(specs)
        or type(confirmed_references) is not tuple
        or len(confirmed_references) != len(specs)
        or type(measured_positions) is not tuple
        or len(measured_positions) != len(specs)
    ):
        return ReferenceBatchResult(
            None, None, None, (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
        )

    actual_targets: list[JointTarget] = []
    packets: list[bytes] = []
    proposed_references: list[JointTrajectoryReference] = []
    failures: list[ReferenceFailure] = []

    for index, (spec, joint_target, conf_ref, q_meas) in enumerate(
        zip(specs, target.joints, confirmed_references, measured_positions)
    ):
        code, actual_target, prop_ref, packet = shape_reference_joint(
            spec, joint_target, conf_ref, q_meas, now, max_reference_gap_s
        )
        if code is not None or actual_target is None or prop_ref is None or packet is None:
            failures.append(
                ReferenceFailure(code or DecisionCode.CONSTRAINT_VIOLATION, index)
            )
            continue
        actual_targets.append(actual_target)
        packets.append(packet)
        proposed_references.append(prop_ref)

    if failures:
        return ReferenceBatchResult(None, None, None, tuple(failures))
    return ReferenceBatchResult(
        tuple(actual_targets), tuple(packets), tuple(proposed_references), ()
    )


def verify_dispatch_claim(
    spec: JointSpec,
    prop_ref: JointTrajectoryReference,
    conf_ref: JointTrajectoryReference,
    plan_joint: JointTarget,
    packet: bytes,
    goal: JointTarget,
    q_meas: float,
    prepared_at_s: float,
) -> DecisionCode | None:
    """Validate one proposed joint reference against all closed constraints at the write gate."""
    if (
        not isinstance(spec, JointSpec)
        or not isinstance(prop_ref, JointTrajectoryReference)
        or not isinstance(conf_ref, JointTrajectoryReference)
        or not isinstance(plan_joint, JointTarget)
        or type(packet) is not bytes
        or not isinstance(goal, JointTarget)
    ):
        return DecisionCode.CONSTRAINT_VIOLATION

    if (
        prop_ref.requested_goal != goal
        or prop_ref.emitted_target != plan_joint
        or prop_ref.packet != packet
        or prop_ref.sample_time_s > prepared_at_s
    ):
        return DecisionCode.CONSTRAINT_VIOLATION

    if prop_ref.sample_time_s == conf_ref.sample_time_s:
        if prop_ref != conf_ref:
            return DecisionCode.CONSTRAINT_VIOLATION
    elif (
        prop_ref.sample_time_s != prepared_at_s
        or prop_ref.sample_time_s <= conf_ref.sample_time_s
    ):
        return DecisionCode.CONSTRAINT_VIOLATION

    try:
        h_ref = prop_ref.sample_time_s - conf_ref.sample_time_s
        h_ref_exact = Fraction(h_ref)
        a_max_exact = Fraction(spec.a_max_rad_s2)
        v_max_exact = Fraction(spec.v_max_rad_s)
        v_prev_pos = Fraction(conf_ref.position_step_velocity_rad_s)
        v_prev_enc = Fraction(conf_ref.encoded_velocity_rad_s)
        q_min_exact = Fraction(spec.q_min_rad)
        q_max_exact = Fraction(spec.q_max_rad)
        lead_exact = Fraction(spec.max_lead_rad)
        q_meas_exact = Fraction(q_meas)
        prop_q_exact = Fraction(prop_ref.q_rad)
        plan_q_exact = Fraction(plan_joint.q_rad)

        if h_ref > 0.0:
            actual_pos_vel = (prop_q_exact - Fraction(conf_ref.q_rad)) / h_ref_exact
            if prop_ref.position_step_velocity_rad_s != actual_pos_vel:
                return DecisionCode.CONSTRAINT_VIOLATION

        if (
            not q_min_exact <= prop_q_exact <= q_max_exact
            or not q_min_exact <= plan_q_exact <= q_max_exact
        ):
            return DecisionCode.POSITION_OUT_OF_BOUNDS

        if (
            abs(prop_ref.position_step_velocity_rad_s) > v_max_exact
            or abs(Fraction(prop_ref.encoded_velocity_rad_s)) > v_max_exact
            or abs(Fraction(plan_joint.dq_rad_s)) > v_max_exact
        ):
            return DecisionCode.SPEED_OUT_OF_BOUNDS

        if prop_ref.sample_time_s > conf_ref.sample_time_s:
            if (
                abs(prop_ref.position_step_velocity_rad_s - v_prev_pos) > a_max_exact * h_ref_exact
                or abs(Fraction(prop_ref.encoded_velocity_rad_s) - v_prev_enc) > a_max_exact * h_ref_exact
            ):
                return DecisionCode.CONSTRAINT_VIOLATION

        if (
            prop_q_exact < q_meas_exact - lead_exact
            or prop_q_exact > q_meas_exact + lead_exact
            or plan_q_exact < q_meas_exact - lead_exact
            or plan_q_exact > q_meas_exact + lead_exact
        ):
            return DecisionCode.CONSTRAINT_VIOLATION
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION

    return None

```

## joint_mapping.py complete
```
from dataclasses import dataclass
import math


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a real int or float")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def _result(value, name, nonzero_inputs=None):
    if not math.isfinite(value):
        raise ValueError(f"{name} result must be finite")
    if nonzero_inputs and value == 0.0 and all(item != 0.0 for item in nonzero_inputs):
        raise ValueError(f"{name} result underflowed")
    return value


def _multiply(name, *values):
    result = 1.0
    for index, value in enumerate(values):
        result *= value
        _result(result, name, values[:index + 1])
    return result


def _divide(numerator, denominator, name):
    try:
        result = numerator / denominator
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError(f"{name} result is not representable") from exc
    return _result(result, name, (numerator,))


def _add(left, right, name):
    return _result(left + right, name)


def _subtract(left, right, name):
    return _result(left - right, name)


@dataclass(frozen=True)
class JointMap:
    reduction: float
    direction: int
    zero_output_rad: float

    def __post_init__(self):
        reduction = _finite(self.reduction, "reduction")
        if reduction <= 0.0:
            raise ValueError("reduction must be positive")
        if type(self.direction) is not int or self.direction not in (-1, 1):
            raise ValueError("direction must be the integer -1 or 1")
        object.__setattr__(self, "reduction", reduction)
        object.__setattr__(self, "zero_output_rad", _finite(self.zero_output_rad, "zero_output_rad"))

    def to_output(self, target: "JointTarget") -> "OutputTarget":
        if not isinstance(target, JointTarget):
            raise ValueError("target must be a JointTarget")

        signed_reduction = _multiply("signed reduction", float(self.direction), self.reduction)
        q_rad = _add(
            self.zero_output_rad,
            _multiply("output position", signed_reduction, target.q_rad),
            "output position",
        )
        output_rad_s = _multiply("output velocity", signed_reduction, target.dq_rad_s)
        rpm = _divide(_multiply("output speed", output_rad_s, 60.0), math.tau, "output speed")
        tau_nm = _divide(
            _multiply("output torque", float(self.direction), target.tau_nm),
            self.reduction,
            "output torque",
        )
        kp = _divide(_divide(target.kp, self.reduction, "output kp"), self.reduction, "output kp")
        kd = _divide(_divide(target.kd, self.reduction, "output kd"), self.reduction, "output kd")
        return OutputTarget(q_rad=q_rad, rpm=rpm, tau_nm=tau_nm, kp=kp, kd=kd)

    def from_output(self, sample: "OutputSample") -> "JointSample":
        if not isinstance(sample, OutputSample):
            raise ValueError("sample must be an OutputSample")

        q_delta = _subtract(sample.q_rad, self.zero_output_rad, "joint position")
        q_rad = _divide(
            _multiply("joint position", float(self.direction), q_delta),
            self.reduction,
            "joint position",
        )
        output_rad_s = _divide(
            _multiply("joint velocity", sample.rpm, math.tau),
            60.0,
            "joint velocity",
        )
        dq_rad_s = _divide(
            _multiply("joint velocity", float(self.direction), output_rad_s),
            self.reduction,
            "joint velocity",
        )
        tau_nm = _multiply("joint torque", float(self.direction), self.reduction, sample.tau_nm)
        return JointSample(q_rad=q_rad, dq_rad_s=dq_rad_s, tau_nm=tau_nm)


@dataclass(frozen=True)
class JointTarget:
    q_rad: float
    dq_rad_s: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputTarget:
    q_rad: float
    rpm: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputSample:
    q_rad: float
    rpm: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))


@dataclass(frozen=True)
class JointSample:
    q_rad: float
    dq_rad_s: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))

```

## im6014_codec.py complete
```
import math
import struct
from collections.abc import Callable

RATIO = 38 / 3
RPM_MIN = -32768 / 64 / RATIO * 60
RPM_MAX = 32767 / 64 / RATIO * 60
POSITION_MIN = -2147483648 / 32768 / RATIO * math.tau
POSITION_MAX = 2147483647 / 32768 / RATIO * math.tau
RAW_POSITION_MIN = -2147483648
RAW_POSITION_MAX = 2147483647
RAW_RPM_MIN = -32768
RAW_RPM_MAX = 32767


def raw_to_position(raw_position):
    if type(raw_position) is not int or not RAW_POSITION_MIN <= raw_position <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return raw_position / 32768 / RATIO * math.tau


def position_to_raw(position):
    position = _finite_control(position, 'Position')
    return _signed_raw(position / math.tau * RATIO * 32768,
                       RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')


def raw_to_rpm(raw_rpm):
    if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
        raise ValueError('raw_rpm must be a signed 16-bit integer')
    return raw_rpm / 64 / RATIO * 60


def rpm_to_raw(rpm):
    rpm = _finite_control(rpm, 'Speed')
    return _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')


def _motor_id(value, name='Individual ID'):
    if type(value) is not int or not 0 <= value <= 14:
        raise ValueError(f'{name} must be an integer from 0 to 14')
    return value


def _finite_control(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f'{name} must be a finite int or float')
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError(f'{name} must be finite') from error
    if not math.isfinite(result):
        raise ValueError(f'{name} must be finite')
    return result


def _signed_raw(value, minimum, maximum, name):
    raw = round(value)
    if not minimum <= raw <= maximum:
        raise ValueError(f'{name} cannot be represented by the motor protocol')
    return raw


def _torque_raw(value):
    return _signed_raw(value / RATIO * 2560, -32768, 32767, 'Feedforward torque')


def _kp_raw(value):
    return _signed_raw(value / RATIO ** 2 * 12800, -32768, 32767, 'Kp')


def _kd_raw(value):
    return _signed_raw(value / RATIO ** 2 * 51200, -32768, 32767, 'Kd')


def _raw_position(value):
    if type(value) is not int or not RAW_POSITION_MIN <= value <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return value


def crc32(data):
    if len(data) % 4:
        raise ValueError('CRC input must contain complete four-byte words')
    crc = 0xFFFFFFFF
    for start in range(0, len(data), 4):
        for byte in data[start:start + 4][::-1]:
            crc ^= byte << 24
            for _ in range(8):
                crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    return crc


def command(motor_id, mode=0, rpm=0, kd=0, torque=0, watchdog=True, position=0, kp=0):
    position = _finite_control(position, 'Position')
    if not POSITION_MIN <= position <= POSITION_MAX:
        raise ValueError('Position cannot be encoded in the motor protocol')
    if mode == 0 and position != 0.0:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    position_raw = _signed_raw(position / math.tau * RATIO * 32768,
                               RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')
    return command_with_raw_position(
        motor_id,
        position_raw,
        mode=mode,
        rpm=rpm,
        kd=kd,
        torque=torque,
        watchdog=watchdog,
        kp=kp,
    )


def command_with_raw_position(
    motor_id, raw_position, mode=0, rpm=0, kd=0, torque=0, watchdog=True, kp=0, raw_rpm=None
):
    """Encode a command while preserving an already selected position grid code."""
    motor_id = _motor_id(motor_id)
    raw_position = _raw_position(raw_position)
    if type(mode) is not int or mode not in (0, 1):
        raise ValueError('Individual ID 0–14 and Stop/FOC modes only')
    if type(watchdog) is not bool:
        raise ValueError('Watchdog must be a bool')
    rpm, kd, torque, kp = (
        _finite_control(value, name) for value, name in
        ((rpm, 'Speed'), (kd, 'Kd'), (torque, 'Feedforward torque'),
         (kp, 'Kp'))
    )
    if not RPM_MIN <= rpm <= RPM_MAX:
        raise ValueError('Speed cannot be encoded in the motor protocol; this is not a rated-speed limit')
    if not 0 <= kd <= 6 or not 0 <= kp <= 30 or not -3.5 <= torque <= 3.5:
        raise ValueError('Bench limits: Kd 0–6, Kp 0–30, feedforward torque ±3.5 Nm')
    torque_raw = _torque_raw(torque)
    if raw_rpm is not None:
        if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
            raise ValueError('raw_rpm must be a signed 16-bit integer')
        rpm_raw = raw_rpm
    else:
        rpm_raw = _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')
    kp_raw = _kp_raw(kp)
    kd_raw = _kd_raw(kd)
    if mode == 0 and (rpm or kd or torque or raw_position or kp or (raw_rpm is not None and raw_rpm != 0)) or mode == 1 and not watchdog:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    raw = b'\xfe\xee' + bytes([motor_id | mode << 4 | int(watchdog) << 7, 0])
    raw += struct.pack('<hhihh', torque_raw, rpm_raw, raw_position, kp_raw, kd_raw)
    return raw + struct.pack('<I', crc32(raw))


def project_position_raw(
    wanted_q,
    q_min,
    q_max,
    map_decoded_position: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw position whose mapped decoded value is in bounds.

    ``map_decoded_position`` maps decoded actuator radians to the caller's
    position domain. ``direction`` declares whether that mapping increases or
    decreases as the raw position code increases. Bounds are closed.
    """
    wanted_q = _finite_control(wanted_q, 'Wanted position')
    q_min = _finite_control(q_min, 'Minimum position')
    q_max = _finite_control(q_max, 'Maximum position')
    if q_min > q_max:
        raise ValueError('Minimum position must not exceed maximum position')
    if not callable(map_decoded_position):
        raise ValueError('Position mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Position mapping direction must be -1 or 1')

    ordered_min = direction * (q_min if direction == 1 else q_max)
    ordered_max = direction * (q_max if direction == 1 else q_min)
    ordered_wanted = direction * wanted_q

    def mapped(raw_position):
        decoded = raw_to_position(raw_position)
        try:
            result = map_decoded_position(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Position mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped position')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_POSITION_MIN
        right = RAW_POSITION_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_POSITION_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def project_speed_raw(
    wanted_dq,
    v_min,
    v_max,
    map_decoded_speed: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw speed whose mapped decoded value is in bounds.

    ``map_decoded_speed`` maps decoded actuator RPM to the caller's
    speed domain. ``direction`` declares whether that mapping increases or
    decreases as the raw speed code increases. Bounds are closed.
    """
    wanted_dq = _finite_control(wanted_dq, 'Wanted speed')
    v_min = _finite_control(v_min, 'Minimum speed')
    v_max = _finite_control(v_max, 'Maximum speed')
    if v_min > v_max:
        raise ValueError('Minimum speed must not exceed maximum speed')
    if not callable(map_decoded_speed):
        raise ValueError('Speed mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Speed mapping direction must be -1 or 1')

    ordered_min = direction * (v_min if direction == 1 else v_max)
    ordered_max = direction * (v_max if direction == 1 else v_min)
    ordered_wanted = direction * wanted_dq

    def mapped(raw_speed):
        decoded = raw_to_rpm(raw_speed)
        try:
            result = map_decoded_speed(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Speed mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped speed')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_RPM_MIN
        right = RAW_RPM_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_RPM_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def feedback(raw, motor_id):
    motor_id = _motor_id(motor_id, 'Expected motor ID')
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Feedback frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Feedback frame must be a bytes-like buffer') from error
    if len(raw) != 26 or raw[:2] != b'\xfc\xee':
        raise RuntimeError('Invalid feedback length/header')
    if struct.unpack('<I', raw[22:])[0] != crc32(raw[2:22]):
        raise RuntimeError('Feedback CRC mismatch')
    m, td, tw, v, tq, sp, pos, err, flags, _, _ = struct.unpack('<BbBBhhiIHBB', raw[2:22])
    if m & 15 != motor_id or (m >> 4) & 7 not in (0, 1):
        raise RuntimeError('Feedback ID/mode mismatch')
    return dict(id=m & 15, mode=(m >> 4) & 7, timeout=m >> 7,
                driver_c=td, winding_c=tw, voltage=v / 2,
                torque_nm=tq / 2560 * RATIO, rpm=sp / 64 / RATIO * 60,
                position_rad=pos / 32768 / RATIO * math.tau,
                errors=err, warnings=(flags >> 13) & 7, raw=raw.hex())


def decode_command(raw):
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Command frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Command frame must be a bytes-like buffer') from error
    if len(raw) != 20 or raw[:2] != b'\xfe\xee':
        raise ValueError('Invalid command length/header')
    if struct.unpack('<I', raw[16:])[0] != crc32(raw[:16]):
        raise ValueError('Command CRC mismatch')
    m = raw[2]
    motor_id = m & 0x0F
    mode = (m >> 4) & 0x07
    watchdog = bool(m & 0x80)
    if motor_id > 14 or mode not in (0, 1) or raw[3] != 0:
        raise ValueError('Invalid command ID, mode, or reserved byte')
    if mode == 1 and not watchdog:
        raise ValueError('FOC command requires watchdog')
    tq, sp, pos, kp, kd = struct.unpack('<hhihh', raw[4:16])
    if mode == 0 and (tq or sp or pos or kp or kd):
        raise ValueError('Stop command must have zero targets')
    decoded = dict(
        motor_id=motor_id,
        mode=mode,
        watchdog=watchdog,
        raw_torque=tq,
        raw_rpm=sp,
        raw_position=pos,
        raw_kp=kp,
        raw_kd=kd,
        torque_nm=tq / 2560 * RATIO,
        rpm=sp / 64 / RATIO * 60,
        position_rad=pos / 32768 / RATIO * math.tau,
        kp=kp * (RATIO ** 2) / 12800,
        kd=kd * (RATIO ** 2) / 51200,
        raw=raw.hex(),
    )
    if not _torque_raw(-3.5) <= tq <= _torque_raw(3.5):
        raise ValueError('Feedforward torque is outside the canonical command range')
    if not 0 <= kp <= _kp_raw(30.0) or not 0 <= kd <= _kd_raw(6.0):
        raise ValueError('Gain is outside the canonical command range')
    return decoded

```

## docs/joint-api.md complete
```
# Joint mapping

The bench GUI and CLI use actuator output units. The mapping API converts external joint units before packet encoding. It does not open a serial port.

```python
from joint_mapping import JointMap, JointTarget, OutputSample

mapping = JointMap(reduction=3, direction=-1, zero_output_rad=0.25)
output = mapping.to_output(JointTarget(-0.5, 2, 12, 36, 9))
joint = mapping.from_output(OutputSample(output.q_rad, output.rpm, output.tau_nm))
```

This example produces an output position of 1.75 rad, speed of about -57.2958 rpm, torque of -4 Nm, Kp of 4 and Kd of 1. Reverse conversion recovers the original position, speed and torque. The resulting torque exceeds the bench encoder's ±3.5 Nm policy, so encoding it rejects the command. Mapping never clips a value to make it pass.

`JointTarget` uses rad, rad/s and Nm. `OutputTarget` uses rad, rpm and Nm. The offset is in actuator output radians. The internal motor reduction stays inside the codec. Ideal gain conversion assumes compatible stiffness and damping definitions. Friction, backlash, efficiency and physical calibration remain unmeasured.

Run a single offline acceptance check from the repository root:

```sh
.venv/bin/python -B scripts/check_milestone.py B11
```

The command prints the path to its receipt and raw logs under `evidence/runs`. The test checks ratios 1, 3 and 6 in both directions, nonzero offsets, independent numeric anchors and invalid values.

## Passive port inspection

```python
from im6014_port import PortConfig, inspect_port
from spin_5rpm import PORT

report = inspect_port(PortConfig(PORT, 6_000_000), ports=())
```

`ports=()` makes this example use only the configured by-id basename. The report names its evidence source and does not establish communication with the motor. Normal inspection can also read passive OS enumeration metadata. Known wrong serial numbers or interfaces reject with expected and observed values. Unknown metadata stays explicitly unverified.

For an alternate adapter route, set both `expected_serial=None` and `expected_channel=None`. This removes the FTDI identity assertion. It does not bypass later device ownership checks or establish motor communication. The bench GUI and CLI default to the recorded FTDI serial and interface 3.

## Diagnostic capture

`PacketCapture` holds at most 256 records by default. Each record contains capped packet prefixes, allowlisted decoded fields, a fixed outcome code, and explicit source and connection metadata. Exported snapshots own their lists and dictionaries. Exception messages, environment values and arbitrary serial-object fields are excluded. An unavailable or regressing capture end clock exports `ended_s=None` and preserves the exchange result or original error. An invalid start clock rejects before exchange.

The GUI includes its ring in the existing JSON snapshot. The CLI enables it in `main`; direct `run(bus, args, log)` callers retain the original uncaptured behavior. Tests opt in with `fixture` provenance. A `physical` label records the caller's declaration and does not independently prove device identity.

## Cooperating bus ownership

Both real bench open sites use `open_managed_port(PortConfig(...), serial_factory=...)`. It checks passive identity before device acquisition and construction. A successful result owns `bus`; call `close()` and inspect its boolean result. `False` means ownership remains held because closure was not confirmed. Retry cleanup before reconnecting. A context manager raises `PortCloseError` on an otherwise normal exit with unconfirmed close; its `managed_port` remains available for cleanup.

This API opens hardware when given a motor path. Its acceptance tests use Linux PTYs exclusively. The device lease coordinates these workbench clients; it cannot exclude a raw client that ignores the lock.

When passive identity metadata is incomplete, the default route reports it as unverified and still permits device acquisition; known mismatches reject. The serial factory must expose the pyserial `is_open` status for confirmed cleanup. A missing status retains the lease. Neither passive inspection nor opening establishes CRC-valid motor communication.

## Controller lifecycle and freshness

`JointCore` owns a fixed ordered set of unique `JointSpec` names and motor IDs. Its states and immutable `Snapshot` are transport-free; `connected(SourceIdentity(...))` records a declaration and never opens hardware. `Decision` evaluates to its `accepted` value.

Connect, check, and arm are distinct steps. `receive(id, JointSample(...), MotorHealth(...))` stamps each valid observation with the core's monotonic clock. `checked()` needs fresh healthy Stop-mode feedback from every active joint. `arm()` requires fresh healthy Stop-mode feedback. The configurable maximum age defaults to 0.5 seconds; this software policy is not a measured loop-rate guarantee. Snapshot `feedback_ages_s` preserves joint order and uses `None` before receipt. Timestamp zero is valid. Unknown IDs and invalid records do not refresh timestamps.

Call `tick()` to fault READY, ARMED, or MOVING when feedback ages out. Stop, disconnect/reconnect, and healthy packets do not clear a fault latch. Recovery requires `begin_check(acknowledge_fault=True)` followed by fresh healthy Stop feedback and successful `checked()`. The check clears observations first. Target dispatch, attributed fault records and command ordering are the next milestones.

## Attributed faults

`Snapshot.faults` holds immutable `JointFault` records in configured joint order. `affected_joints` derives their names. Error and warning masks accumulate by bitwise OR, and watchdog timeout and stale flags latch. Communication codes are fixed `CommunicationFailure` enum values; they do not imply an actuator watchdog timeout. Current healthy feedback clears the current communication observation while the cause remains latched. Stop and reconnect retain causes. Only an explicitly acknowledged, complete, fresh, healthy Stop check clears them. Each core stores at most one record per configured joint and a unique first-occurrence union of fixed communication codes; its size is bounded by the finite enum. `communication_error` is the most recent cause; `communication_errors` is not a chronological event history. A supplied most-recent code must belong to that union.

When opening fails and cleanup cannot confirm closure, `open_managed_port` raises `PortCloseError` with `managed_port` for retry and the original error as `__cause__`. Context exit uses the same exception when closure fails, retaining any body exception as its cause. If cleanup succeeds, the original exception propagates normally.

## Latest target and command expiry

`Target(sequence, joints, window, owner)` contains an immutable complete tuple of `JointTarget` values in configured order, a required station-issued `IntentWindow(id, created_at_s, expires_at_s)`, and the current `OwnerToken`. `JointCore.issue_window(valid_for_s)` issues the latest offered window with a monotonic ID and bounded duration (`max_window_s`, default 1.0s). `submit_target` first expires or faults an existing goal as needed, then checks the full owner token, validates the incoming window against the latest offered window, checks expiry (exact equality with expiry is expired), checks mapped output codec representability, and enforces monotonic command sequence ordering before admitting the goal. A rejected replacement keeps an existing goal only while that goal remains valid.

`consume_target` is deleted in favor of explicit refresh lifecycle: `prepare_refresh()`, `claim_dispatch(plan_id, index)`, and `dispatch_result(plan_id, index, result)`. An admitted goal is refreshed repeatedly until its window expires. Preparing a plan proposes a refresh vector without dispatching. Each `RefreshPlan` contains an exact-count tuple of immutable, validated canonical packet bytes; the adapter writes those bytes unchanged. `joint_targets` records the actual full joint reference decoded from those packets, while `target` preserves the admitted request. `claim_dispatch` verifies freshness, health, goal expiry, and ordered joint index immediately before each write. Only one claim may await an outcome; the core blocks another joint claim, plan preparation, and reconnect until the station reports that claim's actual transport result. Stop, expiry, target replacement, disconnect, or fault can invalidate the plan without discarding that in-flight receipt. `exchange` reports the write result once after the driver outcome; successful returns are deadline-checked before feedback. If the deadline expires after the pre-write hook grants a claim but before `bus.write`, it reports `WriteResult.PREWRITE_DEADLINE`: the software made no write call for that claim. This does not establish motor state or physical protection. `WriteResult.PARTIAL` means the driver returned a positive short count. `WriteResult.FAILED` means the driver raised or returned an invalid count, so byte delivery may be unknown. `Snapshot.dispatch_attempts` holds the latest outcome per joint. `dispatch_result` commits a dispatched record only for a complete write. A dispatched record's `dispatched_at_s` is the valid claim/write start time, not a fabricated completion timestamp. A complete write followed by invalid or regressing core time preserves the complete record and attempt, then faults with `CommunicationFailure.CLOCK_FAILURE` without restoring motion. `WriteResult.PREWRITE_DEADLINE` faults with `CommunicationFailure.PREWRITE_DEADLINE`; `PARTIAL` and `FAILED` fault with `DRIVER_FAILURE`, preserving any prior complete record. A late receipt for an invalidated plan is recorded but cannot restore motion or change `DISCONNECTED`; once it settles, an explicit reconnect is allowed. Reconnect still requires a new owner, acknowledged fresh healthy Stop check, and explicit arm. When an admitted goal expires, housekeeping withdraws it, invalidates pending plans, and disarms the core to `STOPPED` (latched fault preserved), requiring a new check and arm cycle. Sequence watermarks survive consumption, stop, fault, and disconnect.

### Offline controller example

```python
from joint_contract import IntentWindow, JointSpec, MotorHealth, OwnerToken, SourceIdentity, State, Target, WriteResult
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget

clock_time = [0.0]
core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, 40.0, 1.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
assert core.begin_connect()
assert core.connected(SourceIdentity("fixture", "example", 1))
owner = core.claim_owner("example-client")
assert core.begin_check()
assert core.receive(0, JointSample(0, 0, 0), MotorHealth(0, 0, 0, False))
assert core.checked()
assert core.arm(owner)
window = core.issue_window(0.5)
target = Target(6, (JointTarget(.1, 1, -6, 18, 4.5),), window=window, owner=owner)
assert core.submit_target(target)
clock_time[0] += 0.05
plan = core.prepare_refresh()
assert plan is not None
assert core.claim_dispatch(plan.plan_id, 0)
assert core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
assert core.snapshot().state is State.MOVING
assert core.snapshot().dispatched_records[0].sequence == 6
assert core.stop()
assert core.snapshot().last_sequence == 6
```

This example performs no serial operations. A station adapter must validate its own physical setup and own packet transmission when later milestones add one.

## Core and ownership limits

The injected core clock must be finite and monotonic. Invalid or regressing time rejects operations that need a fresh gate; snapshots also require that clock contract. If a complete write receipt arrives after its end clock becomes invalid, the core preserves that known write and claim timestamp, then latches `CommunicationFailure.CLOCK_FAILURE` and withdraws motion until acknowledged recovery. The default clock is `time.monotonic`. Sequence `2**64 - 1` exhausts that core's stream. Start a new core for a new stream; reconnecting or acknowledging a fault never resets ordering.

### Owner generations

`JointCore` generates a fresh unpredictable random 16-byte hex epoch per instance/process via `secrets.token_hex(16)` with no persisted global state. A monotonic generation counter starts at 1 and ranges through uint64. `claim_owner(connection_id)` returns a frozen `OwnerToken(epoch, generation, connection_id)`. `connection_id` is an immutable non-empty string bounded to 64 characters and identifies the client connection; `SourceIdentity` separately identifies the motor connection. The core assumes trusted station callers; the station/server binds its actual client connection identity rather than trusting unverified JSON payload attributes, with no authentication claims beyond that boundary.

`arm(owner)` and `Target` require an exact `OwnerToken` class and matching immutable epoch, generation, and connection ID fields. Token-bearing boundary records reject subclasses. An owner mismatch returns `DecisionCode.INVALID_OWNER` after lifecycle state checks. Stop, any latched joint fault, disconnect, expired goals, and explicit takeover revoke active authority (`current_owner` becomes `None`), withdraw pending goals/plans and offered windows, and never auto-rearm. A claim during checking, ready, armed, or moving state, or a takeover of an existing owner on a connected core, places the core in `STOPPED` (while preserving `FAULT` and `DISCONNECTED`), requiring a fresh stop check and explicit arm call with the new token. Reconnecting requires claiming a fresh generation. Fault recovery also requires a new claim before checking and arming.

Durable attempt and dispatched records retain the original `OwnerToken` stamped at plan creation; an in-flight receipt completing after authority revocation preserves the actual write record with its original owner attribution without transitioning the core to `MOVING`. `Snapshot.latest_owner` retains the most recently issued token after revocation, while `Snapshot.current_owner` is `None` unless that token currently has authority. Bounded O(1) storage retains only these two tokens. When the uint64 generation space is exhausted, a new claim revokes authority, stops the core (or preserves `FAULT`/`DISCONNECTED`), and raises `OverflowError` without wrapping; start a fresh core to obtain a new epoch.

The fixed per-user lock namespace under `/tmp` coordinates cooperating processes. A hostile local user can pre-create the name and deny access; validation fails closed. An administrator must remove a foreign-owned obstruction. Lockfiles persist to preserve flock inode identity, including after device-number reuse. Do not delete them while clients may be running. No automatic pruning or hostile-local-user availability guarantee is supplied.

## Joint Position Limits

Every `JointSpec` requires explicit, immutable, finite position bounds `q_min_rad <= q_max_rad` and non-empty `limits_provenance` documenting the software threshold origin. These are fixture software limits, not physical calibration. Position requests are evaluated against inclusive bounds: exact lower and upper endpoints are accepted. Requests outside them return `DecisionCode.POSITION_OUT_OF_BOUNDS` and preserve any still-valid admitted goal, sequence watermark, owner, and window. Mapped requests must first pass the ordinary canonical codec; an unencodable mapped request returns `INVALID_ARGUMENT` and is never clamped into range. A fresh measured position outside the bounds, including during `CHECKING`, latches the attributed `JointFault.position_limit` cause and faults the core before motion. Simultaneous motor-health causes remain in the same joint fault record. `claim_dispatch` rechecks every fresh measured position and the actual prepared reference before each write. Recovery requires a new owner and an explicitly acknowledged fresh healthy Stop check with every measured position within the inclusive bounds; incoming targets cannot clear a fault. The codec owns the bounded raw position grid search through a monotonic decoded-domain callback and direction. It selects an inward representable endpoint, serializes that exact raw integer without float re-encoding, and decodes the complete canonical packet to populate actual position, velocity, feedforward, and gain reference fields. Stop packets are valid decoder inputs; mode, ID, watchdog, reserved byte, header, and CRC are checked. Repeated refreshes write the cached packet bytes unchanged.

## Speed- and acceleration-bounded trajectory reference and gap policy

Every `JointSpec` requires an explicit, finite positive maximum reference speed `v_max_rad_s` and maximum reference acceleration `a_max_rad_s2`. `JointCore` requires an explicit, finite positive `max_reference_gap_s` policy. All values describe software fixture policy unless calibrated separately.

Upon a successful healthy checked Stop, the controller initializes an unemitted trajectory reference for each joint with position equal to the checked feedback sample, zero exact velocity derivative, and timestamp equal to the sample time (`is_emitted=False`). The anchor has no cached command and cannot dispatch at $h=0$.

Preparing a refresh plan does not advance confirmed history. A `RefreshPlan` always carries one proposed reference, decoded command target, and immutable canonical packet per joint. Only a complete actual write commits that joint's proposed reference. Failed or partial writes leave its prior reference unchanged. Reference `sample_time_s` is the preparation time; `JointDispatchedRecord.dispatched_at_s` remains the actual claim/write start time.

For $h=0$, a previously emitted reference can refresh only when the admitted joint goal is unchanged. The core reuses that reference, decoded target, and exact packet bytes, including its prior position-step derivative and feedforward values; it does not encode the values again or advance their sample time. A changed goal at $h=0$ is rejected with an attributed constraint fault. If $h > \text{max\_reference\_gap\_s}$, motion is withdrawn and the controller drops to `STOPPED` (`REFERENCE_GAP_EXCEEDED`).

For $h>0$, the pure reference step intersects the speed interval $[-V,V]$, acceleration interval $[v_{\text{prev}}-A\cdot h, v_{\text{prev}}+A\cdot h]$, and position interval $[(q_{\min}-q_{\text{prev}})/h,(q_{\max}-q_{\text{prev}})/h]$. It projects the one-step objective $v_{\text{desired}} = (q_{\text{goal}}-q_{\text{prev}})/h + \dot{q}_{\text{goal}}$ into that closed intersection. The objective combines the requested position correction over this sample with velocity feedforward; it is not a continuous trajectory law.

The selected endpoint is projected inward to a representable point on the canonical codec grid. Position-step velocity is the exact rational $(q_{\text{emitted,next}}-q_{\text{emitted,prev}})/h$, where the stored finite float values and computed float difference $h$ are interpreted exactly. The independently decoded wire velocity feedforward has its own history and must satisfy both $|v|\leq V$ and $|v-v_{\text{prev,enc}}|\leq A\cdot h$. Neither stream is substituted for the other, and wire velocity is not used in position algebra. Reversal preserves previous velocity and crosses zero under the same acceleration bound.

Immediately before a positive-cadence write claim, the core recomputes the position-step derivative from the proposed and confirmed decoded endpoint positions and requires exact equality with the stored rational derivative. A mismatch latches an attributed constraint fault and Stops before claiming the write. At $h=0$, the existing exact cached-reference, decoded-target, and packet comparison remains the replay rule.

An exactly zero objective asks for no net position correction after combining position error and velocity feedforward. The controller still projects zero into the feasible interval, so a nonzero previous derivative can require continued bounded motion while decelerating; a stationary reference is possible only when zero is feasible. For a nonzero objective, if no representable position step satisfies the closed bounds, the controller produces no mode-1 write and Stops with `DecisionCode.CONSTRAINT_VIOLATION`, attributed to each joint whose shaping failed. It does not carry hidden fractional motion or relax a bound. These are samplewise software reference limits; they do not promise a continuous motor trajectory, physical acceleration, or certified braking.

## Measured position lead bound

Every `JointSpec` requires an explicit, finite positive `max_lead_rad`. This software bound limits how far any requested goal or emitted trajectory reference can lead the latest fresh measured joint position.

At target admission, the controller checks each joint request against the closed interval $[q_{\text{meas}} - \text{lead}, q_{\text{meas}} + \text{lead}]$ using the latest fresh observation. A requested position outside this bound is rejected with `DecisionCode.LEAD_OUT_OF_BOUNDS`, preserving any still-valid admitted goal and sequence watermark. If observation feedback is stale or missing, target submission is rejected with `DecisionCode.STALE_FEEDBACK`.

During reference shaping ($h>0$), the lead bound interval $[(q_{\text{meas}} - \text{lead} - q_{\text{prev}})/h, (q_{\text{meas}} + \text{lead} - q_{\text{prev}})/h]$ is intersected with the speed, acceleration, and position intervals. An empty intersection produces an attributed constraint fault and Stops motion. At $h=0$, refresh is permitted only if the previously emitted reference remains inside all bounds, including the fresh lead interval.

Immediately before a write claim, `verify_dispatch_claim` rechecks the current fresh measured position against the proposed decoded endpoint and confirmed reference. If feedback drifted after plan preparation such that the endpoint exceeds the lead bound, the write gate denies dispatch, latches an attributed constraint fault, and stops the controller.

```

## All authored source/test diff
```
diff --git a/docs/joint-api.md b/docs/joint-api.md
index 8dcab3f..252ffa6 100644
--- a/docs/joint-api.md
+++ b/docs/joint-api.md
@@ -77,7 +77,7 @@ from joint_controller import JointCore
 from joint_mapping import JointMap, JointSample, JointTarget
 
 clock_time = [0.0]
-core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, 40.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
+core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, 40.0, 1.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
 assert core.begin_connect()
 assert core.connected(SourceIdentity("fixture", "example", 1))
 owner = core.claim_owner("example-client")
@@ -136,3 +136,13 @@ The selected endpoint is projected inward to a representable point on the canoni
 Immediately before a positive-cadence write claim, the core recomputes the position-step derivative from the proposed and confirmed decoded endpoint positions and requires exact equality with the stored rational derivative. A mismatch latches an attributed constraint fault and Stops before claiming the write. At $h=0$, the existing exact cached-reference, decoded-target, and packet comparison remains the replay rule.
 
 An exactly zero objective asks for no net position correction after combining position error and velocity feedforward. The controller still projects zero into the feasible interval, so a nonzero previous derivative can require continued bounded motion while decelerating; a stationary reference is possible only when zero is feasible. For a nonzero objective, if no representable position step satisfies the closed bounds, the controller produces no mode-1 write and Stops with `DecisionCode.CONSTRAINT_VIOLATION`, attributed to each joint whose shaping failed. It does not carry hidden fractional motion or relax a bound. These are samplewise software reference limits; they do not promise a continuous motor trajectory, physical acceleration, or certified braking.
+
+## Measured position lead bound
+
+Every `JointSpec` requires an explicit, finite positive `max_lead_rad`. This software bound limits how far any requested goal or emitted trajectory reference can lead the latest fresh measured joint position.
+
+At target admission, the controller checks each joint request against the closed interval $[q_{\text{meas}} - \text{lead}, q_{\text{meas}} + \text{lead}]$ using the latest fresh observation. A requested position outside this bound is rejected with `DecisionCode.LEAD_OUT_OF_BOUNDS`, preserving any still-valid admitted goal and sequence watermark. If observation feedback is stale or missing, target submission is rejected with `DecisionCode.STALE_FEEDBACK`.
+
+During reference shaping ($h>0$), the lead bound interval $[(q_{\text{meas}} - \text{lead} - q_{\text{prev}})/h, (q_{\text{meas}} + \text{lead} - q_{\text{prev}})/h]$ is intersected with the speed, acceleration, and position intervals. An empty intersection produces an attributed constraint fault and Stops motion. At $h=0$, refresh is permitted only if the previously emitted reference remains inside all bounds, including the fresh lead interval.
+
+Immediately before a write claim, `verify_dispatch_claim` rechecks the current fresh measured position against the proposed decoded endpoint and confirmed reference. If feedback drifted after plan preparation such that the endpoint exceeds the lead bound, the write gate denies dispatch, latches an attributed constraint fault, and stops the controller.
diff --git a/joint_contract.py b/joint_contract.py
index 8b6e1d4..c6dbeb4 100644
--- a/joint_contract.py
+++ b/joint_contract.py
@@ -43,6 +43,7 @@ class DecisionCode(str, Enum):
     EXPIRED = "expired"
     POSITION_OUT_OF_BOUNDS = "position_out_of_bounds"
     SPEED_OUT_OF_BOUNDS = "speed_out_of_bounds"
+    LEAD_OUT_OF_BOUNDS = "lead_out_of_bounds"
     REFERENCE_GAP_EXCEEDED = "reference_gap_exceeded"
     CONSTRAINT_VIOLATION = "constraint_violation"
 
@@ -88,6 +89,7 @@ class JointSpec:
     q_max_rad: float
     v_max_rad_s: float
     a_max_rad_s2: float
+    max_lead_rad: float
     limits_provenance: str
 
     def __post_init__(self) -> None:
@@ -130,6 +132,15 @@ class JointSpec:
         if not math.isfinite(a_max_val) or a_max_val <= 0.0:
             raise ValueError("a_max_rad_s2 must be finite and positive")
 
+        if isinstance(self.max_lead_rad, bool) or not isinstance(self.max_lead_rad, (int, float)):
+            raise ValueError("max_lead_rad must be a finite positive real number")
+        try:
+            max_lead_val = float(self.max_lead_rad)
+        except (OverflowError, TypeError, ValueError) as exc:
+            raise ValueError("max_lead_rad must be finite") from exc
+        if not math.isfinite(max_lead_val) or max_lead_val <= 0.0:
+            raise ValueError("max_lead_rad must be finite and positive")
+
         if (
             type(self.limits_provenance) is not str
             or not self.limits_provenance.strip()
@@ -141,6 +152,7 @@ class JointSpec:
         object.__setattr__(self, "q_max_rad", max_val)
         object.__setattr__(self, "v_max_rad_s", v_max_val)
         object.__setattr__(self, "a_max_rad_s2", a_max_val)
+        object.__setattr__(self, "max_lead_rad", max_lead_val)
 
 @dataclass(frozen=True)
 class JointFault:
diff --git a/joint_controller.py b/joint_controller.py
index b9c2160..0022ba3 100644
--- a/joint_controller.py
+++ b/joint_controller.py
@@ -6,7 +6,6 @@ transport and all externally visible records are immutable snapshots.
 
 from collections.abc import Iterable
 from dataclasses import dataclass
-from fractions import Fraction
 import math
 import secrets
 import time
@@ -33,7 +32,11 @@ from joint_contract import (
     owner_tokens_match,
 )
 from joint_mapping import JointSample
-from joint_reference import prepare_complete_reference, validate_target_vector
+from joint_reference import (
+    prepare_complete_reference,
+    validate_target_vector,
+    verify_dispatch_claim,
+)
 
 __all__ = ("JointCore",)
 
@@ -604,7 +607,16 @@ class JointCore:
         if now >= target.window.expires_at_s:
             return self._rejected(DecisionCode.EXPIRED)
 
-        validation_failures = validate_target_vector(self._specs, target)
+        if not self._all_fresh(now) or any(
+            not joint.valid or joint.sample is None for joint in self._observations
+        ):
+            return self._rejected(DecisionCode.STALE_FEEDBACK)
+
+        validation_failures = validate_target_vector(
+            self._specs,
+            target,
+            tuple(joint.sample.q_rad for joint in self._observations),
+        )
         if validation_failures:
             return self._rejected(validation_failures[0].code)
 
@@ -663,6 +675,7 @@ class JointCore:
             self._specs,
             self._admitted_target,
             tuple(self._confirmed_references),
+            tuple(joint.sample.q_rad for joint in self._observations),
             now,
             self._max_reference_gap_s,
         )
@@ -753,74 +766,27 @@ class JointCore:
 
         plan_joint = self._prepared_plan.joint_targets[index]
         spec = self._specs[index]
-        if plan_joint.q_rad < spec.q_min_rad or plan_joint.q_rad > spec.q_max_rad:
-            self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
-            self.stop()
-            return False
-        if abs(plan_joint.dq_rad_s) > spec.v_max_rad_s:
-            self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
-            self.stop()
-            return False
-
         prop_ref = self._prepared_plan.proposed_references[index]
-        if (
-            prop_ref.requested_goal != self._prepared_plan.target.joints[index]
-            or prop_ref.emitted_target != plan_joint
-            or prop_ref.packet != self._prepared_plan.packets[index]
-            or prop_ref.sample_time_s > self._prepared_plan.prepared_at_s
-        ):
-            self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
-            self.stop()
-            return False
-        if conf_ref is None:
-            self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
-            self.stop()
-            return False
-        if prop_ref.sample_time_s == conf_ref.sample_time_s:
-            if prop_ref != conf_ref:
-                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
-                self.stop()
-                return False
-        elif (
-            prop_ref.sample_time_s != self._prepared_plan.prepared_at_s
-            or prop_ref.sample_time_s <= conf_ref.sample_time_s
-        ):
-            self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
-            self.stop()
-            return False
-        h_ref = prop_ref.sample_time_s - conf_ref.sample_time_s
-        h_ref_exact = Fraction(h_ref)
-        a_max_exact = Fraction(spec.a_max_rad_s2)
-        v_max_exact = Fraction(spec.v_max_rad_s)
-        v_prev_pos = Fraction(conf_ref.position_step_velocity_rad_s)
-        v_prev_enc = Fraction(conf_ref.encoded_velocity_rad_s)
-
-        if h_ref > 0.0:
-            actual_position_step_velocity = (
-                Fraction(prop_ref.q_rad) - Fraction(conf_ref.q_rad)
-            ) / h_ref_exact
-            if prop_ref.position_step_velocity_rad_s != actual_position_step_velocity:
+        failure_code = verify_dispatch_claim(
+            spec=spec,
+            prop_ref=prop_ref,
+            conf_ref=conf_ref,
+            plan_joint=plan_joint,
+            packet=self._prepared_plan.packets[index],
+            goal=self._prepared_plan.target.joints[index],
+            q_meas=self._observations[index].sample.q_rad,
+            prepared_at_s=self._prepared_plan.prepared_at_s,
+        )
+        if failure_code is not None:
+            if failure_code is DecisionCode.POSITION_OUT_OF_BOUNDS:
+                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
+            elif failure_code is DecisionCode.SPEED_OUT_OF_BOUNDS:
+                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
+            else:
                 self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
-                self.stop()
-                return False
-
-        if (
-            abs(prop_ref.position_step_velocity_rad_s) > v_max_exact
-            or abs(Fraction(prop_ref.encoded_velocity_rad_s)) > v_max_exact
-        ):
-            self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
             self.stop()
             return False
 
-        if prop_ref.sample_time_s > conf_ref.sample_time_s:
-            if (
-                abs(prop_ref.position_step_velocity_rad_s - v_prev_pos) > a_max_exact * h_ref_exact
-                or abs(Fraction(prop_ref.encoded_velocity_rad_s) - v_prev_enc) > a_max_exact * h_ref_exact
-            ):
-                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
-                self.stop()
-                return False
-
         self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
         return True
 
diff --git a/joint_reference.py b/joint_reference.py
index 84bd6e6..971700d 100644
--- a/joint_reference.py
+++ b/joint_reference.py
@@ -25,6 +25,7 @@ __all__ = (
     "shape_reference_joint",
     "prepare_complete_reference",
     "validate_target_vector",
+    "verify_dispatch_claim",
     "ReferenceFailure",
     "ReferenceBatchResult",
 )
@@ -176,17 +177,42 @@ def prepare_reference_joint(
 
 
 def validate_target_vector(
-    specs: tuple[JointSpec, ...], target: Target
+    specs: tuple[JointSpec, ...],
+    target: Target,
+    measured_positions: tuple[float, ...],
 ) -> tuple[ReferenceFailure, ...]:
     """Validate every admitted joint request before replacing the current goal."""
-    if not isinstance(target, Target) or len(target.joints) != len(specs):
+    if (
+        not isinstance(target, Target)
+        or len(target.joints) != len(specs)
+        or len(measured_positions) != len(specs)
+    ):
         return (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
 
     failures: list[ReferenceFailure] = []
-    for index, (spec, joint_target) in enumerate(zip(specs, target.joints)):
+    for index, (spec, joint_target, q_meas) in enumerate(
+        zip(specs, target.joints, measured_positions)
+    ):
         code, _, _ = prepare_reference_joint(spec, joint_target)
         if code is not None:
             failures.append(ReferenceFailure(code, index))
+            continue
+        if isinstance(q_meas, bool) or not isinstance(q_meas, (int, float)):
+            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
+            continue
+        try:
+            q_meas_float = float(q_meas)
+        except (OverflowError, TypeError, ValueError):
+            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
+            continue
+        if not math.isfinite(q_meas_float):
+            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
+            continue
+        if (
+            joint_target.q_rad < q_meas_float - spec.max_lead_rad
+            or joint_target.q_rad > q_meas_float + spec.max_lead_rad
+        ):
+            failures.append(ReferenceFailure(DecisionCode.LEAD_OUT_OF_BOUNDS, index))
     return tuple(failures)
 
 
@@ -194,6 +220,7 @@ def shape_reference_joint(
     spec: JointSpec,
     target: JointTarget,
     confirmed_ref: JointTrajectoryReference,
+    q_meas: float,
     now: float,
     max_reference_gap_s: float,
 ) -> tuple[
@@ -217,6 +244,7 @@ def shape_reference_joint(
         target.tau_nm,
         target.kp,
         target.kd,
+        q_meas,
         now,
         max_reference_gap_s,
     ):
@@ -235,6 +263,7 @@ def shape_reference_joint(
         goal_tau,
         goal_kp,
         goal_kd,
+        q_meas_val,
         now,
         max_reference_gap_s,
     ) = normalized
@@ -262,6 +291,20 @@ def shape_reference_joint(
             or confirmed_ref.packet is None
         ):
             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+        if (
+            confirmed_ref.q_rad < spec.q_min_rad
+            or confirmed_ref.q_rad > spec.q_max_rad
+        ):
+            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+        if (
+            confirmed_ref.q_rad < q_meas_val - spec.max_lead_rad
+            or confirmed_ref.q_rad > q_meas_val + spec.max_lead_rad
+        ):
+            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+        if abs(confirmed_ref.encoded_velocity_rad_s) > spec.v_max_rad_s:
+            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+        if abs(confirmed_ref.position_step_velocity_rad_s) > Fraction(spec.v_max_rad_s):
+            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
         return (
             None,
             confirmed_ref.emitted_target,
@@ -281,14 +324,18 @@ def shape_reference_joint(
         q_max_exact = Fraction(spec.q_max_rad)
         v_max_exact = Fraction(spec.v_max_rad_s)
         a_max_exact = Fraction(spec.a_max_rad_s2)
+        lead_exact = Fraction(spec.max_lead_rad)
+        q_meas_exact = Fraction(q_meas_val)
 
         v_pos_lo = (q_min_exact - q_prev_exact) / h_exact
         v_pos_hi = (q_max_exact - q_prev_exact) / h_exact
         v_acc_lo = v_prev_pos_exact - a_max_exact * h_exact
         v_acc_hi = v_prev_pos_exact + a_max_exact * h_exact
+        v_lead_lo = (q_meas_exact - lead_exact - q_prev_exact) / h_exact
+        v_lead_hi = (q_meas_exact + lead_exact - q_prev_exact) / h_exact
 
-        v_lo = max(-v_max_exact, v_pos_lo, v_acc_lo)
-        v_hi = min(v_max_exact, v_pos_hi, v_acc_hi)
+        v_lo = max(-v_max_exact, v_pos_lo, v_acc_lo, v_lead_lo)
+        v_hi = min(v_max_exact, v_pos_hi, v_acc_hi, v_lead_hi)
         if v_lo > v_hi:
             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
 
@@ -360,6 +407,7 @@ def shape_reference_joint(
         position_step_velocity = (q_emitted_exact - q_prev_exact) / h_exact
         safe_position = (
             q_min_exact <= q_emitted_exact <= q_max_exact
+            and (q_meas_exact - lead_exact) <= q_emitted_exact <= (q_meas_exact + lead_exact)
             and q_next_lo <= q_emitted_exact <= q_next_hi
         )
         safe_step = (
@@ -379,6 +427,7 @@ def shape_reference_joint(
             candidate_velocity = (candidate_q_exact - q_prev_exact) / h_exact
             if not (
                 q_min_exact <= candidate_q_exact <= q_max_exact
+                and (q_meas_exact - lead_exact) <= candidate_q_exact <= (q_meas_exact + lead_exact)
                 and q_next_lo <= candidate_q_exact <= q_next_hi
                 and abs(candidate_velocity) <= v_max_exact
                 and abs(candidate_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
@@ -469,6 +518,8 @@ def shape_reference_joint(
     actual_v_enc_exact = Fraction(actual_target.dq_rad_s)
     if not q_min_exact <= actual_q_exact <= q_max_exact:
         return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
+    if not (q_meas_exact - lead_exact <= actual_q_exact <= q_meas_exact + lead_exact):
+        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
     if not q_next_lo <= actual_q_exact <= q_next_hi:
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
     if v_desired != 0 and actual_target.q_rad == confirmed_ref.q_rad:
@@ -499,6 +550,7 @@ def prepare_complete_reference(
     specs: tuple[JointSpec, ...],
     target: Target,
     confirmed_references: tuple[JointTrajectoryReference, ...],
+    measured_positions: tuple[float, ...],
     now: float,
     max_reference_gap_s: float,
 ) -> ReferenceBatchResult:
@@ -511,6 +563,8 @@ def prepare_complete_reference(
         or len(target.joints) != len(specs)
         or type(confirmed_references) is not tuple
         or len(confirmed_references) != len(specs)
+        or type(measured_positions) is not tuple
+        or len(measured_positions) != len(specs)
     ):
         return ReferenceBatchResult(
             None, None, None, (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
@@ -521,11 +575,11 @@ def prepare_complete_reference(
     proposed_references: list[JointTrajectoryReference] = []
     failures: list[ReferenceFailure] = []
 
-    for index, (spec, joint_target, conf_ref) in enumerate(
-        zip(specs, target.joints, confirmed_references)
+    for index, (spec, joint_target, conf_ref, q_meas) in enumerate(
+        zip(specs, target.joints, confirmed_references, measured_positions)
     ):
         code, actual_target, prop_ref, packet = shape_reference_joint(
-            spec, joint_target, conf_ref, now, max_reference_gap_s
+            spec, joint_target, conf_ref, q_meas, now, max_reference_gap_s
         )
         if code is not None or actual_target is None or prop_ref is None or packet is None:
             failures.append(
@@ -541,3 +595,93 @@ def prepare_complete_reference(
     return ReferenceBatchResult(
         tuple(actual_targets), tuple(packets), tuple(proposed_references), ()
     )
+
+
+def verify_dispatch_claim(
+    spec: JointSpec,
+    prop_ref: JointTrajectoryReference,
+    conf_ref: JointTrajectoryReference,
+    plan_joint: JointTarget,
+    packet: bytes,
+    goal: JointTarget,
+    q_meas: float,
+    prepared_at_s: float,
+) -> DecisionCode | None:
+    """Validate one proposed joint reference against all closed constraints at the write gate."""
+    if (
+        not isinstance(spec, JointSpec)
+        or not isinstance(prop_ref, JointTrajectoryReference)
+        or not isinstance(conf_ref, JointTrajectoryReference)
+        or not isinstance(plan_joint, JointTarget)
+        or type(packet) is not bytes
+        or not isinstance(goal, JointTarget)
+    ):
+        return DecisionCode.CONSTRAINT_VIOLATION
+
+    if (
+        prop_ref.requested_goal != goal
+        or prop_ref.emitted_target != plan_joint
+        or prop_ref.packet != packet
+        or prop_ref.sample_time_s > prepared_at_s
+    ):
+        return DecisionCode.CONSTRAINT_VIOLATION
+
+    if prop_ref.sample_time_s == conf_ref.sample_time_s:
+        if prop_ref != conf_ref:
+            return DecisionCode.CONSTRAINT_VIOLATION
+    elif (
+        prop_ref.sample_time_s != prepared_at_s
+        or prop_ref.sample_time_s <= conf_ref.sample_time_s
+    ):
+        return DecisionCode.CONSTRAINT_VIOLATION
+
+    try:
+        h_ref = prop_ref.sample_time_s - conf_ref.sample_time_s
+        h_ref_exact = Fraction(h_ref)
+        a_max_exact = Fraction(spec.a_max_rad_s2)
+        v_max_exact = Fraction(spec.v_max_rad_s)
+        v_prev_pos = Fraction(conf_ref.position_step_velocity_rad_s)
+        v_prev_enc = Fraction(conf_ref.encoded_velocity_rad_s)
+        q_min_exact = Fraction(spec.q_min_rad)
+        q_max_exact = Fraction(spec.q_max_rad)
+        lead_exact = Fraction(spec.max_lead_rad)
+        q_meas_exact = Fraction(q_meas)
+        prop_q_exact = Fraction(prop_ref.q_rad)
+        plan_q_exact = Fraction(plan_joint.q_rad)
+
+        if h_ref > 0.0:
+            actual_pos_vel = (prop_q_exact - Fraction(conf_ref.q_rad)) / h_ref_exact
+            if prop_ref.position_step_velocity_rad_s != actual_pos_vel:
+                return DecisionCode.CONSTRAINT_VIOLATION
+
+        if (
+            not q_min_exact <= prop_q_exact <= q_max_exact
+            or not q_min_exact <= plan_q_exact <= q_max_exact
+        ):
+            return DecisionCode.POSITION_OUT_OF_BOUNDS
+
+        if (
+            abs(prop_ref.position_step_velocity_rad_s) > v_max_exact
+            or abs(Fraction(prop_ref.encoded_velocity_rad_s)) > v_max_exact
+            or abs(Fraction(plan_joint.dq_rad_s)) > v_max_exact
+        ):
+            return DecisionCode.SPEED_OUT_OF_BOUNDS
+
+        if prop_ref.sample_time_s > conf_ref.sample_time_s:
+            if (
+                abs(prop_ref.position_step_velocity_rad_s - v_prev_pos) > a_max_exact * h_ref_exact
+                or abs(Fraction(prop_ref.encoded_velocity_rad_s) - v_prev_enc) > a_max_exact * h_ref_exact
+            ):
+                return DecisionCode.CONSTRAINT_VIOLATION
+
+        if (
+            prop_q_exact < q_meas_exact - lead_exact
+            or prop_q_exact > q_meas_exact + lead_exact
+            or plan_q_exact < q_meas_exact - lead_exact
+            or plan_q_exact > q_meas_exact + lead_exact
+        ):
+            return DecisionCode.CONSTRAINT_VIOLATION
+    except (ArithmeticError, TypeError, ValueError):
+        return DecisionCode.CONSTRAINT_VIOLATION
+
+    return None
diff --git a/scripts/check_milestone.py b/scripts/check_milestone.py
index 26366ab..4c1820c 100644
--- a/scripts/check_milestone.py
+++ b/scripts/check_milestone.py
@@ -23,6 +23,7 @@ CHECKS = {
     'C09': 'test_controller_limits.PositionLimitTests',
     'C10': 'test_controller_limits.ReferenceSpeedTests',
     'C11': 'test_controller_limits.ReferenceAccelerationTests',
+    'C12': 'test_controller_limits.ReferenceLeadTests',
 }
 
 
diff --git a/test_controller.py b/test_controller.py
index a7dc0a5..0949e66 100644
--- a/test_controller.py
+++ b/test_controller.py
@@ -108,8 +108,8 @@ class DeterministicClock:
 class FeedbackAgeTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
         )
 
     def _ready_station(self, clock, *, feedback_max_age_s=1.0):
@@ -315,8 +315,8 @@ class ControllerStateTests(unittest.TestCase):
     def setUp(self):
         self.clock = lambda: 0.0
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
         )
 
 
@@ -326,18 +326,18 @@ class ControllerStateTests(unittest.TestCase):
             JointCore((), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
             JointCore((
-                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
-                JointSpec("J1", 1, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+                JointSpec("J1", 1, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
             ), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
             JointCore((
-                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
-                JointSpec("J2", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+                JointSpec("J2", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
             ), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
-            JointSpec("J1", True, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits")
+            JointSpec("J1", True, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits")
 
-        supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits")]
+        supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits")]
         core = JointCore(supplied, clock=self.clock, max_reference_gap_s=1.0)
         supplied.clear()
         self.assertEqual(tuple(spec.name for spec in core.joint_specs), ("J1",))
@@ -553,8 +553,8 @@ class ControllerStateTests(unittest.TestCase):
 class JointFaultTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
         )
 
     def _ready_core(self, clock=None, *, feedback_max_age_s=1.0):
@@ -875,8 +875,8 @@ class JointFaultTests(unittest.TestCase):
 
     def test_independent_second_core_unchanged_by_fault(self):
         specs2 = (
-            JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
-            JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
         )
         clock = DeterministicClock(0.0)
         core1 = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
diff --git a/test_controller_expiry.py b/test_controller_expiry.py
index 8c485f1..6307c8f 100644
--- a/test_controller_expiry.py
+++ b/test_controller_expiry.py
@@ -29,8 +29,8 @@ SOURCE = SourceIdentity("fixture", "expiry-test", 1)
 class ControllerExpiryTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
diff --git a/test_controller_limits.py b/test_controller_limits.py
index 34255a9..d4a12d4 100644
--- a/test_controller_limits.py
+++ b/test_controller_limits.py
@@ -65,8 +65,8 @@ class PositionLimitTests(unittest.TestCase):
     def setUp(self):
         self.clock = DeterministicClock(0.0)
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1.0, 2.0, 100.0, 500.0, "fixture: software position limits J1"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -0.5, 0.5, 100.0, 500.0, "fixture: software position limits J2"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1.0, 2.0, 100.0, 500.0, 100.0, "fixture: software position limits J1"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -0.5, 0.5, 100.0, 500.0, 100.0, "fixture: software position limits J2"),
         )
         self.valid_sample_j1 = JointSample(0.1, 0.0, 0.0)
         self.valid_sample_j2 = JointSample(0.0, 0.0, 0.0)
@@ -194,6 +194,7 @@ class PositionLimitTests(unittest.TestCase):
                 1.0,
                 100.0,
                 500.0,
+                100.0,
                 "fixture: software limits negative direction",
             ),
             JointSpec(
@@ -204,6 +205,7 @@ class PositionLimitTests(unittest.TestCase):
                 0.5,
                 100.0,
                 500.0,
+                100.0,
                 "fixture: software limits positive direction",
             ),
         )
@@ -270,6 +272,7 @@ class PositionLimitTests(unittest.TestCase):
             grid_pos,
             10.0,
             100.0,
+            100.0,
             "fixture: exact grid point interval",
         )
         found_code = self._project(spec_zero_width, grid_pos)
@@ -290,6 +293,7 @@ class PositionLimitTests(unittest.TestCase):
             mid + 1e-9,
             10.0,
             100.0,
+            100.0,
             "fixture: empty grid interval",
         )
         found_none = self._project(spec_empty_grid, mid)
@@ -316,63 +320,77 @@ class PositionLimitTests(unittest.TestCase):
 
         # q_min_rad > q_max_rad
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 1.0, 0.0, 10.0, 100.0, "fixture: invalid min max")
+            JointSpec("J1", 0, mapping, 1.0, 0.0, 10.0, 100.0, 1.0, "fixture: invalid min max")
 
         # non-numeric / bool types
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, True, 1.0, 10.0, 100.0, "fixture: bool min")
+            JointSpec("J1", 0, mapping, True, 1.0, 10.0, 100.0, 1.0, "fixture: bool min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0.0, False, 10.0, 100.0, "fixture: bool max")
+            JointSpec("J1", 0, mapping, 0.0, False, 10.0, 100.0, 1.0, "fixture: bool max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, "0.0", 1.0, 10.0, 100.0, "fixture: str min")
+            JointSpec("J1", 0, mapping, "0.0", 1.0, 10.0, 100.0, 1.0, "fixture: str min")
 
         # infinite / NaN
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, float("-inf"), 1.0, 10.0, 100.0, "fixture: neg inf min")
+            JointSpec("J1", 0, mapping, float("-inf"), 1.0, 10.0, 100.0, 1.0, "fixture: neg inf min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0.0, float("inf"), 10.0, 100.0, "fixture: inf max")
+            JointSpec("J1", 0, mapping, 0.0, float("inf"), 10.0, 100.0, 1.0, "fixture: inf max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, float("nan"), 1.0, 10.0, 100.0, "fixture: nan min")
+            JointSpec("J1", 0, mapping, float("nan"), 1.0, 10.0, 100.0, 1.0, "fixture: nan min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0, 10**400, 10.0, 100.0, "fixture: overflowing max")
+            JointSpec("J1", 0, mapping, 0, 10**400, 10.0, 100.0, 1.0, "fixture: overflowing max")
 
         # v_max_rad_s <= 0 or not finite
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 0.0, 100.0, "fixture: zero v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 0.0, 100.0, 1.0, "fixture: zero v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, -10.0, 100.0, "fixture: negative v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, -10.0, 100.0, 1.0, "fixture: negative v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, float("inf"), 100.0, "fixture: inf v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, float("inf"), 100.0, 1.0, "fixture: inf v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, float("nan"), 100.0, "fixture: nan v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, float("nan"), 100.0, 1.0, "fixture: nan v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, "10.0", 100.0, "fixture: str v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, "10.0", 100.0, 1.0, "fixture: str v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, True, 100.0, "fixture: bool v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, True, 100.0, 1.0, "fixture: bool v_max")
 
         # a_max_rad_s2 <= 0 or not finite
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 0.0, "fixture: zero a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 0.0, 1.0, "fixture: zero a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, -10.0, "fixture: negative a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, -10.0, 1.0, "fixture: negative a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("inf"), "fixture: inf a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("inf"), 1.0, "fixture: inf a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("nan"), "fixture: nan a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("nan"), 1.0, "fixture: nan a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "10.0", "fixture: str a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "10.0", 1.0, "fixture: str a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, True, "fixture: bool a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, True, 1.0, "fixture: bool a_max")
+
+        # max_lead_rad <= 0 or not finite
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 0.0, "fixture: zero max_lead")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, -10.0, "fixture: negative max_lead")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, float("inf"), "fixture: inf max_lead")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, float("nan"), "fixture: nan max_lead")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "10.0", "fixture: str max_lead")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, True, "fixture: bool max_lead")
 
         # invalid provenance
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, "")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "   ")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, "   ")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 123)
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 123)
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "x" * 257)
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, "x" * 257)
 
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0)
@@ -380,8 +398,12 @@ class PositionLimitTests(unittest.TestCase):
             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0)
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0)
+        with self.assertRaises(TypeError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0)
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, provenance="legacy alias")
+        with self.assertRaises(TypeError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, provenance="legacy alias")
 
         # JointFault position_limit type validation
         with self.assertRaises(ValueError):
@@ -530,7 +552,7 @@ class PositionLimitTests(unittest.TestCase):
         self.assertFalse(core.snapshot().fault_latched)
 
     def test_codec_rounding_overshoot_produces_inward_actual_safe_endpoint(self):
-        spec = JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -0.1, 0.1, 10.0, 100.0, "fixture: rounding overshoot test")
+        spec = JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -0.1, 0.1, 10.0, 100.0, 100.0, "fixture: rounding overshoot test")
         target = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
 
         requested_output = spec.mapping.to_output(target)
@@ -717,7 +739,7 @@ class PositionLimitTests(unittest.TestCase):
     def test_actual_reference_matches_every_canonical_wire_field(self):
         mapping = JointMap(3.0, -1, 0.25)
         spec = JointSpec(
-            "J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: canonical reference test"
+            "J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 100.0, "fixture: canonical reference test"
         )
         requested = JointTarget(0.321, 0.123, 0.321, 1.234, 0.123)
 
@@ -737,7 +759,7 @@ class PositionLimitTests(unittest.TestCase):
 
     def test_unencodable_mapped_request_is_invalid_not_projected_into_range(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8,
             "fixture: wide software position limits",
         )
         code, actual, packet = prepare_reference_joint(
@@ -749,7 +771,7 @@ class PositionLimitTests(unittest.TestCase):
 
     def test_mapping_overflow_is_invalid_argument(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1e-308, 1, 0.0), -1.0, 1.0, 10.0, 100.0,
+            "J1", 0, JointMap(1e-308, 1, 0.0), -1.0, 1.0, 10.0, 100.0, 100.0,
             "fixture: mapping overflow limits",
         )
         code, actual, packet = prepare_reference_joint(
@@ -898,7 +920,7 @@ class PositionLimitTests(unittest.TestCase):
             with self.subTest(result=result):
                 clock = DeterministicClock(0.0)
                 spec = JointSpec(
-                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0,
+                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 100.0,
                     "fixture: late receipt limits",
                 )
                 core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
@@ -963,7 +985,7 @@ class PositionLimitTests(unittest.TestCase):
 
         clock = EndClock(0.0)
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 100.0,
             "fixture: late complete limits",
         )
         core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
@@ -1020,6 +1042,7 @@ class PositionLimitTests(unittest.TestCase):
                 q + half_width,
                 1e8,
                 1e8,
+                1e8,
                 "fixture: seeded software limits",
             )
             output_velocity = rng.uniform(-0.5, 0.5)
@@ -1080,6 +1103,7 @@ class ReferenceSpeedTests(unittest.TestCase):
             2.0,
             1.0,  # v_max_rad_s = 1.0 rad/s
             1000.0,  # a_max_rad_s2 = 1000.0 rad/s2
+            100.0,  # max_lead_rad
             "fixture: speed limit test J1",
         )
         self.spec2 = JointSpec(
@@ -1090,6 +1114,7 @@ class ReferenceSpeedTests(unittest.TestCase):
             1.0,
             2.0,  # v_max_rad_s = 2.0 rad/s
             1000.0,  # a_max_rad_s2 = 1000.0 rad/s2
+            100.0,  # max_lead_rad
             "fixture: speed limit test J2",
         )
         self.specs = (self.spec1, self.spec2)
@@ -1528,14 +1553,14 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_zero_objective_cancellation_is_not_quantization_stall(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0, 100.0,
             "fixture: zero-objective cancellation test",
         )
         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
         target = JointTarget(0.1, -1.0, 0.0, 1.0, 0.1)
 
         code, emitted, reference, packet = shape_reference_joint(
-            spec, target, anchor, 0.1, 1.0
+            spec, target, anchor, anchor.q_rad, 0.1, 1.0
         )
 
         self.assertIsNone(code)
@@ -1547,14 +1572,14 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_finite_extreme_objective_stops_when_grid_cannot_meet_acceleration(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.5e308, 1.5e308,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.5e308, 1.5e308, 100.0,
             "fixture: finite extreme objective",
         )
         anchor = JointTrajectoryReference(-1.0, Fraction(0), 0.0, 0.0, False)
         target = JointTarget(1.0, 0.0, 0.0, 1.0, 0.1)
 
         code, emitted, reference, packet = shape_reference_joint(
-            spec, target, anchor, 1e-308, 1.0
+            spec, target, anchor, anchor.q_rad, 1e-308, 1.0
         )
 
         self.assertIs(code, DecisionCode.CONSTRAINT_VIOLATION)
@@ -1585,7 +1610,7 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_oversized_integer_time_inputs_fail_closed_without_raising(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0, 100.0,
             "fixture: oversized integer time",
         )
         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
@@ -1593,7 +1618,7 @@ class ReferenceSpeedTests(unittest.TestCase):
 
         for now, gap in ((10**400, 1.0), (1.0, 10**400)):
             code, emitted, reference, packet = shape_reference_joint(
-                spec, target, anchor, now, gap
+                spec, target, anchor, 0.0, now, gap
             )
             self.assertIs(code, DecisionCode.INVALID_ARGUMENT)
             self.assertIsNone(emitted)
@@ -1604,11 +1629,11 @@ class ReferenceSpeedTests(unittest.TestCase):
         clock = DeterministicClock(0.0)
         specs = (
             JointSpec(
-                "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0,
+                "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0, 100.0,
                 "fixture: tiny-cadence stall J1",
             ),
             JointSpec(
-                "J2", 1, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0,
+                "J2", 1, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0, 100.0,
                 "fixture: tiny-cadence hold J2",
             ),
         )
@@ -1673,6 +1698,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
             2.0,
             2.0,  # v_max = 2.0 rad/s
             4.0,  # a_max = 4.0 rad/s2
+            100.0,  # max_lead_rad
             "fixture: acceleration test J1",
         )
         self.spec2 = JointSpec(
@@ -1683,6 +1709,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
             2.0,
             3.0,  # v_max = 3.0 rad/s
             6.0,  # a_max = 6.0 rad/s2
+            100.0,  # max_lead_rad
             "fixture: acceleration test J2",
         )
         self.specs = (self.spec1, self.spec2)
@@ -1759,7 +1786,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
         first_goal = JointTarget(0.5, 1.0, 0.0, 1.0, 0.1)
         code, _, moving, _ = shape_reference_joint(
-            spec, first_goal, anchor, 0.125, 1.0
+            spec, first_goal, anchor, anchor.q_rad, 0.125, 1.0
         )
         self.assertIsNone(code)
         self.assertIsNotNone(moving)
@@ -1768,7 +1795,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
         hold_goal = JointTarget(moving.q_rad, 0.0, 0.0, 1.0, 0.1)
         now = moving.sample_time_s + 0.0625
         code, _, decelerating, _ = shape_reference_joint(
-            spec, hold_goal, moving, now, 1.0
+            spec, hold_goal, moving, moving.q_rad, now, 1.0
         )
         self.assertIsNone(code)
         self.assertIsNotNone(decelerating)
@@ -1791,6 +1818,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
                     2.0,
                     2.0,
                     value,
+                    100.0,
                     "fixture: invalid acceleration limit input",
                 )
 
@@ -1805,6 +1833,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
             2.0,
             2.0,
             4.0,
+            100.0,
             "fixture: exact binary-grid acceleration equality",
         )
         self.specs = (self.spec1, self.spec2)
@@ -2014,7 +2043,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
 
     def test_position_and_acceleration_incompatible_withdraws_instead_of_q_clamp(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -10.0, 2.0, 10.0, 10.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -10.0, 2.0, 10.0, 10.0, 100.0,
             "fixture: incompatible limits",
         )
         clock = DeterministicClock(10.0)
@@ -2067,7 +2096,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
         )
         self.assertLess(position_velocity_hi, acceleration_velocity_lo)
         code, emitted, ref, packet = shape_reference_joint(
-            spec, target, anchor, blocked_at, 1.0
+            spec, target, anchor, anchor.q_rad, blocked_at, 1.0
         )
         self.assertIs(code, DecisionCode.CONSTRAINT_VIOLATION)
         self.assertIsNone(emitted)
@@ -2517,5 +2546,577 @@ class ReferenceAccelerationTests(unittest.TestCase):
         self.assertEqual(after.dispatch_attempts, before.dispatch_attempts)
 
 
+class ReferenceLeadTests(unittest.TestCase):
+    def setUp(self):
+        self.clock = DeterministicClock(10.0)
+        self.spec1 = JointSpec(
+            "J1",
+            0,
+            JointMap(1.0, 1, 0.0),
+            -2.0,
+            2.0,
+            2.0,   # v_max = 2.0 rad/s
+            10.0,  # a_max = 10.0 rad/s2
+            0.5,   # max_lead_rad = 0.5 rad
+            "fixture: lead test J1",
+        )
+        self.spec2 = JointSpec(
+            "J2",
+            1,
+            JointMap(1.0, 1, 0.0),
+            -2.0,
+            2.0,
+            2.0,   # v_max = 2.0 rad/s
+            10.0,  # a_max = 10.0 rad/s2
+            0.5,   # max_lead_rad = 0.5 rad
+            "fixture: lead test J2",
+        )
+        self.specs = (self.spec1, self.spec2)
+        self.sample1 = JointSample(0.0, 0.0, 0.0)
+        self.sample2 = JointSample(0.0, 0.0, 0.0)
+
+    def _armed_station(self, max_reference_gap_s=1.0):
+        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=max_reference_gap_s)
+        station = FakeStation(core)
+        self.assertTrue(station.connect().accepted)
+        owner = station.claim("lead-tester")
+        self.assertTrue(core.begin_check().accepted)
+        self.assertTrue(core.receive(0, self.sample1, HEALTHY_STOP).accepted)
+        self.assertTrue(core.receive(1, self.sample2, HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner).accepted)
+        return core, station, owner
+
+    def assert_all_constraints_certificate(self, previous, current, spec, q_meas):
+        h = current.sample_time_s - previous.sample_time_s
+        h_exact = Fraction(h)
+        # Position bounds
+        self.assertGreaterEqual(current.q_rad, spec.q_min_rad)
+        self.assertLessEqual(current.q_rad, spec.q_max_rad)
+        # Speed bounds
+        v_max = Fraction(spec.v_max_rad_s)
+        self.assertLessEqual(abs(current.position_step_velocity_rad_s), v_max)
+        self.assertLessEqual(abs(Fraction(current.encoded_velocity_rad_s)), v_max)
+        # Accel bounds (if h > 0)
+        if h > 0.0:
+            a_max = Fraction(spec.a_max_rad_s2)
+            prev_v_pos = Fraction(previous.position_step_velocity_rad_s)
+            prev_v_enc = Fraction(previous.encoded_velocity_rad_s)
+            curr_v_enc = Fraction(current.encoded_velocity_rad_s)
+            self.assertLessEqual(
+                abs(current.position_step_velocity_rad_s - prev_v_pos),
+                a_max * h_exact,
+            )
+            self.assertLessEqual(
+                abs(curr_v_enc - prev_v_enc),
+                a_max * h_exact,
+            )
+        # Lead bound
+        lead_exact = Fraction(spec.max_lead_rad)
+        q_meas_exact = Fraction(q_meas)
+        curr_q_exact = Fraction(current.q_rad)
+        self.assertGreaterEqual(curr_q_exact, q_meas_exact - lead_exact)
+        self.assertLessEqual(curr_q_exact, q_meas_exact + lead_exact)
+
+    def test_lead_limit_requires_finite_positive_real_value(self):
+        for val in (True, False, 0, 0.0, -0.5, math.nan, math.inf, -math.inf, 10**400, "0.5"):
+            with self.subTest(val=val), self.assertRaises(ValueError):
+                JointSpec(
+                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 2.0, 10.0, val,
+                    "fixture: invalid lead limit input",
+                )
+
+    def test_exact_lead_equality_and_outside_bounds(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+
+        # q_meas is 0.0, max_lead_rad is 0.5. Bounds are [-0.5, 0.5].
+        # Exact upper equality: q = 0.5 is accepted
+        target_exact_upper = Target(
+            1,
+            (JointTarget(0.5, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target_exact_upper).accepted)
+
+        # Exact lower equality: q = -0.5 is accepted
+        target_exact_lower = Target(
+            2,
+            (JointTarget(-0.5, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target_exact_lower).accepted)
+
+        # Outside upper bound: q = 0.5001 is rejected with LEAD_OUT_OF_BOUNDS
+        target_outside_upper = Target(
+            3,
+            (JointTarget(0.5001, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        dec_upper = station.submit(target_outside_upper)
+        self.assertFalse(dec_upper.accepted)
+        self.assertIs(dec_upper.code, DecisionCode.LEAD_OUT_OF_BOUNDS)
+
+        # Outside lower bound: q = -0.5001 is rejected with LEAD_OUT_OF_BOUNDS
+        target_outside_lower = Target(
+            4,
+            (JointTarget(-0.5001, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        dec_lower = station.submit(target_outside_lower)
+        self.assertFalse(dec_lower.accepted)
+        self.assertIs(dec_lower.code, DecisionCode.LEAD_OUT_OF_BOUNDS)
+
+    def test_healthy_rejected_goal_preservation(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+
+        # Submit valid target 1
+        t1 = Target(
+            1,
+            (JointTarget(0.2, 0.0, 0.0, 1.0, 0.1), JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t1).accepted)
+        snap1 = core.snapshot()
+        self.assertEqual(snap1.admitted_target, t1)
+        self.assertEqual(snap1.last_sequence, 1)
+
+        # Submit invalid target 2 exceeding lead limit
+        t2 = Target(
+            2,
+            (JointTarget(0.8, 0.0, 0.0, 1.0, 0.1), JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        rej = station.submit(t2)
+        self.assertFalse(rej.accepted)
+        self.assertIs(rej.code, DecisionCode.LEAD_OUT_OF_BOUNDS)
+
+        # Snapshot still preserves t1 and sequence 1
+        snap2 = core.snapshot()
+        self.assertEqual(snap2.admitted_target, t1)
+        self.assertEqual(snap2.last_sequence, 1)
+
+        # Refresh prepares plan for t1
+        self.clock.value += 0.05
+        plan = station.refresh()
+        self.assertIsNotNone(plan)
+        self.assertEqual(plan.target, t1)
+        self.assertIs(core.snapshot().state, State.MOVING)
+
+    def test_measured_drift_between_admit_prepare_claim(self):
+        # Case A: Drift between admission and prepare:
+        # Goal admitted when q_meas = 0.0. Then q_meas drifts to -0.2 before prepare.
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        t = Target(
+            1,
+            (JointTarget(0.4, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t).accepted)
+
+        # Drift observation to -0.2. Lead interval is [-0.7, 0.3].
+        self.clock.value += 0.05
+        self.assertTrue(
+            core.receive(0, JointSample(-0.2, 0.0, 0.0), MotorHealth(1, 0, 0, False)).accepted
+        )
+        self.assertTrue(
+            core.receive(1, JointSample(0.0, 0.0, 0.0), MotorHealth(1, 0, 0, False)).accepted
+        )
+
+        plan = station.refresh()
+        self.assertIsNotNone(plan)
+        ref = core.snapshot().confirmed_references[0]
+        # Reference endpoint must stay <= -0.2 + 0.5 = 0.3 rad
+        self.assertLessEqual(ref.q_rad, 0.3)
+        self.assertGreaterEqual(ref.q_rad, -0.7)
+        self.assert_all_constraints_certificate(
+            JointTrajectoryReference(0.0, Fraction(0), 0.0, 10.0, False),
+            ref,
+            self.spec1,
+            -0.2,
+        )
+
+        # Case B: Drift between prepare and claim (write gate):
+        # Reset and prepare a fresh plan
+        self.clock.value += 0.05
+        t2 = Target(
+            2,
+            (JointTarget(0.2, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)),
+            window=station.issue_window(1.0),
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t2).accepted)
+        plan2 = core.prepare_refresh()
+        self.assertIsNotNone(plan2)
+
+        # Before claim_dispatch, observation drifts to 0.9 rad (lead bound [0.4, 1.4])
+        # Proposed plan has endpoint ~ 0.2 < 0.4, so it violates fresh lead bound
+        self.assertTrue(
+            core.receive(0, JointSample(0.9, 0.0, 0.0), MotorHealth(1, 0, 0, False)).accepted
+        )
+        # Gate must reject claim!
+        self.assertFalse(core.claim_dispatch(plan2.plan_id, 0))
+        snap = core.snapshot()
+        self.assertIs(snap.state, State.FAULT)
+        self.assertTrue(snap.fault_latched)
+        self.assertTrue(snap.faults[0].constraint_fault)
+
+    def test_simultaneous_speed_accel_position_lead_satisfiable_and_infeasible(self):
+        # Satisfiable case: all 4 constraints overlap
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        t_sat = Target(
+            1,
+            (JointTarget(0.3, 1.0, 0.0, 1.0, 0.1), JointTarget(0.3, 1.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t_sat).accepted)
+        self.clock.value += 0.05
+        plan_sat = station.refresh()
+        self.assertIsNotNone(plan_sat)
+        ref_sat = core.snapshot().confirmed_references[0]
+        self.assert_all_constraints_certificate(
+            JointTrajectoryReference(0.0, Fraction(0), 0.0, 10.0, False),
+            ref_sat,
+            self.spec1,
+            0.0,
+        )
+
+        # Infeasible case: lead bound is disjoint from acceleration bound
+        # Anchor velocity is high positive (+2.0 rad/s).
+        # At h = 0.05, a_max = 10 -> accel interval is [2.0 - 0.5, 2.0 + 0.5] = [1.5, 2.0]
+        # Step position would be >= 0.0 + 1.5 * 0.05 = 0.075 rad.
+        # But if q_meas drifts to -0.6 rad, lead bound [-1.1, -0.1] requires q <= -0.1!
+        # The required velocity would be <= (-0.1 - 0.0)/0.05 = -2.0 rad/s,
+        # which is completely disjoint from [1.5, 2.0]!
+        anchor_fast = JointTrajectoryReference(
+            q_rad=0.0,
+            position_step_velocity_rad_s=Fraction(2, 1),
+            encoded_velocity_rad_s=2.0,
+            sample_time_s=self.clock.value,
+            is_emitted=True,
+            requested_goal=JointTarget(0.3, 1.0, 0.0, 1.0, 0.1),
+            emitted_target=JointTarget(0.0, 2.0, 0.0, 1.0, 0.1),
+            packet=plan_sat.packets[0],
+        )
+        code, emitted, ref, pkt = shape_reference_joint(
+            self.spec1,
+            JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            anchor_fast,
+            -0.6,  # q_meas = -0.6 -> lead upper bound is -0.1
+            self.clock.value + 0.05,
+            1.0,
+        )
+        self.assertIs(code, DecisionCode.CONSTRAINT_VIOLATION)
+        self.assertIsNone(emitted)
+        self.assertIsNone(ref)
+        self.assertIsNone(pkt)
+
+    def test_h0_refresh_inside_and_outside_lead(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        target = Target(
+            1,
+            (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1), JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+
+        # Fresh stop anchor at h = 0 cannot dispatch write
+        self.assertIsNone(core.prepare_refresh())
+        self.assertIs(core.snapshot().state, State.FAULT)
+
+        # Clear fault and advance time to emit first reference
+        self.assertTrue(station.stop().accepted)
+        owner2 = station.claim("h0-tester")
+        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
+        self.clock.value += 0.1
+        self.assertTrue(core.receive(0, self.sample1, HEALTHY_STOP).accepted)
+        self.assertTrue(core.receive(1, self.sample2, HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner2).accepted)
+
+        w2 = station.issue_window(1.0)
+        t_emit = Target(
+            1,
+            (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1), JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)),
+            window=w2,
+            owner=owner2,
+        )
+        self.assertTrue(station.submit(t_emit).accepted)
+        self.clock.value += 0.05
+        plan1 = station.refresh()
+        self.assertIsNotNone(plan1)
+
+        # Case A: At h = 0 (clock unchanged), goal unchanged, observation inside lead:
+        # prepare_refresh reuses previous reference safely
+        plan_h0 = core.prepare_refresh()
+        self.assertIsNotNone(plan_h0)
+        self.assertEqual(plan_h0.joint_targets[0].q_rad, plan1.joint_targets[0].q_rad)
+
+        # Case B: At h = 0, observation drifts outside lead:
+        # e.g. q_meas jumps to 0.8 rad, while previous emitted q is ~ 0.05 rad (outside [0.3, 1.3])
+        self.assertTrue(
+            core.receive(0, JointSample(0.8, 0.0, 0.0), MotorHealth(1, 0, 0, False)).accepted
+        )
+        self.assertIsNone(core.prepare_refresh())
+        snap = core.snapshot()
+        self.assertIs(snap.state, State.FAULT)
+        self.assertTrue(snap.faults[0].constraint_fault)
+
+    def test_missing_and_stale_feedback_handling(self):
+        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
+        station = FakeStation(core)
+        self.assertTrue(station.connect().accepted)
+        owner = station.claim("stale-tester")
+        self.assertTrue(core.begin_check().accepted)
+        self.assertTrue(core.receive(0, self.sample1, HEALTHY_STOP).accepted)
+        self.assertTrue(core.receive(1, self.sample2, HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner).accepted)
+
+        # Before feedback ages out, submission is accepted
+        w = station.issue_window(1.0)
+        t1 = Target(
+            1,
+            (JointTarget(0.1, 0.0, 0.0, 1.0, 0.1), JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)),
+            window=w,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t1).accepted)
+
+        # Advance clock past feedback_max_age_s (default 0.5s)
+        self.clock.value += 0.6
+        t2 = Target(
+            2,
+            (JointTarget(0.2, 0.0, 0.0, 1.0, 0.1), JointTarget(0.2, 0.0, 0.0, 1.0, 0.1)),
+            window=station.issue_window(1.0),
+            owner=owner,
+        )
+        rej = station.submit(t2)
+        self.assertFalse(rej.accepted)
+        self.assertIs(rej.code, DecisionCode.STALE_FEEDBACK)
+        # Sequence watermark and admitted target preserved
+        self.assertEqual(core.snapshot().admitted_target, t1)
+        self.assertEqual(core.snapshot().last_sequence, 1)
+
+    def test_negative_direction_and_wire_quantization(self):
+        mapping = JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25)
+        spec = JointSpec(
+            "J_neg",
+            0,
+            mapping,
+            -2.0,
+            2.0,
+            2.0,
+            10.0,
+            0.3,  # lead = 0.3 rad
+            "fixture: negative direction lead test",
+        )
+        clock = DeterministicClock(10.0)
+        core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
+        station = FakeStation(core)
+        self.assertTrue(station.connect().accepted)
+        owner = station.claim("neg-tester")
+        self.assertTrue(core.begin_check().accepted)
+        self.assertTrue(core.receive(0, JointSample(0.1, 0.0, 0.0), HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner).accepted)
+
+        # q_meas = 0.1, lead = 0.3 -> [ -0.2, 0.4 ]
+        # Exactly on bound: 0.4 is accepted
+        w = station.issue_window(1.0)
+        t_bound = Target(1, (JointTarget(0.4, 0.0, 0.0, 1.0, 0.1),), window=w, owner=owner)
+        self.assertTrue(station.submit(t_bound).accepted)
+
+        clock.value += 0.05
+        plan = station.refresh()
+        self.assertIsNotNone(plan)
+        ref = core.snapshot().confirmed_references[0]
+        # Inward projection must strictly be inside [ -0.2, 0.4 ]
+        self.assertGreaterEqual(ref.q_rad, -0.2)
+        self.assertLessEqual(ref.q_rad, 0.4)
+        # Decoded canonical wire bytes match emitted target exactly
+        decoded = decode_command(plan.packets[0])
+        mapped_back = mapping.from_output(OutputSample(
+            decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
+        ))
+        self.assertEqual(ref.q_rad, mapped_back.q_rad)
+
+    def test_progression_over_multistep_and_conservative_stop_on_too_small_cadence(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(2.0)
+        # Goal is distant: 1.5 rad (measurement is 0.0, lead is 0.5)
+        t_distant = Target(
+            1,
+            (JointTarget(1.5, 0.0, 0.0, 1.0, 0.1), JointTarget(0.0, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t_distant).accepted)
+
+        # Multi-step progression
+        for step in range(5):
+            self.clock.value += 0.05
+            prev_q = core.snapshot().confirmed_references[0].q_rad
+            # Update feedback tracking previous reference
+            self.assertTrue(
+                core.receive(0, JointSample(prev_q, 0.0, 0.0), MotorHealth(1, 0, 0, False)).accepted
+            )
+            self.assertTrue(
+                core.receive(1, JointSample(0.0, 0.0, 0.0), MotorHealth(1, 0, 0, False)).accepted
+            )
+            plan = station.refresh()
+            self.assertIsNotNone(plan)
+            curr_q = core.snapshot().confirmed_references[0].q_rad
+            self.assertGreater(curr_q, prev_q)
+            self.assertLessEqual(curr_q, prev_q + 0.5)
+
+        # Conservative stop on too-small cadence
+        self.clock.value += 1e-10
+        self.assertIsNone(core.prepare_refresh())
+        snap = core.snapshot()
+        self.assertIs(snap.state, State.FAULT)
+        self.assertTrue(snap.faults[0].constraint_fault)
+
+    def test_attributed_fault_union_and_recovery(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        # J1 requests goal outside lead (0.8 > 0.5), J2 requests valid goal (0.1)
+        t_bad = Target(
+            1,
+            (JointTarget(0.8, 0.0, 0.0, 1.0, 0.1), JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        dec = station.submit(t_bad)
+        self.assertFalse(dec.accepted)
+        self.assertIs(dec.code, DecisionCode.LEAD_OUT_OF_BOUNDS)
+
+        # Now submit valid target, then cause J1 lead fault during refresh via feedback drift
+        t_good = Target(
+            1,
+            (JointTarget(0.4, 0.0, 0.0, 1.0, 0.1), JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t_good).accepted)
+        self.clock.value += 0.01
+
+        # Drift J1 feedback so lead bound is empty relative to acceleration
+        # J1 jumps to -1.0 rad: impossible to satisfy in 0.01s
+        self.assertTrue(
+            core.receive(0, JointSample(-1.0, 0.0, 0.0), MotorHealth(1, 0, 0, False)).accepted
+        )
+        self.assertTrue(
+            core.receive(1, JointSample(0.0, 0.0, 0.0), MotorHealth(1, 0, 0, False)).accepted
+        )
+
+        self.assertIsNone(core.prepare_refresh())
+        snap = core.snapshot()
+        self.assertIs(snap.state, State.FAULT)
+        self.assertEqual(snap.affected_joints, ("J1",))
+        self.assertTrue(snap.faults[0].constraint_fault)
+
+        # Recovery requires stop, claim new owner, acknowledged fresh check, re-arm
+        self.assertTrue(station.stop().accepted)
+        new_owner = station.claim("recovery-client")
+        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
+        self.clock.value += 0.1
+        self.assertTrue(core.receive(0, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
+        self.assertTrue(core.receive(1, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(new_owner).accepted)
+        self.assertIs(core.snapshot().state, State.ARMED)
+        self.assertFalse(core.snapshot().fault_latched)
+
+    def test_deterministic_seeded_fuzz_four_constraint_invariants(self):
+        rng = random.Random(12345)
+        for iteration in range(50):
+            reduction = rng.choice((1.0, 2.0, 3.0, 4.0))
+            direction = rng.choice((-1, 1))
+            zero = rng.uniform(-1.0, 1.0)
+            mapping = JointMap(reduction, direction, zero)
+
+            q_min = rng.uniform(-3.0, -1.0)
+            q_max = rng.uniform(1.0, 3.0)
+            v_max = rng.uniform(0.5, 5.0)
+            a_max = rng.uniform(1.0, 20.0)
+            lead = rng.uniform(0.1, 1.0)
+
+            spec = JointSpec(
+                "J_fuzz", 0, mapping, q_min, q_max, v_max, a_max, lead, "fixture: fuzz"
+            )
+
+            # Random anchor
+            q_anchor = rng.uniform(q_min + 0.1, q_max - 0.1)
+            v_anchor = rng.uniform(-v_max, v_max)
+            anchor = JointTrajectoryReference(
+                q_rad=q_anchor,
+                position_step_velocity_rad_s=Fraction(round(v_anchor, 3)),
+                encoded_velocity_rad_s=v_anchor,
+                sample_time_s=10.0,
+                is_emitted=True,
+            )
+
+            # Random measurement and goal
+            q_meas = q_anchor + rng.uniform(-lead * 0.8, lead * 0.8)
+            goal_q = q_meas + rng.uniform(-lead * 1.5, lead * 1.5)
+            goal_v = rng.uniform(-v_max * 1.2, v_max * 1.2)
+            goal = JointTarget(goal_q, goal_v, 0.0, 1.0, 0.1)
+
+            h = rng.choice((0.01, 0.02, 0.05, 0.1))
+            now = 10.0 + h
+
+            code, emitted, ref, pkt = shape_reference_joint(
+                spec, goal, anchor, q_meas, now, 1.0
+            )
+
+            with self.subTest(iteration=iteration):
+                if code is None:
+                    self.assertIsNotNone(emitted)
+                    self.assertIsNotNone(ref)
+                    self.assertIsNotNone(pkt)
+                    # 1. Position bounds
+                    self.assertGreaterEqual(emitted.q_rad, spec.q_min_rad)
+                    self.assertLessEqual(emitted.q_rad, spec.q_max_rad)
+                    # 2. Speed bounds
+                    h_exact = Fraction(h)
+                    v_max_exact = Fraction(spec.v_max_rad_s)
+                    self.assertLessEqual(abs(ref.position_step_velocity_rad_s), v_max_exact)
+                    self.assertLessEqual(abs(Fraction(ref.encoded_velocity_rad_s)), v_max_exact)
+                    # 3. Acceleration bounds
+                    a_max_exact = Fraction(spec.a_max_rad_s2)
+                    self.assertLessEqual(
+                        abs(ref.position_step_velocity_rad_s - anchor.position_step_velocity_rad_s),
+                        a_max_exact * h_exact,
+                    )
+                    self.assertLessEqual(
+                        abs(Fraction(ref.encoded_velocity_rad_s) - Fraction(anchor.encoded_velocity_rad_s)),
+                        a_max_exact * h_exact,
+                    )
+                    # 4. Lead bound
+                    lead_exact = Fraction(spec.max_lead_rad)
+                    q_meas_exact = Fraction(q_meas)
+                    emitted_q_exact = Fraction(emitted.q_rad)
+                    self.assertGreaterEqual(emitted_q_exact, q_meas_exact - lead_exact)
+                    self.assertLessEqual(emitted_q_exact, q_meas_exact + lead_exact)
+                else:
+                    self.assertIsNone(emitted)
+                    self.assertIsNone(ref)
+                    self.assertIsNone(pkt)
+
+
 if __name__ == "__main__":
     unittest.main()
diff --git a/test_controller_owner.py b/test_controller_owner.py
index 08419ae..6718c37 100644
--- a/test_controller_owner.py
+++ b/test_controller_owner.py
@@ -27,8 +27,8 @@ class ControllerOwnerTests(unittest.TestCase):
     def setUp(self):
         self.clock = DeterministicClock(0.0)
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
diff --git a/test_controller_targets.py b/test_controller_targets.py
index ffdac0a..1a1c7e2 100644
--- a/test_controller_targets.py
+++ b/test_controller_targets.py
@@ -21,8 +21,8 @@ from test_controller import DeterministicClock, FakeStation, SAMPLE, HEALTHY_STO
 class LatestTargetTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
 
     def test_ten_thousand_accepted_updates_leave_one_newest_target_and_repeated_refresh(self):
@@ -273,8 +273,8 @@ class LatestTargetTests(unittest.TestCase):
         self.assertEqual(core.snapshot().last_sequence, 1)
 
         specs_ratio = (
-            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(reduction=1.0, direction=1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(reduction=1.0, direction=1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         core_ratio = JointCore(specs_ratio, clock=clock, max_reference_gap_s=1.0)
         station_ratio = FakeStation(core_ratio)
@@ -295,8 +295,8 @@ class LatestTargetTests(unittest.TestCase):
     def test_successful_fake_adapter_uses_actual_codec_foc_packets_with_independent_expected_mappings(self):
         clock = DeterministicClock(0.0)
         specs = (
-            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(reduction=2.0, direction=1, zero_output_rad=0.1), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(reduction=2.0, direction=1, zero_output_rad=0.1), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         core = JointCore(specs, clock=clock, max_reference_gap_s=1.0)
         station = FakeStation(core)
@@ -529,8 +529,8 @@ class LatestTargetTests(unittest.TestCase):
 class CommandSequenceTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),

```

## Actual fake station fixture
```
import unittest
from dataclasses import FrozenInstanceError
import math

from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    IntentWindow,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget


SAMPLE = JointSample(0.1, 0.0, 0.0)
HEALTHY_STOP = MotorHealth(mode=0, errors=0, warnings=0, timeout=False)
SOURCE = SourceIdentity("fixture", "controller-test", 1)


class FakeStation:
    def __init__(self, core):
        self.core = core
        self.writes = []
        self.owner = None

    def _write_stops(self):
        self.writes.extend(command(spec.motor_id, mode=0) for spec in self.core.joint_specs)

    def connect(self):
        decision = self.core.begin_connect()
        if not decision.accepted:
            return decision
        decision = self.core.connected(SOURCE)
        if decision.accepted:
            self._write_stops()
        return decision

    def claim(self, connection_id="human"):
        prior_state = self.core.snapshot().state
        self.owner = self.core.claim_owner(connection_id)
        if self.core.snapshot().state is State.STOPPED and prior_state is not State.STOPPED:
            self._write_stops()
        return self.owner

    def check(self, *, acknowledge_fault=False):
        decision = self.core.begin_check(acknowledge_fault=acknowledge_fault)
        if not decision.accepted:
            return decision
        self._write_stops()
        for spec in self.core.joint_specs:
            decision = self.core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP)
            if not decision.accepted:
                return decision
        return self.core.checked()

    def arm(self, owner: OwnerToken):
        return self.core.arm(owner)

    def issue_window(self, valid_for_s=0.2):
        return self.core.issue_window(valid_for_s)

    def submit(self, target):
        return self.core.submit_target(target)

    def refresh(self):
        plan = self.core.prepare_refresh()
        if plan is None:
            return None
        for index, packet in enumerate(plan.packets):
            if not self.core.claim_dispatch(plan.plan_id, index):
                break
            self.writes.append(packet)
            self.core.dispatch_result(plan.plan_id, index, WriteResult.COMPLETE)
        return plan

    def stop(self):
        decision = self.core.stop()
        if decision.accepted:
            self._write_stops()
        return decision

    def disconnect(self):
        return self.core.disconnect()


class DeterministicClock:
    def __init__(self, value=0.0):
        self.value = value
        self.calls = 0

    def __call__(self):
        self.calls += 1
        return self.value


```

## C12-parent-inspection.json
```
{
  "sourceInspected": true,
  "changedFiles": [
    {
      "path": "docs/joint-api.md",
      "exists": true,
      "bytes": 22125,
      "sha256": "859028a076b11677494044de2f05674a7542e6bdcebf38324d55d8e41b403556"
    },
    {
      "path": "joint_contract.py",
      "exists": true,
      "bytes": 30817,
      "sha256": "93008e1311e12324de8e18486aecf0f7d85ba7e3aa2c80378bcdbcb6914c0dc7"
    },
    {
      "path": "joint_controller.py",
      "exists": true,
      "bytes": 36359,
      "sha256": "7f98e1ff9c500741cce9a7d1db8a233aaddcff9154fa15926e1cae7bc0020220"
    },
    {
      "path": "joint_reference.py",
      "exists": true,
      "bytes": 27259,
      "sha256": "cf70feeeecd26fa6f1db6ad287439be83ba8ab2189b3aed275e65588b4fdb9cb"
    },
    {
      "path": "scripts/check_milestone.py",
      "exists": true,
      "bytes": 3223,
      "sha256": "ffe4747eb32c81919626af1a2e4059d057f109a2f04162138aebe8d965bf2c46"
    },
    {
      "path": "test_controller.py",
      "exists": true,
      "bytes": 40449,
      "sha256": "cd3e36070141ee0df00ac7546f37950f96372174910a7be70ab0fa8a2f7b7018"
    },
    {
      "path": "test_controller_expiry.py",
      "exists": true,
      "bytes": 39356,
      "sha256": "e6f0dbfb3f9b1597a90d09cd2526efdf1e110888f7929a1ef5ae332bf2453750"
    },
    {
      "path": "test_controller_limits.py",
      "exists": true,
      "bytes": 129472,
      "sha256": "3da5409a68bdfeeba33cd3e2741f96bb16e85188ea0383c065352275aa994b97"
    },
    {
      "path": "test_controller_owner.py",
      "exists": true,
      "bytes": 16990,
      "sha256": "05da6991c325df0928b946db27b5e8379f883c86ca503cfd96d1a778553835c0"
    },
    {
      "path": "test_controller_targets.py",
      "exists": true,
      "bytes": 37450,
      "sha256": "55b3642c2d3636ae151366b9b5bf5ca363c5b901848ddd8448c7061d7ab40928"
    }
  ],
  "diffInspected": "C12-diff.patch including full 10 authored path deltas and surrounding finalgate/reference contract",
  "baseUnchanged": "81dae29f79209f08f1b410c912ae536410ae0e06",
  "sourceUnchangedDuringChecks": true,
  "physicalIO": "none",
  "result": "/tmp/pstack-c07-c16-20261008-smgcfm_v/C12-parent-checks/20261008T185148207098Z/result.json",
  "targeted": "11 tests 2failures2errors",
  "milestone": "211 tests2failures2errors",
  "independentExactCertificates": "768 positive speed/accel/lead and768h0 caches pass",
  "C11ConsistencyRepro": "1 passes",
  "defects": [
    "Float lead arithmetic allows exact outside requested goal and cached h0 replay; corrected parent exact repro2 actualfailures",
    "h0 recovery test reuses consumed global sequence",
    "Stale housekeeping expectation conflicts with existing goal invalidation",
    "progression fixture asks2swindow above1smaximum then distant goal outsidelead",
    "seeded fixture constructs emittedreference without required metadata; nominal h differs actualtime subtraction"
  ],
  "parentHarnessCorrection": "First parent lead repro missing requiredmaxgap and false decimal boundary premise retained; corrected C12-parent-lead-exact.py executed2actualfailures",
  "inspection": "clear scoped author effects; draft not accepted"
}

```

## C12-parent-lead-exact.py
```
"""Parent exact lead-bound checks over finite float domain values; no I/O."""
from pathlib import Path
from fractions import Fraction
import math
import sys
import unittest

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from im6014_codec import raw_to_position
from joint_contract import DecisionCode, JointSpec, JointTrajectoryReference, Target
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget
from joint_reference import shape_reference_joint
from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP


class ExactLeadBoundary(unittest.TestCase):
    def test_rounded_admission_boundary_cannot_accept_outside_requested_goal(self):
        clock = DeterministicClock(0.0)
        spec = JointSpec('J', 0, JointMap(1, 1, 0), -1, 1, 1, 10, .2,
                         'parent exact lead software fixture')
        core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
        station = FakeStation(core)
        self.assertTrue(station.connect())
        owner = station.claim('parent')
        self.assertTrue(core.begin_check())
        self.assertTrue(core.receive(0, JointSample(.1, 0, 0), HEALTHY_STOP))
        self.assertTrue(core.checked())
        self.assertTrue(station.arm(owner))
        window = station.issue_window(1)
        valid = Target(1, (JointTarget(.1, 0, 0, 1, .1),), window=window, owner=owner)
        self.assertTrue(station.submit(valid))
        before = core.snapshot()
        q = .1 + .2
        self.assertGreater(Fraction(q) - Fraction(.1), Fraction(.2))
        outside = Target(2, (JointTarget(q, 0, 0, 1, .1),), window=window, owner=owner)
        decision = station.submit(outside)
        self.assertFalse(decision, 'Rounded lead boundary admitted an exactly outside goal')
        self.assertEqual(decision.code, DecisionCode.LEAD_OUT_OF_BOUNDS)
        after = core.snapshot()
        self.assertEqual(after.admitted_target, before.admitted_target)
        self.assertEqual(after.last_sequence, before.last_sequence)

    def test_zero_cadence_replay_cannot_use_rounded_lead_interval(self):
        mapping = JointMap(math.ldexp(raw_to_position(1), 2), 1, 0)
        spec = JointSpec('J', 0, mapping, -1, 1, 1, 4, .36,
                         'parent exact cached lead software fixture')
        goal = JointTarget(.25, 0, 0, 0, 0)
        anchor = JointTrajectoryReference(.25, 0, 0, 0, False)
        code, actual, emitted, packet = shape_reference_joint(spec, goal, anchor, .25, .25, .5)
        self.assertIsNone(code)
        self.assertEqual(actual.q_rad, .25)
        self.assertGreater(Fraction(actual.q_rad) - Fraction(-.11), Fraction(spec.max_lead_rad))
        self.assertEqual(-.11 + spec.max_lead_rad, actual.q_rad)
        repeated = shape_reference_joint(spec, goal, emitted, -.11, .25, .5)
        self.assertEqual(repeated[0], DecisionCode.CONSTRAINT_VIOLATION,
                         'Zero-cadence cached packet exceeded the exact fresh lead bound')
        self.assertIsNone(repeated[3])


unittest.main(argv=[sys.argv[0]], verbosity=2)

```

## C12-original-exact-lead.log
```
test_rounded_admission_boundary_cannot_accept_outside_requested_goal (__main__.ExactLeadBoundary.test_rounded_admission_boundary_cannot_accept_outside_requested_goal) ... FAIL
test_zero_cadence_replay_cannot_use_rounded_lead_interval (__main__.ExactLeadBoundary.test_zero_cadence_replay_cannot_use_rounded_lead_interval) ... FAIL

======================================================================
FAIL: test_rounded_admission_boundary_cannot_accept_outside_requested_goal (__main__.ExactLeadBoundary.test_rounded_admission_boundary_cannot_accept_outside_requested_goal)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C12-parent-lead-exact.py", line 38, in test_rounded_admission_boundary_cannot_accept_outside_requested_goal
    self.assertFalse(decision, 'Rounded lead boundary admitted an exactly outside goal')
AssertionError: Decision(accepted=True, code=<DecisionCode.ACCEPTED: 'accepted'>) is not false : Rounded lead boundary admitted an exactly outside goal

======================================================================
FAIL: test_zero_cadence_replay_cannot_use_rounded_lead_interval (__main__.ExactLeadBoundary.test_zero_cadence_replay_cannot_use_rounded_lead_interval)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C12-parent-lead-exact.py", line 56, in test_zero_cadence_replay_cannot_use_rounded_lead_interval
    self.assertEqual(repeated[0], DecisionCode.CONSTRAINT_VIOLATION,
AssertionError: None != <DecisionCode.CONSTRAINT_VIOLATION: 'constraint_violation'> : Zero-cadence cached packet exceeded the exact fresh lead bound

----------------------------------------------------------------------
Ran 2 tests in 0.004s

FAILED (failures=2)

```

## rubric.md
# Review Rubric

Review through whichever lenses are relevant. Not every lens applies to every change. Use judgment.

## Correctness

Does the code actually do what the intent says it should?

- Edge cases: empty inputs, nil/undefined, boundary values, concurrent access
- Error handling: are errors caught, propagated, or silently swallowed?
- Off-by-one, type coercion, integer overflow, string encoding
- State management: race conditions, stale closures, dangling references
- Does the happy path work? Does the sad path work?
- Idempotency: what happens if this operation runs twice, or if a previous run crashed halfway? If the answer is "it depends on what state was left behind," there's a missing reconciliation step.
- Concurrency: if multiple actors can touch the same mutable state (files, branches, shared data), is access serialized structurally (locks, sequential phases, exclusive ownership), or by conventions that won't hold?

When you find a potential bug, trace the execution path. Don't just flag "this could be nil". Show the call chain that makes it nil.

## Root Causes vs. Symptoms

Is the code fixing the actual problem or papering over a symptom?

Answering this often requires looking beyond the changed files. Read the surrounding code (callers, callees, type definitions, sibling modules) and understand the architecture the change lives in. Use the tools available to you (Read, Grep, Glob) to explore. Follow the call chain. Read the types. Understand why the code exists before judging whether the change addresses the right layer.

- Guard clauses that mask a deeper invariant violation
- Retry logic that hides a broken contract
- Type casts that silence a modeling error
- If you see a workaround, ask: why is the workaround needed? What would a proper fix look like?
- A fix in module A that should really be a fix in module B's contract
- Instructions where structure would be better: if the fix is a comment saying "don't do X" or a convention someone has to remember, ask whether it could instead be a type constraint, a lint rule, or a runtime check that makes the wrong thing impossible

## Structural Integrity

Does the code fit well into the system it's part of?

- Boundary discipline: is validation at system boundaries, or scattered through business logic? Validate data once where it enters the system, then trust it internally.
- Abstraction level: is the code mixing high-level orchestration with low-level detail?
- Coupling: does this change introduce dependencies that will make future changes harder?
- Data model fit: do the data structures match the actual access patterns? The right structure makes downstream code obvious. The wrong one fights you at every turn.
- Bolted-on vs. integrated: was the change patched onto the existing design, or does it read as if the design always accounted for it? If the new requirement had been known from the start, would the code look like this?
- Legacy dual-paths: does the change introduce a new API while keeping the old one alive? If there are no external consumers, migrate callers and delete the old path in the same wave. Don't leave compatibility layers that will become permanent.

Don't penalize simple code for lacking abstraction. Premature abstraction is worse than duplication.

## Verification

Can you tell that this code works from reading it?

- Are there tests? Do they test behavior or implementation details?
- Are there assertions/invariants that would catch regressions?
- If this is a bug fix: is there a test for the bug?
- If this touches an integration boundary: is the full path tested?
- Check the real thing, not a proxy. If the code checks liveness via file mtime or cached state instead of reading the actual value, that's a verification gap.
- For delegated or async work: does the code verify actual output artifacts, or does it trust self-reports and summaries?

## Complexity Budget

Is the complexity justified by what the code accomplishes?

- Code that could be simpler without losing correctness or clarity
- Abstractions that serve only one call site
- Configuration or parameterization for cases that don't exist yet
- Dead code, unused imports, vestigial parameters
- Over-engineering: "just in case" code paths with no current callers
- Obsolete compatibility paths kept alive for transitional stability that's no longer needed. If the migration is done, delete the scaffolding
- Does the user experience justify the complexity? Every feature, control, and option should earn its place. Half-finished features are worse than missing ones.

Simpler is better unless simpler is wrong. Three lines of duplication beat a premature abstraction.

## Security

For each security finding, trace the input path through the code and show it.

- User input flowing to dangerous sinks (SQL, shell, eval, innerHTML) without sanitization
- Authentication/authorization gaps in new endpoints
- Secrets in code, logs, or error messages
- TOCTOU (time-of-check-time-of-use) in security-critical paths

## code-quality-review.md
# Code Quality Review

Each reviewer applies this code-quality lens in addition to the rubric. It is a strict standard focused on implementation quality, maintainability, abstraction quality, and codebase health.

Above all, be ambitious about code structure. Do not merely identify local cleanup. Actively search for "code judo" moves, restructurings that preserve behavior while making the implementation dramatically simpler, smaller, more direct, and more elegant.

## Core Prompt

Start from this baseline:

> Perform a deep code quality audit of the current branch's changes.
> Rethink how to structure / implement the changes to meaningfully improve code quality without impacting behavior.
> Work to improve abstractions, modularity, reduce Spaghetti code, improve succinctness and legibility.
> Be ambitious, if there is a clear path to improving the implementation that involves restructuring some of the codebase, go for it.
> Be extremely thorough and rigorous. Measure twice, cut once.

## Dimensions

Each dimension is stated once. Apply the ones that are relevant.

0. **Be ambitious about structural simplification.** Do not stop at "this could be a bit cleaner." Look for reframings that make whole branches, helpers, modes, conditionals, or layers disappear. Assume a "code judo" move is often available. It uses the existing architecture more effectively and makes the change dramatically simpler. If you can delete complexity rather than rearrange it, push hard for that.

1. **Do not let a PR push a file from under 1k lines to over 1k lines without a very strong reason.** Treat this as a strong smell. Prefer extracting helpers, subcomponents, or modules. If the diff crosses that threshold, ask whether the code should be decomposed first. Waive only for a compelling structural reason where the resulting file stays clearly organized.

2. **Do not allow spaghetti growth in existing code.** Be suspicious of new ad-hoc conditionals, scattered special cases, or one-off branches inserted into unrelated flows. Treat "weird if statements in random places" as a design problem, not a style nit. Prefer pushing the logic into a dedicated helper, state machine, or module instead of tangling an existing path.

3. **Bias toward cleaning the design, not just accepting working code.** If behavior can stay the same while the structure becomes meaningfully cleaner, push for the cleaner version. Prefer simplifications that remove moving pieces over refactors that spread the same complexity around.

4. **Prefer direct, boring, maintainable code over hacky or magical code.** Treat brittle, ad-hoc, or "magic" behavior as a problem. Be skeptical of generic mechanisms that hide simple data-shape assumptions. Flag thin abstractions, identity wrappers, or pass-through helpers that add indirection without buying clarity.

5. **Push on type and boundary cleanliness when it affects maintainability.** Question unnecessary optionality, `unknown`, `any`, or cast-heavy code when a clearer type boundary could exist. Prefer explicit typed models over loosely-shaped ad-hoc objects. If a branch leans on a silent fallback to paper over an unclear invariant, ask whether the boundary should be made explicit.

6. **Keep logic in the canonical layer and reuse existing helpers.** Call out feature logic leaking into shared paths or implementation details leaking through APIs. Prefer existing canonical utilities over bespoke one-offs. Push code toward the right package, service, or module instead of normalizing drift.

7. **Treat unnecessary sequential orchestration and non-atomic updates as design smells when the cleaner structure is obvious.** If independent work is serialized for no reason, ask whether it should run in parallel. If related updates can leave state half-applied, push for a more atomic structure. Do not over-index on micro-optimizations, but do flag avoidable orchestration complexity that makes the code more brittle.

## Output Expectations

Prioritize structural code-quality regressions and missed simplifications first, then spaghetti and branching complexity, then boundary, type, and file-size concerns, then smaller modularity and legibility issues.

## Approval Bar

Do not approve merely because behavior seems correct. Treat these as presumptive blockers unless the author can justify them: the PR keeps a lot of incidental complexity when a code-judo move would delete it. Pushes a file from below 1000 lines to above 1000 lines. Adds ad-hoc branching that tangles an existing flow. Scatters feature checks across shared code. Adds an unnecessary abstraction, wrapper, or cast-heavy contract, or duplicates an existing helper or puts logic in the wrong layer when there is a clear canonical home. If those conditions are not met, leave explicit, actionable feedback and push for a cleaner decomposition.

## Review Tone

Be direct, serious, and demanding about quality. Do not be rude, but do not soften major maintainability issues into mild suggestions. If the code is making the codebase messier, say so. If the implementation missed an obvious dramatic simplification, say that too. Do not be satisfied with "maybe rename this" when the real issue is structural.
