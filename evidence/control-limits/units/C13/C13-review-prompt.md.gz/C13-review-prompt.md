Use ONLY supplied complete inline material. TEXT REVIEW ONLY, no tools/reads/shell/MCP/network/permissions/subagents. Return JSON array of actionable findings with file/function/line/severity/evidence/fix, or [].
Intent C13: required positive finite peak joint effort; combined ff+kp*(actual decoded q-measuredq)+kd*(actual decoded wirevelocity-measuredvelocity), actual quantized gains mapped once. Three authority gates plus independent measured peak monitoring. All prior owner/expiry/position/V/A/exactlead/history semantics must hold. No physical claims. Original draft NOT accepted. Known defects being repaired: nonexistent testcodec imports; two missed accelerationtest constructors; combined float rounding can admit exactly abovepeak canonicaleffort (actualparentrepro supplied). Tests may assume nominal torque/position instead of actualquantizedboundary. Ignore duplicates of these knownrootcauses, find distinct defects and needless structures. C14thermal/dwell and C15timing/C16station remain future work.

## Complete joint_contract.py
```
"""Frozen domain records and status types for joint control.

All records are immutable (frozen) data contracts with no transport or clock ownership.
"""

from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
import math
from typing import Literal

from im6014_codec import decode_command
from joint_mapping import JointMap, JointSample, JointTarget


class State(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    CHECKING = "checking"
    READY = "ready"
    ARMED = "armed"
    MOVING = "moving"
    STOPPED = "stopped"
    FAULT = "fault"


class DecisionCode(str, Enum):
    ACCEPTED = "accepted"
    INVALID_STATE = "invalid_state"
    INVALID_ARGUMENT = "invalid_argument"
    INVALID_OWNER = "invalid_owner"
    INVALID_SOURCE = "invalid_source"
    UNKNOWN_JOINT = "unknown_joint"
    INVALID_OBSERVATION = "invalid_observation"
    FAULT_ACK_REQUIRED = "fault_ack_required"
    FAULT_LATCHED = "fault_latched"
    OBSERVATIONS_INCOMPLETE = "observations_incomplete"
    STALE_FEEDBACK = "stale_feedback"
    UNHEALTHY = "unhealthy"
    NOT_STOPPED = "not_stopped"
    DUPLICATE_OR_OLDER = "duplicate_or_older"
    EXPIRED = "expired"
    POSITION_OUT_OF_BOUNDS = "position_out_of_bounds"
    SPEED_OUT_OF_BOUNDS = "speed_out_of_bounds"
    LEAD_OUT_OF_BOUNDS = "lead_out_of_bounds"
    EFFORT_OUT_OF_BOUNDS = "effort_out_of_bounds"
    REFERENCE_GAP_EXCEEDED = "reference_gap_exceeded"
    CONSTRAINT_VIOLATION = "constraint_violation"


class CommunicationFailure(str, Enum):
    TIMEOUT = "timeout"
    INVALID_FEEDBACK = "invalid_feedback"
    DRIVER_FAILURE = "driver_failure"
    CLOCK_FAILURE = "clock_failure"
    PREWRITE_DEADLINE = "prewrite_deadline"


class WriteResult(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    PREWRITE_DEADLINE = "prewrite_deadline"


@dataclass(frozen=True)
class Decision:
    accepted: bool
    code: DecisionCode

    def __post_init__(self) -> None:
        if type(self.accepted) is not bool:
            raise ValueError("accepted must be a bool")
        if not isinstance(self.code, DecisionCode):
            raise ValueError("code must be a DecisionCode")
        if self.accepted != (self.code is DecisionCode.ACCEPTED):
            raise ValueError("accepted must match the decision code")

    def __bool__(self) -> bool:
        return self.accepted


@dataclass(frozen=True)
class JointSpec:
    name: str
    motor_id: int
    mapping: JointMap
    q_min_rad: float
    q_max_rad: float
    v_max_rad_s: float
    a_max_rad_s2: float
    max_lead_rad: float
    max_effort_nm: float
    limits_provenance: str

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if not isinstance(self.mapping, JointMap):
            raise ValueError("mapping must be a JointMap")

        if isinstance(self.q_min_rad, bool) or not isinstance(self.q_min_rad, (int, float)):
            raise ValueError("q_min_rad must be a finite real number")
        if isinstance(self.q_max_rad, bool) or not isinstance(self.q_max_rad, (int, float)):
            raise ValueError("q_max_rad must be a finite real number")
        try:
            min_val = float(self.q_min_rad)
            max_val = float(self.q_max_rad)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("position limits must be finite") from exc
        if not math.isfinite(min_val) or not math.isfinite(max_val):
            raise ValueError("position limits must be finite")
        if min_val > max_val:
            raise ValueError("q_min_rad must be less than or equal to q_max_rad")

        if isinstance(self.v_max_rad_s, bool) or not isinstance(self.v_max_rad_s, (int, float)):
            raise ValueError("v_max_rad_s must be a finite positive real number")
        try:
            v_max_val = float(self.v_max_rad_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("speed limit must be finite") from exc
        if not math.isfinite(v_max_val) or v_max_val <= 0.0:
            raise ValueError("v_max_rad_s must be finite and positive")

        if isinstance(self.a_max_rad_s2, bool) or not isinstance(self.a_max_rad_s2, (int, float)):
            raise ValueError("a_max_rad_s2 must be a finite positive real number")
        try:
            a_max_val = float(self.a_max_rad_s2)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("acceleration limit must be finite") from exc
        if not math.isfinite(a_max_val) or a_max_val <= 0.0:
            raise ValueError("a_max_rad_s2 must be finite and positive")

        if isinstance(self.max_lead_rad, bool) or not isinstance(self.max_lead_rad, (int, float)):
            raise ValueError("max_lead_rad must be a finite positive real number")
        try:
            max_lead_val = float(self.max_lead_rad)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_lead_rad must be finite") from exc
        if not math.isfinite(max_lead_val) or max_lead_val <= 0.0:
            raise ValueError("max_lead_rad must be finite and positive")

        if isinstance(self.max_effort_nm, bool) or not isinstance(self.max_effort_nm, (int, float)):
            raise ValueError("max_effort_nm must be a finite positive real number")
        try:
            max_effort_val = float(self.max_effort_nm)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_effort_nm must be finite") from exc
        if not math.isfinite(max_effort_val) or max_effort_val <= 0.0:
            raise ValueError("max_effort_nm must be finite and positive")

        if (
            type(self.limits_provenance) is not str
            or not self.limits_provenance.strip()
            or len(self.limits_provenance) > 256
        ):
            raise ValueError("limits_provenance must be a bounded non-empty string")

        object.__setattr__(self, "q_min_rad", min_val)
        object.__setattr__(self, "q_max_rad", max_val)
        object.__setattr__(self, "v_max_rad_s", v_max_val)
        object.__setattr__(self, "a_max_rad_s2", a_max_val)
        object.__setattr__(self, "max_lead_rad", max_lead_val)
        object.__setattr__(self, "max_effort_nm", max_effort_val)

    @property
    def peak_effort_nm(self) -> float:
        return self.max_effort_nm

    @property
    def tau_max_nm(self) -> float:
        return self.max_effort_nm


@dataclass(frozen=True)
class JointFault:
    name: str
    motor_id: int
    errors: int = 0
    warnings: int = 0
    timeout: bool = False
    communication_error: CommunicationFailure | None = None
    stale: bool = False
    communication_errors: tuple[CommunicationFailure, ...] = ()
    position_limit: bool = False
    speed_limit: bool = False
    effort_limit: bool = False
    constraint_fault: bool = False

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if type(self.stale) is not bool:
            raise ValueError("stale must be a bool")
        if type(self.communication_errors) is not tuple or any(
            not isinstance(c, CommunicationFailure) for c in self.communication_errors
        ):
            raise ValueError("communication_errors must be a tuple of CommunicationFailure")
        if type(self.position_limit) is not bool:
            raise ValueError("position_limit must be a bool")
        if type(self.speed_limit) is not bool:
            raise ValueError("speed_limit must be a bool")
        if type(self.effort_limit) is not bool:
            raise ValueError("effort_limit must be a bool")
        if type(self.constraint_fault) is not bool:
            raise ValueError("constraint_fault must be a bool")

        if len(self.communication_errors) != len(set(self.communication_errors)):
            raise ValueError("communication_errors must contain unique codes")
        if self.communication_error is not None and self.communication_errors and (
            self.communication_error not in self.communication_errors
        ):
            raise ValueError("communication_error must belong to communication_errors")

        if self.communication_error is not None and not self.communication_errors:
            object.__setattr__(self, "communication_errors", (self.communication_error,))
        elif self.communication_errors and self.communication_error is None:
            object.__setattr__(self, "communication_error", self.communication_errors[-1])


@dataclass(frozen=True)
class MotorHealth:
    mode: int
    errors: int
    warnings: int
    timeout: bool

    def __post_init__(self) -> None:
        if type(self.mode) is not int or self.mode not in (0, 1):
            raise ValueError("mode must be the integer 0 or 1")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")

    @property
    def healthy(self) -> bool:
        return self.errors == 0 and self.warnings == 0 and not self.timeout


@dataclass(frozen=True)
class SourceIdentity:
    backend: Literal["physical", "demo", "fixture"]
    identity: str
    connection: int

    def __post_init__(self) -> None:
        if type(self.backend) is not str or self.backend not in ("physical", "demo", "fixture"):
            raise ValueError("backend must be physical, demo, or fixture")
        if type(self.identity) is not str or not self.identity.strip():
            raise ValueError("identity must be a non-empty string")
        if type(self.connection) is not int or self.connection < 0:
            raise ValueError("connection must be a nonnegative integer")


@dataclass(frozen=True)
class JointStatus:
    sample: JointSample | None = None
    health: MotorHealth | None = None
    received_at: float | None = None
    communication_error: CommunicationFailure | None = None

    def __post_init__(self) -> None:
        if (self.sample is None) != (self.health is None):
            raise ValueError("sample and health must both be present or both be absent")
        if self.sample is not None and not isinstance(self.sample, JointSample):
            raise ValueError("sample must be a JointSample")
        if self.health is not None and not isinstance(self.health, MotorHealth):
            raise ValueError("health must be MotorHealth")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if self.valid and self.received_at is None:
            raise ValueError("a valid observation requires received_at")
        if self.received_at is not None:
            if isinstance(self.received_at, bool) or not isinstance(self.received_at, (int, float)):
                raise ValueError("received_at must be a finite real number or None")
            try:
                received_at = float(self.received_at)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("received_at must be finite") from exc
            if not math.isfinite(received_at):
                raise ValueError("received_at must be finite")
            if not self.valid:
                raise ValueError("received_at requires a valid observation")
            object.__setattr__(self, "received_at", received_at)

    @property
    def valid(self) -> bool:
        return self.sample is not None and self.health is not None

    @property
    def healthy(self) -> bool:
        return self.valid and self.health.healthy and self.communication_error is None

    @property
    def errors(self) -> int:
        return self.health.errors if self.health is not None else 0

    @property
    def warnings(self) -> int:
        return self.health.warnings if self.health is not None else 0

    @property
    def timeout(self) -> bool:
        return self.health.timeout if self.health is not None else False


@dataclass(frozen=True)
class OwnerToken:
    epoch: str
    generation: int
    connection_id: str

    def __post_init__(self) -> None:
        if type(self.epoch) is not str or not self.epoch.strip() or len(self.epoch) > 64:
            raise ValueError("epoch must be a bounded non-empty string")
        if type(self.generation) is not int or not (1 <= self.generation <= (1 << 64) - 1):
            raise ValueError("generation must be an integer from 1 to 2**64 - 1")
        if type(self.connection_id) is not str or not self.connection_id.strip() or len(self.connection_id) > 64:
            raise ValueError("connection_id must be a bounded non-empty string")


def owner_tokens_match(candidate: object, current: object) -> bool:
    return (
        type(candidate) is OwnerToken
        and type(current) is OwnerToken
        and candidate.epoch == current.epoch
        and candidate.generation == current.generation
        and candidate.connection_id == current.connection_id
    )


@dataclass(frozen=True)
class IntentWindow:
    id: int
    created_at_s: float
    expires_at_s: float

    def __post_init__(self) -> None:
        if type(self.id) is not int or not (0 <= self.id <= (1 << 64) - 1):
            raise ValueError("window ID must be an integer from 0 to 2**64 - 1")
        if isinstance(self.created_at_s, bool) or not isinstance(self.created_at_s, (int, float)):
            raise ValueError("created_at_s must be a finite real number")
        if isinstance(self.expires_at_s, bool) or not isinstance(self.expires_at_s, (int, float)):
            raise ValueError("expires_at_s must be a finite real number")
        try:
            created = float(self.created_at_s)
            expires = float(self.expires_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("window timestamps must be finite") from exc
        if not math.isfinite(created) or not math.isfinite(expires):
            raise ValueError("window timestamps must be finite")
        if expires <= created:
            raise ValueError("expires_at_s must be strictly greater than created_at_s")
        object.__setattr__(self, "created_at_s", created)
        object.__setattr__(self, "expires_at_s", expires)


@dataclass(frozen=True)
class Target:
    sequence: int
    joints: tuple[JointTarget, ...]
    window: IntentWindow
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if type(self.joints) is not tuple:
            raise ValueError("joints must be a tuple of JointTarget")
        if not self.joints:
            raise ValueError("joints must be a non-empty tuple")
        if any(not isinstance(joint, JointTarget) for joint in self.joints):
            raise ValueError("every joint target must be a JointTarget")
        if not isinstance(self.window, IntentWindow):
            raise ValueError("window must be an IntentWindow")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")


@dataclass(frozen=True)
class JointTrajectoryReference:
    q_rad: float
    position_step_velocity_rad_s: Fraction
    encoded_velocity_rad_s: float
    sample_time_s: float
    is_emitted: bool = False
    requested_goal: JointTarget | None = None
    emitted_target: JointTarget | None = None
    packet: bytes | None = None

    def __post_init__(self) -> None:
        for name, val in (("q_rad", self.q_rad),
                          ("encoded_velocity_rad_s", self.encoded_velocity_rad_s),
                          ("sample_time_s", self.sample_time_s)):
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                raise ValueError(f"{name} must be a finite real number")
            try:
                v = float(val)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError(f"{name} must be finite") from exc
            if not math.isfinite(v):
                raise ValueError(f"{name} must be finite")
            object.__setattr__(self, name, v)

        derivative = self.position_step_velocity_rad_s
        if isinstance(derivative, bool) or not isinstance(derivative, (int, float, Fraction)):
            raise ValueError("position_step_velocity_rad_s must be an exact finite rational")
        if isinstance(derivative, Fraction):
            exact_derivative = derivative
        else:
            try:
                as_float = float(derivative)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("position_step_velocity_rad_s must be finite") from exc
            if not math.isfinite(as_float):
                raise ValueError("position_step_velocity_rad_s must be finite")
            exact_derivative = Fraction(as_float)
        object.__setattr__(self, "position_step_velocity_rad_s", exact_derivative)

        if type(self.is_emitted) is not bool:
            raise ValueError("is_emitted must be a bool")
        if self.is_emitted:
            if not isinstance(self.requested_goal, JointTarget):
                raise ValueError("an emitted reference requires its requested goal")
            if not isinstance(self.emitted_target, JointTarget):
                raise ValueError("an emitted reference requires its decoded target")
            if type(self.packet) is not bytes:
                raise ValueError("an emitted reference requires immutable packet bytes")
            try:
                decoded = decode_command(self.packet)
            except ValueError as exc:
                raise ValueError("an emitted reference requires a canonical command") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("an emitted reference requires a watchdog-enabled FOC command")
            if self.q_rad != self.emitted_target.q_rad:
                raise ValueError("reference position must match its decoded target")
            if self.encoded_velocity_rad_s != self.emitted_target.dq_rad_s:
                raise ValueError("encoded velocity must match its decoded target")
        else:
            if (
                self.requested_goal is not None
                or self.emitted_target is not None
                or self.packet is not None
            ):
                raise ValueError("an unemitted Stop anchor cannot contain an emitted command")
            if exact_derivative != 0 or self.encoded_velocity_rad_s != 0.0:
                raise ValueError("an unemitted Stop anchor must have zero velocity history")


@dataclass(frozen=True)
class RefreshPlan:
    plan_id: int
    target: Target
    prepared_at_s: float
    joint_targets: tuple[JointTarget, ...]
    packets: tuple[bytes, ...]
    proposed_references: tuple[JointTrajectoryReference, ...]

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, Target):
            raise ValueError("target must be a Target")
        if isinstance(self.prepared_at_s, bool) or not isinstance(self.prepared_at_s, (int, float)):
            raise ValueError("prepared_at_s must be a finite real number")
        try:
            prepared = float(self.prepared_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("prepared_at_s must be finite") from exc
        if not math.isfinite(prepared):
            raise ValueError("prepared_at_s must be finite")
        object.__setattr__(self, "prepared_at_s", prepared)
        if type(self.joint_targets) is not tuple or not self.joint_targets:
            raise ValueError("joint_targets must be a non-empty tuple")
        if any(not isinstance(jt, JointTarget) for jt in self.joint_targets):
            raise ValueError("every joint target must be a JointTarget")
        if len(self.target.joints) != len(self.joint_targets):
            raise ValueError("joint_targets must match the complete target vector")
        if type(self.packets) is not tuple or len(self.packets) != len(self.joint_targets):
            raise ValueError("packets must be a tuple matching joint_targets")
        for packet in self.packets:
            if type(packet) is not bytes:
                raise ValueError("packets must contain immutable bytes")
            try:
                decoded = decode_command(packet)
            except ValueError as exc:
                raise ValueError("packets must contain canonical commands") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("refresh packets must be watchdog-enabled FOC commands")
        if (
            type(self.proposed_references) is not tuple
            or len(self.proposed_references) != len(self.joint_targets)
        ):
            raise ValueError("proposed_references must match joint_targets length")
        for goal, target, packet, reference in zip(
            self.target.joints,
            self.joint_targets,
            self.packets,
            self.proposed_references,
        ):
            if not isinstance(reference, JointTrajectoryReference) or not reference.is_emitted:
                raise ValueError("every plan requires a complete emitted reference")
            if reference.requested_goal != goal:
                raise ValueError("reference goal must match the admitted joint goal")
            if reference.emitted_target != target or reference.packet != packet:
                raise ValueError("reference target and packet must match the prepared command")
            if reference.sample_time_s > prepared:
                raise ValueError("reference sample time cannot follow plan preparation")

    @property
    def window(self) -> IntentWindow:
        return self.target.window

    @property
    def owner(self) -> OwnerToken:
        return self.target.owner


@dataclass(frozen=True)
class JointDispatchedRecord:
    sequence: int
    target: JointTarget
    dispatched_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.dispatched_at_s, bool) or not isinstance(self.dispatched_at_s, (int, float)):
            raise ValueError("dispatched_at_s must be a finite real number")
        try:
            dispatched = float(self.dispatched_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("dispatched_at_s must be finite") from exc
        if not math.isfinite(dispatched):
            raise ValueError("dispatched_at_s must be finite")
        object.__setattr__(self, "dispatched_at_s", dispatched)


@dataclass(frozen=True)
class JointDispatchAttempt:
    plan_id: int
    sequence: int
    target: JointTarget
    result: WriteResult
    started_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if not isinstance(self.result, WriteResult):
            raise ValueError("result must be a WriteResult")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.started_at_s, bool) or not isinstance(self.started_at_s, (int, float)):
            raise ValueError("started_at_s must be a finite real number")
        try:
            started = float(self.started_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("started_at_s must be finite") from exc
        if not math.isfinite(started):
            raise ValueError("started_at_s must be finite")
        object.__setattr__(self, "started_at_s", started)


@dataclass(frozen=True)
class Snapshot:
    state: State
    joint_names: tuple[str, ...]
    joints: tuple[JointStatus, ...]
    source: SourceIdentity | None
    fault_latched: bool
    feedback_ages_s: tuple[float | None, ...]
    faults: tuple[JointFault, ...] = ()
    admitted_target: Target | None = None
    prepared_plan: RefreshPlan | None = None
    dispatched_records: tuple[JointDispatchedRecord | None, ...] = ()
    last_sequence: int = -1
    dispatch_attempts: tuple[JointDispatchAttempt | None, ...] = ()
    latest_owner: OwnerToken | None = None
    current_owner: OwnerToken | None = None
    confirmed_references: tuple[JointTrajectoryReference | None, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.state, State):
            raise ValueError("state must be a State")
        if type(self.joint_names) is not tuple or any(type(name) is not str for name in self.joint_names):
            raise ValueError("joint_names must be a tuple of strings")
        if type(self.joints) is not tuple or any(not isinstance(joint, JointStatus) for joint in self.joints):
            raise ValueError("joints must be a tuple of JointStatus")
        if type(self.feedback_ages_s) is not tuple:
            raise ValueError("feedback_ages_s must be a tuple")
        if len(self.joint_names) != len(self.joints):
            raise ValueError("joint names and statuses must have equal lengths")
        if len(self.feedback_ages_s) != len(self.joints):
            raise ValueError("feedback ages and joint statuses must have equal lengths")
        normalized_ages: list[float | None] = []
        for joint, age in zip(self.joints, self.feedback_ages_s):
            if joint.received_at is None:
                if age is not None:
                    raise ValueError("feedback age must be None before a joint is received")
                normalized_ages.append(None)
                continue
            if isinstance(age, bool) or not isinstance(age, (int, float)):
                raise ValueError("feedback age must be a finite nonnegative number")
            try:
                age_value = float(age)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("feedback age must be finite") from exc
            if not math.isfinite(age_value) or age_value < 0.0:
                raise ValueError("feedback age must be finite and nonnegative")
            normalized_ages.append(age_value)
        object.__setattr__(self, "feedback_ages_s", tuple(normalized_ages))
        if self.source is not None and not isinstance(self.source, SourceIdentity):
            raise ValueError("source must be a SourceIdentity or None")
        if type(self.fault_latched) is not bool:
            raise ValueError("fault_latched must be a bool")
        if type(self.faults) is not tuple or any(not isinstance(f, JointFault) for f in self.faults):
            raise ValueError("faults must be a tuple of JointFault")
        if self.admitted_target is not None and not isinstance(self.admitted_target, Target):
            raise ValueError("admitted_target must be a Target or None")
        if self.prepared_plan is not None and not isinstance(self.prepared_plan, RefreshPlan):
            raise ValueError("prepared_plan must be a RefreshPlan or None")
        if not self.dispatched_records:
            object.__setattr__(self, "dispatched_records", tuple(None for _ in self.joints))
        else:
            if type(self.dispatched_records) is not tuple or len(self.dispatched_records) != len(self.joints):
                raise ValueError("dispatched_records must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchedRecord) for r in self.dispatched_records):
                raise ValueError("every dispatched record must be a JointDispatchedRecord or None")
        if not self.dispatch_attempts:
            object.__setattr__(self, "dispatch_attempts", tuple(None for _ in self.joints))
        else:
            if type(self.dispatch_attempts) is not tuple or len(self.dispatch_attempts) != len(self.joints):
                raise ValueError("dispatch_attempts must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchAttempt) for r in self.dispatch_attempts):
                raise ValueError("every dispatch attempt must be a JointDispatchAttempt or None")
        if type(self.last_sequence) is not int or not (-1 <= self.last_sequence <= (1 << 64) - 1):
            raise ValueError("last_sequence must be an integer from -1 to 2**64 - 1")
        if self.latest_owner is not None and type(self.latest_owner) is not OwnerToken:
            raise ValueError("latest_owner must be an OwnerToken or None")
        if self.current_owner is not None and type(self.current_owner) is not OwnerToken:
            raise ValueError("current_owner must be an OwnerToken or None")
        if not self.confirmed_references:
            object.__setattr__(self, "confirmed_references", tuple(None for _ in self.joints))
        else:
            if type(self.confirmed_references) is not tuple or len(self.confirmed_references) != len(self.joints):
                raise ValueError("confirmed_references must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointTrajectoryReference) for r in self.confirmed_references):
                raise ValueError("every confirmed reference must be a JointTrajectoryReference or None")

    @property
    def affected_joints(self) -> tuple[str, ...]:
        return tuple(fault.name for fault in self.faults)

```

## Complete joint_controller.py
```
"""Transport-free lifecycle and health state for an ordered joint set.

All methods on a JointCore belong to one calling thread. The core owns no
transport and all externally visible records are immutable snapshots.
"""

from collections.abc import Iterable
from dataclasses import dataclass
import math
import secrets
import time

from joint_contract import (
    CommunicationFailure,
    Decision,
    DecisionCode,
    IntentWindow,
    JointDispatchAttempt,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    JointTrajectoryReference,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
    owner_tokens_match,
)
from joint_mapping import JointSample
from joint_reference import (
    prepare_complete_reference,
    validate_target_vector,
    verify_dispatch_claim,
)

__all__ = ("JointCore",)


@dataclass(frozen=True)
class _DispatchClaim:
    plan: RefreshPlan
    index: int
    started_at_s: float


class JointCore:
    """Thread-confined state machine for one fixed, ordered set of joints.

    The core public API assumes trusted station callers; C16 server binds its
    actual connection identity rather than trusting client-supplied JSON fields.
    No authentication claims are made beyond that boundary.
    """

    def __init__(
        self,
        joints: Iterable[JointSpec],
        *,
        max_reference_gap_s: float,
        feedback_max_age_s: float = 0.5,
        max_window_s: float = 1.0,
        clock=None,
    ):
        if isinstance(max_reference_gap_s, bool) or not isinstance(max_reference_gap_s, (int, float)):
            raise ValueError("max_reference_gap_s must be a finite positive real number")
        try:
            max_reference_gap_s = float(max_reference_gap_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_reference_gap_s must be finite") from exc
        if not math.isfinite(max_reference_gap_s) or max_reference_gap_s <= 0.0:
            raise ValueError("max_reference_gap_s must be finite and positive")

        if isinstance(feedback_max_age_s, bool) or not isinstance(feedback_max_age_s, (int, float)):
            raise ValueError("feedback_max_age_s must be a finite positive real number")
        try:
            feedback_max_age_s = float(feedback_max_age_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("feedback_max_age_s must be finite") from exc
        if not math.isfinite(feedback_max_age_s) or feedback_max_age_s <= 0.0:
            raise ValueError("feedback_max_age_s must be finite and positive")

        if isinstance(max_window_s, bool) or not isinstance(max_window_s, (int, float)):
            raise ValueError("max_window_s must be a finite positive real number")
        try:
            max_window_s = float(max_window_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_window_s must be finite") from exc
        if not math.isfinite(max_window_s) or max_window_s <= 0.0:
            raise ValueError("max_window_s must be finite and positive")

        if clock is None:
            clock = time.monotonic
        if not callable(clock):
            raise ValueError("clock must be callable")

        self._epoch = secrets.token_hex(16)

        try:
            specs = tuple(joints)
        except TypeError as exc:
            raise ValueError("joints must be an iterable of JointSpec") from exc
        if not specs:
            raise ValueError("at least one active joint is required")
        if any(not isinstance(spec, JointSpec) for spec in specs):
            raise ValueError("every joint must be a JointSpec")
        if len({spec.name for spec in specs}) != len(specs):
            raise ValueError("joint names must be unique")
        if len({spec.motor_id for spec in specs}) != len(specs):
            raise ValueError("motor IDs must be unique")

        self._specs: tuple[JointSpec, ...] = specs
        self._id_to_index: dict[int, int] = {
            spec.motor_id: index for index, spec in enumerate(specs)
        }
        self._state: State = State.DISCONNECTED
        self._observations: list[JointStatus] = [JointStatus() for _ in specs]
        self._source: SourceIdentity | None = None
        self._max_reference_gap_s = max_reference_gap_s
        self._feedback_max_age_s = feedback_max_age_s
        self._max_window_s = max_window_s
        self._clock = clock
        self._now_high_water_s: float | None = None
        self._next_window_id: int = 0
        self._offered_window: IntentWindow | None = None
        self._next_generation: int = 1
        self._latest_owner: OwnerToken | None = None
        self._current_owner: OwnerToken | None = None
        self._admitted_target: Target | None = None
        self._prepared_plan: RefreshPlan | None = None
        self._next_plan_id: int = 0
        self._next_dispatch_index: int = 0
        self._dispatch_claim: _DispatchClaim | None = None
        self._dispatched_records: list[JointDispatchedRecord | None] = [None for _ in specs]
        self._dispatch_attempts: list[JointDispatchAttempt | None] = [None for _ in specs]
        self._confirmed_references: list[JointTrajectoryReference | None] = [None for _ in specs]
        self._faults: dict[str, JointFault] = {}
        self._last_sequence: int = -1

    @property
    def max_reference_gap_s(self) -> float:
        return self._max_reference_gap_s

    @property
    def joint_specs(self) -> tuple[JointSpec, ...]:
        return self._specs

    @property
    def admitted_target(self) -> Target | None:
        return self._admitted_target

    @staticmethod
    def _accepted() -> Decision:
        return Decision(True, DecisionCode.ACCEPTED)

    @staticmethod
    def _rejected(code: DecisionCode) -> Decision:
        return Decision(False, code)

    def _clear_observations(self) -> None:
        self._observations = [JointStatus() for _ in self._specs]

    def _invalidate_plan(self) -> None:
        self._prepared_plan = None
        self._next_dispatch_index = 0

    def _revoke_authority(self) -> None:
        self._current_owner = None
        self._offered_window = None
        self._admitted_target = None
        self._invalidate_plan()

    def claim_owner(self, connection_id: str) -> OwnerToken:
        """Issue and claim owner authority for a trusted station caller.

        The core public API assumes trusted station callers; C16 server binds its
        actual connection identity rather than trusting client-supplied JSON fields.
        No authentication claims are made beyond that boundary.
        """
        if (
            type(connection_id) is not str
            or not connection_id.strip()
            or len(connection_id) > 64
        ):
            raise ValueError("connection_id must be a bounded non-empty string")
        was_owned = self._current_owner is not None
        stop_for_claim = self._state in (
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
        ) or (was_owned and self._state not in (State.DISCONNECTED, State.CONNECTING))
        self._revoke_authority()
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            pass
        elif self._state is State.FAULT or self._faults:
            self._state = State.FAULT
        elif stop_for_claim:
            self._state = State.STOPPED

        if self._next_generation > (1 << 64) - 1:
            raise OverflowError("owner generation sequence exhausted")

        generation = self._next_generation
        self._next_generation += 1
        token = OwnerToken(
            epoch=self._epoch,
            generation=generation,
            connection_id=connection_id,
        )
        self._current_owner = token
        self._latest_owner = token
        return token

    def _record_dispatch_failure(
        self, index: int, cause: CommunicationFailure
    ) -> None:
        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            spec.motor_id,
            communication_error=cause,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample,
            joint.health,
            joint.received_at,
            cause,
        )

    def _latch_joint_fault(
        self,
        name: str,
        motor_id: int,
        *,
        errors: int = 0,
        warnings: int = 0,
        timeout: bool = False,
        communication_error: CommunicationFailure | None = None,
        stale: bool = False,
        position_limit: bool = False,
        speed_limit: bool = False,
        effort_limit: bool = False,
        constraint_fault: bool = False,
    ) -> None:
        existing = self._faults.get(name) or JointFault(name, motor_id)
        communication_errors = existing.communication_errors
        if communication_error is not None and communication_error not in communication_errors:
            communication_errors += (communication_error,)
        fault = JointFault(
            name, motor_id,
            errors=existing.errors | errors,
            warnings=existing.warnings | warnings,
            timeout=existing.timeout or timeout,
            stale=existing.stale or stale,
            communication_error=communication_error or existing.communication_error,
            communication_errors=communication_errors,
            position_limit=existing.position_limit or position_limit,
            speed_limit=existing.speed_limit or speed_limit,
            effort_limit=existing.effort_limit or effort_limit,
            constraint_fault=existing.constraint_fault or constraint_fault,
        )
        self._faults[name] = fault
        if self._state is not State.DISCONNECTED:
            self._state = State.FAULT
        self._revoke_authority()

    def _withdraw_expired_goal(self) -> None:
        self._revoke_authority()
        if self._faults:
            self._state = State.FAULT
        elif self._state in (State.ARMED, State.MOVING):
            self._state = State.STOPPED

    def _now(self) -> float:
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("clock must return a finite real number")
        try:
            result = float(value)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("clock must return a finite real number") from exc
        if not math.isfinite(result):
            raise ValueError("clock must return a finite real number")
        if self._now_high_water_s is not None and result < self._now_high_water_s:
            raise ValueError(
                f"clock regressed from {self._now_high_water_s} to {result}"
            )
        self._now_high_water_s = result
        return result

    @staticmethod
    def _age(received_at: float, now: float) -> float:
        age = now - received_at
        if not math.isfinite(age) or age < 0.0:
            raise ValueError("clock must be monotonic and feedback age finite")
        return age

    def _all_fresh(self, now: float) -> bool:
        return all(
            joint.valid
            and joint.received_at is not None
            and self._age(joint.received_at, now) <= self._feedback_max_age_s
            for joint in self._observations
        )

    def _housekeeping(self, now: float) -> DecisionCode | None:
        if self._state in (State.READY, State.ARMED, State.MOVING):
            stale_by_joint: list[bool] = []
            pos_outside_by_joint: list[bool] = []
            speed_outside_by_joint: list[bool] = []
            effort_outside_by_joint: list[bool] = []
            for spec, joint in zip(self._specs, self._observations):
                stale_by_joint.append(
                    not joint.valid
                    or joint.received_at is None
                    or self._age(joint.received_at, now) > self._feedback_max_age_s
                )
                pos_outside_by_joint.append(
                    joint.valid
                    and joint.sample is not None
                    and (joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad)
                )
                speed_outside_by_joint.append(
                    joint.valid
                    and joint.sample is not None
                    and (abs(joint.sample.dq_rad_s) > spec.v_max_rad_s)
                )
                effort_outside_by_joint.append(
                    joint.valid
                    and joint.sample is not None
                    and (abs(joint.sample.tau_nm) > spec.max_effort_nm)
                )
            for spec, stale, pos_out, speed_out, effort_out in zip(
                self._specs, stale_by_joint, pos_outside_by_joint, speed_outside_by_joint, effort_outside_by_joint
            ):
                if stale or pos_out or speed_out or effort_out:
                    self._latch_joint_fault(
                        spec.name,
                        spec.motor_id,
                        stale=stale,
                        position_limit=pos_out,
                        speed_limit=speed_out,
                        effort_limit=effort_out,
                    )
            if any(stale_by_joint):
                return DecisionCode.STALE_FEEDBACK
            if any(pos_outside_by_joint):
                return DecisionCode.POSITION_OUT_OF_BOUNDS
            if any(speed_outside_by_joint):
                return DecisionCode.SPEED_OUT_OF_BOUNDS
            if any(effort_outside_by_joint):
                return DecisionCode.EFFORT_OUT_OF_BOUNDS
        if (
            self._admitted_target is not None
            and now >= self._admitted_target.window.expires_at_s
        ):
            self._withdraw_expired_goal()
            return DecisionCode.EXPIRED
        return None

    def issue_window(self, valid_for_s: float) -> IntentWindow:
        if isinstance(valid_for_s, bool) or not isinstance(valid_for_s, (int, float)):
            raise ValueError("valid_for_s must be a finite positive real number")
        try:
            valid_for_s = float(valid_for_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("valid_for_s must be finite") from exc
        if not math.isfinite(valid_for_s) or valid_for_s <= 0.0:
            raise ValueError("valid_for_s must be finite and positive")
        if valid_for_s > self._max_window_s:
            raise ValueError(
                f"valid_for_s ({valid_for_s}) exceeds configured maximum window ({self._max_window_s})"
            )
        now = self._now()
        window_id = self._next_window_id
        if window_id > (1 << 64) - 1:
            raise OverflowError("window ID sequence exhausted")
        self._next_window_id += 1
        window = IntentWindow(
            id=window_id,
            created_at_s=now,
            expires_at_s=now + valid_for_s,
        )
        self._offered_window = window
        return window

    def begin_connect(self) -> Decision:
        if self._state is not State.DISCONNECTED or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        self._state = State.CONNECTING
        return self._accepted()

    def connected(self, source: SourceIdentity) -> Decision:
        if self._state is not State.CONNECTING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not isinstance(source, SourceIdentity):
            return self._rejected(DecisionCode.INVALID_SOURCE)
        self._clear_observations()
        self._source = source
        self._state = State.CONNECTED
        return self._accepted()

    def begin_check(self, *, acknowledge_fault: bool = False) -> Decision:
        if type(acknowledge_fault) is not bool:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._state not in (State.CONNECTED, State.STOPPED, State.FAULT) or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        if bool(self._faults) and not acknowledge_fault:
            return self._rejected(DecisionCode.FAULT_ACK_REQUIRED)
        self._clear_observations()
        self._admitted_target = None
        self._confirmed_references = [None for _ in self._specs]
        self._invalidate_plan()
        self._state = State.CHECKING
        return self._accepted()

    def receive(
        self, motor_id: int, sample: JointSample, status: MotorHealth
    ) -> Decision:
        if self._state not in (
            State.CONNECTED,
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
            State.STOPPED,
            State.FAULT,
        ):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)
        if not isinstance(sample, JointSample) or not isinstance(status, MotorHealth):
            return self._rejected(DecisionCode.INVALID_OBSERVATION)

        now = self._now()
        self._observations[index] = JointStatus(sample, status, now)
        spec = self._specs[index]
        position_limit = (
            sample.q_rad < spec.q_min_rad or sample.q_rad > spec.q_max_rad
        )
        speed_limit = (
            abs(sample.dq_rad_s) > spec.v_max_rad_s
        )
        effort_limit = (
            abs(sample.tau_nm) > spec.max_effort_nm
        )
        if not status.healthy or position_limit or speed_limit or effort_limit:
            self._latch_joint_fault(
                spec.name,
                motor_id,
                errors=status.errors,
                warnings=status.warnings,
                timeout=status.timeout,
                position_limit=position_limit,
                speed_limit=speed_limit,
                effort_limit=effort_limit,
            )
        if position_limit:
            return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
        if speed_limit:
            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
        if effort_limit:
            return self._rejected(DecisionCode.EFFORT_OUT_OF_BOUNDS)
        return self._accepted()

    def communication_failed(
        self, motor_id: int, code: CommunicationFailure
    ) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)

        if not isinstance(code, CommunicationFailure):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        failure_code = code

        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            motor_id,
            communication_error=failure_code,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample, joint.health, joint.received_at, failure_code
        )
        return self._accepted()

    def checked(self) -> Decision:
        if self._state is not State.CHECKING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        pos_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
        ]
        speed_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
        ]
        effort_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if abs(joint.sample.tau_nm) > spec.max_effort_nm
        ]
        if pos_out_of_bounds or speed_out_of_bounds or effort_out_of_bounds:
            for spec in pos_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            for spec in speed_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            for spec in effort_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, effort_limit=True)
            if pos_out_of_bounds:
                return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
            if speed_out_of_bounds:
                return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
            return self._rejected(DecisionCode.EFFORT_OUT_OF_BOUNDS)

        self._state = State.READY
        self._faults.clear()
        self._confirmed_references = [
            JointTrajectoryReference(
                q_rad=joint.sample.q_rad,
                position_step_velocity_rad_s=0.0,
                encoded_velocity_rad_s=0.0,
                sample_time_s=joint.received_at,
                is_emitted=False,
            )
            for joint in self._observations
        ]
        return self._accepted()

    def arm(self, owner: OwnerToken) -> Decision:
        if self._state is not State.READY:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not owner_tokens_match(owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)
        if bool(self._faults):
            return self._rejected(DecisionCode.FAULT_LATCHED)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        pos_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
        ]
        speed_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
        ]
        effort_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if abs(joint.sample.tau_nm) > spec.max_effort_nm
        ]
        if pos_out_of_bounds or speed_out_of_bounds or effort_out_of_bounds:
            for spec in pos_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            for spec in speed_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            for spec in effort_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, effort_limit=True)
            if pos_out_of_bounds:
                return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
            if speed_out_of_bounds:
                return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
            return self._rejected(DecisionCode.EFFORT_OUT_OF_BOUNDS)

        self._state = State.ARMED
        return self._accepted()

    def tick(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        self._housekeeping(now)
        return self._accepted()

    def submit_target(self, target: Target) -> Decision:
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        housekeeping = self._housekeeping(now)
        if housekeeping is not None:
            return self._rejected(housekeeping)
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)

        if not isinstance(target, Target) or len(target.joints) != len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        if not owner_tokens_match(target.owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)

        if not isinstance(target.window, IntentWindow):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._offered_window is None:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if target.window.id < self._offered_window.id:
            return self._rejected(DecisionCode.EXPIRED)
        if target.window.id != self._offered_window.id:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if (
            target.window.created_at_s != self._offered_window.created_at_s
            or target.window.expires_at_s != self._offered_window.expires_at_s
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if now >= target.window.expires_at_s:
            return self._rejected(DecisionCode.EXPIRED)

        if not self._all_fresh(now) or any(
            not joint.valid for joint in self._observations
        ):
            return self._rejected(DecisionCode.STALE_FEEDBACK)

        validation_failures = validate_target_vector(
            self._specs,
            target,
            tuple(joint.sample for joint in self._observations),
        )
        if validation_failures:
            return self._rejected(validation_failures[0].code)

        if target.sequence <= self._last_sequence:
            return self._rejected(DecisionCode.DUPLICATE_OR_OLDER)

        self._admitted_target = target
        self._last_sequence = target.sequence
        self._invalidate_plan()
        return self._accepted()

    def prepare_refresh(self) -> RefreshPlan | None:
        if self._dispatch_claim is not None:
            return None
        if self._state not in (State.ARMED, State.MOVING):
            return None
        if self._state is State.FAULT or bool(self._faults):
            return None
        try:
            now = self._now()
        except ValueError:
            self.stop()
            raise
        if self._housekeeping(now) is not None:
            return None
        if any(not joint.healthy for joint in self._observations):
            return None
        if self._admitted_target is None:
            return None
        if not owner_tokens_match(self._admitted_target.owner, self._current_owner):
            return None

        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid:
                return None
            pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
            speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
            effort_out = abs(joint.sample.tau_nm) > spec.max_effort_nm
            if pos_out or speed_out or effort_out:
                self._latch_joint_fault(
                    spec.name,
                    spec.motor_id,
                    position_limit=pos_out,
                    speed_limit=speed_out,
                    effort_limit=effort_out,
                )
                self.stop()
                return None

        for spec, conf_ref in zip(self._specs, self._confirmed_references):
            if conf_ref is None:
                return None
            gap = now - conf_ref.sample_time_s
            if not math.isfinite(gap) or gap < 0.0:
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
                self.stop()
                return None
            if gap > self._max_reference_gap_s:
                self.stop()
                return None

        prepared = prepare_complete_reference(
            self._specs,
            self._admitted_target,
            tuple(self._confirmed_references),
            tuple(joint.sample for joint in self._observations),
            now,
            self._max_reference_gap_s,
        )
        if not prepared.ready:
            for failure in prepared.failures:
                if failure.joint_index is None:
                    continue
                spec = self._specs[failure.joint_index]
                if failure.code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, position_limit=True
                    )
                elif failure.code is DecisionCode.SPEED_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, speed_limit=True
                    )
                elif failure.code is DecisionCode.EFFORT_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, effort_limit=True
                    )
                else:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, constraint_fault=True
                    )
            self.stop()
            return None

        plan_id = self._next_plan_id
        if plan_id > (1 << 64) - 1:
            raise OverflowError("plan ID sequence exhausted")
        self._next_plan_id += 1

        plan = RefreshPlan(
            plan_id=plan_id,
            target=self._admitted_target,
            prepared_at_s=now,
            joint_targets=prepared.joint_targets,
            packets=prepared.packets,
            proposed_references=prepared.proposed_references,
        )
        self._prepared_plan = plan
        self._next_dispatch_index = 0
        return plan

    def claim_dispatch(self, plan_id: int, index: int) -> bool:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return False
        if self._dispatch_claim is not None:
            return False
        if self._prepared_plan is None or self._prepared_plan.plan_id != plan_id:
            return False
        if self._state not in (State.ARMED, State.MOVING):
            return False
        if self._state is State.FAULT or bool(self._faults):
            return False
        if index < 0 or index >= len(self._specs):
            return False
        if index != self._next_dispatch_index:
            return False

        try:
            now = self._now()
        except Exception:
            self.stop()
            raise
        if self._housekeeping(now) is not None:
            return False
        if self._admitted_target is None or self._prepared_plan is None:
            return False
        if not owner_tokens_match(self._prepared_plan.target.owner, self._current_owner):
            return False
        if any(not joint.healthy for joint in self._observations):
            return False

        if not self._all_fresh(now):
            return False
        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid:
                return False
            pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
            speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
            effort_out = abs(joint.sample.tau_nm) > spec.max_effort_nm
            if pos_out or speed_out or effort_out:
                self._latch_joint_fault(
                    spec.name,
                    spec.motor_id,
                    position_limit=pos_out,
                    speed_limit=speed_out,
                    effort_limit=effort_out,
                )
                self.stop()
                return False

        conf_ref = self._confirmed_references[index]
        if conf_ref is not None:
            gap = now - conf_ref.sample_time_s
            if not math.isfinite(gap) or gap < 0.0 or gap > self._max_reference_gap_s:
                self.stop()
                return False

        plan_joint = self._prepared_plan.joint_targets[index]
        spec = self._specs[index]
        prop_ref = self._prepared_plan.proposed_references[index]
        failure_code = verify_dispatch_claim(
            spec=spec,
            prop_ref=prop_ref,
            conf_ref=conf_ref,
            plan_joint=plan_joint,
            packet=self._prepared_plan.packets[index],
            goal=self._prepared_plan.target.joints[index],
            sample=self._observations[index].sample,
            prepared_at_s=self._prepared_plan.prepared_at_s,
        )
        if failure_code is not None:
            if failure_code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            elif failure_code is DecisionCode.SPEED_OUT_OF_BOUNDS:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            elif failure_code is DecisionCode.EFFORT_OUT_OF_BOUNDS:
                self._latch_joint_fault(spec.name, spec.motor_id, effort_limit=True)
            else:
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
            self.stop()
            return False

        self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
        return True

    def dispatch_result(
        self, plan_id: int, index: int, result: WriteResult
    ) -> Decision:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if not isinstance(result, WriteResult):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        claim = self._dispatch_claim
        if claim is None or claim.plan.plan_id != plan_id or claim.index != index:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if index < 0 or index >= len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        plan = claim.plan
        joint_target = plan.joint_targets[index]
        self._dispatch_attempts[index] = JointDispatchAttempt(
            plan_id=plan.plan_id,
            sequence=plan.target.sequence,
            target=joint_target,
            result=result,
            started_at_s=claim.started_at_s,
            owner=plan.target.owner,
        )
        if result is WriteResult.COMPLETE:
            record = JointDispatchedRecord(
                sequence=plan.target.sequence,
                target=joint_target,
                dispatched_at_s=claim.started_at_s,
                owner=plan.target.owner,
            )
            self._dispatched_records[index] = record
            self._confirmed_references[index] = plan.proposed_references[index]
            try:
                now = self._now()
            except Exception:
                self._record_dispatch_failure(index, CommunicationFailure.CLOCK_FAILURE)
                self._dispatch_claim = None
                return self._rejected(DecisionCode.FAULT_LATCHED)

            housekeeping = self._housekeeping(now)
            still_current = (
                self._prepared_plan is plan
                and self._admitted_target is plan.target
                and self._state in (State.ARMED, State.MOVING)
                and not self._faults
                and owner_tokens_match(self._current_owner, plan.target.owner)
            )
            if still_current and housekeeping is None:
                self._next_dispatch_index = index + 1
                self._state = State.MOVING
            self._dispatch_claim = None
            return self._accepted()

        cause = (
            CommunicationFailure.PREWRITE_DEADLINE
            if result is WriteResult.PREWRITE_DEADLINE
            else CommunicationFailure.DRIVER_FAILURE
        )
        self._record_dispatch_failure(index, cause)
        self._dispatch_claim = None
        return self._rejected(DecisionCode.FAULT_LATCHED)

    def stop(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        self._revoke_authority()
        if self._state is State.FAULT or bool(self._faults):
            self._state = State.FAULT
        else:
            self._state = State.STOPPED
        return self._accepted()

    def disconnect(self) -> Decision:
        self._state = State.DISCONNECTED
        self._source = None
        self._clear_observations()
        self._confirmed_references = [None for _ in self._specs]
        self._revoke_authority()
        return self._accepted()

    def snapshot(self) -> Snapshot:
        received = [joint.received_at for joint in self._observations]
        now = self._now() if any(value is not None for value in received) else None
        ages = tuple(
            None if value is None else self._age(value, now)
            for value in received
        )
        faults = tuple(self._faults[spec.name] for spec in self._specs
                       if spec.name in self._faults)
        return Snapshot(
            state=self._state,
            joint_names=tuple(spec.name for spec in self._specs),
            joints=tuple(self._observations),
            source=self._source,
            fault_latched=bool(self._faults),
            feedback_ages_s=ages,
            faults=faults,
            admitted_target=self._admitted_target,
            prepared_plan=self._prepared_plan,
            dispatched_records=tuple(self._dispatched_records),
            dispatch_attempts=tuple(self._dispatch_attempts),
            last_sequence=self._last_sequence,
            latest_owner=self._latest_owner,
            current_owner=self._current_owner,
            confirmed_references=tuple(self._confirmed_references),
        )

```

## Complete joint_reference.py
```
"""Pure joint reference validation and canonical packet preparation."""

from dataclasses import dataclass
from fractions import Fraction
import math
from im6014_codec import (
    command,
    command_with_raw_position,
    decode_command,
    project_position_raw,
    project_speed_raw,
    raw_to_position,
    raw_to_rpm,
)
from joint_contract import (
    DecisionCode,
    JointSpec,
    JointTrajectoryReference,
    Target,
)
from joint_mapping import JointMap, JointSample, JointTarget, OutputSample

__all__ = (
    "map_decoded_command",
    "predict_joint_effort",
    "prepare_reference_joint",
    "shape_reference_joint",
    "prepare_complete_reference",
    "validate_target_vector",
    "verify_dispatch_claim",
    "ReferenceFailure",
    "ReferenceBatchResult",
)


def map_decoded_command(mapping: JointMap, decoded: dict) -> JointTarget:
    """Map canonical decoded command fields back once into joint target units."""
    actual_output = mapping.from_output(
        OutputSample(decoded["position_rad"], decoded["rpm"], decoded["torque_nm"])
    )
    gain_scale = mapping.reduction ** 2
    return JointTarget(
        q_rad=actual_output.q_rad,
        dq_rad_s=actual_output.dq_rad_s,
        tau_nm=actual_output.tau_nm,
        kp=decoded["kp"] * gain_scale,
        kd=decoded["kd"] * gain_scale,
    )


def predict_joint_effort(target: JointTarget, sample: JointSample) -> float:
    """Predict combined joint effort: tau_ff + kp*(qref - qmeas) + kd*(dqref - dqmeas).

    All terms are evaluated together in joint units without separate per-term
    clipping. Finite overflow fails closed by raising ValueError.
    """
    if not isinstance(target, JointTarget) or not isinstance(sample, JointSample):
        raise ValueError("target and sample must be JointTarget and JointSample")
    for val in (
        target.tau_nm,
        target.kp,
        target.q_rad,
        target.kd,
        target.dq_rad_s,
        sample.q_rad,
        sample.dq_rad_s,
    ):
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            raise ValueError("effort predictor terms must be real numbers")
        try:
            num = float(val)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("effort predictor terms must be finite") from exc
        if not math.isfinite(num):
            raise ValueError("effort predictor terms must be finite")

    try:
        term_p = float(target.kp) * (float(target.q_rad) - float(sample.q_rad))
        term_d = float(target.kd) * (float(target.dq_rad_s) - float(sample.dq_rad_s))
        tau = float(target.tau_nm) + term_p + term_d
    except (ArithmeticError, OverflowError) as exc:
        raise ValueError("effort prediction overflowed") from exc

    if not math.isfinite(tau):
        raise ValueError("predicted effort is not finite")

    return tau


@dataclass(frozen=True)
class ReferenceFailure:
    code: DecisionCode
    joint_index: int | None

    def __post_init__(self) -> None:
        if not isinstance(self.code, DecisionCode):
            raise ValueError("reference failure code must be a DecisionCode")
        if self.joint_index is not None and (
            type(self.joint_index) is not int or self.joint_index < 0
        ):
            raise ValueError("joint_index must be a nonnegative integer or None")


@dataclass(frozen=True)
class ReferenceBatchResult:
    joint_targets: tuple[JointTarget, ...] | None
    packets: tuple[bytes, ...] | None
    proposed_references: tuple[JointTrajectoryReference, ...] | None
    failures: tuple[ReferenceFailure, ...]

    def __post_init__(self) -> None:
        if type(self.failures) is not tuple or any(
            not isinstance(failure, ReferenceFailure) for failure in self.failures
        ):
            raise ValueError("failures must be a tuple of ReferenceFailure")
        if self.failures:
            if any(
                value is not None
                for value in (self.joint_targets, self.packets, self.proposed_references)
            ):
                raise ValueError("a failed batch cannot expose a partial plan")
            indices = [failure.joint_index for failure in self.failures]
            if len(indices) != len(set(indices)):
                raise ValueError("a batch can report at most one failure per joint")
            return

        if (
            type(self.joint_targets) is not tuple
            or type(self.packets) is not tuple
            or type(self.proposed_references) is not tuple
            or not self.joint_targets
            or len(self.joint_targets) != len(self.packets)
            or len(self.joint_targets) != len(self.proposed_references)
        ):
            raise ValueError("a successful batch requires complete parallel tuples")
        if any(not isinstance(target, JointTarget) for target in self.joint_targets):
            raise ValueError("every batch target must be a JointTarget")
        if any(type(packet) is not bytes for packet in self.packets):
            raise ValueError("every batch packet must be immutable bytes")
        if any(not isinstance(ref, JointTrajectoryReference) for ref in self.proposed_references):
            raise ValueError("every batch reference must be a JointTrajectoryReference")

    @property
    def ready(self) -> bool:
        return not self.failures


def prepare_reference_joint(
    spec: JointSpec, target: JointTarget
) -> tuple[DecisionCode | None, JointTarget | None, bytes | None]:
    """Validate a request and bind its actual decoded command to canonical bytes."""
    if not isinstance(spec, JointSpec) or not isinstance(target, JointTarget):
        return DecisionCode.INVALID_ARGUMENT, None, None
    if target.q_rad < spec.q_min_rad or target.q_rad > spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
    if abs(target.dq_rad_s) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None

    try:
        output = spec.mapping.to_output(target)
        # Validate the original mapped request through the ordinary codec before
        # projecting its position onto an inward representable grid point.
        command(
            spec.motor_id,
            mode=1,
            rpm=output.rpm,
            kd=output.kd,
            torque=output.tau_nm,
            watchdog=True,
            position=output.q_rad,
            kp=output.kp,
        )
        raw_position = project_position_raw(
            target.q_rad,
            spec.q_min_rad,
            spec.q_max_rad,
            lambda output_q: spec.mapping.from_output(
                OutputSample(output_q, 0.0, 0.0)
            ).q_rad,
            spec.mapping.direction,
        )
        if raw_position is None:
            return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None

        raw_rpm = project_speed_raw(
            target.dq_rad_s,
            -spec.v_max_rad_s,
            spec.v_max_rad_s,
            lambda output_rpm: spec.mapping.from_output(
                OutputSample(0.0, output_rpm, 0.0)
            ).dq_rad_s,
            spec.mapping.direction,
        )
        if raw_rpm is None:
            return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.INVALID_ARGUMENT, None, None

    try:
        packet = command_with_raw_position(
            spec.motor_id,
            raw_position,
            mode=1,
            rpm=output.rpm,
            kd=output.kd,
            torque=output.tau_nm,
            watchdog=True,
            kp=output.kp,
            raw_rpm=raw_rpm,
        )
        decoded = decode_command(packet)
        actual_target = map_decoded_command(spec.mapping, decoded)
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.INVALID_ARGUMENT, None, None

    if not spec.q_min_rad <= actual_target.q_rad <= spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
    if abs(actual_target.dq_rad_s) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
    return None, actual_target, packet


def validate_target_vector(
    specs: tuple[JointSpec, ...],
    target: Target,
    samples: tuple[JointSample, ...],
) -> tuple[ReferenceFailure, ...]:
    """Validate every admitted joint request before replacing the current goal."""
    if (
        not isinstance(target, Target)
        or type(specs) is not tuple
        or type(samples) is not tuple
        or len(target.joints) != len(specs)
        or len(samples) != len(specs)
    ):
        return (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)

    failures: list[ReferenceFailure] = []
    for index, (spec, joint_target, sample) in enumerate(
        zip(specs, target.joints, samples)
    ):
        code, actual_target, _ = prepare_reference_joint(spec, joint_target)
        if code is not None or actual_target is None:
            failures.append(ReferenceFailure(code or DecisionCode.INVALID_ARGUMENT, index))
            continue
        if not isinstance(sample, JointSample):
            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
            continue
        valid_sample = True
        for val in (sample.q_rad, sample.dq_rad_s, sample.tau_nm):
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                valid_sample = False
                break
            try:
                num = float(val)
            except (OverflowError, TypeError, ValueError):
                valid_sample = False
                break
            if not math.isfinite(num):
                valid_sample = False
                break
        if not valid_sample:
            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
            continue

        q_meas_exact = Fraction(sample.q_rad)
        lead_exact = Fraction(spec.max_lead_rad)
        requested_q_exact = Fraction(joint_target.q_rad)
        if not (
            q_meas_exact - lead_exact
            <= requested_q_exact
            <= q_meas_exact + lead_exact
        ):
            failures.append(ReferenceFailure(DecisionCode.LEAD_OUT_OF_BOUNDS, index))
            continue

        try:
            pred_effort = predict_joint_effort(actual_target, sample)
            if abs(Fraction(pred_effort)) > Fraction(spec.max_effort_nm):
                failures.append(ReferenceFailure(DecisionCode.EFFORT_OUT_OF_BOUNDS, index))
                continue
        except (ArithmeticError, OverflowError, ValueError):
            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
            continue
    return tuple(failures)


def shape_reference_joint(
    spec: JointSpec,
    target: JointTarget,
    confirmed_ref: JointTrajectoryReference,
    sample: JointSample,
    now: float,
    max_reference_gap_s: float,
) -> tuple[
    DecisionCode | None,
    JointTarget | None,
    JointTrajectoryReference | None,
    bytes | None,
]:
    """Shape one discrete reference point and retain its exact emitted command."""
    if (
        not isinstance(spec, JointSpec)
        or not isinstance(target, JointTarget)
        or not isinstance(confirmed_ref, JointTrajectoryReference)
        or not isinstance(sample, JointSample)
    ):
        return DecisionCode.INVALID_ARGUMENT, None, None, None

    normalized: list[float] = []
    for val in (
        target.q_rad,
        target.dq_rad_s,
        target.tau_nm,
        target.kp,
        target.kd,
        sample.q_rad,
        sample.dq_rad_s,
        sample.tau_nm,
        now,
        max_reference_gap_s,
    ):
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        try:
            numeric = float(val)
        except (OverflowError, TypeError, ValueError):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        if not math.isfinite(numeric):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        normalized.append(numeric)
    (
        goal_q,
        goal_dq,
        goal_tau,
        goal_kp,
        goal_kd,
        q_meas_val,
        dq_meas_val,
        tau_meas_val,
        now,
        max_reference_gap_s,
    ) = normalized
    if max_reference_gap_s <= 0.0:
        return DecisionCode.INVALID_ARGUMENT, None, None, None

    if goal_q < spec.q_min_rad or goal_q > spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
    if abs(goal_dq) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None, None

    h = now - confirmed_ref.sample_time_s
    if not math.isfinite(h) or h < 0.0:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if h > max_reference_gap_s:
        return DecisionCode.REFERENCE_GAP_EXCEEDED, None, None, None

    if h == 0.0:
        if not confirmed_ref.is_emitted:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if target != confirmed_ref.requested_goal:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if (
            confirmed_ref.emitted_target is None
            or confirmed_ref.packet is None
        ):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if (
            confirmed_ref.q_rad < spec.q_min_rad
            or confirmed_ref.q_rad > spec.q_max_rad
        ):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        q_ref_exact = Fraction(confirmed_ref.q_rad)
        q_meas_exact = Fraction(q_meas_val)
        lead_exact = Fraction(spec.max_lead_rad)
        if not (
            q_meas_exact - lead_exact
            <= q_ref_exact
            <= q_meas_exact + lead_exact
        ):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if abs(confirmed_ref.encoded_velocity_rad_s) > spec.v_max_rad_s:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if abs(confirmed_ref.position_step_velocity_rad_s) > Fraction(spec.v_max_rad_s):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        try:
            pred_h0 = predict_joint_effort(confirmed_ref.emitted_target, sample)
            if abs(Fraction(pred_h0)) > Fraction(spec.max_effort_nm):
                return DecisionCode.EFFORT_OUT_OF_BOUNDS, None, None, None
        except (ArithmeticError, OverflowError, ValueError):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        return (
            None,
            confirmed_ref.emitted_target,
            confirmed_ref,
            confirmed_ref.packet,
        )

    # Use exact rational arithmetic over the stored finite float-domain values.
    # The sample cadence is the actual float subtraction above, not a decimal
    # interpretation of either timestamp.
    try:
        h_exact = Fraction(h)
        q_prev_exact = Fraction(confirmed_ref.q_rad)
        v_prev_pos_exact = Fraction(confirmed_ref.position_step_velocity_rad_s)
        v_prev_enc_exact = Fraction(confirmed_ref.encoded_velocity_rad_s)
        q_min_exact = Fraction(spec.q_min_rad)
        q_max_exact = Fraction(spec.q_max_rad)
        v_max_exact = Fraction(spec.v_max_rad_s)
        a_max_exact = Fraction(spec.a_max_rad_s2)
        lead_exact = Fraction(spec.max_lead_rad)
        q_meas_exact = Fraction(q_meas_val)

        v_pos_lo = (q_min_exact - q_prev_exact) / h_exact
        v_pos_hi = (q_max_exact - q_prev_exact) / h_exact
        v_acc_lo = v_prev_pos_exact - a_max_exact * h_exact
        v_acc_hi = v_prev_pos_exact + a_max_exact * h_exact
        v_lead_lo = (q_meas_exact - lead_exact - q_prev_exact) / h_exact
        v_lead_hi = (q_meas_exact + lead_exact - q_prev_exact) / h_exact

        v_lo = max(-v_max_exact, v_pos_lo, v_acc_lo, v_lead_lo)
        v_hi = min(v_max_exact, v_pos_hi, v_acc_hi, v_lead_hi)
        if v_lo > v_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        # q and dq jointly define a one-step objective; q does not replace dq.
        v_desired = (Fraction(goal_q) - q_prev_exact) / h_exact + Fraction(goal_dq)
        v_projected = max(v_lo, min(v_hi, v_desired))
        q_continuous = q_prev_exact + v_projected * h_exact
        q_next_lo = q_prev_exact + v_lo * h_exact
        q_next_hi = q_prev_exact + v_hi * h_exact
        if q_next_lo > q_next_hi or not q_next_lo <= q_continuous <= q_next_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        q_wanted = float(q_continuous)
        q_lower = float(q_next_lo)
        q_upper = float(q_next_hi)
        if not all(math.isfinite(value) for value in (q_wanted, q_lower, q_upper)):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        v_enc_lo = max(-v_max_exact, v_prev_enc_exact - a_max_exact * h_exact)
        v_enc_hi = min(v_max_exact, v_prev_enc_exact + a_max_exact * h_exact)
        if v_enc_lo > v_enc_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        v_enc_desired = Fraction(goal_dq)
        v_enc_projected = max(v_enc_lo, min(v_enc_hi, v_enc_desired))
        v_enc_wanted = float(v_enc_projected)
        v_enc_lower = float(v_enc_lo)
        v_enc_upper = float(v_enc_hi)
        if not all(math.isfinite(value) for value in (v_enc_wanted, v_enc_lower, v_enc_upper)):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        output_req = spec.mapping.to_output(
            JointTarget(goal_q, goal_dq, goal_tau, goal_kp, goal_kd)
        )
        command(
            spec.motor_id,
            mode=1,
            rpm=output_req.rpm,
            kd=output_req.kd,
            torque=output_req.tau_nm,
            watchdog=True,
            position=output_req.q_rad,
            kp=output_req.kp,
        )
        raw_pos = project_position_raw(
            q_wanted,
            q_lower,
            q_upper,
            lambda out_q: spec.mapping.from_output(OutputSample(out_q, 0.0, 0.0)).q_rad,
            spec.mapping.direction,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    if raw_pos is None:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    def mapped_position(raw_position: int) -> float:
        return spec.mapping.from_output(
            OutputSample(raw_to_position(raw_position), 0.0, 0.0)
        ).q_rad

    try:
        q_emitted = mapped_position(raw_pos)
        q_emitted_exact = Fraction(q_emitted)
        position_step_velocity = (q_emitted_exact - q_prev_exact) / h_exact
        safe_position = (
            q_min_exact <= q_emitted_exact <= q_max_exact
            and (q_meas_exact - lead_exact) <= q_emitted_exact <= (q_meas_exact + lead_exact)
            and q_next_lo <= q_emitted_exact <= q_next_hi
        )
        safe_step = (
            abs(position_step_velocity) <= v_max_exact
            and abs(position_step_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
        )
        if not safe_position or not safe_step:
            if q_emitted_exact < q_next_lo or position_step_velocity < v_lo:
                raw_step = spec.mapping.direction
            elif q_emitted_exact > q_next_hi or position_step_velocity > v_hi:
                raw_step = -spec.mapping.direction
            else:
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_candidate = raw_pos + raw_step
            candidate_q = mapped_position(raw_candidate)
            candidate_q_exact = Fraction(candidate_q)
            candidate_velocity = (candidate_q_exact - q_prev_exact) / h_exact
            if not (
                q_min_exact <= candidate_q_exact <= q_max_exact
                and (q_meas_exact - lead_exact) <= candidate_q_exact <= (q_meas_exact + lead_exact)
                and q_next_lo <= candidate_q_exact <= q_next_hi
                and abs(candidate_velocity) <= v_max_exact
                and abs(candidate_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
            ):
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_pos = raw_candidate
            q_emitted = candidate_q
            q_emitted_exact = candidate_q_exact
            position_step_velocity = candidate_velocity
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        raw_rpm = project_speed_raw(
            v_enc_wanted,
            v_enc_lower,
            v_enc_upper,
            lambda out_rpm: spec.mapping.from_output(OutputSample(0.0, out_rpm, 0.0)).dq_rad_s,
            spec.mapping.direction,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    if raw_rpm is None:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    def mapped_speed(raw_s: int) -> float:
        return spec.mapping.from_output(
            OutputSample(0.0, raw_to_rpm(raw_s), 0.0)
        ).dq_rad_s

    try:
        v_emitted_enc = mapped_speed(raw_rpm)
        v_emitted_enc_exact = Fraction(v_emitted_enc)
        safe_enc = (
            abs(v_emitted_enc_exact) <= v_max_exact
            and abs(v_emitted_enc_exact - v_prev_enc_exact) <= a_max_exact * h_exact
            and v_enc_lo <= v_emitted_enc_exact <= v_enc_hi
        )
        if not safe_enc:
            if v_emitted_enc_exact < v_enc_lo:
                raw_rpm_step = spec.mapping.direction
            elif v_emitted_enc_exact > v_enc_hi:
                raw_rpm_step = -spec.mapping.direction
            else:
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_rpm_cand = raw_rpm + raw_rpm_step
            cand_v_enc = mapped_speed(raw_rpm_cand)
            cand_v_enc_exact = Fraction(cand_v_enc)
            if not (
                abs(cand_v_enc_exact) <= v_max_exact
                and abs(cand_v_enc_exact - v_prev_enc_exact) <= a_max_exact * h_exact
                and v_enc_lo <= cand_v_enc_exact <= v_enc_hi
            ):
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_rpm = raw_rpm_cand
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        packet = command_with_raw_position(
            spec.motor_id,
            raw_pos,
            mode=1,
            kd=output_req.kd,
            torque=output_req.tau_nm,
            watchdog=True,
            kp=output_req.kp,
            raw_rpm=raw_rpm,
        )
        decoded = decode_command(packet)
        actual_target = map_decoded_command(spec.mapping, decoded)
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    actual_q_exact = Fraction(actual_target.q_rad)
    actual_position_step_velocity = (actual_q_exact - q_prev_exact) / h_exact
    actual_v_enc_exact = Fraction(actual_target.dq_rad_s)
    if not q_min_exact <= actual_q_exact <= q_max_exact:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
    if not (q_meas_exact - lead_exact <= actual_q_exact <= q_meas_exact + lead_exact):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if not q_next_lo <= actual_q_exact <= q_next_hi:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if v_desired != 0 and actual_target.q_rad == confirmed_ref.q_rad:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_v_enc_exact) > v_max_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_v_enc_exact - v_prev_enc_exact) > a_max_exact * h_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_position_step_velocity) > v_max_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_position_step_velocity - v_prev_pos_exact) > a_max_exact * h_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        pred_effort = predict_joint_effort(actual_target, sample)
        if abs(Fraction(pred_effort)) > Fraction(spec.max_effort_nm):
            return DecisionCode.EFFORT_OUT_OF_BOUNDS, None, None, None
    except (ArithmeticError, OverflowError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    proposed_ref = JointTrajectoryReference(
        q_rad=actual_target.q_rad,
        position_step_velocity_rad_s=actual_position_step_velocity,
        encoded_velocity_rad_s=actual_target.dq_rad_s,
        sample_time_s=now,
        is_emitted=True,
        requested_goal=JointTarget(goal_q, goal_dq, goal_tau, goal_kp, goal_kd),
        emitted_target=actual_target,
        packet=packet,
    )
    return None, actual_target, proposed_ref, packet


def prepare_complete_reference(
    specs: tuple[JointSpec, ...],
    target: Target,
    confirmed_references: tuple[JointTrajectoryReference, ...],
    samples: tuple[JointSample, ...],
    now: float,
    max_reference_gap_s: float,
) -> ReferenceBatchResult:
    """Shape all joints and report every failed index without exposing a partial plan."""
    if (
        type(specs) is not tuple
        or not specs
        or any(not isinstance(spec, JointSpec) for spec in specs)
        or not isinstance(target, Target)
        or len(target.joints) != len(specs)
        or type(confirmed_references) is not tuple
        or len(confirmed_references) != len(specs)
        or type(samples) is not tuple
        or len(samples) != len(specs)
    ):
        return ReferenceBatchResult(
            None, None, None, (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
        )

    actual_targets: list[JointTarget] = []
    packets: list[bytes] = []
    proposed_references: list[JointTrajectoryReference] = []
    failures: list[ReferenceFailure] = []

    for index, (spec, joint_target, conf_ref, sample) in enumerate(
        zip(specs, target.joints, confirmed_references, samples)
    ):
        code, actual_target, prop_ref, packet = shape_reference_joint(
            spec, joint_target, conf_ref, sample, now, max_reference_gap_s
        )
        if code is not None or actual_target is None or prop_ref is None or packet is None:
            failures.append(
                ReferenceFailure(code or DecisionCode.CONSTRAINT_VIOLATION, index)
            )
            continue
        actual_targets.append(actual_target)
        packets.append(packet)
        proposed_references.append(prop_ref)

    if failures:
        return ReferenceBatchResult(None, None, None, tuple(failures))
    return ReferenceBatchResult(
        tuple(actual_targets), tuple(packets), tuple(proposed_references), ()
    )


def verify_dispatch_claim(
    spec: JointSpec,
    prop_ref: JointTrajectoryReference,
    conf_ref: JointTrajectoryReference,
    plan_joint: JointTarget,
    packet: bytes,
    goal: JointTarget,
    sample: JointSample,
    prepared_at_s: float,
) -> DecisionCode | None:
    """Validate one proposed joint reference against all closed constraints at the write gate."""
    if (
        not isinstance(spec, JointSpec)
        or not isinstance(prop_ref, JointTrajectoryReference)
        or not isinstance(conf_ref, JointTrajectoryReference)
        or not isinstance(plan_joint, JointTarget)
        or type(packet) is not bytes
        or not isinstance(goal, JointTarget)
        or not isinstance(sample, JointSample)
    ):
        return DecisionCode.CONSTRAINT_VIOLATION
    for val in (sample.q_rad, sample.dq_rad_s, sample.tau_nm):
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            return DecisionCode.CONSTRAINT_VIOLATION
        try:
            num = float(val)
        except (OverflowError, TypeError, ValueError):
            return DecisionCode.CONSTRAINT_VIOLATION
        if not math.isfinite(num):
            return DecisionCode.CONSTRAINT_VIOLATION

    if (
        prop_ref.requested_goal != goal
        or prop_ref.emitted_target != plan_joint
        or prop_ref.packet != packet
        or prop_ref.sample_time_s > prepared_at_s
    ):
        return DecisionCode.CONSTRAINT_VIOLATION

    if prop_ref.sample_time_s == conf_ref.sample_time_s:
        if prop_ref != conf_ref:
            return DecisionCode.CONSTRAINT_VIOLATION
    elif (
        prop_ref.sample_time_s != prepared_at_s
        or prop_ref.sample_time_s <= conf_ref.sample_time_s
    ):
        return DecisionCode.CONSTRAINT_VIOLATION

    try:
        h_ref = prop_ref.sample_time_s - conf_ref.sample_time_s
        h_ref_exact = Fraction(h_ref)
        a_max_exact = Fraction(spec.a_max_rad_s2)
        v_max_exact = Fraction(spec.v_max_rad_s)
        v_prev_pos = Fraction(conf_ref.position_step_velocity_rad_s)
        v_prev_enc = Fraction(conf_ref.encoded_velocity_rad_s)
        q_min_exact = Fraction(spec.q_min_rad)
        q_max_exact = Fraction(spec.q_max_rad)
        lead_exact = Fraction(spec.max_lead_rad)
        q_meas_exact = Fraction(sample.q_rad)
        prop_q_exact = Fraction(prop_ref.q_rad)
        plan_q_exact = Fraction(plan_joint.q_rad)

        if h_ref > 0.0:
            actual_pos_vel = (prop_q_exact - Fraction(conf_ref.q_rad)) / h_ref_exact
            if prop_ref.position_step_velocity_rad_s != actual_pos_vel:
                return DecisionCode.CONSTRAINT_VIOLATION

        if (
            not q_min_exact <= prop_q_exact <= q_max_exact
            or not q_min_exact <= plan_q_exact <= q_max_exact
        ):
            return DecisionCode.POSITION_OUT_OF_BOUNDS

        if (
            abs(prop_ref.position_step_velocity_rad_s) > v_max_exact
            or abs(Fraction(prop_ref.encoded_velocity_rad_s)) > v_max_exact
            or abs(Fraction(plan_joint.dq_rad_s)) > v_max_exact
        ):
            return DecisionCode.SPEED_OUT_OF_BOUNDS

        if prop_ref.sample_time_s > conf_ref.sample_time_s:
            if (
                abs(prop_ref.position_step_velocity_rad_s - v_prev_pos) > a_max_exact * h_ref_exact
                or abs(Fraction(prop_ref.encoded_velocity_rad_s) - v_prev_enc) > a_max_exact * h_ref_exact
            ):
                return DecisionCode.CONSTRAINT_VIOLATION

        if (
            prop_q_exact < q_meas_exact - lead_exact
            or prop_q_exact > q_meas_exact + lead_exact
            or plan_q_exact < q_meas_exact - lead_exact
            or plan_q_exact > q_meas_exact + lead_exact
        ):
            return DecisionCode.CONSTRAINT_VIOLATION

        try:
            pred_effort = predict_joint_effort(plan_joint, sample)
            if abs(Fraction(pred_effort)) > Fraction(spec.max_effort_nm):
                return DecisionCode.EFFORT_OUT_OF_BOUNDS
        except (ArithmeticError, OverflowError, ValueError):
            return DecisionCode.CONSTRAINT_VIOLATION
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION

    return None

```

## Complete joint_mapping.py
```
from dataclasses import dataclass
import math


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a real int or float")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def _result(value, name, nonzero_inputs=None):
    if not math.isfinite(value):
        raise ValueError(f"{name} result must be finite")
    if nonzero_inputs and value == 0.0 and all(item != 0.0 for item in nonzero_inputs):
        raise ValueError(f"{name} result underflowed")
    return value


def _multiply(name, *values):
    result = 1.0
    for index, value in enumerate(values):
        result *= value
        _result(result, name, values[:index + 1])
    return result


def _divide(numerator, denominator, name):
    try:
        result = numerator / denominator
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError(f"{name} result is not representable") from exc
    return _result(result, name, (numerator,))


def _add(left, right, name):
    return _result(left + right, name)


def _subtract(left, right, name):
    return _result(left - right, name)


@dataclass(frozen=True)
class JointMap:
    reduction: float
    direction: int
    zero_output_rad: float

    def __post_init__(self):
        reduction = _finite(self.reduction, "reduction")
        if reduction <= 0.0:
            raise ValueError("reduction must be positive")
        if type(self.direction) is not int or self.direction not in (-1, 1):
            raise ValueError("direction must be the integer -1 or 1")
        object.__setattr__(self, "reduction", reduction)
        object.__setattr__(self, "zero_output_rad", _finite(self.zero_output_rad, "zero_output_rad"))

    def to_output(self, target: "JointTarget") -> "OutputTarget":
        if not isinstance(target, JointTarget):
            raise ValueError("target must be a JointTarget")

        signed_reduction = _multiply("signed reduction", float(self.direction), self.reduction)
        q_rad = _add(
            self.zero_output_rad,
            _multiply("output position", signed_reduction, target.q_rad),
            "output position",
        )
        output_rad_s = _multiply("output velocity", signed_reduction, target.dq_rad_s)
        rpm = _divide(_multiply("output speed", output_rad_s, 60.0), math.tau, "output speed")
        tau_nm = _divide(
            _multiply("output torque", float(self.direction), target.tau_nm),
            self.reduction,
            "output torque",
        )
        kp = _divide(_divide(target.kp, self.reduction, "output kp"), self.reduction, "output kp")
        kd = _divide(_divide(target.kd, self.reduction, "output kd"), self.reduction, "output kd")
        return OutputTarget(q_rad=q_rad, rpm=rpm, tau_nm=tau_nm, kp=kp, kd=kd)

    def from_output(self, sample: "OutputSample") -> "JointSample":
        if not isinstance(sample, OutputSample):
            raise ValueError("sample must be an OutputSample")

        q_delta = _subtract(sample.q_rad, self.zero_output_rad, "joint position")
        q_rad = _divide(
            _multiply("joint position", float(self.direction), q_delta),
            self.reduction,
            "joint position",
        )
        output_rad_s = _divide(
            _multiply("joint velocity", sample.rpm, math.tau),
            60.0,
            "joint velocity",
        )
        dq_rad_s = _divide(
            _multiply("joint velocity", float(self.direction), output_rad_s),
            self.reduction,
            "joint velocity",
        )
        tau_nm = _multiply("joint torque", float(self.direction), self.reduction, sample.tau_nm)
        return JointSample(q_rad=q_rad, dq_rad_s=dq_rad_s, tau_nm=tau_nm)


@dataclass(frozen=True)
class JointTarget:
    q_rad: float
    dq_rad_s: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputTarget:
    q_rad: float
    rpm: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputSample:
    q_rad: float
    rpm: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))


@dataclass(frozen=True)
class JointSample:
    q_rad: float
    dq_rad_s: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))

```

## Complete im6014_codec.py
```
import math
import struct
from collections.abc import Callable

RATIO = 38 / 3
RPM_MIN = -32768 / 64 / RATIO * 60
RPM_MAX = 32767 / 64 / RATIO * 60
POSITION_MIN = -2147483648 / 32768 / RATIO * math.tau
POSITION_MAX = 2147483647 / 32768 / RATIO * math.tau
RAW_POSITION_MIN = -2147483648
RAW_POSITION_MAX = 2147483647
RAW_RPM_MIN = -32768
RAW_RPM_MAX = 32767


def raw_to_position(raw_position):
    if type(raw_position) is not int or not RAW_POSITION_MIN <= raw_position <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return raw_position / 32768 / RATIO * math.tau


def position_to_raw(position):
    position = _finite_control(position, 'Position')
    return _signed_raw(position / math.tau * RATIO * 32768,
                       RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')


def raw_to_rpm(raw_rpm):
    if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
        raise ValueError('raw_rpm must be a signed 16-bit integer')
    return raw_rpm / 64 / RATIO * 60


def rpm_to_raw(rpm):
    rpm = _finite_control(rpm, 'Speed')
    return _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')


def _motor_id(value, name='Individual ID'):
    if type(value) is not int or not 0 <= value <= 14:
        raise ValueError(f'{name} must be an integer from 0 to 14')
    return value


def _finite_control(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f'{name} must be a finite int or float')
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError(f'{name} must be finite') from error
    if not math.isfinite(result):
        raise ValueError(f'{name} must be finite')
    return result


def _signed_raw(value, minimum, maximum, name):
    raw = round(value)
    if not minimum <= raw <= maximum:
        raise ValueError(f'{name} cannot be represented by the motor protocol')
    return raw


def _torque_raw(value):
    return _signed_raw(value / RATIO * 2560, -32768, 32767, 'Feedforward torque')


def _kp_raw(value):
    return _signed_raw(value / RATIO ** 2 * 12800, -32768, 32767, 'Kp')


def _kd_raw(value):
    return _signed_raw(value / RATIO ** 2 * 51200, -32768, 32767, 'Kd')


def _raw_position(value):
    if type(value) is not int or not RAW_POSITION_MIN <= value <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return value


def crc32(data):
    if len(data) % 4:
        raise ValueError('CRC input must contain complete four-byte words')
    crc = 0xFFFFFFFF
    for start in range(0, len(data), 4):
        for byte in data[start:start + 4][::-1]:
            crc ^= byte << 24
            for _ in range(8):
                crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    return crc


def command(motor_id, mode=0, rpm=0, kd=0, torque=0, watchdog=True, position=0, kp=0):
    position = _finite_control(position, 'Position')
    if not POSITION_MIN <= position <= POSITION_MAX:
        raise ValueError('Position cannot be encoded in the motor protocol')
    if mode == 0 and position != 0.0:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    position_raw = _signed_raw(position / math.tau * RATIO * 32768,
                               RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')
    return command_with_raw_position(
        motor_id,
        position_raw,
        mode=mode,
        rpm=rpm,
        kd=kd,
        torque=torque,
        watchdog=watchdog,
        kp=kp,
    )


def command_with_raw_position(
    motor_id, raw_position, mode=0, rpm=0, kd=0, torque=0, watchdog=True, kp=0, raw_rpm=None
):
    """Encode a command while preserving an already selected position grid code."""
    motor_id = _motor_id(motor_id)
    raw_position = _raw_position(raw_position)
    if type(mode) is not int or mode not in (0, 1):
        raise ValueError('Individual ID 0–14 and Stop/FOC modes only')
    if type(watchdog) is not bool:
        raise ValueError('Watchdog must be a bool')
    rpm, kd, torque, kp = (
        _finite_control(value, name) for value, name in
        ((rpm, 'Speed'), (kd, 'Kd'), (torque, 'Feedforward torque'),
         (kp, 'Kp'))
    )
    if not RPM_MIN <= rpm <= RPM_MAX:
        raise ValueError('Speed cannot be encoded in the motor protocol; this is not a rated-speed limit')
    if not 0 <= kd <= 6 or not 0 <= kp <= 30 or not -3.5 <= torque <= 3.5:
        raise ValueError('Bench limits: Kd 0–6, Kp 0–30, feedforward torque ±3.5 Nm')
    torque_raw = _torque_raw(torque)
    if raw_rpm is not None:
        if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
            raise ValueError('raw_rpm must be a signed 16-bit integer')
        rpm_raw = raw_rpm
    else:
        rpm_raw = _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')
    kp_raw = _kp_raw(kp)
    kd_raw = _kd_raw(kd)
    if mode == 0 and (rpm or kd or torque or raw_position or kp or (raw_rpm is not None and raw_rpm != 0)) or mode == 1 and not watchdog:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    raw = b'\xfe\xee' + bytes([motor_id | mode << 4 | int(watchdog) << 7, 0])
    raw += struct.pack('<hhihh', torque_raw, rpm_raw, raw_position, kp_raw, kd_raw)
    return raw + struct.pack('<I', crc32(raw))


def project_position_raw(
    wanted_q,
    q_min,
    q_max,
    map_decoded_position: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw position whose mapped decoded value is in bounds.

    ``map_decoded_position`` maps decoded actuator radians to the caller's
    position domain. ``direction`` declares whether that mapping increases or
    decreases as the raw position code increases. Bounds are closed.
    """
    wanted_q = _finite_control(wanted_q, 'Wanted position')
    q_min = _finite_control(q_min, 'Minimum position')
    q_max = _finite_control(q_max, 'Maximum position')
    if q_min > q_max:
        raise ValueError('Minimum position must not exceed maximum position')
    if not callable(map_decoded_position):
        raise ValueError('Position mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Position mapping direction must be -1 or 1')

    ordered_min = direction * (q_min if direction == 1 else q_max)
    ordered_max = direction * (q_max if direction == 1 else q_min)
    ordered_wanted = direction * wanted_q

    def mapped(raw_position):
        decoded = raw_to_position(raw_position)
        try:
            result = map_decoded_position(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Position mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped position')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_POSITION_MIN
        right = RAW_POSITION_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_POSITION_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def project_speed_raw(
    wanted_dq,
    v_min,
    v_max,
    map_decoded_speed: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw speed whose mapped decoded value is in bounds.

    ``map_decoded_speed`` maps decoded actuator RPM to the caller's
    speed domain. ``direction`` declares whether that mapping increases or
    decreases as the raw speed code increases. Bounds are closed.
    """
    wanted_dq = _finite_control(wanted_dq, 'Wanted speed')
    v_min = _finite_control(v_min, 'Minimum speed')
    v_max = _finite_control(v_max, 'Maximum speed')
    if v_min > v_max:
        raise ValueError('Minimum speed must not exceed maximum speed')
    if not callable(map_decoded_speed):
        raise ValueError('Speed mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Speed mapping direction must be -1 or 1')

    ordered_min = direction * (v_min if direction == 1 else v_max)
    ordered_max = direction * (v_max if direction == 1 else v_min)
    ordered_wanted = direction * wanted_dq

    def mapped(raw_speed):
        decoded = raw_to_rpm(raw_speed)
        try:
            result = map_decoded_speed(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Speed mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped speed')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_RPM_MIN
        right = RAW_RPM_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_RPM_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def feedback(raw, motor_id):
    motor_id = _motor_id(motor_id, 'Expected motor ID')
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Feedback frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Feedback frame must be a bytes-like buffer') from error
    if len(raw) != 26 or raw[:2] != b'\xfc\xee':
        raise RuntimeError('Invalid feedback length/header')
    if struct.unpack('<I', raw[22:])[0] != crc32(raw[2:22]):
        raise RuntimeError('Feedback CRC mismatch')
    m, td, tw, v, tq, sp, pos, err, flags, _, _ = struct.unpack('<BbBBhhiIHBB', raw[2:22])
    if m & 15 != motor_id or (m >> 4) & 7 not in (0, 1):
        raise RuntimeError('Feedback ID/mode mismatch')
    return dict(id=m & 15, mode=(m >> 4) & 7, timeout=m >> 7,
                driver_c=td, winding_c=tw, voltage=v / 2,
                torque_nm=tq / 2560 * RATIO, rpm=sp / 64 / RATIO * 60,
                position_rad=pos / 32768 / RATIO * math.tau,
                errors=err, warnings=(flags >> 13) & 7, raw=raw.hex())


def decode_command(raw):
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Command frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Command frame must be a bytes-like buffer') from error
    if len(raw) != 20 or raw[:2] != b'\xfe\xee':
        raise ValueError('Invalid command length/header')
    if struct.unpack('<I', raw[16:])[0] != crc32(raw[:16]):
        raise ValueError('Command CRC mismatch')
    m = raw[2]
    motor_id = m & 0x0F
    mode = (m >> 4) & 0x07
    watchdog = bool(m & 0x80)
    if motor_id > 14 or mode not in (0, 1) or raw[3] != 0:
        raise ValueError('Invalid command ID, mode, or reserved byte')
    if mode == 1 and not watchdog:
        raise ValueError('FOC command requires watchdog')
    tq, sp, pos, kp, kd = struct.unpack('<hhihh', raw[4:16])
    if mode == 0 and (tq or sp or pos or kp or kd):
        raise ValueError('Stop command must have zero targets')
    decoded = dict(
        motor_id=motor_id,
        mode=mode,
        watchdog=watchdog,
        raw_torque=tq,
        raw_rpm=sp,
        raw_position=pos,
        raw_kp=kp,
        raw_kd=kd,
        torque_nm=tq / 2560 * RATIO,
        rpm=sp / 64 / RATIO * 60,
        position_rad=pos / 32768 / RATIO * math.tau,
        kp=kp * (RATIO ** 2) / 12800,
        kd=kd * (RATIO ** 2) / 51200,
        raw=raw.hex(),
    )
    if not _torque_raw(-3.5) <= tq <= _torque_raw(3.5):
        raise ValueError('Feedforward torque is outside the canonical command range')
    if not 0 <= kp <= _kp_raw(30.0) or not 0 <= kd <= _kd_raw(6.0):
        raise ValueError('Gain is outside the canonical command range')
    return decoded

```

## Complete test_controller_effort.py
```
"""Acceptance and unit tests for C13 combined effort prediction and measured monitoring."""

from fractions import Fraction
import math
import unittest

from im6014_codec import (
    KP_MAX,
    decode_command,
    raw_to_kp,
    raw_to_position,
)
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    JointFault,
    JointSpec,
    JointTrajectoryReference,
    MotorHealth,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget, OutputSample
from joint_reference import (
    map_decoded_command,
    predict_joint_effort,
    prepare_reference_joint,
    shape_reference_joint,
)
from test_controller import DeterministicClock, FakeStation, HEALTHY_STOP, SOURCE


class EffortLimitTests(unittest.TestCase):
    def setUp(self):
        self.clock = DeterministicClock(10.0)
        self.spec1 = JointSpec(
            "J1",
            0,
            JointMap(1.0, 1, 0.0),
            -2.0,
            2.0,
            5.0,     # v_max_rad_s
            50.0,    # a_max_rad_s2
            1.0,     # max_lead_rad
            10.0,    # max_effort_nm
            "fixture: effort test J1",
        )
        self.spec2 = JointSpec(
            "J2",
            1,
            JointMap(1.0, 1, 0.0),
            -2.0,
            2.0,
            5.0,
            50.0,
            1.0,
            15.0,    # max_effort_nm
            "fixture: effort test J2",
        )
        self.specs = (self.spec1, self.spec2)
        self.sample1 = JointSample(0.0, 0.0, 0.0)
        self.sample2 = JointSample(0.0, 0.0, 0.0)

    def _armed_station(self, max_reference_gap_s=1.0):
        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=max_reference_gap_s)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("effort-tester")
        self.assertTrue(core.begin_check().accepted)
        self.assertTrue(core.receive(0, self.sample1, HEALTHY_STOP).accepted)
        self.assertTrue(core.receive(1, self.sample2, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertTrue(station.arm(owner).accepted)
        return core, station, owner

    def test_effort_limit_requires_finite_positive_real_value(self):
        mapping = JointMap(1.0, 1, 0.0)
        for val in (True, False, 0, 0.0, -1.0, math.nan, math.inf, -math.inf, 10**400, "10.0"):
            with self.subTest(val=val), self.assertRaises(ValueError):
                JointSpec(
                    "J1", 0, mapping, -2.0, 2.0, 5.0, 50.0, 1.0, val,
                    "fixture: invalid effort limit input",
                )

        spec = JointSpec("J1", 0, mapping, -2.0, 2.0, 5.0, 50.0, 1.0, 12.5, "fixture: alias test")
        self.assertEqual(spec.max_effort_nm, 12.5)
        self.assertEqual(spec.peak_effort_nm, 12.5)
        self.assertEqual(spec.tau_max_nm, 12.5)

    def test_combined_sum_trips_when_each_term_individually_under_peak(self):
        # max_effort_nm is 10.0
        # tau_pred = tau_ff + kp*(q_ref - q_meas) + kd*(dq_ref - dq_meas)
        # Choose terms: tau_ff = 4.0, kp*(q - q_meas) = 4.0, kd*(dq - dq_meas) = 4.0
        # Each term alone is 4.0 <= 10.0, but total is 12.0 > 10.0
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        # q_meas=0.0, dq_meas=0.0
        target = Target(
            1,
            (
                JointTarget(q_rad=0.4, dq_rad_s=4.0, tau_nm=4.0, kp=10.0, kd=1.0),
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0, kp=1.0, kd=0.1),
            ),
            window=window,
            owner=owner,
        )
        decision = station.submit(target)
        self.assertFalse(decision.accepted)
        self.assertIs(decision.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)

        # Ensure no term clipping occurred: individual terms are under peak
        self.assertLessEqual(abs(4.0), self.spec1.max_effort_nm)
        self.assertLessEqual(abs(10.0 * 0.4), self.spec1.max_effort_nm)
        self.assertLessEqual(abs(1.0 * 4.0), self.spec1.max_effort_nm)

    def test_opposing_and_cancelling_terms(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        # Opposing terms: tau_ff = 8.0, kp*(q - q_meas) = -6.0 -> net is ~2.0 <= 10.0
        # q_meas = 0.0, q = -0.6, kp = 10.0 -> kp*(q - q_meas) = -6.0
        cancelling_target = Target(
            1,
            (
                JointTarget(q_rad=-0.6, dq_rad_s=0.0, tau_nm=8.0, kp=10.0, kd=0.0),
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0, kp=1.0, kd=0.1),
            ),
            window=window,
            owner=owner,
        )
        decision = station.submit(cancelling_target)
        self.assertTrue(decision.accepted)

        # Opposing terms that do NOT cancel sufficiently:
        # tau_ff = -8.0, kp*(q - q_meas) = -5.0 -> net is -13.0, |-13.0| > 10.0
        tripping_target = Target(
            2,
            (
                JointTarget(q_rad=-0.5, dq_rad_s=0.0, tau_nm=-8.0, kp=10.0, kd=0.0),
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0, kp=1.0, kd=0.1),
            ),
            window=window,
            owner=owner,
        )
        decision2 = station.submit(tripping_target)
        self.assertFalse(decision2.accepted)
        self.assertIs(decision2.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)

    def test_negative_mapping_and_units(self):
        # reduction=3.0, direction=-1, zero_output_rad=0.25
        mapping = JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25)
        spec = JointSpec(
            "J_neg", 0, mapping, -2.0, 2.0, 5.0, 50.0, 1.0, 10.0, "fixture: neg mapping effort"
        )
        # joint target: tau_nm = 3.0 Nm in joint units
        jt = JointTarget(q_rad=0.1, dq_rad_s=0.2, tau_nm=3.0, kp=9.0, kd=0.9)
        sample = JointSample(q_rad=0.1, dq_rad_s=0.2, tau_nm=0.0)

        # encode and map back
        code, actual, packet = prepare_reference_joint(spec, jt)
        self.assertIsNone(code)
        self.assertIsNotNone(actual)
        self.assertIsNotNone(packet)

        # predict effort on actual command
        pred_effort = predict_joint_effort(actual, sample)
        # Since q_ref == q_meas and dq_ref == dq_meas, predicted effort is just tau_ff
        self.assertAlmostEqual(pred_effort, 3.0, places=3)
        self.assertLessEqual(abs(pred_effort), spec.max_effort_nm)

    def test_encoded_gains_boundary_uses_quantized_wire_values(self):
        # Test that predict_joint_effort uses actual quantized wire gains,
        # not the raw float gains before encoding.
        mapping = JointMap(1.0, 1, 0.0)
        spec = JointSpec("J", 0, mapping, -2.0, 2.0, 5.0, 50.0, 1.0, 20.0, "fixture: quant test")

        # Pick a kp that is between integer raw codes:
        # e.g. kp corresponding to raw code 100.5
        raw_code = 100
        kp_discrete = raw_to_kp(raw_code)
        # Add a fraction so continuous kp is slightly higher
        kp_continuous = kp_discrete + 0.05
        jt = JointTarget(q_rad=0.1, dq_rad_s=0.0, tau_nm=0.0, kp=kp_continuous, kd=0.0)
        sample = JointSample(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0)

        # prepare_reference_joint quantizes Kp to wire
        code, actual, packet = prepare_reference_joint(spec, jt)
        self.assertIsNone(code)
        decoded = decode_command(packet)
        self.assertEqual(decoded["kp"], kp_discrete)

        # actual.kp from map_decoded_command matches the wire quantized kp
        self.assertEqual(actual.kp, kp_discrete)
        predicted = predict_joint_effort(actual, sample)
        expected = kp_discrete * 0.1
        self.assertEqual(predicted, expected)

    def test_target_admission_enforces_peak_prediction(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        # Submit target exceeding spec1 limit (10.0 Nm):
        # tau_ff = 12.0 Nm
        target = Target(
            1,
            (
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=12.0, kp=0.0, kd=0.0),
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0, kp=0.0, kd=0.0),
            ),
            window=window,
            owner=owner,
        )
        decision = station.submit(target)
        self.assertFalse(decision.accepted)
        self.assertIs(decision.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)
        self.assertIsNone(core.snapshot().admitted_target)

    def test_rejected_incoming_goal_leaves_watermark_and_prior_admitted_goal_intact(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        valid_target = Target(
            1,
            (
                JointTarget(q_rad=0.1, dq_rad_s=0.0, tau_nm=2.0, kp=1.0, kd=0.1),
                JointTarget(q_rad=0.1, dq_rad_s=0.0, tau_nm=2.0, kp=1.0, kd=0.1),
            ),
            window=window,
            owner=owner,
        )
        self.assertTrue(station.submit(valid_target).accepted)
        self.assertEqual(core.snapshot().last_sequence, 1)
        self.assertEqual(core.snapshot().admitted_target, valid_target)

        # Rejected target 2 due to effort violation
        invalid_target = Target(
            2,
            (
                JointTarget(q_rad=0.1, dq_rad_s=0.0, tau_nm=25.0, kp=1.0, kd=0.1),
                JointTarget(q_rad=0.1, dq_rad_s=0.0, tau_nm=2.0, kp=1.0, kd=0.1),
            ),
            window=window,
            owner=owner,
        )
        decision = station.submit(invalid_target)
        self.assertFalse(decision.accepted)
        self.assertIs(decision.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)

        # Sequence watermark and admitted target intact; state remains ARMED
        snap = core.snapshot()
        self.assertEqual(snap.last_sequence, 1)
        self.assertEqual(snap.admitted_target, valid_target)
        self.assertIs(snap.state, State.ARMED)
        self.assertFalse(snap.fault_latched)

    def test_exact_effort_boundary_is_inclusive(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        # spec1 limit is 10.0 Nm.
        # tau_ff = 10.0 exactly is accepted
        exact_target = Target(
            1,
            (
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=10.0, kp=0.0, kd=0.0),
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0, kp=0.0, kd=0.0),
            ),
            window=window,
            owner=owner,
        )
        self.assertTrue(station.submit(exact_target).accepted)

        # Negative exact equality -10.0 Nm is accepted
        exact_neg_target = Target(
            2,
            (
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=-10.0, kp=0.0, kd=0.0),
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0, kp=0.0, kd=0.0),
            ),
            window=window,
            owner=owner,
        )
        self.assertTrue(station.submit(exact_neg_target).accepted)

        # Strictly above 10.0 Nm trips
        above_target = Target(
            3,
            (
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=10.001, kp=0.0, kd=0.0),
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0, kp=0.0, kd=0.0),
            ),
            window=window,
            owner=owner,
        )
        decision = station.submit(above_target)
        self.assertFalse(decision.accepted)
        self.assertIs(decision.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)

    def test_changed_feedback_after_preparation_invalidates_dispatch_claim(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        # Admitted target has tau_ff = 8.0, kd = 2.0. With dq_meas = 0.0, effort = 8.0 <= 10.0
        target = Target(
            1,
            (
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=8.0, kp=0.0, kd=2.0),
                JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=0.0, kp=0.0, kd=0.0),
            ),
            window=window,
            owner=owner,
        )
        self.assertTrue(station.submit(target).accepted)
        self.clock.value += 0.05
        plan = core.prepare_refresh()
        self.assertIsNotNone(plan)

        # Now before dispatch, observation feedback changes: dq_meas becomes -2.0 rad/s
        # kd * (dq_ref - dq_meas) = 2.0 * (0.0 - (-2.0)) = 4.0
        # Total predicted effort = 8.0 + 4.0 = 12.0 > 10.0
        self.clock.value += 0.01
        self.assertTrue(
            core.receive(
                0,
                JointSample(0.0, -2.0, 0.0),
                MotorHealth(mode=1, errors=0, warnings=0, timeout=False),
            ).accepted
        )

        # claim_dispatch re-evaluates effort with the fresh feedback and rejects
        claimed = core.claim_dispatch(plan.plan_id, 0)
        self.assertFalse(claimed)

        # Rejection latches effort_limit and faults controller
        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertTrue(snap.faults[0].effort_limit)
        self.assertEqual(snap.faults[0].name, "J1")

    def test_independent_measured_effort_monitoring_trips_immediately(self):
        # 1. receive() trips when abs(tau_nm) > max_effort_nm
        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("measured-tester")
        self.assertTrue(core.begin_check().accepted)

        # J1 receives tau_nm = 10.5 > 10.0
        decision = core.receive(0, JointSample(0.0, 0.0, 10.5), HEALTHY_STOP)
        self.assertFalse(decision.accepted)
        self.assertIs(decision.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)

        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertTrue(snap.faults[0].effort_limit)
        self.assertEqual(snap.faults[0].name, "J1")

        # 2. Measured effort exact equality is allowed
        self.assertTrue(station.stop().accepted)
        owner2 = station.claim("recovery-tester")
        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
        # J1 receives exact limit tau_nm = 10.0 -> accepted
        self.assertTrue(core.receive(0, JointSample(0.0, 0.0, 10.0), HEALTHY_STOP).accepted)
        self.assertTrue(core.receive(1, JointSample(0.0, 0.0, -15.0), HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertTrue(station.arm(owner2).accepted)
        self.assertIs(core.snapshot().state, State.ARMED)

        # 3. receive() with negative effort exceeding limit trips
        decision_neg = core.receive(0, JointSample(0.0, 0.0, -10.1), HEALTHY_STOP)
        self.assertFalse(decision_neg.accepted)
        self.assertIs(decision_neg.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)
        self.assertTrue(core.snapshot().faults[0].effort_limit)

    def test_housekeeping_checked_and_arm_detect_measured_effort_violations(self):
        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("hk-tester")

        # Setup checked with out-of-bounds effort manually injected via observations
        self.assertTrue(core.begin_check().accepted)
        # receive valid within bounds
        self.assertTrue(core.receive(0, JointSample(0.0, 0.0, 5.0), HEALTHY_STOP).accepted)
        self.assertTrue(core.receive(1, JointSample(0.0, 0.0, 5.0), HEALTHY_STOP).accepted)
        # Now mutate observation sample on J1 to exceed limit
        core._observations[0] = JointContract_JointStatus_replace(
            core._observations[0], JointSample(0.0, 0.0, 11.0)
        )
        decision = core.checked()
        self.assertFalse(decision.accepted)
        self.assertIs(decision.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)
        self.assertTrue(core.snapshot().faults[0].effort_limit)

    def test_per_joint_attribution(self):
        core, station, owner = self._armed_station()
        window = station.issue_window(1.0)

        # J1 is within limit (5.0 <= 10.0), J2 exceeds limit (20.0 > 15.0)
        decision = core.receive(1, JointSample(0.0, 0.0, 20.0), HEALTHY_STOP)
        self.assertFalse(decision.accepted)
        self.assertIs(decision.code, DecisionCode.EFFORT_OUT_OF_BOUNDS)

        snap = core.snapshot()
        self.assertEqual(len(snap.faults), 1)
        self.assertEqual(snap.faults[0].name, "J2")
        self.assertEqual(snap.faults[0].motor_id, 1)
        self.assertTrue(snap.faults[0].effort_limit)
        self.assertEqual(snap.affected_joints, ("J2",))

    def test_invalid_arithmetic_overflow_fails_closed(self):
        # Huge numbers that overflow float arithmetic
        target = JointTarget(q_rad=0.0, dq_rad_s=0.0, tau_nm=1e308, kp=1e308, kd=1e308)
        sample = JointSample(q_rad=1e308, dq_rad_s=1e308, tau_nm=0.0)

        with self.assertRaises((OverflowError, ValueError)):
            predict_joint_effort(target, sample)

    def test_cause_union_and_fresh_healthy_stop_recovery(self):
        core, station, owner = self._armed_station()

        # Trip position limit AND effort limit on J1
        spec1 = self.spec1
        core._latch_joint_fault(spec1.name, spec1.motor_id, position_limit=True, effort_limit=True)

        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.faults[0].position_limit)
        self.assertTrue(snap.faults[0].effort_limit)

        # Disconnect and reconnect does not clear the fault
        self.assertTrue(core.disconnect().accepted)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertIs(core.snapshot().state, State.CONNECTED)
        self.assertTrue(core.snapshot().fault_latched)

        # begin_check without acknowledge_fault fails
        dec_check = core.begin_check()
        self.assertFalse(dec_check.accepted)
        self.assertIs(dec_check.code, DecisionCode.FAULT_ACK_REQUIRED)

        # Proper recovery with acknowledged stop check inside bounds
        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
        self.assertTrue(core.receive(0, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
        self.assertTrue(core.receive(1, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertEqual(core.snapshot().faults, ())
        self.assertFalse(core.snapshot().fault_latched)


def JointContract_JointStatus_replace(status, new_sample):
    from joint_contract import JointStatus
    return JointStatus(
        sample=new_sample,
        health=status.health,
        received_at=status.received_at,
        communication_error=status.communication_error,
    )


if __name__ == "__main__":
    unittest.main()

```

## Complete test_controller.py
```
import unittest
from dataclasses import FrozenInstanceError
import math

from im6014_codec import command
from joint_contract import (
    CommunicationFailure,
    DecisionCode,
    IntentWindow,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget


SAMPLE = JointSample(0.1, 0.0, 0.0)
HEALTHY_STOP = MotorHealth(mode=0, errors=0, warnings=0, timeout=False)
SOURCE = SourceIdentity("fixture", "controller-test", 1)


class FakeStation:
    def __init__(self, core):
        self.core = core
        self.writes = []
        self.owner = None

    def _write_stops(self):
        self.writes.extend(command(spec.motor_id, mode=0) for spec in self.core.joint_specs)

    def connect(self):
        decision = self.core.begin_connect()
        if not decision.accepted:
            return decision
        decision = self.core.connected(SOURCE)
        if decision.accepted:
            self._write_stops()
        return decision

    def claim(self, connection_id="human"):
        prior_state = self.core.snapshot().state
        self.owner = self.core.claim_owner(connection_id)
        if self.core.snapshot().state is State.STOPPED and prior_state is not State.STOPPED:
            self._write_stops()
        return self.owner

    def check(self, *, acknowledge_fault=False):
        decision = self.core.begin_check(acknowledge_fault=acknowledge_fault)
        if not decision.accepted:
            return decision
        self._write_stops()
        for spec in self.core.joint_specs:
            decision = self.core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP)
            if not decision.accepted:
                return decision
        return self.core.checked()

    def arm(self, owner: OwnerToken):
        return self.core.arm(owner)

    def issue_window(self, valid_for_s=0.2):
        return self.core.issue_window(valid_for_s)

    def submit(self, target):
        return self.core.submit_target(target)

    def refresh(self):
        plan = self.core.prepare_refresh()
        if plan is None:
            return None
        for index, packet in enumerate(plan.packets):
            if not self.core.claim_dispatch(plan.plan_id, index):
                break
            self.writes.append(packet)
            self.core.dispatch_result(plan.plan_id, index, WriteResult.COMPLETE)
        return plan

    def stop(self):
        decision = self.core.stop()
        if decision.accepted:
            self._write_stops()
        return decision

    def disconnect(self):
        return self.core.disconnect()


class DeterministicClock:
    def __init__(self, value=0.0):
        self.value = value
        self.calls = 0

    def __call__(self):
        self.calls += 1
        return self.value


class FeedbackAgeTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
        )

    def _ready_station(self, clock, *, feedback_max_age_s=1.0):
        core = JointCore(
            self.specs,
            clock=clock,
            feedback_max_age_s=feedback_max_age_s,
            max_reference_gap_s=1.0,
        )
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        station.claim("fixture")
        self.assertTrue(station.check().accepted)
        return core, station

    def test_feedback_age_configuration_is_finite_positive_and_typed(self):
        for value in (True, False, 0, -1.0, math.nan, math.inf, -math.inf, 10**400, "1"):
            with self.subTest(value=repr(value)), self.assertRaises(ValueError):
                JointCore(self.specs, feedback_max_age_s=value, max_reference_gap_s=1.0)
        with self.assertRaises(ValueError):
            JointCore(self.specs, clock=0, max_reference_gap_s=1.0)

    def test_zero_timestamp_and_exact_freshness_boundary(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)

        received = core.snapshot()
        self.assertEqual(tuple(joint.received_at for joint in received.joints), (0.0, 0.0))
        self.assertEqual(received.feedback_ages_s, (0.0, 0.0))

        clock.value = 1.0
        at_boundary = core.snapshot()
        self.assertEqual(at_boundary.feedback_ages_s, (1.0, 1.0))
        self.assertTrue(core.arm(station.owner).accepted)

        with self.assertRaises(FrozenInstanceError):
            at_boundary.joints[0].received_at = 1.0
        with self.assertRaises(TypeError):
            at_boundary.feedback_ages_s[0] = 0.0

    def test_checked_rejects_feedback_older_than_limit(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0, max_reference_gap_s=1.0)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)
        for spec in self.specs:
            self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)

        clock.value = 1.000001
        rejected = core.checked()
        self.assertEqual(rejected.code, DecisionCode.STALE_FEEDBACK)
        self.assertIs(core.snapshot().state, State.CHECKING)
        self.assertFalse(core.snapshot().fault_latched)
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.CHECKING)

    def test_bad_id_and_observation_do_not_refresh_receipt_time(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        initial = core.snapshot()
        calls_before = clock.calls

        clock.value = 0.5
        self.assertEqual(
            core.receive(14, SAMPLE, HEALTHY_STOP).code,
            DecisionCode.UNKNOWN_JOINT,
        )
        self.assertEqual(
            core.receive(self.specs[0].motor_id, object(), HEALTHY_STOP).code,
            DecisionCode.INVALID_OBSERVATION,
        )
        self.assertEqual(clock.calls, calls_before)
        self.assertEqual(
            tuple(joint.received_at for joint in core.snapshot().joints),
            tuple(joint.received_at for joint in initial.joints),
        )

        clock.value = 1.000001
        self.assertEqual(core.arm(station.owner).code, DecisionCode.STALE_FEEDBACK)

    def test_fresh_j1_cannot_hide_stale_j2_from_arm_or_tick(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        station.writes.clear()

        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        clock.value = 1.000001
        before_writes = list(station.writes)
        rejected = station.arm(station.owner)
        self.assertEqual(rejected.code, DecisionCode.STALE_FEEDBACK)
        self.assertIs(core.snapshot().state, State.READY)
        self.assertEqual(station.writes, before_writes)

        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        station.writes.clear()
        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(station.arm(station.owner).accepted)
        clock.value = 1.000001
        before_writes = list(station.writes)
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(station.writes, before_writes)

    def test_disconnect_invalidates_age_and_stale_fault_needs_acknowledged_check(self):
        clock = DeterministicClock(0.0)
        core, station = self._ready_station(clock)
        self.assertTrue(station.arm(station.owner).accepted)

        clock.value = 1.1
        self.assertTrue(core.tick().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        before_disconnect = core.snapshot()

        self.assertTrue(station.disconnect().accepted)
        disconnected = core.snapshot()
        self.assertTrue(all(joint.received_at is None for joint in disconnected.joints))
        self.assertEqual(disconnected.feedback_ages_s, (None, None))
        self.assertEqual(before_disconnect.feedback_ages_s, (1.1, 1.1))
        self.assertTrue(disconnected.fault_latched)

        self.assertTrue(station.connect().accepted)
        writes_after_connect = list(station.writes)
        self.assertEqual(
            station.check().code,
            DecisionCode.FAULT_ACK_REQUIRED,
        )
        self.assertEqual(station.writes, writes_after_connect)

        station.writes.clear()
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertEqual(
            station.writes,
            [command(spec.motor_id, mode=0) for spec in self.specs],
        )
        self.assertIs(core.snapshot().state, State.READY)
        self.assertFalse(core.snapshot().fault_latched)


def core_at(test, state, clock=None):
    if clock is None:
        clock = DeterministicClock(0.0)
    core = JointCore(test.specs, clock=clock, max_reference_gap_s=1.0)
    station = FakeStation(core)
    if state is State.DISCONNECTED:
        return core
    if state is State.CONNECTING:
        test.assertTrue(core.begin_connect().accepted)
        return core

    test.assertTrue(station.connect().accepted)
    if state is State.CONNECTED:
        return core
    owner = station.claim("fixture")
    if state is State.CHECKING:
        test.assertTrue(core.begin_check().accepted)
        return core

    test.assertTrue(station.check().accepted)
    if state is State.READY:
        return core
    if state is State.ARMED:
        test.assertTrue(station.arm(owner).accepted)
        return core
    if state is State.MOVING:
        test.assertTrue(station.arm(owner).accepted)
        window = station.issue_window(1.0)
        target = Target(
            0,
            (
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
            ),
            window=window,
            owner=owner,
        )
        test.assertTrue(core.submit_target(target).accepted)
        if hasattr(clock, "value"):
            clock.value += 0.05
        test.assertIsNotNone(station.refresh())
        return core
    if state is State.STOPPED:
        test.assertTrue(station.arm(owner).accepted)
        test.assertTrue(station.stop().accepted)
        return core
    if state is State.FAULT:
        test.assertTrue(station.arm(owner).accepted)
        test.assertTrue(core.receive(
            test.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=1, warnings=0, timeout=False),
        ).accepted)
        return core
    raise AssertionError(f"{state} is not reachable")


class ControllerStateTests(unittest.TestCase):
    def setUp(self):
        self.clock = lambda: 0.0
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
        )


    def test_joint_set_is_nonempty_unique_and_owned(self):
        mapping = JointMap(1, 1, 0.0)
        with self.assertRaises(ValueError):
            JointCore((), max_reference_gap_s=1.0)
        with self.assertRaises(ValueError):
            JointCore((
                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
                JointSpec("J1", 1, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
            ), max_reference_gap_s=1.0)
        with self.assertRaises(ValueError):
            JointCore((
                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
                JointSpec("J2", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
            ), max_reference_gap_s=1.0)
        with self.assertRaises(ValueError):
            JointSpec("J1", True, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits")

        supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits")]
        core = JointCore(supplied, clock=self.clock, max_reference_gap_s=1.0)
        supplied.clear()
        self.assertEqual(tuple(spec.name for spec in core.joint_specs), ("J1",))

    def test_health_and_source_records_reject_invalid_values(self):
        for kwargs in (
            dict(mode=True, errors=0, warnings=0, timeout=False),
            dict(mode=0, errors=True, warnings=0, timeout=False),
            dict(mode=0, errors=0, warnings=-1, timeout=False),
            dict(mode=0, errors=0, warnings=0, timeout=1),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                MotorHealth(**kwargs)
        with self.assertRaises(ValueError):
            SourceIdentity("other", "x", 1)

    def test_fake_lifecycle_writes_only_after_accepted_actions(self):
        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
        station = FakeStation(core)
        expected = [command(spec.motor_id, mode=0) for spec in self.specs]

        self.assertFalse(station.check().accepted)
        self.assertFalse(station.stop().accepted)
        self.assertEqual(station.writes, [])

        self.assertTrue(station.connect().accepted)
        self.assertEqual(station.writes, expected)
        station.writes.clear()
        self.assertFalse(station.connect().accepted)
        self.assertEqual(station.writes, [])

        owner = station.claim("fixture")
        self.assertTrue(station.check().accepted)
        self.assertEqual(station.writes, expected)
        self.assertIs(core.snapshot().state, State.READY)
        station.writes.clear()
        self.assertTrue(station.arm(owner).accepted)
        self.assertIs(core.snapshot().state, State.ARMED)
        self.assertTrue(station.stop().accepted)
        self.assertEqual(station.writes, expected)
        self.assertIs(core.snapshot().state, State.STOPPED)

    def test_arm_requires_current_stop_feedback(self):
        core = core_at(self, State.READY)
        owner = core.snapshot().latest_owner
        self.assertTrue(core.receive(1, SAMPLE, MotorHealth(1, 0, 0, False)))
        before = core.snapshot()
        self.assertEqual(core.arm(owner).code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot(), before)
        self.assertTrue(core.receive(1, SAMPLE, HEALTHY_STOP))
        self.assertTrue(core.arm(owner))

    def test_check_requires_every_healthy_joint_in_stop_mode(self):
        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.begin_check().accepted)

        before = core.snapshot()
        rejected = core.checked()
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.OBSERVATIONS_INCOMPLETE)
        self.assertEqual(core.snapshot(), before)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        foc = MotorHealth(mode=1, errors=0, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, foc).accepted)
        before = core.snapshot()
        self.assertEqual(core.checked().code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot(), before)

        unhealthy = MotorHealth(mode=0, errors=0, warnings=1, timeout=False)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, unhealthy).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        before = core.snapshot()
        rejected = core.checked()
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.INVALID_STATE)
        self.assertEqual(core.snapshot(), before)

        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP))
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertTrue(core.begin_check(acknowledge_fault=True))
        self.assertTrue(core.snapshot().fault_latched)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP))
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        self.assertIs(core.snapshot().state, State.READY)

    def test_fault_survives_stop_disconnect_reconnect_and_healthy_packets(self):
        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("fixture")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner).accepted)

        bad_health = MotorHealth(mode=0, errors=4, warnings=2, timeout=True)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, bad_health).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        station.writes.clear()
        self.assertTrue(station.stop().accepted)
        self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertTrue(core.snapshot().fault_latched)

        self.assertTrue(station.disconnect().accepted)
        disconnected = core.snapshot()
        self.assertIs(disconnected.state, State.DISCONNECTED)
        self.assertTrue(disconnected.fault_latched)
        self.assertTrue(all(not joint.valid for joint in disconnected.joints))
        self.assertIsNone(disconnected.source)

        self.assertTrue(station.connect().accepted)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.snapshot().fault_latched)
        before = core.snapshot()
        self.assertEqual(core.begin_check().code, DecisionCode.FAULT_ACK_REQUIRED)
        self.assertEqual(core.snapshot(), before)

        station.writes.clear()
        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        self.assertEqual(station.writes, [command(spec.motor_id, mode=0) for spec in self.specs])
        self.assertIs(core.snapshot().state, State.READY)
        self.assertFalse(core.snapshot().fault_latched)

    def test_disconnect_and_new_connection_invalidate_observations(self):
        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        prior = core.snapshot()
        self.assertTrue(prior.joints[0].valid)

        self.assertTrue(core.disconnect().accepted)
        self.assertTrue(all(not joint.valid for joint in core.snapshot().joints))
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SourceIdentity("fixture", "controller-test", 2)).accepted)
        self.assertTrue(all(not joint.valid for joint in core.snapshot().joints))
        self.assertTrue(prior.joints[0].valid)

    def test_snapshots_are_immutable_owned_values(self):
        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=1.0)
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        before = core.snapshot()
        self.assertIsInstance(before.joints, tuple)
        self.assertIsInstance(before.joint_names, tuple)
        self.assertIsInstance(before.dispatch_attempts, tuple)
        self.assertEqual(before.dispatch_attempts, (None, None))
        self.assertFalse(hasattr(core, "pending_target"))
        self.assertFalse(hasattr(before, "pending_target"))

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        after = core.snapshot()
        self.assertFalse(before.joints[0].valid)
        self.assertTrue(after.joints[0].valid)
        with self.assertRaises(FrozenInstanceError):
            after.state = State.FAULT
        with self.assertRaises(FrozenInstanceError):
            after.joints[0].health = HEALTHY_STOP
        with self.assertRaises(TypeError):
            after.joints[0] = before.joints[0]
        with self.assertRaises(TypeError):
            after.dispatch_attempts[0] = before.dispatch_attempts[0]

    def test_invalid_transition_matrix_preserves_snapshot(self):
        rejected = {
            State.DISCONNECTED: ("connected", "begin_check", "checked", "arm", "stop"),
            State.CONNECTING: ("begin_connect", "begin_check", "checked", "arm", "stop"),
            State.CONNECTED: ("begin_connect", "connected", "checked", "arm"),
            State.CHECKING: ("begin_connect", "connected", "begin_check", "arm"),
            State.READY: ("begin_connect", "connected", "begin_check", "checked"),
            State.ARMED: ("begin_connect", "connected", "begin_check", "checked", "arm"),
            State.MOVING: ("begin_connect", "connected", "begin_check", "checked", "arm"),
            State.STOPPED: ("begin_connect", "connected", "checked", "arm"),
            State.FAULT: ("begin_connect", "connected", "begin_check", "checked", "arm"),
        }

        for state, events in rejected.items():
            for event in events + ("wrong_joint",):
                with self.subTest(state=state, event=event):
                    core = core_at(self, state)
                    station = FakeStation(core)
                    before = core.snapshot()
                    arm_owner = core.snapshot().current_owner or OwnerToken(
                        "matrix-epoch", 1, "matrix-client"
                    )
                    action = {
                        "begin_connect": station.connect,
                        "connected": lambda: core.connected(SOURCE),
                        "begin_check": station.check,
                        "checked": core.checked,
                        "arm": lambda: core.arm(arm_owner),
                        "stop": station.stop,
                        "wrong_joint": lambda: core.receive(14, SAMPLE, HEALTHY_STOP),
                    }[event]
                    decision = action()
                    self.assertFalse(decision.accepted)
                    self.assertFalse(decision)
                    self.assertEqual(station.writes, [])
                    self.assertEqual(core.snapshot(), before)


class JointFaultTests(unittest.TestCase):
    def setUp(self):
        self.specs = (
            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
        )

    def _ready_core(self, clock=None, *, feedback_max_age_s=1.0):
        if clock is None:
            clock = DeterministicClock(0.0)
        core = JointCore(
            self.specs,
            clock=clock,
            feedback_max_age_s=feedback_max_age_s,
            max_reference_gap_s=1.0,
        )
        self.assertTrue(core.begin_connect().accepted)
        self.assertTrue(core.connected(SOURCE).accepted)
        core.claim_owner("fixture")
        self.assertTrue(core.begin_check().accepted)
        for spec in self.specs:
            self.assertTrue(core.receive(spec.motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertTrue(core.checked().accepted)
        return core

    def test_stale_j2_attributes_only_stale_joint_with_refreshed_j1(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock, feedback_max_age_s=1.0)
        self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)
        self.assertIs(core.snapshot().state, State.ARMED)

        clock.value = 0.8
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)

        clock.value = 1.1
        self.assertTrue(core.tick().accepted)
        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.affected_joints, ("J2",))
        self.assertEqual(len(snap.faults), 1)

        j2_fault = snap.faults[0]
        self.assertEqual(j2_fault.name, "J2")
        self.assertEqual(j2_fault.motor_id, 1)
        self.assertTrue(j2_fault.stale)
        self.assertEqual(j2_fault.errors, 0)
        self.assertEqual(j2_fault.warnings, 0)
        self.assertFalse(j2_fault.timeout)
        self.assertIsNone(j2_fault.communication_error)

        self.assertNotIn("J1", snap.affected_joints)
        self.assertEqual(snap.joints[0].received_at, 0.8)
        self.assertEqual(snap.joints[1].received_at, 0.0)

    def test_unknown_bits_and_32bit_error_mask_retained(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock)
        self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)

        unknown_errors = 0x80000004
        status = MotorHealth(mode=0, errors=unknown_errors, warnings=5, timeout=True)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, status).accepted)

        snap = core.snapshot()
        self.assertIs(snap.state, State.FAULT)
        self.assertEqual(snap.affected_joints, ("J1",))
        j1_fault = snap.faults[0]
        self.assertEqual(j1_fault.errors, unknown_errors)
        self.assertEqual(j1_fault.errors & 0x80000000, 0x80000000)
        self.assertEqual(j1_fault.warnings, 5)
        self.assertTrue(j1_fault.timeout)
        self.assertFalse(j1_fault.stale)

        for kwargs in (
            dict(mode=0, errors=-1, warnings=0, timeout=False),
            dict(mode=0, errors=0x1_0000_0000, warnings=0, timeout=False),
            dict(mode=0, errors=0, warnings=-1, timeout=False),
            dict(mode=0, errors=0, warnings=8, timeout=False),
            dict(mode=0, errors=0, warnings=0, timeout="True"),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                MotorHealth(**kwargs)

        for kwargs in (
            dict(name="J1", motor_id=0, errors=-1),
            dict(name="J1", motor_id=0, errors=0x1_0000_0000),
            dict(name="J1", motor_id=0, warnings=-1),
            dict(name="J1", motor_id=0, warnings=8),
            dict(name="J1", motor_id=0, timeout=1),
            dict(name="J1", motor_id=0, stale=1),
            dict(name="", motor_id=0),
            dict(name="J1", motor_id=15),
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                JointFault(**kwargs)

    def test_healthy_after_fault_preserves_latched_attribution(self):
        core = self._ready_core()
        self.assertTrue(core.arm(core.snapshot().latest_owner).accepted)

        unhealthy = MotorHealth(mode=0, errors=0x02, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, unhealthy).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))
        self.assertEqual(core.snapshot().faults[0].errors, 0x02)

        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        snap = core.snapshot()

        self.assertTrue(snap.joints[0].healthy)
        self.assertEqual(snap.joints[0].errors, 0)
        self.assertEqual(snap.joints[0].health.errors, 0)

        self.assertIs(snap.state, State.FAULT)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.affected_joints, ("J1",))
        self.assertEqual(len(snap.faults), 1)
        self.assertEqual(snap.faults[0].errors, 0x02)
        self.assertNotEqual(snap.faults[0].errors, 0)

    def test_multiple_faults_on_joint_preserves_prior_flags_with_bounded_storage(self):
        core = self._ready_core()

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x01, warnings=1, timeout=False),
        ).accepted)

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x04, warnings=2, timeout=True),
        ).accepted)

        self.assertTrue(core.communication_failed(
            self.specs[0].motor_id,
            CommunicationFailure.DRIVER_FAILURE,
        ).accepted)

        snap = core.snapshot()
        self.assertEqual(len(snap.faults), 1)
        j1_fault = snap.faults[0]
        self.assertEqual(j1_fault.name, "J1")
        self.assertEqual(j1_fault.errors, 0x05)
        self.assertEqual(j1_fault.warnings, 3)
        self.assertTrue(j1_fault.timeout)
        self.assertEqual(j1_fault.communication_error, CommunicationFailure.DRIVER_FAILURE)
        self.assertIn(CommunicationFailure.DRIVER_FAILURE, j1_fault.communication_errors)

        for _ in range(10):
            self.assertTrue(core.receive(
                self.specs[0].motor_id,
                SAMPLE,
                MotorHealth(mode=0, errors=0x02, warnings=0, timeout=False),
            ).accepted)
        self.assertEqual(len(core.snapshot().faults), 1)
        self.assertEqual(core.snapshot().faults[0].errors, 0x07)

    def test_communication_failures_with_fixed_enum_codes(self):
        for code in (
            CommunicationFailure.TIMEOUT,
            CommunicationFailure.INVALID_FEEDBACK,
            CommunicationFailure.DRIVER_FAILURE,
        ):
            with self.subTest(code=code):
                core = self._ready_core()
                decision = core.communication_failed(self.specs[0].motor_id, code)
                self.assertTrue(decision.accepted)
                snap = core.snapshot()
                self.assertIs(snap.state, State.FAULT)
                self.assertEqual(snap.affected_joints, ("J1",))
                fault = snap.faults[0]
                self.assertEqual(fault.communication_error, code)
                self.assertFalse(fault.timeout)
                self.assertEqual(snap.joints[0].communication_error, code)
                self.assertFalse(snap.joints[0].healthy)

        core = self._ready_core()
        self.assertTrue(core.communication_failed(self.specs[1].motor_id, CommunicationFailure.INVALID_FEEDBACK).accepted)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))
        self.assertEqual(core.snapshot().faults[0].communication_error, CommunicationFailure.INVALID_FEEDBACK)

    def test_current_communication_status_clears_without_erasing_cause(self):
        core = self._ready_core()
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT))
        before = core.snapshot()
        self.assertTrue(core.receive(0, SAMPLE, HEALTHY_STOP))
        after = core.snapshot()
        self.assertTrue(after.joints[0].healthy)
        self.assertIsNone(after.joints[0].communication_error)
        self.assertEqual(after.faults, before.faults)
        self.assertIs(after.state, State.FAULT)

    def test_fault_record_requires_bounded_consistent_communication_codes(self):
        a, b = CommunicationFailure.TIMEOUT, CommunicationFailure.DRIVER_FAILURE
        for kwargs in (dict(communication_error=a, communication_errors=(b,)),
                       dict(communication_errors=(a, a)),
                       dict(communication_errors=(a,) * 4)):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                JointFault("J1", 0, **kwargs)
        record = JointFault("J1", 0, communication_error=a, communication_errors=(a, b))
        self.assertIs(record.communication_error, a)
        self.assertEqual(record.communication_errors, (a, b))

    def test_unknown_ids_and_invalid_codes_reject_unchanged(self):
        core = self._ready_core()
        before = core.snapshot()

        self.assertEqual(core.communication_failed(0, "timeout").code,
                         DecisionCode.INVALID_ARGUMENT)
        self.assertEqual(core.snapshot(), before)

        rejected_id = core.communication_failed(14, CommunicationFailure.TIMEOUT)
        self.assertFalse(rejected_id)
        self.assertEqual(rejected_id.code, DecisionCode.UNKNOWN_JOINT)
        self.assertEqual(core.snapshot(), before)

        self.assertEqual(
            core.communication_failed(True, CommunicationFailure.TIMEOUT).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed("0", CommunicationFailure.TIMEOUT).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(core.snapshot(), before)

        self.assertEqual(
            core.communication_failed(0, "unrecognized_failure").code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, RuntimeError("comm timeout")).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, 999).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(
            core.communication_failed(0, None).code,
            DecisionCode.INVALID_ARGUMENT,
        )
        self.assertEqual(core.snapshot(), before)

    def test_failed_recovery_retains_causes(self):
        clock = DeterministicClock(0.0)
        core = self._ready_core(clock, feedback_max_age_s=1.0)
        owner = core.snapshot().latest_owner
        self.assertTrue(core.arm(owner).accepted)

        self.assertTrue(core.receive(
            self.specs[0].motor_id,
            SAMPLE,
            MotorHealth(mode=0, errors=0x04, warnings=0, timeout=False),
        ).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        rejected = core.begin_check(acknowledge_fault=False)
        self.assertFalse(rejected)
        self.assertEqual(rejected.code, DecisionCode.FAULT_ACK_REQUIRED)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
        self.assertIs(core.snapshot().state, State.CHECKING)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertEqual(core.checked().code, DecisionCode.OBSERVATIONS_INCOMPLETE)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        non_stop = MotorHealth(mode=1, errors=0, warnings=0, timeout=False)
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, non_stop).accepted)
        self.assertTrue(core.receive(self.specs[1].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertEqual(core.checked().code, DecisionCode.NOT_STOPPED)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        clock.value = 2.0
        self.assertTrue(core.receive(self.specs[0].motor_id, SAMPLE, HEALTHY_STOP).accepted)
        self.assertEqual(core.checked().code, DecisionCode.STALE_FEEDBACK)
        self.assertEqual(core.snapshot().affected_joints, ("J1",))

        self.assertEqual(core.arm(owner).code, DecisionCode.INVALID_STATE)

    def test_successful_recovery_clears_fault_causes(self):
        clock = DeterministicClock(0.0)
        core = JointCore(self.specs, clock=clock, feedback_max_age_s=1.0, max_reference_gap_s=1.0)
        station = FakeStation(core)
        self.assertTrue(station.connect().accepted)
        owner = station.claim("fixture")
        self.assertTrue(station.check().accepted)
        self.assertTrue(station.arm(owner).accepted)

        self.assertTrue(core.communication_failed(
            self.specs[1].motor_id,
            CommunicationFailure.TIMEOUT,
        ).accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.stop().accepted)
        self.assertIs(core.snapshot().state, State.FAULT)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.disconnect().accepted)
        self.assertIs(core.snapshot().state, State.DISCONNECTED)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.connect().accepted)
        self.assertIs(core.snapshot().state, State.CONNECTED)
        self.assertTrue(core.snapshot().fault_latched)
        self.assertEqual(core.snapshot().affected_joints, ("J2",))

        self.assertTrue(station.check(acknowledge_fault=True).accepted)
        snap = core.snapshot()
        self.assertIs(snap.state, State.READY)
        self.assertFalse(snap.fault_latched)
        self.assertEqual(snap.faults, ())
        self.assertEqual(snap.affected_joints, ())

    def test_independent_second_core_unchanged_by_fault(self):
        specs2 = (
            JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
            JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
        )
        clock = DeterministicClock(0.0)
        core1 = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
        core2 = JointCore(specs2, clock=clock, max_reference_gap_s=1.0)

        station1 = FakeStation(core1)
        station2 = FakeStation(core2)
        self.assertTrue(station1.connect().accepted)
        owner1 = station1.claim("fixture-1")
        self.assertTrue(station1.check().accepted)
        self.assertTrue(station1.arm(owner1).accepted)

        self.assertTrue(station2.connect().accepted)
        owner2 = station2.claim("fixture-2")
        self.assertTrue(station2.check().accepted)
        self.assertTrue(station2.arm(owner2).accepted)

        self.assertTrue(core1.communication_failed(
            self.specs[0].motor_id,
            CommunicationFailure.DRIVER_FAILURE,
        ).accepted)
        snap1 = core1.snapshot()
        self.assertIs(snap1.state, State.FAULT)
        self.assertTrue(snap1.fault_latched)
        self.assertEqual(snap1.affected_joints, ("J1",))

        snap2 = core2.snapshot()
        self.assertIs(snap2.state, State.ARMED)
        self.assertFalse(snap2.fault_latched)
        self.assertEqual(snap2.faults, ())
        self.assertEqual(snap2.affected_joints, ())
        self.assertTrue(station2.stop().accepted)
        self.assertIs(core2.snapshot().state, State.STOPPED)

    def test_immutability_of_fault_records_and_snapshot_collections(self):
        fault = JointFault("J1", 0, errors=1, warnings=2, timeout=True)
        with self.assertRaises(FrozenInstanceError):
            fault.errors = 0
        with self.assertRaises(FrozenInstanceError):
            fault.name = "other"

        core = self._ready_core()
        self.assertTrue(core.communication_failed(0, CommunicationFailure.TIMEOUT).accepted)
        snap = core.snapshot()

        self.assertIsInstance(snap.faults, tuple)
        self.assertIsInstance(snap.affected_joints, tuple)
        with self.assertRaises(FrozenInstanceError):
            snap.faults[0].timeout = False
        with self.assertRaises(TypeError):
            snap.faults[0] = fault
        with self.assertRaises(TypeError):
            snap.affected_joints[0] = "J2"







if __name__ == "__main__":
    unittest.main()

```

## Complete docs/joint-api.md
```
# Joint mapping

The bench GUI and CLI use actuator output units. The mapping API converts external joint units before packet encoding. It does not open a serial port.

```python
from joint_mapping import JointMap, JointTarget, OutputSample

mapping = JointMap(reduction=3, direction=-1, zero_output_rad=0.25)
output = mapping.to_output(JointTarget(-0.5, 2, 12, 36, 9))
joint = mapping.from_output(OutputSample(output.q_rad, output.rpm, output.tau_nm))
```

This example produces an output position of 1.75 rad, speed of about -57.2958 rpm, torque of -4 Nm, Kp of 4 and Kd of 1. Reverse conversion recovers the original position, speed and torque. The resulting torque exceeds the bench encoder's ±3.5 Nm policy, so encoding it rejects the command. Mapping never clips a value to make it pass.

`JointTarget` uses rad, rad/s and Nm. `OutputTarget` uses rad, rpm and Nm. The offset is in actuator output radians. The internal motor reduction stays inside the codec. Ideal gain conversion assumes compatible stiffness and damping definitions. Friction, backlash, efficiency and physical calibration remain unmeasured.

Run a single offline acceptance check from the repository root:

```sh
.venv/bin/python -B scripts/check_milestone.py B11
```

The command prints the path to its receipt and raw logs under `evidence/runs`. The test checks ratios 1, 3 and 6 in both directions, nonzero offsets, independent numeric anchors and invalid values.

## Passive port inspection

```python
from im6014_port import PortConfig, inspect_port
from spin_5rpm import PORT

report = inspect_port(PortConfig(PORT, 6_000_000), ports=())
```

`ports=()` makes this example use only the configured by-id basename. The report names its evidence source and does not establish communication with the motor. Normal inspection can also read passive OS enumeration metadata. Known wrong serial numbers or interfaces reject with expected and observed values. Unknown metadata stays explicitly unverified.

For an alternate adapter route, set both `expected_serial=None` and `expected_channel=None`. This removes the FTDI identity assertion. It does not bypass later device ownership checks or establish motor communication. The bench GUI and CLI default to the recorded FTDI serial and interface 3.

## Diagnostic capture

`PacketCapture` holds at most 256 records by default. Each record contains capped packet prefixes, allowlisted decoded fields, a fixed outcome code, and explicit source and connection metadata. Exported snapshots own their lists and dictionaries. Exception messages, environment values and arbitrary serial-object fields are excluded. An unavailable or regressing capture end clock exports `ended_s=None` and preserves the exchange result or original error. An invalid start clock rejects before exchange.

The GUI includes its ring in the existing JSON snapshot. The CLI enables it in `main`; direct `run(bus, args, log)` callers retain the original uncaptured behavior. Tests opt in with `fixture` provenance. A `physical` label records the caller's declaration and does not independently prove device identity.

## Cooperating bus ownership

Both real bench open sites use `open_managed_port(PortConfig(...), serial_factory=...)`. It checks passive identity before device acquisition and construction. A successful result owns `bus`; call `close()` and inspect its boolean result. `False` means ownership remains held because closure was not confirmed. Retry cleanup before reconnecting. A context manager raises `PortCloseError` on an otherwise normal exit with unconfirmed close; its `managed_port` remains available for cleanup.

This API opens hardware when given a motor path. Its acceptance tests use Linux PTYs exclusively. The device lease coordinates these workbench clients; it cannot exclude a raw client that ignores the lock.

When passive identity metadata is incomplete, the default route reports it as unverified and still permits device acquisition; known mismatches reject. The serial factory must expose the pyserial `is_open` status for confirmed cleanup. A missing status retains the lease. Neither passive inspection nor opening establishes CRC-valid motor communication.

## Controller lifecycle and freshness

`JointCore` owns a fixed ordered set of unique `JointSpec` names and motor IDs. Its states and immutable `Snapshot` are transport-free; `connected(SourceIdentity(...))` records a declaration and never opens hardware. `Decision` evaluates to its `accepted` value.

Connect, check, and arm are distinct steps. `receive(id, JointSample(...), MotorHealth(...))` stamps each valid observation with the core's monotonic clock. `checked()` needs fresh healthy Stop-mode feedback from every active joint. `arm()` requires fresh healthy Stop-mode feedback. The configurable maximum age defaults to 0.5 seconds; this software policy is not a measured loop-rate guarantee. Snapshot `feedback_ages_s` preserves joint order and uses `None` before receipt. Timestamp zero is valid. Unknown IDs and invalid records do not refresh timestamps.

Call `tick()` to fault READY, ARMED, or MOVING when feedback ages out. Stop, disconnect/reconnect, and healthy packets do not clear a fault latch. Recovery requires `begin_check(acknowledge_fault=True)` followed by fresh healthy Stop feedback and successful `checked()`. The check clears observations first. Target dispatch, attributed fault records and command ordering are the next milestones.

## Attributed faults

`Snapshot.faults` holds immutable `JointFault` records in configured joint order. `affected_joints` derives their names. Error and warning masks accumulate by bitwise OR, and watchdog timeout and stale flags latch. Communication codes are fixed `CommunicationFailure` enum values; they do not imply an actuator watchdog timeout. Current healthy feedback clears the current communication observation while the cause remains latched. Stop and reconnect retain causes. Only an explicitly acknowledged, complete, fresh, healthy Stop check clears them. Each core stores at most one record per configured joint and a unique first-occurrence union of fixed communication codes; its size is bounded by the finite enum. `communication_error` is the most recent cause; `communication_errors` is not a chronological event history. A supplied most-recent code must belong to that union.

When opening fails and cleanup cannot confirm closure, `open_managed_port` raises `PortCloseError` with `managed_port` for retry and the original error as `__cause__`. Context exit uses the same exception when closure fails, retaining any body exception as its cause. If cleanup succeeds, the original exception propagates normally.

## Latest target and command expiry

`Target(sequence, joints, window, owner)` contains an immutable complete tuple of `JointTarget` values in configured order, a required station-issued `IntentWindow(id, created_at_s, expires_at_s)`, and the current `OwnerToken`. `JointCore.issue_window(valid_for_s)` issues the latest offered window with a monotonic ID and bounded duration (`max_window_s`, default 1.0s). `submit_target` first expires or faults an existing goal as needed, then checks the full owner token, validates the incoming window against the latest offered window, checks expiry (exact equality with expiry is expired), checks mapped output codec representability, and enforces monotonic command sequence ordering before admitting the goal. A rejected replacement keeps an existing goal only while that goal remains valid.

`consume_target` is deleted in favor of explicit refresh lifecycle: `prepare_refresh()`, `claim_dispatch(plan_id, index)`, and `dispatch_result(plan_id, index, result)`. An admitted goal is refreshed repeatedly until its window expires. Preparing a plan proposes a refresh vector without dispatching. Each `RefreshPlan` contains an exact-count tuple of immutable, validated canonical packet bytes; the adapter writes those bytes unchanged. `joint_targets` records the actual full joint reference decoded from those packets, while `target` preserves the admitted request. `claim_dispatch` verifies freshness, health, goal expiry, and ordered joint index immediately before each write. Only one claim may await an outcome; the core blocks another joint claim, plan preparation, and reconnect until the station reports that claim's actual transport result. Stop, expiry, target replacement, disconnect, or fault can invalidate the plan without discarding that in-flight receipt. `exchange` reports the write result once after the driver outcome; successful returns are deadline-checked before feedback. If the deadline expires after the pre-write hook grants a claim but before `bus.write`, it reports `WriteResult.PREWRITE_DEADLINE`: the software made no write call for that claim. This does not establish motor state or physical protection. `WriteResult.PARTIAL` means the driver returned a positive short count. `WriteResult.FAILED` means the driver raised or returned an invalid count, so byte delivery may be unknown. `Snapshot.dispatch_attempts` holds the latest outcome per joint. `dispatch_result` commits a dispatched record only for a complete write. A dispatched record's `dispatched_at_s` is the valid claim/write start time, not a fabricated completion timestamp. A complete write followed by invalid or regressing core time preserves the complete record and attempt, then faults with `CommunicationFailure.CLOCK_FAILURE` without restoring motion. `WriteResult.PREWRITE_DEADLINE` faults with `CommunicationFailure.PREWRITE_DEADLINE`; `PARTIAL` and `FAILED` fault with `DRIVER_FAILURE`, preserving any prior complete record. A late receipt for an invalidated plan is recorded but cannot restore motion or change `DISCONNECTED`; once it settles, an explicit reconnect is allowed. Reconnect still requires a new owner, acknowledged fresh healthy Stop check, and explicit arm. When an admitted goal expires, housekeeping withdraws it, invalidates pending plans, and disarms the core to `STOPPED` (latched fault preserved), requiring a new check and arm cycle. Sequence watermarks survive consumption, stop, fault, and disconnect.

### Offline controller example

```python
from joint_contract import IntentWindow, JointSpec, MotorHealth, OwnerToken, SourceIdentity, State, Target, WriteResult
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget

clock_time = [0.0]
core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, 40.0, 1.0, 50.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
assert core.begin_connect()
assert core.connected(SourceIdentity("fixture", "example", 1))
owner = core.claim_owner("example-client")
assert core.begin_check()
assert core.receive(0, JointSample(0, 0, 0), MotorHealth(0, 0, 0, False))
assert core.checked()
assert core.arm(owner)
window = core.issue_window(0.5)
target = Target(6, (JointTarget(.1, 1, -6, 18, 4.5),), window=window, owner=owner)
assert core.submit_target(target)
clock_time[0] += 0.05
plan = core.prepare_refresh()
assert plan is not None
assert core.claim_dispatch(plan.plan_id, 0)
assert core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
assert core.snapshot().state is State.MOVING
assert core.snapshot().dispatched_records[0].sequence == 6
assert core.stop()
assert core.snapshot().last_sequence == 6
```

This example performs no serial operations. A station adapter must validate its own physical setup and own packet transmission when later milestones add one.

## Core and ownership limits

The injected core clock must be finite and monotonic. Invalid or regressing time rejects operations that need a fresh gate; snapshots also require that clock contract. If the clock callback raises or returns invalid or regressing time at the final write gate, the core stops and revokes motion authority before granting the claim, then propagates the clock error. Repairing the clock does not restore the owner, goal, or prepared plan. If a complete write receipt arrives after its end clock becomes invalid, the core preserves that known write and claim timestamp, then latches `CommunicationFailure.CLOCK_FAILURE` and withdraws motion until acknowledged recovery. The default clock is `time.monotonic`. Sequence `2**64 - 1` exhausts that core's stream. Start a new core for a new stream; reconnecting or acknowledging a fault never resets ordering.

### Owner generations

`JointCore` generates a fresh unpredictable random 16-byte hex epoch per instance/process via `secrets.token_hex(16)` with no persisted global state. A monotonic generation counter starts at 1 and ranges through uint64. `claim_owner(connection_id)` returns a frozen `OwnerToken(epoch, generation, connection_id)`. `connection_id` is an immutable non-empty string bounded to 64 characters and identifies the client connection; `SourceIdentity` separately identifies the motor connection. The core assumes trusted station callers; the station/server binds its actual client connection identity rather than trusting unverified JSON payload attributes, with no authentication claims beyond that boundary.

`arm(owner)` and `Target` require an exact `OwnerToken` class and matching immutable epoch, generation, and connection ID fields. Token-bearing boundary records reject subclasses. An owner mismatch returns `DecisionCode.INVALID_OWNER` after lifecycle state checks. Stop, any latched joint fault, disconnect, expired goals, and explicit takeover revoke active authority (`current_owner` becomes `None`), withdraw pending goals/plans and offered windows, and never auto-rearm. A claim during checking, ready, armed, or moving state, or a takeover of an existing owner on a connected core, places the core in `STOPPED` (while preserving `FAULT` and `DISCONNECTED`), requiring a fresh stop check and explicit arm call with the new token. Reconnecting requires claiming a fresh generation. Fault recovery also requires a new claim before checking and arming.

Durable attempt and dispatched records retain the original `OwnerToken` stamped at plan creation; an in-flight receipt completing after authority revocation preserves the actual write record with its original owner attribution without transitioning the core to `MOVING`. `Snapshot.latest_owner` retains the most recently issued token after revocation, while `Snapshot.current_owner` is `None` unless that token currently has authority. Bounded O(1) storage retains only these two tokens. When the uint64 generation space is exhausted, a new claim revokes authority, stops the core (or preserves `FAULT`/`DISCONNECTED`), and raises `OverflowError` without wrapping; start a fresh core to obtain a new epoch.

The fixed per-user lock namespace under `/tmp` coordinates cooperating processes. A hostile local user can pre-create the name and deny access; validation fails closed. An administrator must remove a foreign-owned obstruction. Lockfiles persist to preserve flock inode identity, including after device-number reuse. Do not delete them while clients may be running. No automatic pruning or hostile-local-user availability guarantee is supplied.

## Joint Position Limits

Every `JointSpec` requires explicit, immutable, finite position bounds `q_min_rad <= q_max_rad` and non-empty `limits_provenance` documenting the software threshold origin. These are fixture software limits, not physical calibration. Position requests are evaluated against inclusive bounds: exact lower and upper endpoints are accepted. Requests outside them return `DecisionCode.POSITION_OUT_OF_BOUNDS` and preserve any still-valid admitted goal, sequence watermark, owner, and window. Mapped requests must first pass the ordinary canonical codec; an unencodable mapped request returns `INVALID_ARGUMENT` and is never clamped into range. A fresh measured position outside the bounds, including during `CHECKING`, latches the attributed `JointFault.position_limit` cause and faults the core before motion. Simultaneous motor-health causes remain in the same joint fault record. `claim_dispatch` rechecks every fresh measured position and the actual prepared reference before each write. Recovery requires a new owner and an explicitly acknowledged fresh healthy Stop check with every measured position within the inclusive bounds; incoming targets cannot clear a fault. The codec owns the bounded raw position grid search through a monotonic decoded-domain callback and direction. It selects an inward representable endpoint, serializes that exact raw integer without float re-encoding, and decodes the complete canonical packet to populate actual position, velocity, feedforward, and gain reference fields. Stop packets are valid decoder inputs; mode, ID, watchdog, reserved byte, header, and CRC are checked. Repeated refreshes write the cached packet bytes unchanged.

## Speed- and acceleration-bounded trajectory reference and gap policy

Every `JointSpec` requires an explicit, finite positive maximum reference speed `v_max_rad_s` and maximum reference acceleration `a_max_rad_s2`. `JointCore` requires an explicit, finite positive `max_reference_gap_s` policy. All values describe software fixture policy unless calibrated separately.

Upon a successful healthy checked Stop, the controller initializes an unemitted trajectory reference for each joint with position equal to the checked feedback sample, zero exact velocity derivative, and timestamp equal to the sample time (`is_emitted=False`). The anchor has no cached command and cannot dispatch at $h=0$.

Preparing a refresh plan does not advance confirmed history. A `RefreshPlan` always carries one proposed reference, decoded command target, and immutable canonical packet per joint. Only a complete actual write commits that joint's proposed reference. Failed or partial writes leave its prior reference unchanged. Reference `sample_time_s` is the preparation time; `JointDispatchedRecord.dispatched_at_s` remains the actual claim/write start time.

For $h=0$, a previously emitted reference can refresh only when the admitted joint goal is unchanged. The core reuses that reference, decoded target, and exact packet bytes, including its prior position-step derivative and feedforward values; it does not encode the values again or advance their sample time. A changed goal at $h=0$ is rejected with an attributed constraint fault. If $h > \text{max\_reference\_gap\_s}$, motion is withdrawn and the controller drops to `STOPPED` (`REFERENCE_GAP_EXCEEDED`).

For $h>0$, the pure reference step intersects the speed interval $[-V,V]$, acceleration interval $[v_{\text{prev}}-A\cdot h, v_{\text{prev}}+A\cdot h]$, and position interval $[(q_{\min}-q_{\text{prev}})/h,(q_{\max}-q_{\text{prev}})/h]$. It projects the one-step objective $v_{\text{desired}} = (q_{\text{goal}}-q_{\text{prev}})/h + \dot{q}_{\text{goal}}$ into that closed intersection. The objective combines the requested position correction over this sample with velocity feedforward; it is not a continuous trajectory law.

The selected endpoint is projected inward to a representable point on the canonical codec grid. Position-step velocity is the exact rational $(q_{\text{emitted,next}}-q_{\text{emitted,prev}})/h$, where the stored finite float values and computed float difference $h$ are interpreted exactly. The independently decoded wire velocity feedforward has its own history and must satisfy both $|v|\leq V$ and $|v-v_{\text{prev,enc}}|\leq A\cdot h$. Neither stream is substituted for the other, and wire velocity is not used in position algebra. Reversal preserves previous velocity and crosses zero under the same acceleration bound.

Immediately before a positive-cadence write claim, the core recomputes the position-step derivative from the proposed and confirmed decoded endpoint positions and requires exact equality with the stored rational derivative. A mismatch latches an attributed constraint fault and Stops before claiming the write. At $h=0$, the existing exact cached-reference, decoded-target, and packet comparison remains the replay rule.

An exactly zero objective asks for no net position correction after combining position error and velocity feedforward. The controller still projects zero into the feasible interval, so a nonzero previous derivative can require continued bounded motion while decelerating; a stationary reference is possible only when zero is feasible. For a nonzero objective, if no representable position step satisfies the closed bounds, the controller produces no mode-1 write and Stops with `DecisionCode.CONSTRAINT_VIOLATION`, attributed to each joint whose shaping failed. It does not carry hidden fractional motion or relax a bound. These are samplewise software reference limits; they do not promise a continuous motor trajectory, physical acceleration, or certified braking.

## Measured position lead bound

Every `JointSpec` requires an explicit, finite positive `max_lead_rad`. This software bound limits how far any requested goal or emitted trajectory reference can lead the latest fresh measured joint position.

At target admission, the controller checks each joint request against the closed interval $[q_{\text{meas}} - \text{lead}, q_{\text{meas}} + \text{lead}]$ using the latest fresh observation. Admission and zero-cadence replay compare the exact rational values of the normalized finite binary floats; endpoints are inclusive, with no tolerance or rounded float interval arithmetic. A requested position outside this bound is rejected with `DecisionCode.LEAD_OUT_OF_BOUNDS`, preserving any still-valid admitted goal and sequence watermark. If observation feedback is stale or missing, target submission is rejected with `DecisionCode.STALE_FEEDBACK`.

During reference shaping ($h>0$), the lead bound interval $[(q_{\text{meas}} - \text{lead} - q_{\text{prev}})/h, (q_{\text{meas}} + \text{lead} - q_{\text{prev}})/h]$ is intersected with the speed, acceleration, and position intervals. An empty intersection produces an attributed constraint fault and Stops motion. At $h=0$, refresh is permitted only if the previously emitted reference remains inside all bounds, including the fresh lead interval.

Immediately before a write claim, `verify_dispatch_claim` rechecks the current fresh measured position against the proposed decoded endpoint and confirmed reference. If feedback drifted after plan preparation such that the endpoint exceeds the lead bound, the write gate denies dispatch, latches an attributed constraint fault, and stops the controller.

## Effort prediction and monitoring bounds

Every `JointSpec` requires an explicit, finite positive peak effort limit `max_effort_nm` in joint Nm (also accessible via alias properties `peak_effort_nm` and `tau_max_nm`). All limits describe software fixture policy with explicit provenance, not physical motor calibration or thermal rating claims.

The effort predictor computes predicted torque in joint units:

$$\tau_{\text{pred}} = \tau_{\text{ff}} + k_p (q_{\text{ref}} - q_{\text{meas}}) + k_d (\dot{q}_{\text{ref}} - \dot{q}_{\text{meas}})$$

All terms are evaluated together without separate per-term clipping. The predictor uses actual encoded/quantized wire gains and command values mapped back once through canonical mapping (`map_decoded_command`), and combines them with current measured joint position and measured velocity (not a substituted reference derivative). Finite arithmetic overflow fails closed. Boundaries are inclusive: $|\tau| \le \text{limit}$ is permitted, while magnitude strictly exceeding the limit faults or rejects.

Enforcement occurs at three stages:
1. **Target admission (`submit_target`)**: The controller predicts effort for the admitted target against fresh feedback. If peak predicted effort exceeds `max_effort_nm`, the target is rejected with `DecisionCode.EFFORT_OUT_OF_BOUNDS`, preserving the existing admitted goal and sequence watermark.
2. **Reference preparation (`prepare_refresh` / `shape_reference_joint`)**: Peak effort prediction is checked for $h=0$ and $h>0$. If predicted effort violates the limit, reference generation fails closed with `DecisionCode.EFFORT_OUT_OF_BOUNDS`, latching an attributed `JointFault.effort_limit` and stopping the controller.
3. **Per-write gate (`claim_dispatch` / `verify_dispatch_claim`)**: Immediately before dispatching, the core rechecks predicted effort on the actual prepared command against fresh observations. Changes in feedback since plan preparation invalidate dispatch, latching `JointFault.effort_limit` and withdrawing motion.

Independent measured effort monitoring inspects every incoming observation in `receive()`, periodic `_housekeeping()`, `checked()`, `arm()`, `prepare_refresh()`, and `claim_dispatch()`. Any measured joint effort magnitude strictly exceeding `spec.max_effort_nm` immediately latches `JointFault.effort_limit` on that joint and drops the controller to `FAULT`. Recovery requires an explicit fresh healthy Stop check with all measured efforts within bounds (`begin_check(acknowledge_fault=True)` followed by `receive` and `checked`). Reconnects and incoming targets never clear latched faults.


```

## Complete authored patch (new test already fully supplied)
```diff
diff --git a/docs/joint-api.md b/docs/joint-api.md
index 88e5fa5..9edad82 100644
--- a/docs/joint-api.md
+++ b/docs/joint-api.md
@@ -77,7 +77,7 @@ from joint_controller import JointCore
 from joint_mapping import JointMap, JointSample, JointTarget
 
 clock_time = [0.0]
-core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, 40.0, 1.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
+core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, 40.0, 1.0, 50.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
 assert core.begin_connect()
 assert core.connected(SourceIdentity("fixture", "example", 1))
 owner = core.claim_owner("example-client")
@@ -146,3 +146,21 @@ At target admission, the controller checks each joint request against the closed
 During reference shaping ($h>0$), the lead bound interval $[(q_{\text{meas}} - \text{lead} - q_{\text{prev}})/h, (q_{\text{meas}} + \text{lead} - q_{\text{prev}})/h]$ is intersected with the speed, acceleration, and position intervals. An empty intersection produces an attributed constraint fault and Stops motion. At $h=0$, refresh is permitted only if the previously emitted reference remains inside all bounds, including the fresh lead interval.
 
 Immediately before a write claim, `verify_dispatch_claim` rechecks the current fresh measured position against the proposed decoded endpoint and confirmed reference. If feedback drifted after plan preparation such that the endpoint exceeds the lead bound, the write gate denies dispatch, latches an attributed constraint fault, and stops the controller.
+
+## Effort prediction and monitoring bounds
+
+Every `JointSpec` requires an explicit, finite positive peak effort limit `max_effort_nm` in joint Nm (also accessible via alias properties `peak_effort_nm` and `tau_max_nm`). All limits describe software fixture policy with explicit provenance, not physical motor calibration or thermal rating claims.
+
+The effort predictor computes predicted torque in joint units:
+
+$$\tau_{\text{pred}} = \tau_{\text{ff}} + k_p (q_{\text{ref}} - q_{\text{meas}}) + k_d (\dot{q}_{\text{ref}} - \dot{q}_{\text{meas}})$$
+
+All terms are evaluated together without separate per-term clipping. The predictor uses actual encoded/quantized wire gains and command values mapped back once through canonical mapping (`map_decoded_command`), and combines them with current measured joint position and measured velocity (not a substituted reference derivative). Finite arithmetic overflow fails closed. Boundaries are inclusive: $|\tau| \le \text{limit}$ is permitted, while magnitude strictly exceeding the limit faults or rejects.
+
+Enforcement occurs at three stages:
+1. **Target admission (`submit_target`)**: The controller predicts effort for the admitted target against fresh feedback. If peak predicted effort exceeds `max_effort_nm`, the target is rejected with `DecisionCode.EFFORT_OUT_OF_BOUNDS`, preserving the existing admitted goal and sequence watermark.
+2. **Reference preparation (`prepare_refresh` / `shape_reference_joint`)**: Peak effort prediction is checked for $h=0$ and $h>0$. If predicted effort violates the limit, reference generation fails closed with `DecisionCode.EFFORT_OUT_OF_BOUNDS`, latching an attributed `JointFault.effort_limit` and stopping the controller.
+3. **Per-write gate (`claim_dispatch` / `verify_dispatch_claim`)**: Immediately before dispatching, the core rechecks predicted effort on the actual prepared command against fresh observations. Changes in feedback since plan preparation invalidate dispatch, latching `JointFault.effort_limit` and withdrawing motion.
+
+Independent measured effort monitoring inspects every incoming observation in `receive()`, periodic `_housekeeping()`, `checked()`, `arm()`, `prepare_refresh()`, and `claim_dispatch()`. Any measured joint effort magnitude strictly exceeding `spec.max_effort_nm` immediately latches `JointFault.effort_limit` on that joint and drops the controller to `FAULT`. Recovery requires an explicit fresh healthy Stop check with all measured efforts within bounds (`begin_check(acknowledge_fault=True)` followed by `receive` and `checked`). Reconnects and incoming targets never clear latched faults.
+
diff --git a/joint_contract.py b/joint_contract.py
index c6dbeb4..d6cbb7c 100644
--- a/joint_contract.py
+++ b/joint_contract.py
@@ -44,6 +44,7 @@ class DecisionCode(str, Enum):
     POSITION_OUT_OF_BOUNDS = "position_out_of_bounds"
     SPEED_OUT_OF_BOUNDS = "speed_out_of_bounds"
     LEAD_OUT_OF_BOUNDS = "lead_out_of_bounds"
+    EFFORT_OUT_OF_BOUNDS = "effort_out_of_bounds"
     REFERENCE_GAP_EXCEEDED = "reference_gap_exceeded"
     CONSTRAINT_VIOLATION = "constraint_violation"
 
@@ -90,6 +91,7 @@ class JointSpec:
     v_max_rad_s: float
     a_max_rad_s2: float
     max_lead_rad: float
+    max_effort_nm: float
     limits_provenance: str
 
     def __post_init__(self) -> None:
@@ -141,6 +143,15 @@ class JointSpec:
         if not math.isfinite(max_lead_val) or max_lead_val <= 0.0:
             raise ValueError("max_lead_rad must be finite and positive")
 
+        if isinstance(self.max_effort_nm, bool) or not isinstance(self.max_effort_nm, (int, float)):
+            raise ValueError("max_effort_nm must be a finite positive real number")
+        try:
+            max_effort_val = float(self.max_effort_nm)
+        except (OverflowError, TypeError, ValueError) as exc:
+            raise ValueError("max_effort_nm must be finite") from exc
+        if not math.isfinite(max_effort_val) or max_effort_val <= 0.0:
+            raise ValueError("max_effort_nm must be finite and positive")
+
         if (
             type(self.limits_provenance) is not str
             or not self.limits_provenance.strip()
@@ -153,6 +164,16 @@ class JointSpec:
         object.__setattr__(self, "v_max_rad_s", v_max_val)
         object.__setattr__(self, "a_max_rad_s2", a_max_val)
         object.__setattr__(self, "max_lead_rad", max_lead_val)
+        object.__setattr__(self, "max_effort_nm", max_effort_val)
+
+    @property
+    def peak_effort_nm(self) -> float:
+        return self.max_effort_nm
+
+    @property
+    def tau_max_nm(self) -> float:
+        return self.max_effort_nm
+
 
 @dataclass(frozen=True)
 class JointFault:
@@ -166,6 +187,7 @@ class JointFault:
     communication_errors: tuple[CommunicationFailure, ...] = ()
     position_limit: bool = False
     speed_limit: bool = False
+    effort_limit: bool = False
     constraint_fault: bool = False
 
     def __post_init__(self) -> None:
@@ -191,6 +213,8 @@ class JointFault:
             raise ValueError("position_limit must be a bool")
         if type(self.speed_limit) is not bool:
             raise ValueError("speed_limit must be a bool")
+        if type(self.effort_limit) is not bool:
+            raise ValueError("effort_limit must be a bool")
         if type(self.constraint_fault) is not bool:
             raise ValueError("constraint_fault must be a bool")
 
diff --git a/joint_controller.py b/joint_controller.py
index fb116e4..1b6138a 100644
--- a/joint_controller.py
+++ b/joint_controller.py
@@ -244,6 +244,7 @@ class JointCore:
         stale: bool = False,
         position_limit: bool = False,
         speed_limit: bool = False,
+        effort_limit: bool = False,
         constraint_fault: bool = False,
     ) -> None:
         existing = self._faults.get(name) or JointFault(name, motor_id)
@@ -260,6 +261,7 @@ class JointCore:
             communication_errors=communication_errors,
             position_limit=existing.position_limit or position_limit,
             speed_limit=existing.speed_limit or speed_limit,
+            effort_limit=existing.effort_limit or effort_limit,
             constraint_fault=existing.constraint_fault or constraint_fault,
         )
         self._faults[name] = fault
@@ -311,6 +313,7 @@ class JointCore:
             stale_by_joint: list[bool] = []
             pos_outside_by_joint: list[bool] = []
             speed_outside_by_joint: list[bool] = []
+            effort_outside_by_joint: list[bool] = []
             for spec, joint in zip(self._specs, self._observations):
                 stale_by_joint.append(
                     not joint.valid
@@ -327,16 +330,22 @@ class JointCore:
                     and joint.sample is not None
                     and (abs(joint.sample.dq_rad_s) > spec.v_max_rad_s)
                 )
-            for spec, stale, pos_out, speed_out in zip(
-                self._specs, stale_by_joint, pos_outside_by_joint, speed_outside_by_joint
+                effort_outside_by_joint.append(
+                    joint.valid
+                    and joint.sample is not None
+                    and (abs(joint.sample.tau_nm) > spec.max_effort_nm)
+                )
+            for spec, stale, pos_out, speed_out, effort_out in zip(
+                self._specs, stale_by_joint, pos_outside_by_joint, speed_outside_by_joint, effort_outside_by_joint
             ):
-                if stale or pos_out or speed_out:
+                if stale or pos_out or speed_out or effort_out:
                     self._latch_joint_fault(
                         spec.name,
                         spec.motor_id,
                         stale=stale,
                         position_limit=pos_out,
                         speed_limit=speed_out,
+                        effort_limit=effort_out,
                     )
             if any(stale_by_joint):
                 return DecisionCode.STALE_FEEDBACK
@@ -344,6 +353,8 @@ class JointCore:
                 return DecisionCode.POSITION_OUT_OF_BOUNDS
             if any(speed_outside_by_joint):
                 return DecisionCode.SPEED_OUT_OF_BOUNDS
+            if any(effort_outside_by_joint):
+                return DecisionCode.EFFORT_OUT_OF_BOUNDS
         if (
             self._admitted_target is not None
             and now >= self._admitted_target.window.expires_at_s
@@ -438,7 +449,10 @@ class JointCore:
         speed_limit = (
             abs(sample.dq_rad_s) > spec.v_max_rad_s
         )
-        if not status.healthy or position_limit or speed_limit:
+        effort_limit = (
+            abs(sample.tau_nm) > spec.max_effort_nm
+        )
+        if not status.healthy or position_limit or speed_limit or effort_limit:
             self._latch_joint_fault(
                 spec.name,
                 motor_id,
@@ -447,11 +461,14 @@ class JointCore:
                 timeout=status.timeout,
                 position_limit=position_limit,
                 speed_limit=speed_limit,
+                effort_limit=effort_limit,
             )
         if position_limit:
             return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
         if speed_limit:
             return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
+        if effort_limit:
+            return self._rejected(DecisionCode.EFFORT_OUT_OF_BOUNDS)
         return self._accepted()
 
     def communication_failed(
@@ -504,14 +521,23 @@ class JointCore:
             for spec, joint in zip(self._specs, self._observations)
             if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
         ]
-        if pos_out_of_bounds or speed_out_of_bounds:
+        effort_out_of_bounds = [
+            spec
+            for spec, joint in zip(self._specs, self._observations)
+            if abs(joint.sample.tau_nm) > spec.max_effort_nm
+        ]
+        if pos_out_of_bounds or speed_out_of_bounds or effort_out_of_bounds:
             for spec in pos_out_of_bounds:
                 self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
             for spec in speed_out_of_bounds:
                 self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
+            for spec in effort_out_of_bounds:
+                self._latch_joint_fault(spec.name, spec.motor_id, effort_limit=True)
             if pos_out_of_bounds:
                 return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
-            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
+            if speed_out_of_bounds:
+                return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
+            return self._rejected(DecisionCode.EFFORT_OUT_OF_BOUNDS)
 
         self._state = State.READY
         self._faults.clear()
@@ -554,14 +580,23 @@ class JointCore:
             for spec, joint in zip(self._specs, self._observations)
             if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
         ]
-        if pos_out_of_bounds or speed_out_of_bounds:
+        effort_out_of_bounds = [
+            spec
+            for spec, joint in zip(self._specs, self._observations)
+            if abs(joint.sample.tau_nm) > spec.max_effort_nm
+        ]
+        if pos_out_of_bounds or speed_out_of_bounds or effort_out_of_bounds:
             for spec in pos_out_of_bounds:
                 self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
             for spec in speed_out_of_bounds:
                 self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
+            for spec in effort_out_of_bounds:
+                self._latch_joint_fault(spec.name, spec.motor_id, effort_limit=True)
             if pos_out_of_bounds:
                 return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
-            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
+            if speed_out_of_bounds:
+                return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
+            return self._rejected(DecisionCode.EFFORT_OUT_OF_BOUNDS)
 
         self._state = State.ARMED
         return self._accepted()
@@ -615,7 +650,7 @@ class JointCore:
         validation_failures = validate_target_vector(
             self._specs,
             target,
-            tuple(joint.sample.q_rad for joint in self._observations),
+            tuple(joint.sample for joint in self._observations),
         )
         if validation_failures:
             return self._rejected(validation_failures[0].code)
@@ -654,8 +689,15 @@ class JointCore:
                 return None
             pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
             speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
-            if pos_out or speed_out:
-                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=pos_out, speed_limit=speed_out)
+            effort_out = abs(joint.sample.tau_nm) > spec.max_effort_nm
+            if pos_out or speed_out or effort_out:
+                self._latch_joint_fault(
+                    spec.name,
+                    spec.motor_id,
+                    position_limit=pos_out,
+                    speed_limit=speed_out,
+                    effort_limit=effort_out,
+                )
                 self.stop()
                 return None
 
@@ -675,7 +717,7 @@ class JointCore:
             self._specs,
             self._admitted_target,
             tuple(self._confirmed_references),
-            tuple(joint.sample.q_rad for joint in self._observations),
+            tuple(joint.sample for joint in self._observations),
             now,
             self._max_reference_gap_s,
         )
@@ -692,6 +734,10 @@ class JointCore:
                     self._latch_joint_fault(
                         spec.name, spec.motor_id, speed_limit=True
                     )
+                elif failure.code is DecisionCode.EFFORT_OUT_OF_BOUNDS:
+                    self._latch_joint_fault(
+                        spec.name, spec.motor_id, effort_limit=True
+                    )
                 else:
                     self._latch_joint_fault(
                         spec.name, spec.motor_id, constraint_fault=True
@@ -756,8 +802,15 @@ class JointCore:
                 return False
             pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
             speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
-            if pos_out or speed_out:
-                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=pos_out, speed_limit=speed_out)
+            effort_out = abs(joint.sample.tau_nm) > spec.max_effort_nm
+            if pos_out or speed_out or effort_out:
+                self._latch_joint_fault(
+                    spec.name,
+                    spec.motor_id,
+                    position_limit=pos_out,
+                    speed_limit=speed_out,
+                    effort_limit=effort_out,
+                )
                 self.stop()
                 return False
 
@@ -778,7 +831,7 @@ class JointCore:
             plan_joint=plan_joint,
             packet=self._prepared_plan.packets[index],
             goal=self._prepared_plan.target.joints[index],
-            q_meas=self._observations[index].sample.q_rad,
+            sample=self._observations[index].sample,
             prepared_at_s=self._prepared_plan.prepared_at_s,
         )
         if failure_code is not None:
@@ -786,6 +839,8 @@ class JointCore:
                 self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
             elif failure_code is DecisionCode.SPEED_OUT_OF_BOUNDS:
                 self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
+            elif failure_code is DecisionCode.EFFORT_OUT_OF_BOUNDS:
+                self._latch_joint_fault(spec.name, spec.motor_id, effort_limit=True)
             else:
                 self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
             self.stop()
diff --git a/joint_reference.py b/joint_reference.py
index a94bc46..a8bd04a 100644
--- a/joint_reference.py
+++ b/joint_reference.py
@@ -18,9 +18,11 @@ from joint_contract import (
     JointTrajectoryReference,
     Target,
 )
-from joint_mapping import JointTarget, OutputSample
+from joint_mapping import JointMap, JointSample, JointTarget, OutputSample
 
 __all__ = (
+    "map_decoded_command",
+    "predict_joint_effort",
     "prepare_reference_joint",
     "shape_reference_joint",
     "prepare_complete_reference",
@@ -31,6 +33,60 @@ __all__ = (
 )
 
 
+def map_decoded_command(mapping: JointMap, decoded: dict) -> JointTarget:
+    """Map canonical decoded command fields back once into joint target units."""
+    actual_output = mapping.from_output(
+        OutputSample(decoded["position_rad"], decoded["rpm"], decoded["torque_nm"])
+    )
+    gain_scale = mapping.reduction ** 2
+    return JointTarget(
+        q_rad=actual_output.q_rad,
+        dq_rad_s=actual_output.dq_rad_s,
+        tau_nm=actual_output.tau_nm,
+        kp=decoded["kp"] * gain_scale,
+        kd=decoded["kd"] * gain_scale,
+    )
+
+
+def predict_joint_effort(target: JointTarget, sample: JointSample) -> float:
+    """Predict combined joint effort: tau_ff + kp*(qref - qmeas) + kd*(dqref - dqmeas).
+
+    All terms are evaluated together in joint units without separate per-term
+    clipping. Finite overflow fails closed by raising ValueError.
+    """
+    if not isinstance(target, JointTarget) or not isinstance(sample, JointSample):
+        raise ValueError("target and sample must be JointTarget and JointSample")
+    for val in (
+        target.tau_nm,
+        target.kp,
+        target.q_rad,
+        target.kd,
+        target.dq_rad_s,
+        sample.q_rad,
+        sample.dq_rad_s,
+    ):
+        if isinstance(val, bool) or not isinstance(val, (int, float)):
+            raise ValueError("effort predictor terms must be real numbers")
+        try:
+            num = float(val)
+        except (OverflowError, TypeError, ValueError) as exc:
+            raise ValueError("effort predictor terms must be finite") from exc
+        if not math.isfinite(num):
+            raise ValueError("effort predictor terms must be finite")
+
+    try:
+        term_p = float(target.kp) * (float(target.q_rad) - float(sample.q_rad))
+        term_d = float(target.kd) * (float(target.dq_rad_s) - float(sample.dq_rad_s))
+        tau = float(target.tau_nm) + term_p + term_d
+    except (ArithmeticError, OverflowError) as exc:
+        raise ValueError("effort prediction overflowed") from exc
+
+    if not math.isfinite(tau):
+        raise ValueError("predicted effort is not finite")
+
+    return tau
+
+
 @dataclass(frozen=True)
 class ReferenceFailure:
     code: DecisionCode
@@ -153,19 +209,7 @@ def prepare_reference_joint(
             raw_rpm=raw_rpm,
         )
         decoded = decode_command(packet)
-        actual_output = spec.mapping.from_output(
-            OutputSample(
-                decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
-            )
-        )
-        gain_scale = spec.mapping.reduction ** 2
-        actual_target = JointTarget(
-            q_rad=actual_output.q_rad,
-            dq_rad_s=actual_output.dq_rad_s,
-            tau_nm=actual_output.tau_nm,
-            kp=decoded["kp"] * gain_scale,
-            kd=decoded["kd"] * gain_scale,
-        )
+        actual_target = map_decoded_command(spec.mapping, decoded)
     except (ArithmeticError, TypeError, ValueError):
         return DecisionCode.INVALID_ARGUMENT, None, None
 
@@ -179,36 +223,47 @@ def prepare_reference_joint(
 def validate_target_vector(
     specs: tuple[JointSpec, ...],
     target: Target,
-    measured_positions: tuple[float, ...],
+    samples: tuple[JointSample, ...],
 ) -> tuple[ReferenceFailure, ...]:
     """Validate every admitted joint request before replacing the current goal."""
     if (
         not isinstance(target, Target)
+        or type(specs) is not tuple
+        or type(samples) is not tuple
         or len(target.joints) != len(specs)
-        or len(measured_positions) != len(specs)
+        or len(samples) != len(specs)
     ):
         return (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
 
     failures: list[ReferenceFailure] = []
-    for index, (spec, joint_target, q_meas) in enumerate(
-        zip(specs, target.joints, measured_positions)
+    for index, (spec, joint_target, sample) in enumerate(
+        zip(specs, target.joints, samples)
     ):
-        code, _, _ = prepare_reference_joint(spec, joint_target)
-        if code is not None:
-            failures.append(ReferenceFailure(code, index))
+        code, actual_target, _ = prepare_reference_joint(spec, joint_target)
+        if code is not None or actual_target is None:
+            failures.append(ReferenceFailure(code or DecisionCode.INVALID_ARGUMENT, index))
             continue
-        if isinstance(q_meas, bool) or not isinstance(q_meas, (int, float)):
+        if not isinstance(sample, JointSample):
             failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
             continue
-        try:
-            q_meas_float = float(q_meas)
-        except (OverflowError, TypeError, ValueError):
+        valid_sample = True
+        for val in (sample.q_rad, sample.dq_rad_s, sample.tau_nm):
+            if isinstance(val, bool) or not isinstance(val, (int, float)):
+                valid_sample = False
+                break
+            try:
+                num = float(val)
+            except (OverflowError, TypeError, ValueError):
+                valid_sample = False
+                break
+            if not math.isfinite(num):
+                valid_sample = False
+                break
+        if not valid_sample:
             failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
             continue
-        if not math.isfinite(q_meas_float):
-            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
-            continue
-        q_meas_exact = Fraction(q_meas_float)
+
+        q_meas_exact = Fraction(sample.q_rad)
         lead_exact = Fraction(spec.max_lead_rad)
         requested_q_exact = Fraction(joint_target.q_rad)
         if not (
@@ -217,6 +272,16 @@ def validate_target_vector(
             <= q_meas_exact + lead_exact
         ):
             failures.append(ReferenceFailure(DecisionCode.LEAD_OUT_OF_BOUNDS, index))
+            continue
+
+        try:
+            pred_effort = predict_joint_effort(actual_target, sample)
+            if abs(Fraction(pred_effort)) > Fraction(spec.max_effort_nm):
+                failures.append(ReferenceFailure(DecisionCode.EFFORT_OUT_OF_BOUNDS, index))
+                continue
+        except (ArithmeticError, OverflowError, ValueError):
+            failures.append(ReferenceFailure(DecisionCode.INVALID_ARGUMENT, index))
+            continue
     return tuple(failures)
 
 
@@ -224,7 +289,7 @@ def shape_reference_joint(
     spec: JointSpec,
     target: JointTarget,
     confirmed_ref: JointTrajectoryReference,
-    q_meas: float,
+    sample: JointSample,
     now: float,
     max_reference_gap_s: float,
 ) -> tuple[
@@ -238,6 +303,7 @@ def shape_reference_joint(
         not isinstance(spec, JointSpec)
         or not isinstance(target, JointTarget)
         or not isinstance(confirmed_ref, JointTrajectoryReference)
+        or not isinstance(sample, JointSample)
     ):
         return DecisionCode.INVALID_ARGUMENT, None, None, None
 
@@ -248,7 +314,9 @@ def shape_reference_joint(
         target.tau_nm,
         target.kp,
         target.kd,
-        q_meas,
+        sample.q_rad,
+        sample.dq_rad_s,
+        sample.tau_nm,
         now,
         max_reference_gap_s,
     ):
@@ -268,6 +336,8 @@ def shape_reference_joint(
         goal_kp,
         goal_kd,
         q_meas_val,
+        dq_meas_val,
+        tau_meas_val,
         now,
         max_reference_gap_s,
     ) = normalized
@@ -313,6 +383,12 @@ def shape_reference_joint(
             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
         if abs(confirmed_ref.position_step_velocity_rad_s) > Fraction(spec.v_max_rad_s):
             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+        try:
+            pred_h0 = predict_joint_effort(confirmed_ref.emitted_target, sample)
+            if abs(Fraction(pred_h0)) > Fraction(spec.max_effort_nm):
+                return DecisionCode.EFFORT_OUT_OF_BOUNDS, None, None, None
+        except (ArithmeticError, OverflowError, ValueError):
+            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
         return (
             None,
             confirmed_ref.emitted_target,
@@ -507,17 +583,7 @@ def shape_reference_joint(
             raw_rpm=raw_rpm,
         )
         decoded = decode_command(packet)
-        actual_output = spec.mapping.from_output(
-            OutputSample(decoded["position_rad"], decoded["rpm"], decoded["torque_nm"])
-        )
-        gain_scale = spec.mapping.reduction ** 2
-        actual_target = JointTarget(
-            q_rad=actual_output.q_rad,
-            dq_rad_s=actual_output.dq_rad_s,
-            tau_nm=actual_output.tau_nm,
-            kp=decoded["kp"] * gain_scale,
-            kd=decoded["kd"] * gain_scale,
-        )
+        actual_target = map_decoded_command(spec.mapping, decoded)
     except (ArithmeticError, TypeError, ValueError):
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
 
@@ -541,6 +607,13 @@ def shape_reference_joint(
     if abs(actual_position_step_velocity - v_prev_pos_exact) > a_max_exact * h_exact:
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
 
+    try:
+        pred_effort = predict_joint_effort(actual_target, sample)
+        if abs(Fraction(pred_effort)) > Fraction(spec.max_effort_nm):
+            return DecisionCode.EFFORT_OUT_OF_BOUNDS, None, None, None
+    except (ArithmeticError, OverflowError, ValueError):
+        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+
     proposed_ref = JointTrajectoryReference(
         q_rad=actual_target.q_rad,
         position_step_velocity_rad_s=actual_position_step_velocity,
@@ -558,7 +631,7 @@ def prepare_complete_reference(
     specs: tuple[JointSpec, ...],
     target: Target,
     confirmed_references: tuple[JointTrajectoryReference, ...],
-    measured_positions: tuple[float, ...],
+    samples: tuple[JointSample, ...],
     now: float,
     max_reference_gap_s: float,
 ) -> ReferenceBatchResult:
@@ -571,8 +644,8 @@ def prepare_complete_reference(
         or len(target.joints) != len(specs)
         or type(confirmed_references) is not tuple
         or len(confirmed_references) != len(specs)
-        or type(measured_positions) is not tuple
-        or len(measured_positions) != len(specs)
+        or type(samples) is not tuple
+        or len(samples) != len(specs)
     ):
         return ReferenceBatchResult(
             None, None, None, (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
@@ -583,11 +656,11 @@ def prepare_complete_reference(
     proposed_references: list[JointTrajectoryReference] = []
     failures: list[ReferenceFailure] = []
 
-    for index, (spec, joint_target, conf_ref, q_meas) in enumerate(
-        zip(specs, target.joints, confirmed_references, measured_positions)
+    for index, (spec, joint_target, conf_ref, sample) in enumerate(
+        zip(specs, target.joints, confirmed_references, samples)
     ):
         code, actual_target, prop_ref, packet = shape_reference_joint(
-            spec, joint_target, conf_ref, q_meas, now, max_reference_gap_s
+            spec, joint_target, conf_ref, sample, now, max_reference_gap_s
         )
         if code is not None or actual_target is None or prop_ref is None or packet is None:
             failures.append(
@@ -612,7 +685,7 @@ def verify_dispatch_claim(
     plan_joint: JointTarget,
     packet: bytes,
     goal: JointTarget,
-    q_meas: float,
+    sample: JointSample,
     prepared_at_s: float,
 ) -> DecisionCode | None:
     """Validate one proposed joint reference against all closed constraints at the write gate."""
@@ -623,8 +696,18 @@ def verify_dispatch_claim(
         or not isinstance(plan_joint, JointTarget)
         or type(packet) is not bytes
         or not isinstance(goal, JointTarget)
+        or not isinstance(sample, JointSample)
     ):
         return DecisionCode.CONSTRAINT_VIOLATION
+    for val in (sample.q_rad, sample.dq_rad_s, sample.tau_nm):
+        if isinstance(val, bool) or not isinstance(val, (int, float)):
+            return DecisionCode.CONSTRAINT_VIOLATION
+        try:
+            num = float(val)
+        except (OverflowError, TypeError, ValueError):
+            return DecisionCode.CONSTRAINT_VIOLATION
+        if not math.isfinite(num):
+            return DecisionCode.CONSTRAINT_VIOLATION
 
     if (
         prop_ref.requested_goal != goal
@@ -653,7 +736,7 @@ def verify_dispatch_claim(
         q_min_exact = Fraction(spec.q_min_rad)
         q_max_exact = Fraction(spec.q_max_rad)
         lead_exact = Fraction(spec.max_lead_rad)
-        q_meas_exact = Fraction(q_meas)
+        q_meas_exact = Fraction(sample.q_rad)
         prop_q_exact = Fraction(prop_ref.q_rad)
         plan_q_exact = Fraction(plan_joint.q_rad)
 
@@ -689,6 +772,13 @@ def verify_dispatch_claim(
             or plan_q_exact > q_meas_exact + lead_exact
         ):
             return DecisionCode.CONSTRAINT_VIOLATION
+
+        try:
+            pred_effort = predict_joint_effort(plan_joint, sample)
+            if abs(Fraction(pred_effort)) > Fraction(spec.max_effort_nm):
+                return DecisionCode.EFFORT_OUT_OF_BOUNDS
+        except (ArithmeticError, OverflowError, ValueError):
+            return DecisionCode.CONSTRAINT_VIOLATION
     except (ArithmeticError, TypeError, ValueError):
         return DecisionCode.CONSTRAINT_VIOLATION
 
diff --git a/scripts/check_milestone.py b/scripts/check_milestone.py
index a3ee61b..12446e4 100644
--- a/scripts/check_milestone.py
+++ b/scripts/check_milestone.py
@@ -24,6 +24,7 @@ CHECKS = {
     'C10': 'test_controller_limits.ReferenceSpeedTests',
     'C11': 'test_controller_limits.ReferenceAccelerationTests',
     'C12': 'test_controller_lead.ReferenceLeadTests',
+    'C13': 'test_controller_effort.EffortLimitTests',
 }
 
 
diff --git a/scripts/check_offline_baseline.sh b/scripts/check_offline_baseline.sh
index 2004b20..8aec0a8 100755
--- a/scripts/check_offline_baseline.sh
+++ b/scripts/check_offline_baseline.sh
@@ -78,7 +78,7 @@ run_logged() {
     return 0
 }
 
-files=(motor_dashboard.py motor_session.py spin_5rpm.py im6014_codec.py im6014_serial.py fake_serial.py test_spin_5rpm.py test_dashboard.py test_startup.py test_startup_verifier.py test_protocol.py test_serial_deadline.py evidence/boundary/vendor-crc-vectors.json USER_MANUAL.md joint_mapping.py test_joint_mapping.py test_numerical_inputs.py im6014_port.py test_port_config.py test_diagnostic_capture.py test_bus_owner.py joint_contract.py joint_reference.py joint_controller.py test_controller.py test_controller_targets.py test_controller_expiry.py test_controller_owner.py test_controller_limits.py test_controller_lead.py)
+files=(motor_dashboard.py motor_session.py spin_5rpm.py im6014_codec.py im6014_serial.py fake_serial.py test_spin_5rpm.py test_dashboard.py test_startup.py test_startup_verifier.py test_protocol.py test_serial_deadline.py evidence/boundary/vendor-crc-vectors.json USER_MANUAL.md joint_mapping.py test_joint_mapping.py test_numerical_inputs.py im6014_port.py test_port_config.py test_diagnostic_capture.py test_bus_owner.py joint_contract.py joint_reference.py joint_controller.py test_controller.py test_controller_targets.py test_controller_expiry.py test_controller_owner.py test_controller_limits.py test_controller_lead.py test_controller_effort.py)
 for name in "${files[@]}"; do
     mkdir -p -- "$scratch/$(dirname -- "$name")" || exit 2
     if ! cp -- "$repo_dir/$name" "$scratch/$name" || ! cmp -s -- "$repo_dir/$name" "$scratch/$name"; then
@@ -98,7 +98,7 @@ cd -- "$scratch" || exit 2
 run_logged packet-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" test_spin_5rpm.py
 run_logged protocol-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_protocol
 run_logged serial-deadline-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_serial_deadline
-run_logged milestone-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_joint_mapping test_numerical_inputs test_port_config test_diagnostic_capture test_bus_owner test_controller test_controller_targets test_controller_expiry test_controller_owner test_controller_limits test_controller_lead
+run_logged milestone-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_joint_mapping test_numerical_inputs test_port_config test_diagnostic_capture test_bus_owner test_controller test_controller_targets test_controller_expiry test_controller_owner test_controller_limits test_controller_lead test_controller_effort
 run_logged dashboard-tests env QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1 "$python_path" test_dashboard.py
 for name in dashboard_preview.png dashboard_dark_preview.png dashboard_test_results.json; do
     if [[ -f "$scratch/$name" ]]; then
diff --git a/test_controller.py b/test_controller.py
index 0949e66..f2a618e 100644
--- a/test_controller.py
+++ b/test_controller.py
@@ -108,8 +108,8 @@ class DeterministicClock:
 class FeedbackAgeTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
         )
 
     def _ready_station(self, clock, *, feedback_max_age_s=1.0):
@@ -315,8 +315,8 @@ class ControllerStateTests(unittest.TestCase):
     def setUp(self):
         self.clock = lambda: 0.0
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
         )
 
 
@@ -326,18 +326,18 @@ class ControllerStateTests(unittest.TestCase):
             JointCore((), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
             JointCore((
-                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
-                JointSpec("J1", 1, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
+                JointSpec("J1", 1, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
             ), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
             JointCore((
-                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
-                JointSpec("J2", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
+                JointSpec("J2", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
             ), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
-            JointSpec("J1", True, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits")
+            JointSpec("J1", True, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits")
 
-        supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits")]
+        supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits")]
         core = JointCore(supplied, clock=self.clock, max_reference_gap_s=1.0)
         supplied.clear()
         self.assertEqual(tuple(spec.name for spec in core.joint_specs), ("J1",))
@@ -553,8 +553,8 @@ class ControllerStateTests(unittest.TestCase):
 class JointFaultTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
         )
 
     def _ready_core(self, clock=None, *, feedback_max_age_s=1.0):
@@ -875,8 +875,8 @@ class JointFaultTests(unittest.TestCase):
 
     def test_independent_second_core_unchanged_by_fault(self):
         specs2 = (
-            JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
-            JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
+            JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
         )
         clock = DeterministicClock(0.0)
         core1 = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
diff --git a/test_controller_expiry.py b/test_controller_expiry.py
index fb1cdec..58cb760 100644
--- a/test_controller_expiry.py
+++ b/test_controller_expiry.py
@@ -29,8 +29,8 @@ SOURCE = SourceIdentity("fixture", "expiry-test", 1)
 class ControllerExpiryTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
diff --git a/test_controller_lead.py b/test_controller_lead.py
index a167289..7f66319 100644
--- a/test_controller_lead.py
+++ b/test_controller_lead.py
@@ -32,6 +32,7 @@ class ReferenceLeadTests(unittest.TestCase):
             2.0,   # v_max = 2.0 rad/s
             10.0,  # a_max = 10.0 rad/s2
             0.5,   # max_lead_rad = 0.5 rad
+            50.0,  # max_effort_nm = 50.0 Nm
             "fixture: lead test J1",
         )
         self.spec2 = JointSpec(
@@ -43,6 +44,7 @@ class ReferenceLeadTests(unittest.TestCase):
             2.0,   # v_max = 2.0 rad/s
             10.0,  # a_max = 10.0 rad/s2
             0.5,   # max_lead_rad = 0.5 rad
+            50.0,  # max_effort_nm = 50.0 Nm
             "fixture: lead test J2",
         )
         self.specs = (self.spec1, self.spec2)
@@ -140,7 +142,7 @@ class ReferenceLeadTests(unittest.TestCase):
         for val in (True, False, 0, 0.0, -0.5, math.nan, math.inf, -math.inf, 10**400, "0.5"):
             with self.subTest(val=val), self.assertRaises(ValueError):
                 JointSpec(
-                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 2.0, 10.0, val,
+                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 2.0, 10.0, val, 50.0,
                     "fixture: invalid lead limit input",
                 )
 
@@ -192,7 +194,7 @@ class ReferenceLeadTests(unittest.TestCase):
     def test_parent_exact_admission_reproduction(self):
         clock = DeterministicClock(0.0)
         spec = JointSpec(
-            "J", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 10.0, 0.2,
+            "J", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 10.0, 0.2, 50.0,
             "fixture: exact lead admission regression",
         )
         core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
@@ -223,7 +225,7 @@ class ReferenceLeadTests(unittest.TestCase):
     def test_exact_binary_admission_boundaries_are_inclusive(self):
         clock = DeterministicClock(0.0)
         spec = JointSpec(
-            "J", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 10.0, 0.25,
+            "J", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 10.0, 0.25, 50.0,
             "fixture: exact binary lead equality",
         )
         core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
@@ -371,7 +373,7 @@ class ReferenceLeadTests(unittest.TestCase):
             0.0, Fraction(0), 0.0, self.clock.value, False
         )
         code, anchor_target, anchor_fast, anchor_packet = shape_reference_joint(
-            self.spec1, anchor_goal, stop_anchor, 0.0, self.clock.value + 0.2, 1.0
+            self.spec1, anchor_goal, stop_anchor, JointSample(0.0, 0.0, 0.0), self.clock.value + 0.2, 1.0
         )
         self.assertIsNone(code)
         self.assertTrue(anchor_fast.is_emitted)
@@ -400,7 +402,7 @@ class ReferenceLeadTests(unittest.TestCase):
             self.spec1,
             anchor_goal,
             anchor_fast,
-            drifted_q_meas,
+            JointSample(drifted_q_meas, 0.0, 0.0),
             next_now,
             1.0,
         )
@@ -465,13 +467,13 @@ class ReferenceLeadTests(unittest.TestCase):
     def _quarter_cache(self, max_lead):
         mapping = JointMap(math.ldexp(raw_to_position(1), 2), 1, 0.0)
         spec = JointSpec(
-            "J", 0, mapping, -1.0, 1.0, 1.0, 4.0, max_lead,
+            "J", 0, mapping, -1.0, 1.0, 1.0, 4.0, max_lead, 50.0,
             "fixture: exact cached lead reference",
         )
         goal = JointTarget(0.25, 0.0, 0.0, 0.0, 0.0)
         anchor = JointTrajectoryReference(0.25, Fraction(0), 0.0, 0.0, False)
         code, actual, emitted, packet = shape_reference_joint(
-            spec, goal, anchor, 0.25, 0.25, 0.5
+            spec, goal, anchor, JointSample(0.25, 0.0, 0.0), 0.25, 0.5
         )
         self.assertIsNone(code)
         self.assertEqual(actual.q_rad, 0.25)
@@ -489,7 +491,7 @@ class ReferenceLeadTests(unittest.TestCase):
         )
 
         code, repeated_target, repeated_ref, repeated_packet = shape_reference_joint(
-            spec, goal, emitted_ref, -0.11, emitted_ref.sample_time_s, 0.5
+            spec, goal, emitted_ref, JointSample(-0.11, 0.0, 0.0), emitted_ref.sample_time_s, 0.5
         )
         self.assertIs(code, DecisionCode.CONSTRAINT_VIOLATION)
         self.assertIsNone(repeated_target)
@@ -501,7 +503,7 @@ class ReferenceLeadTests(unittest.TestCase):
         self.assertEqual(Fraction(actual.q_rad) - Fraction(-0.125), Fraction(0.375))
 
         code, repeated_target, repeated_ref, repeated_packet = shape_reference_joint(
-            spec, goal, emitted_ref, -0.125, emitted_ref.sample_time_s, 0.5
+            spec, goal, emitted_ref, JointSample(-0.125, 0.0, 0.0), emitted_ref.sample_time_s, 0.5
         )
         self.assertIsNone(code)
         self.assertEqual(repeated_target, actual)
@@ -622,6 +624,7 @@ class ReferenceLeadTests(unittest.TestCase):
             2.0,
             10.0,
             0.25,  # lead = 0.25 rad
+            50.0,  # max_effort_nm = 50.0 Nm
             "fixture: negative direction lead test",
         )
         clock = DeterministicClock(10.0)
@@ -772,7 +775,7 @@ class ReferenceLeadTests(unittest.TestCase):
             lead = rng.uniform(0.55, 0.75)
             mapping = JointMap(reduction, direction, zero)
             spec = JointSpec(
-                "J_fuzz", 0, mapping, q_min, q_max, v_max, a_max, lead,
+                "J_fuzz", 0, mapping, q_min, q_max, v_max, a_max, lead, 100.0,
                 "fixture: seeded emitted-reference certificate",
             )
             cadence = rng.choice(cadences)
@@ -784,7 +787,7 @@ class ReferenceLeadTests(unittest.TestCase):
             now = previous.sample_time_s + cadence
 
             code, emitted, reference, packet = shape_reference_joint(
-                spec, goal, previous, 0.0, now, 1.0
+                spec, goal, previous, JointSample(0.0, 0.0, 0.0), now, 1.0
             )
             with self.subTest(iteration=iteration, phase="advance"):
                 self.assertIsNone(code)
@@ -803,7 +806,7 @@ class ReferenceLeadTests(unittest.TestCase):
             reverse_goal = JointTarget(-goal_sign * 0.45, 0.0, 0.0, 1.0, 0.1)
             now = previous.sample_time_s + cadence
             code, emitted, reference, packet = shape_reference_joint(
-                spec, reverse_goal, previous, previous.q_rad, now, 1.0
+                spec, reverse_goal, previous, JointSample(previous.q_rad, 0.0, 0.0), now, 1.0
             )
             with self.subTest(iteration=iteration, phase="reverse"):
                 self.assertIsNone(code)
@@ -824,7 +827,7 @@ class ReferenceLeadTests(unittest.TestCase):
             impossible_measurement = previous.q_rad + 1.0
             now = previous.sample_time_s + cadence
             code, emitted, reference, packet = shape_reference_joint(
-                spec, reverse_goal, previous, impossible_measurement, now, 1.0
+                spec, reverse_goal, previous, JointSample(impossible_measurement, 0.0, 0.0), now, 1.0
             )
             with self.subTest(iteration=iteration, phase="infeasible"):
                 self.assertIs(code, DecisionCode.CONSTRAINT_VIOLATION)
diff --git a/test_controller_limits.py b/test_controller_limits.py
index 6846d31..062ff01 100644
--- a/test_controller_limits.py
+++ b/test_controller_limits.py
@@ -65,8 +65,8 @@ class PositionLimitTests(unittest.TestCase):
     def setUp(self):
         self.clock = DeterministicClock(0.0)
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1.0, 2.0, 100.0, 500.0, 100.0, "fixture: software position limits J1"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -0.5, 0.5, 100.0, 500.0, 100.0, "fixture: software position limits J2"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1.0, 2.0, 100.0, 500.0, 100.0, 100.0, "fixture: software position limits J1"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -0.5, 0.5, 100.0, 500.0, 100.0, 100.0, "fixture: software position limits J2"),
         )
         self.valid_sample_j1 = JointSample(0.1, 0.0, 0.0)
         self.valid_sample_j2 = JointSample(0.0, 0.0, 0.0)
@@ -195,6 +195,7 @@ class PositionLimitTests(unittest.TestCase):
                 100.0,
                 500.0,
                 100.0,
+                100.0,
                 "fixture: software limits negative direction",
             ),
             JointSpec(
@@ -206,6 +207,7 @@ class PositionLimitTests(unittest.TestCase):
                 100.0,
                 500.0,
                 100.0,
+                100.0,
                 "fixture: software limits positive direction",
             ),
         )
@@ -273,6 +275,7 @@ class PositionLimitTests(unittest.TestCase):
             10.0,
             100.0,
             100.0,
+            100.0,
             "fixture: exact grid point interval",
         )
         found_code = self._project(spec_zero_width, grid_pos)
@@ -294,6 +297,7 @@ class PositionLimitTests(unittest.TestCase):
             10.0,
             100.0,
             100.0,
+            100.0,
             "fixture: empty grid interval",
         )
         found_none = self._project(spec_empty_grid, mid)
@@ -320,77 +324,91 @@ class PositionLimitTests(unittest.TestCase):
 
         # q_min_rad > q_max_rad
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 1.0, 0.0, 10.0, 100.0, 1.0, "fixture: invalid min max")
+            JointSpec("J1", 0, mapping, 1.0, 0.0, 10.0, 100.0, 1.0, 50.0, "fixture: invalid min max")
 
         # non-numeric / bool types
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, True, 1.0, 10.0, 100.0, 1.0, "fixture: bool min")
+            JointSpec("J1", 0, mapping, True, 1.0, 10.0, 100.0, 1.0, 50.0, "fixture: bool min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0.0, False, 10.0, 100.0, 1.0, "fixture: bool max")
+            JointSpec("J1", 0, mapping, 0.0, False, 10.0, 100.0, 1.0, 50.0, "fixture: bool max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, "0.0", 1.0, 10.0, 100.0, 1.0, "fixture: str min")
+            JointSpec("J1", 0, mapping, "0.0", 1.0, 10.0, 100.0, 1.0, 50.0, "fixture: str min")
 
         # infinite / NaN
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, float("-inf"), 1.0, 10.0, 100.0, 1.0, "fixture: neg inf min")
+            JointSpec("J1", 0, mapping, float("-inf"), 1.0, 10.0, 100.0, 1.0, 50.0, "fixture: neg inf min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0.0, float("inf"), 10.0, 100.0, 1.0, "fixture: inf max")
+            JointSpec("J1", 0, mapping, 0.0, float("inf"), 10.0, 100.0, 1.0, 50.0, "fixture: inf max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, float("nan"), 1.0, 10.0, 100.0, 1.0, "fixture: nan min")
+            JointSpec("J1", 0, mapping, float("nan"), 1.0, 10.0, 100.0, 1.0, 50.0, "fixture: nan min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0, 10**400, 10.0, 100.0, 1.0, "fixture: overflowing max")
+            JointSpec("J1", 0, mapping, 0, 10**400, 10.0, 100.0, 1.0, 50.0, "fixture: overflowing max")
 
         # v_max_rad_s <= 0 or not finite
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 0.0, 100.0, 1.0, "fixture: zero v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 0.0, 100.0, 1.0, 50.0, "fixture: zero v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, -10.0, 100.0, 1.0, "fixture: negative v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, -10.0, 100.0, 1.0, 50.0, "fixture: negative v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, float("inf"), 100.0, 1.0, "fixture: inf v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, float("inf"), 100.0, 1.0, 50.0, "fixture: inf v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, float("nan"), 100.0, 1.0, "fixture: nan v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, float("nan"), 100.0, 1.0, 50.0, "fixture: nan v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, "10.0", 100.0, 1.0, "fixture: str v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, "10.0", 100.0, 1.0, 50.0, "fixture: str v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, True, 100.0, 1.0, "fixture: bool v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, True, 100.0, 1.0, 50.0, "fixture: bool v_max")
 
         # a_max_rad_s2 <= 0 or not finite
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 0.0, 1.0, "fixture: zero a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 0.0, 1.0, 50.0, "fixture: zero a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, -10.0, 1.0, "fixture: negative a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, -10.0, 1.0, 50.0, "fixture: negative a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("inf"), 1.0, "fixture: inf a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("inf"), 1.0, 50.0, "fixture: inf a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("nan"), 1.0, "fixture: nan a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("nan"), 1.0, 50.0, "fixture: nan a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "10.0", 1.0, "fixture: str a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "10.0", 1.0, 50.0, "fixture: str a_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, True, 1.0, "fixture: bool a_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, True, 1.0, 50.0, "fixture: bool a_max")
 
         # max_lead_rad <= 0 or not finite
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 0.0, "fixture: zero max_lead")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 0.0, 50.0, "fixture: zero max_lead")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, -10.0, "fixture: negative max_lead")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, -10.0, 50.0, "fixture: negative max_lead")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, float("inf"), "fixture: inf max_lead")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, float("inf"), 50.0, "fixture: inf max_lead")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, float("nan"), "fixture: nan max_lead")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, float("nan"), 50.0, "fixture: nan max_lead")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "10.0", "fixture: str max_lead")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "10.0", 50.0, "fixture: str max_lead")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, True, "fixture: bool max_lead")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, True, 50.0, "fixture: bool max_lead")
+
+        # max_effort_nm <= 0 or not finite
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 0.0, "fixture: zero max_effort")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, -10.0, "fixture: negative max_effort")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, float("inf"), "fixture: inf max_effort")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, float("nan"), "fixture: nan max_effort")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, "10.0", "fixture: str max_effort")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, True, "fixture: bool max_effort")
 
         # invalid provenance
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, "")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 50.0, "")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, "   ")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 50.0, "   ")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 123)
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 50.0, 123)
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, "x" * 257)
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 50.0, "x" * 257)
 
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0)
@@ -400,21 +418,28 @@ class PositionLimitTests(unittest.TestCase):
             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0)
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0)
+        with self.assertRaises(TypeError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 50.0)
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, provenance="legacy alias")
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, provenance="legacy alias")
+        with self.assertRaises(TypeError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 1.0, 50.0, provenance="legacy alias")
 
-        # JointFault position_limit type validation
+        # JointFault position_limit / speed_limit / effort_limit / constraint_fault type validation
         with self.assertRaises(ValueError):
             JointFault("J1", 0, position_limit="bad")
         with self.assertRaises(ValueError):
             JointFault("J1", 0, speed_limit="bad")
+        with self.assertRaises(ValueError):
+            JointFault("J1", 0, effort_limit="bad")
         with self.assertRaises(ValueError):
             JointFault("J1", 0, constraint_fault="bad")
-        jf = JointFault("J1", 0, position_limit=True, speed_limit=True, constraint_fault=True)
+        jf = JointFault("J1", 0, position_limit=True, speed_limit=True, effort_limit=True, constraint_fault=True)
         self.assertTrue(jf.position_limit)
         self.assertTrue(jf.speed_limit)
+        self.assertTrue(jf.effort_limit)
         self.assertTrue(jf.constraint_fault)
         self.assertFalse(hasattr(jf, "position_out_of_bounds"))
 
@@ -552,7 +577,7 @@ class PositionLimitTests(unittest.TestCase):
         self.assertFalse(core.snapshot().fault_latched)
 
     def test_codec_rounding_overshoot_produces_inward_actual_safe_endpoint(self):
-        spec = JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -0.1, 0.1, 10.0, 100.0, 100.0, "fixture: rounding overshoot test")
+        spec = JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -0.1, 0.1, 10.0, 100.0, 100.0, 100.0, "fixture: rounding overshoot test")
         target = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
 
         requested_output = spec.mapping.to_output(target)
@@ -739,7 +764,7 @@ class PositionLimitTests(unittest.TestCase):
     def test_actual_reference_matches_every_canonical_wire_field(self):
         mapping = JointMap(3.0, -1, 0.25)
         spec = JointSpec(
-            "J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 100.0, "fixture: canonical reference test"
+            "J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, 100.0, 100.0, "fixture: canonical reference test"
         )
         requested = JointTarget(0.321, 0.123, 0.321, 1.234, 0.123)
 
@@ -759,7 +784,7 @@ class PositionLimitTests(unittest.TestCase):
 
     def test_unencodable_mapped_request_is_invalid_not_projected_into_range(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8,
             "fixture: wide software position limits",
         )
         code, actual, packet = prepare_reference_joint(
@@ -771,7 +796,7 @@ class PositionLimitTests(unittest.TestCase):
 
     def test_mapping_overflow_is_invalid_argument(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1e-308, 1, 0.0), -1.0, 1.0, 10.0, 100.0, 100.0,
+            "J1", 0, JointMap(1e-308, 1, 0.0), -1.0, 1.0, 10.0, 100.0, 100.0, 100.0,
             "fixture: mapping overflow limits",
         )
         code, actual, packet = prepare_reference_joint(
@@ -920,7 +945,7 @@ class PositionLimitTests(unittest.TestCase):
             with self.subTest(result=result):
                 clock = DeterministicClock(0.0)
                 spec = JointSpec(
-                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 100.0,
+                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 100.0, 100.0,
                     "fixture: late receipt limits",
                 )
                 core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
@@ -985,7 +1010,7 @@ class PositionLimitTests(unittest.TestCase):
 
         clock = EndClock(0.0)
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 100.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 100.0, 100.0,
             "fixture: late complete limits",
         )
         core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
@@ -1043,6 +1068,7 @@ class PositionLimitTests(unittest.TestCase):
                 1e8,
                 1e8,
                 1e8,
+                1e8,
                 "fixture: seeded software limits",
             )
             output_velocity = rng.uniform(-0.5, 0.5)
@@ -1104,6 +1130,7 @@ class ReferenceSpeedTests(unittest.TestCase):
             1.0,  # v_max_rad_s = 1.0 rad/s
             1000.0,  # a_max_rad_s2 = 1000.0 rad/s2
             100.0,  # max_lead_rad
+            100.0,  # max_effort_nm
             "fixture: speed limit test J1",
         )
         self.spec2 = JointSpec(
@@ -1115,6 +1142,7 @@ class ReferenceSpeedTests(unittest.TestCase):
             2.0,  # v_max_rad_s = 2.0 rad/s
             1000.0,  # a_max_rad_s2 = 1000.0 rad/s2
             100.0,  # max_lead_rad
+            100.0,  # max_effort_nm
             "fixture: speed limit test J2",
         )
         self.specs = (self.spec1, self.spec2)
@@ -1553,14 +1581,14 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_zero_objective_cancellation_is_not_quantization_stall(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0, 100.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0, 100.0, 100.0,
             "fixture: zero-objective cancellation test",
         )
         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
         target = JointTarget(0.1, -1.0, 0.0, 1.0, 0.1)
 
         code, emitted, reference, packet = shape_reference_joint(
-            spec, target, anchor, anchor.q_rad, 0.1, 1.0
+            spec, target, anchor, JointSample(anchor.q_rad, 0.0, 0.0), 0.1, 1.0
         )
 
         self.assertIsNone(code)
@@ -1572,14 +1600,14 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_finite_extreme_objective_stops_when_grid_cannot_meet_acceleration(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.5e308, 1.5e308, 100.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.5e308, 1.5e308, 100.0, 100.0,
             "fixture: finite extreme objective",
         )
         anchor = JointTrajectoryReference(-1.0, Fraction(0), 0.0, 0.0, False)
         target = JointTarget(1.0, 0.0, 0.0, 1.0, 0.1)
 
         code, emitted, reference, packet = shape_reference_joint(
-            spec, target, anchor, anchor.q_rad, 1e-308, 1.0
+            spec, target, anchor, JointSample(anchor.q_rad, 0.0, 0.0), 1e-308, 1.0
         )
 
         self.assertIs(code, DecisionCode.CONSTRAINT_VIOLATION)
@@ -1610,7 +1638,7 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_oversized_integer_time_inputs_fail_closed_without_raising(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0, 100.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0, 100.0, 100.0,
             "fixture: oversized integer time",
         )
         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
@@ -1618,7 +1646,7 @@ class ReferenceSpeedTests(unittest.TestCase):
 
         for now, gap in ((10**400, 1.0), (1.0, 10**400)):
             code, emitted, reference, packet = shape_reference_joint(
-                spec, target, anchor, 0.0, now, gap
+                spec, target, anchor, JointSample(0.0, 0.0, 0.0), now, gap
             )
             self.assertIs(code, DecisionCode.INVALID_ARGUMENT)
             self.assertIsNone(emitted)
@@ -1629,11 +1657,11 @@ class ReferenceSpeedTests(unittest.TestCase):
         clock = DeterministicClock(0.0)
         specs = (
             JointSpec(
-                "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0, 100.0,
+                "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0, 100.0, 100.0,
                 "fixture: tiny-cadence stall J1",
             ),
             JointSpec(
-                "J2", 1, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0, 100.0,
+                "J2", 1, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0, 100.0, 100.0,
                 "fixture: tiny-cadence hold J2",
             ),
         )
@@ -1699,6 +1727,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
             2.0,  # v_max = 2.0 rad/s
             4.0,  # a_max = 4.0 rad/s2
             100.0,  # max_lead_rad
+            100.0,  # max_effort_nm
             "fixture: acceleration test J1",
         )
         self.spec2 = JointSpec(
@@ -1710,6 +1739,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
             3.0,  # v_max = 3.0 rad/s
             6.0,  # a_max = 6.0 rad/s2
             100.0,  # max_lead_rad
+            100.0,  # max_effort_nm
             "fixture: acceleration test J2",
         )
         self.specs = (self.spec1, self.spec2)
@@ -1786,7 +1816,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
         first_goal = JointTarget(0.5, 1.0, 0.0, 1.0, 0.1)
         code, _, moving, _ = shape_reference_joint(
-            spec, first_goal, anchor, anchor.q_rad, 0.125, 1.0
+            spec, first_goal, anchor, JointSample(anchor.q_rad, 0.0, 0.0), 0.125, 1.0
         )
         self.assertIsNone(code)
         self.assertIsNotNone(moving)
@@ -1795,7 +1825,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
         hold_goal = JointTarget(moving.q_rad, 0.0, 0.0, 1.0, 0.1)
         now = moving.sample_time_s + 0.0625
         code, _, decelerating, _ = shape_reference_joint(
-            spec, hold_goal, moving, moving.q_rad, now, 1.0
+            spec, hold_goal, moving, JointSample(moving.q_rad, 0.0, 0.0), now, 1.0
         )
         self.assertIsNone(code)
         self.assertIsNotNone(decelerating)
@@ -2043,7 +2073,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
 
     def test_position_and_acceleration_incompatible_withdraws_instead_of_q_clamp(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -10.0, 2.0, 10.0, 10.0, 100.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -10.0, 2.0, 10.0, 10.0, 100.0, 100.0,
             "fixture: incompatible limits",
         )
         clock = DeterministicClock(10.0)
@@ -2096,7 +2126,7 @@ class ReferenceAccelerationTests(unittest.TestCase):
         )
         self.assertLess(position_velocity_hi, acceleration_velocity_lo)
         code, emitted, ref, packet = shape_reference_joint(
-            spec, target, anchor, anchor.q_rad, blocked_at, 1.0
+            spec, target, anchor, JointSample(anchor.q_rad, 0.0, 0.0), blocked_at, 1.0
         )
         self.assertIs(code, DecisionCode.CONSTRAINT_VIOLATION)
         self.assertIsNone(emitted)
diff --git a/test_controller_owner.py b/test_controller_owner.py
index 6718c37..7e050be 100644
--- a/test_controller_owner.py
+++ b/test_controller_owner.py
@@ -27,8 +27,8 @@ class ControllerOwnerTests(unittest.TestCase):
     def setUp(self):
         self.clock = DeterministicClock(0.0)
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, 1.0, 50.0, "fixture: software position limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
diff --git a/test_controller_targets.py b/test_controller_targets.py
index 1a1c7e2..04d57b4 100644
--- a/test_controller_targets.py
+++ b/test_controller_targets.py
@@ -21,8 +21,8 @@ from test_controller import DeterministicClock, FakeStation, SAMPLE, HEALTHY_STO
 class LatestTargetTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
 
     def test_ten_thousand_accepted_updates_leave_one_newest_target_and_repeated_refresh(self):
@@ -273,8 +273,8 @@ class LatestTargetTests(unittest.TestCase):
         self.assertEqual(core.snapshot().last_sequence, 1)
 
         specs_ratio = (
-            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(reduction=1.0, direction=1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(reduction=1.0, direction=1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         core_ratio = JointCore(specs_ratio, clock=clock, max_reference_gap_s=1.0)
         station_ratio = FakeStation(core_ratio)
@@ -295,8 +295,8 @@ class LatestTargetTests(unittest.TestCase):
     def test_successful_fake_adapter_uses_actual_codec_foc_packets_with_independent_expected_mappings(self):
         clock = DeterministicClock(0.0)
         specs = (
-            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(reduction=2.0, direction=1, zero_output_rad=0.1), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(reduction=2.0, direction=1, zero_output_rad=0.1), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         core = JointCore(specs, clock=clock, max_reference_gap_s=1.0)
         station = FakeStation(core)
@@ -529,8 +529,8 @@ class LatestTargetTests(unittest.TestCase):
 class CommandSequenceTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
diff --git a/test_startup.py b/test_startup.py
index 6c6e5d9..a6eb209 100644
--- a/test_startup.py
+++ b/test_startup.py
@@ -111,7 +111,7 @@ def _cleanup_after_main(window, state):
 
 def _fingerprint(root):
     names = ("motor_dashboard.py", "motor_session.py", "spin_5rpm.py", "im6014_codec.py", "im6014_serial.py", "fake_serial.py", "USER_MANUAL.md",
-             "test_spin_5rpm.py", "test_dashboard.py", "test_startup.py", "test_startup_verifier.py", "test_protocol.py", "test_serial_deadline.py", "evidence/boundary/vendor-crc-vectors.json", "joint_mapping.py", "test_joint_mapping.py", "test_numerical_inputs.py", "im6014_port.py", "test_port_config.py", "test_diagnostic_capture.py", "test_bus_owner.py", "joint_contract.py", "joint_reference.py", "joint_controller.py", "test_controller.py", "test_controller_targets.py", "test_controller_expiry.py", "test_controller_owner.py", "test_controller_limits.py", "test_controller_lead.py")
+             "test_spin_5rpm.py", "test_dashboard.py", "test_startup.py", "test_startup_verifier.py", "test_protocol.py", "test_serial_deadline.py", "evidence/boundary/vendor-crc-vectors.json", "joint_mapping.py", "test_joint_mapping.py", "test_numerical_inputs.py", "im6014_port.py", "test_port_config.py", "test_diagnostic_capture.py", "test_bus_owner.py", "joint_contract.py", "joint_reference.py", "joint_controller.py", "test_controller.py", "test_controller_targets.py", "test_controller_expiry.py", "test_controller_owner.py", "test_controller_limits.py", "test_controller_lead.py", "test_controller_effort.py")
     files = {}
     for name in names:
         path = root / name

```

## Parent evidence C13-parent-effort-repro.py
```
"""Parent exact combined-effort boundary tests; canonical bytes and fake authority only."""
from pathlib import Path
from fractions import Fraction
from dataclasses import replace
import sys,unittest,json
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from joint_contract import JointSpec,Target,DecisionCode
from joint_mapping import JointMap,JointSample,JointTarget
from joint_controller import JointCore
from joint_reference import prepare_reference_joint,predict_joint_effort
from test_controller import FakeStation,DeterministicClock,HEALTHY_STOP

def exact(t,s):
 return Fraction(t.tau_nm)+Fraction(t.kp)*(Fraction(t.q_rad)-Fraction(s.q_rad))+Fraction(t.kd)*(Fraction(t.dq_rad_s)-Fraction(s.dq_rad_s))

class EffortBoundary(unittest.TestCase):
 def test_canonical_admission_cannot_round_unsafe_combined_sum_into_peak(self):
  broad=JointSpec('J',0,JointMap(1,1,0),-2,2,10,100,1,100,'parent canonical exact-effort fixture')
  cases=[]
  for q in (.1,.2,.3):
   for ff in (.1,.2,.3):
    goal=JointTarget(q,.2,ff,1,.1)
    code,t,packet=prepare_reference_joint(broad,goal);self.assertIsNone(code)
    sample=JointSample(-.1,-.2,0)
    e=exact(t,sample);rounded=predict_joint_effort(t,sample)
    if e>Fraction(rounded)>0:cases.append((goal,t,packet,sample,e,rounded))
  self.assertTrue(cases,'Parent fixture must actually establish round-down before claiming a production defect')
  goal,t,packet,sample,e,limit=cases[0]
  print(json.dumps({'canonicalPacket':packet.hex(),'exactEffort':str(e),'roundedEffort':limit,'exactExcess':str(e-Fraction(limit))}))
  spec=replace(broad,max_effort_nm=limit)
  clock=DeterministicClock(0);core=JointCore((spec,),clock=clock,max_reference_gap_s=1)
  station=FakeStation(core);self.assertTrue(station.connect());owner=station.claim('parent')
  self.assertTrue(core.begin_check());self.assertTrue(core.receive(0,sample,HEALTHY_STOP));self.assertTrue(core.checked());self.assertTrue(station.arm(owner))
  before=core.snapshot();target=Target(1,(goal,),window=station.issue_window(1),owner=owner)
  result=station.submit(target)
  self.assertFalse(result,'Canonical combined effort exactly exceeds peak even though float predictor rounded to equality')
  self.assertEqual(result.code,DecisionCode.EFFORT_OUT_OF_BOUNDS)
  self.assertEqual(core.snapshot().last_sequence,before.last_sequence)
  self.assertEqual(core.snapshot().admitted_target,before.admitted_target)

 def test_predictor_keeps_finite_cancellation(self):
  t=JointTarget(.25,.125,4,16,8);s=JointSample(.5,.625,0)
  self.assertEqual(exact(t,s),-4)
  self.assertEqual(predict_joint_effort(t,s),-4)

unittest.main(argv=[sys.argv[0]],verbosity=2)

```

## Parent evidence C13-original-effort-repro.log
```
test_canonical_admission_cannot_round_unsafe_combined_sum_into_peak (__main__.EffortBoundary.test_canonical_admission_cannot_round_unsafe_combined_sum_into_peak) ... FAIL
test_predictor_keeps_finite_cancellation (__main__.EffortBoundary.test_predictor_keeps_finite_cancellation) ... ok

======================================================================
FAIL: test_canonical_admission_cannot_round_unsafe_combined_sum_into_peak (__main__.EffortBoundary.test_canonical_admission_cannot_round_unsafe_combined_sum_into_peak)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C13-parent-effort-repro.py", line 36, in test_canonical_admission_cannot_round_unsafe_combined_sum_into_peak
    self.assertFalse(result,'Canonical combined effort exactly exceeds peak even though float predictor rounded to equality')
AssertionError: Decision(accepted=True, code=<DecisionCode.ACCEPTED: 'accepted'>) is not false : Canonical combined effort exactly exceeds peak even though float predictor rounded to equality

----------------------------------------------------------------------
Ran 2 tests in 0.011s

FAILED (failures=1)
{"canonicalPacket": "feee900014001a00ce1900005000200024fb021b", "exactEffort": "110264429730653091072387838386043/324518553658426726783156020576256", "roundedEffort": 0.33977850723047515, "exactExcess": "8725754498523003/324518553658426726783156020576256"}

```

## rubric.md
# Review Rubric

Review through whichever lenses are relevant. Not every lens applies to every change. Use judgment.

## Correctness

Does the code actually do what the intent says it should?

- Edge cases: empty inputs, nil/undefined, boundary values, concurrent access
- Error handling: are errors caught, propagated, or silently swallowed?
- Off-by-one, type coercion, integer overflow, string encoding
- State management: race conditions, stale closures, dangling references
- Does the happy path work? Does the sad path work?
- Idempotency: what happens if this operation runs twice, or if a previous run crashed halfway? If the answer is "it depends on what state was left behind," there's a missing reconciliation step.
- Concurrency: if multiple actors can touch the same mutable state (files, branches, shared data), is access serialized structurally (locks, sequential phases, exclusive ownership), or by conventions that won't hold?

When you find a potential bug, trace the execution path. Don't just flag "this could be nil". Show the call chain that makes it nil.

## Root Causes vs. Symptoms

Is the code fixing the actual problem or papering over a symptom?

Answering this often requires looking beyond the changed files. Read the surrounding code (callers, callees, type definitions, sibling modules) and understand the architecture the change lives in. Use the tools available to you (Read, Grep, Glob) to explore. Follow the call chain. Read the types. Understand why the code exists before judging whether the change addresses the right layer.

- Guard clauses that mask a deeper invariant violation
- Retry logic that hides a broken contract
- Type casts that silence a modeling error
- If you see a workaround, ask: why is the workaround needed? What would a proper fix look like?
- A fix in module A that should really be a fix in module B's contract
- Instructions where structure would be better: if the fix is a comment saying "don't do X" or a convention someone has to remember, ask whether it could instead be a type constraint, a lint rule, or a runtime check that makes the wrong thing impossible

## Structural Integrity

Does the code fit well into the system it's part of?

- Boundary discipline: is validation at system boundaries, or scattered through business logic? Validate data once where it enters the system, then trust it internally.
- Abstraction level: is the code mixing high-level orchestration with low-level detail?
- Coupling: does this change introduce dependencies that will make future changes harder?
- Data model fit: do the data structures match the actual access patterns? The right structure makes downstream code obvious. The wrong one fights you at every turn.
- Bolted-on vs. integrated: was the change patched onto the existing design, or does it read as if the design always accounted for it? If the new requirement had been known from the start, would the code look like this?
- Legacy dual-paths: does the change introduce a new API while keeping the old one alive? If there are no external consumers, migrate callers and delete the old path in the same wave. Don't leave compatibility layers that will become permanent.

Don't penalize simple code for lacking abstraction. Premature abstraction is worse than duplication.

## Verification

Can you tell that this code works from reading it?

- Are there tests? Do they test behavior or implementation details?
- Are there assertions/invariants that would catch regressions?
- If this is a bug fix: is there a test for the bug?
- If this touches an integration boundary: is the full path tested?
- Check the real thing, not a proxy. If the code checks liveness via file mtime or cached state instead of reading the actual value, that's a verification gap.
- For delegated or async work: does the code verify actual output artifacts, or does it trust self-reports and summaries?

## Complexity Budget

Is the complexity justified by what the code accomplishes?

- Code that could be simpler without losing correctness or clarity
- Abstractions that serve only one call site
- Configuration or parameterization for cases that don't exist yet
- Dead code, unused imports, vestigial parameters
- Over-engineering: "just in case" code paths with no current callers
- Obsolete compatibility paths kept alive for transitional stability that's no longer needed. If the migration is done, delete the scaffolding
- Does the user experience justify the complexity? Every feature, control, and option should earn its place. Half-finished features are worse than missing ones.

Simpler is better unless simpler is wrong. Three lines of duplication beat a premature abstraction.

## Security

For each security finding, trace the input path through the code and show it.

- User input flowing to dangerous sinks (SQL, shell, eval, innerHTML) without sanitization
- Authentication/authorization gaps in new endpoints
- Secrets in code, logs, or error messages
- TOCTOU (time-of-check-time-of-use) in security-critical paths

## code-quality-review.md
# Code Quality Review

Each reviewer applies this code-quality lens in addition to the rubric. It is a strict standard focused on implementation quality, maintainability, abstraction quality, and codebase health.

Above all, be ambitious about code structure. Do not merely identify local cleanup. Actively search for "code judo" moves, restructurings that preserve behavior while making the implementation dramatically simpler, smaller, more direct, and more elegant.

## Core Prompt

Start from this baseline:

> Perform a deep code quality audit of the current branch's changes.
> Rethink how to structure / implement the changes to meaningfully improve code quality without impacting behavior.
> Work to improve abstractions, modularity, reduce Spaghetti code, improve succinctness and legibility.
> Be ambitious, if there is a clear path to improving the implementation that involves restructuring some of the codebase, go for it.
> Be extremely thorough and rigorous. Measure twice, cut once.

## Dimensions

Each dimension is stated once. Apply the ones that are relevant.

0. **Be ambitious about structural simplification.** Do not stop at "this could be a bit cleaner." Look for reframings that make whole branches, helpers, modes, conditionals, or layers disappear. Assume a "code judo" move is often available. It uses the existing architecture more effectively and makes the change dramatically simpler. If you can delete complexity rather than rearrange it, push hard for that.

1. **Do not let a PR push a file from under 1k lines to over 1k lines without a very strong reason.** Treat this as a strong smell. Prefer extracting helpers, subcomponents, or modules. If the diff crosses that threshold, ask whether the code should be decomposed first. Waive only for a compelling structural reason where the resulting file stays clearly organized.

2. **Do not allow spaghetti growth in existing code.** Be suspicious of new ad-hoc conditionals, scattered special cases, or one-off branches inserted into unrelated flows. Treat "weird if statements in random places" as a design problem, not a style nit. Prefer pushing the logic into a dedicated helper, state machine, or module instead of tangling an existing path.

3. **Bias toward cleaning the design, not just accepting working code.** If behavior can stay the same while the structure becomes meaningfully cleaner, push for the cleaner version. Prefer simplifications that remove moving pieces over refactors that spread the same complexity around.

4. **Prefer direct, boring, maintainable code over hacky or magical code.** Treat brittle, ad-hoc, or "magic" behavior as a problem. Be skeptical of generic mechanisms that hide simple data-shape assumptions. Flag thin abstractions, identity wrappers, or pass-through helpers that add indirection without buying clarity.

5. **Push on type and boundary cleanliness when it affects maintainability.** Question unnecessary optionality, `unknown`, `any`, or cast-heavy code when a clearer type boundary could exist. Prefer explicit typed models over loosely-shaped ad-hoc objects. If a branch leans on a silent fallback to paper over an unclear invariant, ask whether the boundary should be made explicit.

6. **Keep logic in the canonical layer and reuse existing helpers.** Call out feature logic leaking into shared paths or implementation details leaking through APIs. Prefer existing canonical utilities over bespoke one-offs. Push code toward the right package, service, or module instead of normalizing drift.

7. **Treat unnecessary sequential orchestration and non-atomic updates as design smells when the cleaner structure is obvious.** If independent work is serialized for no reason, ask whether it should run in parallel. If related updates can leave state half-applied, push for a more atomic structure. Do not over-index on micro-optimizations, but do flag avoidable orchestration complexity that makes the code more brittle.

## Output Expectations

Prioritize structural code-quality regressions and missed simplifications first, then spaghetti and branching complexity, then boundary, type, and file-size concerns, then smaller modularity and legibility issues.

## Approval Bar

Do not approve merely because behavior seems correct. Treat these as presumptive blockers unless the author can justify them: the PR keeps a lot of incidental complexity when a code-judo move would delete it. Pushes a file from below 1000 lines to above 1000 lines. Adds ad-hoc branching that tangles an existing flow. Scatters feature checks across shared code. Adds an unnecessary abstraction, wrapper, or cast-heavy contract, or duplicates an existing helper or puts logic in the wrong layer when there is a clear canonical home. If those conditions are not met, leave explicit, actionable feedback and push for a cleaner decomposition.

## Review Tone

Be direct, serious, and demanding about quality. Do not be rude, but do not soften major maintainability issues into mild suggestions. If the code is making the codebase messier, say so. If the implementation missed an obvious dramatic simplification, say that too. Do not be satisfied with "maybe rename this" when the real issue is structural.
