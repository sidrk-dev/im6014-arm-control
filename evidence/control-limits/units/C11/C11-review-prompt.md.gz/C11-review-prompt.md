Review the supplied C11 acceleration draft. It is NOT accepted. Parent found fixture failures in the included raw log and has assigned a separate repair. Use only supplied inline text; no tools, shell, filesystem, MCP, network or permission requests. Return JSON array of actionable runtime or test correctness findings with file,line,priority,reason and concrete fix; [] if none. Focus exact Fraction sampled position derivative, separate decoded wire velocity, both acceleration differences, inward codec projection, actualwrite history, cached h0, attribution and final gate. Existing fixture failures should not be reported again unless there is a distinct root cause. No physical motor claims. A parent independent 24-map768point positive/reversal acceleration/speed oracle plus768h0cache checks passed original draft, not an acceptance of tests. Both saved reviewer routes share OpenCode provider.

### joint_contract.py complete
```
"""Frozen domain records and status types for joint control.

All records are immutable (frozen) data contracts with no transport or clock ownership.
"""

from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
import math
from typing import Literal

from im6014_codec import decode_command
from joint_mapping import JointMap, JointSample, JointTarget


class State(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    CHECKING = "checking"
    READY = "ready"
    ARMED = "armed"
    MOVING = "moving"
    STOPPED = "stopped"
    FAULT = "fault"


class DecisionCode(str, Enum):
    ACCEPTED = "accepted"
    INVALID_STATE = "invalid_state"
    INVALID_ARGUMENT = "invalid_argument"
    INVALID_OWNER = "invalid_owner"
    INVALID_SOURCE = "invalid_source"
    UNKNOWN_JOINT = "unknown_joint"
    INVALID_OBSERVATION = "invalid_observation"
    FAULT_ACK_REQUIRED = "fault_ack_required"
    FAULT_LATCHED = "fault_latched"
    OBSERVATIONS_INCOMPLETE = "observations_incomplete"
    STALE_FEEDBACK = "stale_feedback"
    UNHEALTHY = "unhealthy"
    NOT_STOPPED = "not_stopped"
    DUPLICATE_OR_OLDER = "duplicate_or_older"
    EXPIRED = "expired"
    POSITION_OUT_OF_BOUNDS = "position_out_of_bounds"
    SPEED_OUT_OF_BOUNDS = "speed_out_of_bounds"
    REFERENCE_GAP_EXCEEDED = "reference_gap_exceeded"
    CONSTRAINT_VIOLATION = "constraint_violation"


class CommunicationFailure(str, Enum):
    TIMEOUT = "timeout"
    INVALID_FEEDBACK = "invalid_feedback"
    DRIVER_FAILURE = "driver_failure"
    CLOCK_FAILURE = "clock_failure"
    PREWRITE_DEADLINE = "prewrite_deadline"


class WriteResult(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    PREWRITE_DEADLINE = "prewrite_deadline"


@dataclass(frozen=True)
class Decision:
    accepted: bool
    code: DecisionCode

    def __post_init__(self) -> None:
        if type(self.accepted) is not bool:
            raise ValueError("accepted must be a bool")
        if not isinstance(self.code, DecisionCode):
            raise ValueError("code must be a DecisionCode")
        if self.accepted != (self.code is DecisionCode.ACCEPTED):
            raise ValueError("accepted must match the decision code")

    def __bool__(self) -> bool:
        return self.accepted


@dataclass(frozen=True)
class JointSpec:
    name: str
    motor_id: int
    mapping: JointMap
    q_min_rad: float
    q_max_rad: float
    v_max_rad_s: float
    a_max_rad_s2: float
    limits_provenance: str

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if not isinstance(self.mapping, JointMap):
            raise ValueError("mapping must be a JointMap")

        if isinstance(self.q_min_rad, bool) or not isinstance(self.q_min_rad, (int, float)):
            raise ValueError("q_min_rad must be a finite real number")
        if isinstance(self.q_max_rad, bool) or not isinstance(self.q_max_rad, (int, float)):
            raise ValueError("q_max_rad must be a finite real number")
        try:
            min_val = float(self.q_min_rad)
            max_val = float(self.q_max_rad)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("position limits must be finite") from exc
        if not math.isfinite(min_val) or not math.isfinite(max_val):
            raise ValueError("position limits must be finite")
        if min_val > max_val:
            raise ValueError("q_min_rad must be less than or equal to q_max_rad")

        if isinstance(self.v_max_rad_s, bool) or not isinstance(self.v_max_rad_s, (int, float)):
            raise ValueError("v_max_rad_s must be a finite positive real number")
        try:
            v_max_val = float(self.v_max_rad_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("speed limit must be finite") from exc
        if not math.isfinite(v_max_val) or v_max_val <= 0.0:
            raise ValueError("v_max_rad_s must be finite and positive")

        if isinstance(self.a_max_rad_s2, bool) or not isinstance(self.a_max_rad_s2, (int, float)):
            raise ValueError("a_max_rad_s2 must be a finite positive real number")
        try:
            a_max_val = float(self.a_max_rad_s2)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("acceleration limit must be finite") from exc
        if not math.isfinite(a_max_val) or a_max_val <= 0.0:
            raise ValueError("a_max_rad_s2 must be finite and positive")

        if (
            type(self.limits_provenance) is not str
            or not self.limits_provenance.strip()
            or len(self.limits_provenance) > 256
        ):
            raise ValueError("limits_provenance must be a bounded non-empty string")

        object.__setattr__(self, "q_min_rad", min_val)
        object.__setattr__(self, "q_max_rad", max_val)
        object.__setattr__(self, "v_max_rad_s", v_max_val)
        object.__setattr__(self, "a_max_rad_s2", a_max_val)

@dataclass(frozen=True)
class JointFault:
    name: str
    motor_id: int
    errors: int = 0
    warnings: int = 0
    timeout: bool = False
    communication_error: CommunicationFailure | None = None
    stale: bool = False
    communication_errors: tuple[CommunicationFailure, ...] = ()
    position_limit: bool = False
    speed_limit: bool = False
    constraint_fault: bool = False

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if type(self.stale) is not bool:
            raise ValueError("stale must be a bool")
        if type(self.communication_errors) is not tuple or any(
            not isinstance(c, CommunicationFailure) for c in self.communication_errors
        ):
            raise ValueError("communication_errors must be a tuple of CommunicationFailure")
        if type(self.position_limit) is not bool:
            raise ValueError("position_limit must be a bool")
        if type(self.speed_limit) is not bool:
            raise ValueError("speed_limit must be a bool")
        if type(self.constraint_fault) is not bool:
            raise ValueError("constraint_fault must be a bool")

        if len(self.communication_errors) != len(set(self.communication_errors)):
            raise ValueError("communication_errors must contain unique codes")
        if self.communication_error is not None and self.communication_errors and (
            self.communication_error not in self.communication_errors
        ):
            raise ValueError("communication_error must belong to communication_errors")

        if self.communication_error is not None and not self.communication_errors:
            object.__setattr__(self, "communication_errors", (self.communication_error,))
        elif self.communication_errors and self.communication_error is None:
            object.__setattr__(self, "communication_error", self.communication_errors[-1])


@dataclass(frozen=True)
class MotorHealth:
    mode: int
    errors: int
    warnings: int
    timeout: bool

    def __post_init__(self) -> None:
        if type(self.mode) is not int or self.mode not in (0, 1):
            raise ValueError("mode must be the integer 0 or 1")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")

    @property
    def healthy(self) -> bool:
        return self.errors == 0 and self.warnings == 0 and not self.timeout


@dataclass(frozen=True)
class SourceIdentity:
    backend: Literal["physical", "demo", "fixture"]
    identity: str
    connection: int

    def __post_init__(self) -> None:
        if type(self.backend) is not str or self.backend not in ("physical", "demo", "fixture"):
            raise ValueError("backend must be physical, demo, or fixture")
        if type(self.identity) is not str or not self.identity.strip():
            raise ValueError("identity must be a non-empty string")
        if type(self.connection) is not int or self.connection < 0:
            raise ValueError("connection must be a nonnegative integer")


@dataclass(frozen=True)
class JointStatus:
    sample: JointSample | None = None
    health: MotorHealth | None = None
    received_at: float | None = None
    communication_error: CommunicationFailure | None = None

    def __post_init__(self) -> None:
        if (self.sample is None) != (self.health is None):
            raise ValueError("sample and health must both be present or both be absent")
        if self.sample is not None and not isinstance(self.sample, JointSample):
            raise ValueError("sample must be a JointSample")
        if self.health is not None and not isinstance(self.health, MotorHealth):
            raise ValueError("health must be MotorHealth")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if self.valid and self.received_at is None:
            raise ValueError("a valid observation requires received_at")
        if self.received_at is not None:
            if isinstance(self.received_at, bool) or not isinstance(self.received_at, (int, float)):
                raise ValueError("received_at must be a finite real number or None")
            try:
                received_at = float(self.received_at)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("received_at must be finite") from exc
            if not math.isfinite(received_at):
                raise ValueError("received_at must be finite")
            if not self.valid:
                raise ValueError("received_at requires a valid observation")
            object.__setattr__(self, "received_at", received_at)

    @property
    def valid(self) -> bool:
        return self.sample is not None and self.health is not None

    @property
    def healthy(self) -> bool:
        return self.valid and self.health.healthy and self.communication_error is None

    @property
    def errors(self) -> int:
        return self.health.errors if self.health is not None else 0

    @property
    def warnings(self) -> int:
        return self.health.warnings if self.health is not None else 0

    @property
    def timeout(self) -> bool:
        return self.health.timeout if self.health is not None else False


@dataclass(frozen=True)
class OwnerToken:
    epoch: str
    generation: int
    connection_id: str

    def __post_init__(self) -> None:
        if type(self.epoch) is not str or not self.epoch.strip() or len(self.epoch) > 64:
            raise ValueError("epoch must be a bounded non-empty string")
        if type(self.generation) is not int or not (1 <= self.generation <= (1 << 64) - 1):
            raise ValueError("generation must be an integer from 1 to 2**64 - 1")
        if type(self.connection_id) is not str or not self.connection_id.strip() or len(self.connection_id) > 64:
            raise ValueError("connection_id must be a bounded non-empty string")


def owner_tokens_match(candidate: object, current: object) -> bool:
    return (
        type(candidate) is OwnerToken
        and type(current) is OwnerToken
        and candidate.epoch == current.epoch
        and candidate.generation == current.generation
        and candidate.connection_id == current.connection_id
    )


@dataclass(frozen=True)
class IntentWindow:
    id: int
    created_at_s: float
    expires_at_s: float

    def __post_init__(self) -> None:
        if type(self.id) is not int or not (0 <= self.id <= (1 << 64) - 1):
            raise ValueError("window ID must be an integer from 0 to 2**64 - 1")
        if isinstance(self.created_at_s, bool) or not isinstance(self.created_at_s, (int, float)):
            raise ValueError("created_at_s must be a finite real number")
        if isinstance(self.expires_at_s, bool) or not isinstance(self.expires_at_s, (int, float)):
            raise ValueError("expires_at_s must be a finite real number")
        try:
            created = float(self.created_at_s)
            expires = float(self.expires_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("window timestamps must be finite") from exc
        if not math.isfinite(created) or not math.isfinite(expires):
            raise ValueError("window timestamps must be finite")
        if expires <= created:
            raise ValueError("expires_at_s must be strictly greater than created_at_s")
        object.__setattr__(self, "created_at_s", created)
        object.__setattr__(self, "expires_at_s", expires)


@dataclass(frozen=True)
class Target:
    sequence: int
    joints: tuple[JointTarget, ...]
    window: IntentWindow
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if type(self.joints) is not tuple:
            raise ValueError("joints must be a tuple of JointTarget")
        if not self.joints:
            raise ValueError("joints must be a non-empty tuple")
        if any(not isinstance(joint, JointTarget) for joint in self.joints):
            raise ValueError("every joint target must be a JointTarget")
        if not isinstance(self.window, IntentWindow):
            raise ValueError("window must be an IntentWindow")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")


@dataclass(frozen=True)
class JointTrajectoryReference:
    q_rad: float
    position_step_velocity_rad_s: Fraction
    encoded_velocity_rad_s: float
    sample_time_s: float
    is_emitted: bool = False
    requested_goal: JointTarget | None = None
    emitted_target: JointTarget | None = None
    packet: bytes | None = None

    def __post_init__(self) -> None:
        for name, val in (("q_rad", self.q_rad),
                          ("encoded_velocity_rad_s", self.encoded_velocity_rad_s),
                          ("sample_time_s", self.sample_time_s)):
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                raise ValueError(f"{name} must be a finite real number")
            try:
                v = float(val)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError(f"{name} must be finite") from exc
            if not math.isfinite(v):
                raise ValueError(f"{name} must be finite")
            object.__setattr__(self, name, v)

        derivative = self.position_step_velocity_rad_s
        if isinstance(derivative, bool) or not isinstance(derivative, (int, float, Fraction)):
            raise ValueError("position_step_velocity_rad_s must be an exact finite rational")
        if isinstance(derivative, Fraction):
            exact_derivative = derivative
        else:
            try:
                as_float = float(derivative)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("position_step_velocity_rad_s must be finite") from exc
            if not math.isfinite(as_float):
                raise ValueError("position_step_velocity_rad_s must be finite")
            exact_derivative = Fraction(as_float)
        object.__setattr__(self, "position_step_velocity_rad_s", exact_derivative)

        if type(self.is_emitted) is not bool:
            raise ValueError("is_emitted must be a bool")
        if self.is_emitted:
            if not isinstance(self.requested_goal, JointTarget):
                raise ValueError("an emitted reference requires its requested goal")
            if not isinstance(self.emitted_target, JointTarget):
                raise ValueError("an emitted reference requires its decoded target")
            if type(self.packet) is not bytes:
                raise ValueError("an emitted reference requires immutable packet bytes")
            try:
                decoded = decode_command(self.packet)
            except ValueError as exc:
                raise ValueError("an emitted reference requires a canonical command") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("an emitted reference requires a watchdog-enabled FOC command")
            if self.q_rad != self.emitted_target.q_rad:
                raise ValueError("reference position must match its decoded target")
            if self.encoded_velocity_rad_s != self.emitted_target.dq_rad_s:
                raise ValueError("encoded velocity must match its decoded target")
        else:
            if (
                self.requested_goal is not None
                or self.emitted_target is not None
                or self.packet is not None
            ):
                raise ValueError("an unemitted Stop anchor cannot contain an emitted command")
            if exact_derivative != 0 or self.encoded_velocity_rad_s != 0.0:
                raise ValueError("an unemitted Stop anchor must have zero velocity history")


@dataclass(frozen=True)
class RefreshPlan:
    plan_id: int
    target: Target
    prepared_at_s: float
    joint_targets: tuple[JointTarget, ...]
    packets: tuple[bytes, ...]
    proposed_references: tuple[JointTrajectoryReference, ...]

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, Target):
            raise ValueError("target must be a Target")
        if isinstance(self.prepared_at_s, bool) or not isinstance(self.prepared_at_s, (int, float)):
            raise ValueError("prepared_at_s must be a finite real number")
        try:
            prepared = float(self.prepared_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("prepared_at_s must be finite") from exc
        if not math.isfinite(prepared):
            raise ValueError("prepared_at_s must be finite")
        object.__setattr__(self, "prepared_at_s", prepared)
        if type(self.joint_targets) is not tuple or not self.joint_targets:
            raise ValueError("joint_targets must be a non-empty tuple")
        if any(not isinstance(jt, JointTarget) for jt in self.joint_targets):
            raise ValueError("every joint target must be a JointTarget")
        if len(self.target.joints) != len(self.joint_targets):
            raise ValueError("joint_targets must match the complete target vector")
        if type(self.packets) is not tuple or len(self.packets) != len(self.joint_targets):
            raise ValueError("packets must be a tuple matching joint_targets")
        for packet in self.packets:
            if type(packet) is not bytes:
                raise ValueError("packets must contain immutable bytes")
            try:
                decoded = decode_command(packet)
            except ValueError as exc:
                raise ValueError("packets must contain canonical commands") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("refresh packets must be watchdog-enabled FOC commands")
        if (
            type(self.proposed_references) is not tuple
            or len(self.proposed_references) != len(self.joint_targets)
        ):
            raise ValueError("proposed_references must match joint_targets length")
        for goal, target, packet, reference in zip(
            self.target.joints,
            self.joint_targets,
            self.packets,
            self.proposed_references,
        ):
            if not isinstance(reference, JointTrajectoryReference) or not reference.is_emitted:
                raise ValueError("every plan requires a complete emitted reference")
            if reference.requested_goal != goal:
                raise ValueError("reference goal must match the admitted joint goal")
            if reference.emitted_target != target or reference.packet != packet:
                raise ValueError("reference target and packet must match the prepared command")
            if reference.sample_time_s > prepared:
                raise ValueError("reference sample time cannot follow plan preparation")

    @property
    def window(self) -> IntentWindow:
        return self.target.window

    @property
    def owner(self) -> OwnerToken:
        return self.target.owner


@dataclass(frozen=True)
class JointDispatchedRecord:
    sequence: int
    target: JointTarget
    dispatched_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.dispatched_at_s, bool) or not isinstance(self.dispatched_at_s, (int, float)):
            raise ValueError("dispatched_at_s must be a finite real number")
        try:
            dispatched = float(self.dispatched_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("dispatched_at_s must be finite") from exc
        if not math.isfinite(dispatched):
            raise ValueError("dispatched_at_s must be finite")
        object.__setattr__(self, "dispatched_at_s", dispatched)


@dataclass(frozen=True)
class JointDispatchAttempt:
    plan_id: int
    sequence: int
    target: JointTarget
    result: WriteResult
    started_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if not isinstance(self.result, WriteResult):
            raise ValueError("result must be a WriteResult")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.started_at_s, bool) or not isinstance(self.started_at_s, (int, float)):
            raise ValueError("started_at_s must be a finite real number")
        try:
            started = float(self.started_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("started_at_s must be finite") from exc
        if not math.isfinite(started):
            raise ValueError("started_at_s must be finite")
        object.__setattr__(self, "started_at_s", started)


@dataclass(frozen=True)
class Snapshot:
    state: State
    joint_names: tuple[str, ...]
    joints: tuple[JointStatus, ...]
    source: SourceIdentity | None
    fault_latched: bool
    feedback_ages_s: tuple[float | None, ...]
    faults: tuple[JointFault, ...] = ()
    admitted_target: Target | None = None
    prepared_plan: RefreshPlan | None = None
    dispatched_records: tuple[JointDispatchedRecord | None, ...] = ()
    last_sequence: int = -1
    dispatch_attempts: tuple[JointDispatchAttempt | None, ...] = ()
    latest_owner: OwnerToken | None = None
    current_owner: OwnerToken | None = None
    confirmed_references: tuple[JointTrajectoryReference | None, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.state, State):
            raise ValueError("state must be a State")
        if type(self.joint_names) is not tuple or any(type(name) is not str for name in self.joint_names):
            raise ValueError("joint_names must be a tuple of strings")
        if type(self.joints) is not tuple or any(not isinstance(joint, JointStatus) for joint in self.joints):
            raise ValueError("joints must be a tuple of JointStatus")
        if type(self.feedback_ages_s) is not tuple:
            raise ValueError("feedback_ages_s must be a tuple")
        if len(self.joint_names) != len(self.joints):
            raise ValueError("joint names and statuses must have equal lengths")
        if len(self.feedback_ages_s) != len(self.joints):
            raise ValueError("feedback ages and joint statuses must have equal lengths")
        normalized_ages: list[float | None] = []
        for joint, age in zip(self.joints, self.feedback_ages_s):
            if joint.received_at is None:
                if age is not None:
                    raise ValueError("feedback age must be None before a joint is received")
                normalized_ages.append(None)
                continue
            if isinstance(age, bool) or not isinstance(age, (int, float)):
                raise ValueError("feedback age must be a finite nonnegative number")
            try:
                age_value = float(age)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("feedback age must be finite") from exc
            if not math.isfinite(age_value) or age_value < 0.0:
                raise ValueError("feedback age must be finite and nonnegative")
            normalized_ages.append(age_value)
        object.__setattr__(self, "feedback_ages_s", tuple(normalized_ages))
        if self.source is not None and not isinstance(self.source, SourceIdentity):
            raise ValueError("source must be a SourceIdentity or None")
        if type(self.fault_latched) is not bool:
            raise ValueError("fault_latched must be a bool")
        if type(self.faults) is not tuple or any(not isinstance(f, JointFault) for f in self.faults):
            raise ValueError("faults must be a tuple of JointFault")
        if self.admitted_target is not None and not isinstance(self.admitted_target, Target):
            raise ValueError("admitted_target must be a Target or None")
        if self.prepared_plan is not None and not isinstance(self.prepared_plan, RefreshPlan):
            raise ValueError("prepared_plan must be a RefreshPlan or None")
        if not self.dispatched_records:
            object.__setattr__(self, "dispatched_records", tuple(None for _ in self.joints))
        else:
            if type(self.dispatched_records) is not tuple or len(self.dispatched_records) != len(self.joints):
                raise ValueError("dispatched_records must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchedRecord) for r in self.dispatched_records):
                raise ValueError("every dispatched record must be a JointDispatchedRecord or None")
        if not self.dispatch_attempts:
            object.__setattr__(self, "dispatch_attempts", tuple(None for _ in self.joints))
        else:
            if type(self.dispatch_attempts) is not tuple or len(self.dispatch_attempts) != len(self.joints):
                raise ValueError("dispatch_attempts must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchAttempt) for r in self.dispatch_attempts):
                raise ValueError("every dispatch attempt must be a JointDispatchAttempt or None")
        if type(self.last_sequence) is not int or not (-1 <= self.last_sequence <= (1 << 64) - 1):
            raise ValueError("last_sequence must be an integer from -1 to 2**64 - 1")
        if self.latest_owner is not None and type(self.latest_owner) is not OwnerToken:
            raise ValueError("latest_owner must be an OwnerToken or None")
        if self.current_owner is not None and type(self.current_owner) is not OwnerToken:
            raise ValueError("current_owner must be an OwnerToken or None")
        if not self.confirmed_references:
            object.__setattr__(self, "confirmed_references", tuple(None for _ in self.joints))
        else:
            if type(self.confirmed_references) is not tuple or len(self.confirmed_references) != len(self.joints):
                raise ValueError("confirmed_references must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointTrajectoryReference) for r in self.confirmed_references):
                raise ValueError("every confirmed reference must be a JointTrajectoryReference or None")

    @property
    def affected_joints(self) -> tuple[str, ...]:
        return tuple(fault.name for fault in self.faults)

```

### joint_controller.py complete
```
"""Transport-free lifecycle and health state for an ordered joint set.

All methods on a JointCore belong to one calling thread. The core owns no
transport and all externally visible records are immutable snapshots.
"""

from collections.abc import Iterable
from dataclasses import dataclass
from fractions import Fraction
import math
import secrets
import time

from joint_contract import (
    CommunicationFailure,
    Decision,
    DecisionCode,
    IntentWindow,
    JointDispatchAttempt,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    JointTrajectoryReference,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
    owner_tokens_match,
)
from joint_mapping import JointSample
from joint_reference import prepare_complete_reference, validate_target_vector

__all__ = ("JointCore",)


@dataclass(frozen=True)
class _DispatchClaim:
    plan: RefreshPlan
    index: int
    started_at_s: float


class JointCore:
    """Thread-confined state machine for one fixed, ordered set of joints.

    The core public API assumes trusted station callers; C16 server binds its
    actual connection identity rather than trusting client-supplied JSON fields.
    No authentication claims are made beyond that boundary.
    """

    def __init__(
        self,
        joints: Iterable[JointSpec],
        *,
        max_reference_gap_s: float,
        feedback_max_age_s: float = 0.5,
        max_window_s: float = 1.0,
        clock=None,
    ):
        if isinstance(max_reference_gap_s, bool) or not isinstance(max_reference_gap_s, (int, float)):
            raise ValueError("max_reference_gap_s must be a finite positive real number")
        try:
            max_reference_gap_s = float(max_reference_gap_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_reference_gap_s must be finite") from exc
        if not math.isfinite(max_reference_gap_s) or max_reference_gap_s <= 0.0:
            raise ValueError("max_reference_gap_s must be finite and positive")

        if isinstance(feedback_max_age_s, bool) or not isinstance(feedback_max_age_s, (int, float)):
            raise ValueError("feedback_max_age_s must be a finite positive real number")
        try:
            feedback_max_age_s = float(feedback_max_age_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("feedback_max_age_s must be finite") from exc
        if not math.isfinite(feedback_max_age_s) or feedback_max_age_s <= 0.0:
            raise ValueError("feedback_max_age_s must be finite and positive")

        if isinstance(max_window_s, bool) or not isinstance(max_window_s, (int, float)):
            raise ValueError("max_window_s must be a finite positive real number")
        try:
            max_window_s = float(max_window_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_window_s must be finite") from exc
        if not math.isfinite(max_window_s) or max_window_s <= 0.0:
            raise ValueError("max_window_s must be finite and positive")

        if clock is None:
            clock = time.monotonic
        if not callable(clock):
            raise ValueError("clock must be callable")

        self._epoch = secrets.token_hex(16)

        try:
            specs = tuple(joints)
        except TypeError as exc:
            raise ValueError("joints must be an iterable of JointSpec") from exc
        if not specs:
            raise ValueError("at least one active joint is required")
        if any(not isinstance(spec, JointSpec) for spec in specs):
            raise ValueError("every joint must be a JointSpec")
        if len({spec.name for spec in specs}) != len(specs):
            raise ValueError("joint names must be unique")
        if len({spec.motor_id for spec in specs}) != len(specs):
            raise ValueError("motor IDs must be unique")

        self._specs: tuple[JointSpec, ...] = specs
        self._id_to_index: dict[int, int] = {
            spec.motor_id: index for index, spec in enumerate(specs)
        }
        self._state: State = State.DISCONNECTED
        self._observations: list[JointStatus] = [JointStatus() for _ in specs]
        self._source: SourceIdentity | None = None
        self._max_reference_gap_s = max_reference_gap_s
        self._feedback_max_age_s = feedback_max_age_s
        self._max_window_s = max_window_s
        self._clock = clock
        self._now_high_water_s: float | None = None
        self._next_window_id: int = 0
        self._offered_window: IntentWindow | None = None
        self._next_generation: int = 1
        self._latest_owner: OwnerToken | None = None
        self._current_owner: OwnerToken | None = None
        self._admitted_target: Target | None = None
        self._prepared_plan: RefreshPlan | None = None
        self._next_plan_id: int = 0
        self._next_dispatch_index: int = 0
        self._dispatch_claim: _DispatchClaim | None = None
        self._dispatched_records: list[JointDispatchedRecord | None] = [None for _ in specs]
        self._dispatch_attempts: list[JointDispatchAttempt | None] = [None for _ in specs]
        self._confirmed_references: list[JointTrajectoryReference | None] = [None for _ in specs]
        self._faults: dict[str, JointFault] = {}
        self._last_sequence: int = -1

    @property
    def max_reference_gap_s(self) -> float:
        return self._max_reference_gap_s

    @property
    def joint_specs(self) -> tuple[JointSpec, ...]:
        return self._specs

    @property
    def admitted_target(self) -> Target | None:
        return self._admitted_target

    @staticmethod
    def _accepted() -> Decision:
        return Decision(True, DecisionCode.ACCEPTED)

    @staticmethod
    def _rejected(code: DecisionCode) -> Decision:
        return Decision(False, code)

    def _clear_observations(self) -> None:
        self._observations = [JointStatus() for _ in self._specs]

    def _invalidate_plan(self) -> None:
        self._prepared_plan = None
        self._next_dispatch_index = 0

    def _revoke_authority(self) -> None:
        self._current_owner = None
        self._offered_window = None
        self._admitted_target = None
        self._invalidate_plan()

    def claim_owner(self, connection_id: str) -> OwnerToken:
        """Issue and claim owner authority for a trusted station caller.

        The core public API assumes trusted station callers; C16 server binds its
        actual connection identity rather than trusting client-supplied JSON fields.
        No authentication claims are made beyond that boundary.
        """
        if (
            type(connection_id) is not str
            or not connection_id.strip()
            or len(connection_id) > 64
        ):
            raise ValueError("connection_id must be a bounded non-empty string")
        was_owned = self._current_owner is not None
        stop_for_claim = self._state in (
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
        ) or (was_owned and self._state not in (State.DISCONNECTED, State.CONNECTING))
        self._revoke_authority()
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            pass
        elif self._state is State.FAULT or self._faults:
            self._state = State.FAULT
        elif stop_for_claim:
            self._state = State.STOPPED

        if self._next_generation > (1 << 64) - 1:
            raise OverflowError("owner generation sequence exhausted")

        generation = self._next_generation
        self._next_generation += 1
        token = OwnerToken(
            epoch=self._epoch,
            generation=generation,
            connection_id=connection_id,
        )
        self._current_owner = token
        self._latest_owner = token
        return token

    def _record_dispatch_failure(
        self, index: int, cause: CommunicationFailure
    ) -> None:
        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            spec.motor_id,
            communication_error=cause,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample,
            joint.health,
            joint.received_at,
            cause,
        )

    def _latch_joint_fault(
        self,
        name: str,
        motor_id: int,
        *,
        errors: int = 0,
        warnings: int = 0,
        timeout: bool = False,
        communication_error: CommunicationFailure | None = None,
        stale: bool = False,
        position_limit: bool = False,
        speed_limit: bool = False,
        constraint_fault: bool = False,
    ) -> None:
        existing = self._faults.get(name) or JointFault(name, motor_id)
        communication_errors = existing.communication_errors
        if communication_error is not None and communication_error not in communication_errors:
            communication_errors += (communication_error,)
        fault = JointFault(
            name, motor_id,
            errors=existing.errors | errors,
            warnings=existing.warnings | warnings,
            timeout=existing.timeout or timeout,
            stale=existing.stale or stale,
            communication_error=communication_error or existing.communication_error,
            communication_errors=communication_errors,
            position_limit=existing.position_limit or position_limit,
            speed_limit=existing.speed_limit or speed_limit,
            constraint_fault=existing.constraint_fault or constraint_fault,
        )
        self._faults[name] = fault
        if self._state is not State.DISCONNECTED:
            self._state = State.FAULT
        self._revoke_authority()

    def _withdraw_expired_goal(self) -> None:
        self._revoke_authority()
        if self._faults:
            self._state = State.FAULT
        elif self._state in (State.ARMED, State.MOVING):
            self._state = State.STOPPED

    def _now(self) -> float:
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("clock must return a finite real number")
        try:
            result = float(value)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("clock must return a finite real number") from exc
        if not math.isfinite(result):
            raise ValueError("clock must return a finite real number")
        if self._now_high_water_s is not None and result < self._now_high_water_s:
            raise ValueError(
                f"clock regressed from {self._now_high_water_s} to {result}"
            )
        self._now_high_water_s = result
        return result

    @staticmethod
    def _age(received_at: float, now: float) -> float:
        age = now - received_at
        if not math.isfinite(age) or age < 0.0:
            raise ValueError("clock must be monotonic and feedback age finite")
        return age

    def _all_fresh(self, now: float) -> bool:
        return all(
            joint.valid
            and joint.received_at is not None
            and self._age(joint.received_at, now) <= self._feedback_max_age_s
            for joint in self._observations
        )

    def _housekeeping(self, now: float) -> DecisionCode | None:
        if self._state in (State.READY, State.ARMED, State.MOVING):
            stale_by_joint: list[bool] = []
            pos_outside_by_joint: list[bool] = []
            speed_outside_by_joint: list[bool] = []
            for spec, joint in zip(self._specs, self._observations):
                stale_by_joint.append(
                    not joint.valid
                    or joint.received_at is None
                    or self._age(joint.received_at, now) > self._feedback_max_age_s
                )
                pos_outside_by_joint.append(
                    joint.valid
                    and joint.sample is not None
                    and (joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad)
                )
                speed_outside_by_joint.append(
                    joint.valid
                    and joint.sample is not None
                    and (abs(joint.sample.dq_rad_s) > spec.v_max_rad_s)
                )
            for spec, stale, pos_out, speed_out in zip(
                self._specs, stale_by_joint, pos_outside_by_joint, speed_outside_by_joint
            ):
                if stale or pos_out or speed_out:
                    self._latch_joint_fault(
                        spec.name,
                        spec.motor_id,
                        stale=stale,
                        position_limit=pos_out,
                        speed_limit=speed_out,
                    )
            if any(stale_by_joint):
                return DecisionCode.STALE_FEEDBACK
            if any(pos_outside_by_joint):
                return DecisionCode.POSITION_OUT_OF_BOUNDS
            if any(speed_outside_by_joint):
                return DecisionCode.SPEED_OUT_OF_BOUNDS
        if (
            self._admitted_target is not None
            and now >= self._admitted_target.window.expires_at_s
        ):
            self._withdraw_expired_goal()
            return DecisionCode.EXPIRED
        return None

    def issue_window(self, valid_for_s: float) -> IntentWindow:
        if isinstance(valid_for_s, bool) or not isinstance(valid_for_s, (int, float)):
            raise ValueError("valid_for_s must be a finite positive real number")
        try:
            valid_for_s = float(valid_for_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("valid_for_s must be finite") from exc
        if not math.isfinite(valid_for_s) or valid_for_s <= 0.0:
            raise ValueError("valid_for_s must be finite and positive")
        if valid_for_s > self._max_window_s:
            raise ValueError(
                f"valid_for_s ({valid_for_s}) exceeds configured maximum window ({self._max_window_s})"
            )
        now = self._now()
        window_id = self._next_window_id
        if window_id > (1 << 64) - 1:
            raise OverflowError("window ID sequence exhausted")
        self._next_window_id += 1
        window = IntentWindow(
            id=window_id,
            created_at_s=now,
            expires_at_s=now + valid_for_s,
        )
        self._offered_window = window
        return window

    def begin_connect(self) -> Decision:
        if self._state is not State.DISCONNECTED or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        self._state = State.CONNECTING
        return self._accepted()

    def connected(self, source: SourceIdentity) -> Decision:
        if self._state is not State.CONNECTING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not isinstance(source, SourceIdentity):
            return self._rejected(DecisionCode.INVALID_SOURCE)
        self._clear_observations()
        self._source = source
        self._state = State.CONNECTED
        return self._accepted()

    def begin_check(self, *, acknowledge_fault: bool = False) -> Decision:
        if type(acknowledge_fault) is not bool:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._state not in (State.CONNECTED, State.STOPPED, State.FAULT) or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        if bool(self._faults) and not acknowledge_fault:
            return self._rejected(DecisionCode.FAULT_ACK_REQUIRED)
        self._clear_observations()
        self._admitted_target = None
        self._confirmed_references = [None for _ in self._specs]
        self._invalidate_plan()
        self._state = State.CHECKING
        return self._accepted()

    def receive(
        self, motor_id: int, sample: JointSample, status: MotorHealth
    ) -> Decision:
        if self._state not in (
            State.CONNECTED,
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
            State.STOPPED,
            State.FAULT,
        ):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)
        if not isinstance(sample, JointSample) or not isinstance(status, MotorHealth):
            return self._rejected(DecisionCode.INVALID_OBSERVATION)

        now = self._now()
        self._observations[index] = JointStatus(sample, status, now)
        spec = self._specs[index]
        position_limit = (
            sample.q_rad < spec.q_min_rad or sample.q_rad > spec.q_max_rad
        )
        speed_limit = (
            abs(sample.dq_rad_s) > spec.v_max_rad_s
        )
        if not status.healthy or position_limit or speed_limit:
            self._latch_joint_fault(
                spec.name,
                motor_id,
                errors=status.errors,
                warnings=status.warnings,
                timeout=status.timeout,
                position_limit=position_limit,
                speed_limit=speed_limit,
            )
        if position_limit:
            return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
        if speed_limit:
            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)
        return self._accepted()

    def communication_failed(
        self, motor_id: int, code: CommunicationFailure
    ) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)

        if not isinstance(code, CommunicationFailure):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        failure_code = code

        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            motor_id,
            communication_error=failure_code,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample, joint.health, joint.received_at, failure_code
        )
        return self._accepted()

    def checked(self) -> Decision:
        if self._state is not State.CHECKING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        pos_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
        ]
        speed_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
        ]
        if pos_out_of_bounds or speed_out_of_bounds:
            for spec in pos_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            for spec in speed_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            if pos_out_of_bounds:
                return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)

        self._state = State.READY
        self._faults.clear()
        self._confirmed_references = [
            JointTrajectoryReference(
                q_rad=joint.sample.q_rad,
                position_step_velocity_rad_s=0.0,
                encoded_velocity_rad_s=0.0,
                sample_time_s=joint.received_at,
                is_emitted=False,
            )
            for joint in self._observations
        ]
        return self._accepted()

    def arm(self, owner: OwnerToken) -> Decision:
        if self._state is not State.READY:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not owner_tokens_match(owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)
        if bool(self._faults):
            return self._rejected(DecisionCode.FAULT_LATCHED)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        pos_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
        ]
        speed_out_of_bounds = [
            spec
            for spec, joint in zip(self._specs, self._observations)
            if abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
        ]
        if pos_out_of_bounds or speed_out_of_bounds:
            for spec in pos_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            for spec in speed_out_of_bounds:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            if pos_out_of_bounds:
                return self._rejected(DecisionCode.POSITION_OUT_OF_BOUNDS)
            return self._rejected(DecisionCode.SPEED_OUT_OF_BOUNDS)

        self._state = State.ARMED
        return self._accepted()

    def tick(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        self._housekeeping(now)
        return self._accepted()

    def submit_target(self, target: Target) -> Decision:
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        housekeeping = self._housekeeping(now)
        if housekeeping is not None:
            return self._rejected(housekeeping)
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)

        if not isinstance(target, Target) or len(target.joints) != len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        if not owner_tokens_match(target.owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)

        if not isinstance(target.window, IntentWindow):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._offered_window is None:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if target.window.id < self._offered_window.id:
            return self._rejected(DecisionCode.EXPIRED)
        if target.window.id != self._offered_window.id:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if (
            target.window.created_at_s != self._offered_window.created_at_s
            or target.window.expires_at_s != self._offered_window.expires_at_s
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if now >= target.window.expires_at_s:
            return self._rejected(DecisionCode.EXPIRED)

        validation_failures = validate_target_vector(self._specs, target)
        if validation_failures:
            return self._rejected(validation_failures[0].code)

        if target.sequence <= self._last_sequence:
            return self._rejected(DecisionCode.DUPLICATE_OR_OLDER)

        self._admitted_target = target
        self._last_sequence = target.sequence
        self._invalidate_plan()
        return self._accepted()

    def prepare_refresh(self) -> RefreshPlan | None:
        if self._dispatch_claim is not None:
            return None
        if self._state not in (State.ARMED, State.MOVING):
            return None
        if self._state is State.FAULT or bool(self._faults):
            return None
        try:
            now = self._now()
        except ValueError:
            self.stop()
            raise
        if self._housekeeping(now) is not None:
            return None
        if any(not joint.healthy for joint in self._observations):
            return None
        if self._admitted_target is None:
            return None
        if not owner_tokens_match(self._admitted_target.owner, self._current_owner):
            return None

        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid or joint.sample is None:
                return None
            pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
            speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
            if pos_out or speed_out:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=pos_out, speed_limit=speed_out)
                self.stop()
                return None

        for spec, conf_ref in zip(self._specs, self._confirmed_references):
            if conf_ref is None:
                return None
            gap = now - conf_ref.sample_time_s
            if not math.isfinite(gap) or gap < 0.0:
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
                self.stop()
                return None
            if gap > self._max_reference_gap_s:
                self.stop()
                return None

        prepared = prepare_complete_reference(
            self._specs,
            self._admitted_target,
            tuple(self._confirmed_references),
            now,
            self._max_reference_gap_s,
        )
        if not prepared.ready:
            for failure in prepared.failures:
                if failure.joint_index is None:
                    continue
                spec = self._specs[failure.joint_index]
                if failure.code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, position_limit=True
                    )
                elif failure.code is DecisionCode.SPEED_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, speed_limit=True
                    )
                else:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, constraint_fault=True
                    )
            self.stop()
            return None

        plan_id = self._next_plan_id
        if plan_id > (1 << 64) - 1:
            raise OverflowError("plan ID sequence exhausted")
        self._next_plan_id += 1

        plan = RefreshPlan(
            plan_id=plan_id,
            target=self._admitted_target,
            prepared_at_s=now,
            joint_targets=prepared.joint_targets,
            packets=prepared.packets,
            proposed_references=prepared.proposed_references,
        )
        self._prepared_plan = plan
        self._next_dispatch_index = 0
        return plan

    def claim_dispatch(self, plan_id: int, index: int) -> bool:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return False
        if self._dispatch_claim is not None:
            return False
        if self._prepared_plan is None or self._prepared_plan.plan_id != plan_id:
            return False
        if self._state not in (State.ARMED, State.MOVING):
            return False
        if self._state is State.FAULT or bool(self._faults):
            return False
        if index < 0 or index >= len(self._specs):
            return False
        if index != self._next_dispatch_index:
            return False

        now = self._now()
        if self._housekeeping(now) is not None:
            return False
        if self._admitted_target is None or self._prepared_plan is None:
            return False
        if not owner_tokens_match(self._prepared_plan.target.owner, self._current_owner):
            return False
        if any(not joint.healthy for joint in self._observations):
            return False

        if not self._all_fresh(now):
            return False
        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid or joint.sample is None:
                return False
            pos_out = joint.sample.q_rad < spec.q_min_rad or joint.sample.q_rad > spec.q_max_rad
            speed_out = abs(joint.sample.dq_rad_s) > spec.v_max_rad_s
            if pos_out or speed_out:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=pos_out, speed_limit=speed_out)
                self.stop()
                return False

        conf_ref = self._confirmed_references[index]
        if conf_ref is not None:
            gap = now - conf_ref.sample_time_s
            if not math.isfinite(gap) or gap < 0.0 or gap > self._max_reference_gap_s:
                self.stop()
                return False

        plan_joint = self._prepared_plan.joint_targets[index]
        spec = self._specs[index]
        if plan_joint.q_rad < spec.q_min_rad or plan_joint.q_rad > spec.q_max_rad:
            self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            self.stop()
            return False
        if abs(plan_joint.dq_rad_s) > spec.v_max_rad_s:
            self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            self.stop()
            return False

        prop_ref = self._prepared_plan.proposed_references[index]
        if (
            prop_ref.requested_goal != self._prepared_plan.target.joints[index]
            or prop_ref.emitted_target != plan_joint
            or prop_ref.packet != self._prepared_plan.packets[index]
            or prop_ref.sample_time_s > self._prepared_plan.prepared_at_s
        ):
            self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
            self.stop()
            return False
        if conf_ref is None:
            self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
            self.stop()
            return False
        if prop_ref.sample_time_s == conf_ref.sample_time_s:
            if prop_ref != conf_ref:
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
                self.stop()
                return False
        elif (
            prop_ref.sample_time_s != self._prepared_plan.prepared_at_s
            or prop_ref.sample_time_s <= conf_ref.sample_time_s
        ):
            self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
            self.stop()
            return False
        h_ref = prop_ref.sample_time_s - conf_ref.sample_time_s
        h_ref_exact = Fraction(h_ref)
        a_max_exact = Fraction(spec.a_max_rad_s2)
        v_max_exact = Fraction(spec.v_max_rad_s)
        v_prev_pos = Fraction(conf_ref.position_step_velocity_rad_s)
        v_prev_enc = Fraction(conf_ref.encoded_velocity_rad_s)

        if (
            abs(prop_ref.position_step_velocity_rad_s) > v_max_exact
            or abs(Fraction(prop_ref.encoded_velocity_rad_s)) > v_max_exact
        ):
            self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            self.stop()
            return False

        if prop_ref.sample_time_s > conf_ref.sample_time_s:
            if (
                abs(prop_ref.position_step_velocity_rad_s - v_prev_pos) > a_max_exact * h_ref_exact
                or abs(Fraction(prop_ref.encoded_velocity_rad_s) - v_prev_enc) > a_max_exact * h_ref_exact
            ):
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
                self.stop()
                return False

        self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
        return True

    def dispatch_result(
        self, plan_id: int, index: int, result: WriteResult
    ) -> Decision:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if not isinstance(result, WriteResult):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        claim = self._dispatch_claim
        if claim is None or claim.plan.plan_id != plan_id or claim.index != index:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if index < 0 or index >= len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        plan = claim.plan
        joint_target = plan.joint_targets[index]
        self._dispatch_attempts[index] = JointDispatchAttempt(
            plan_id=plan.plan_id,
            sequence=plan.target.sequence,
            target=joint_target,
            result=result,
            started_at_s=claim.started_at_s,
            owner=plan.target.owner,
        )
        if result is WriteResult.COMPLETE:
            record = JointDispatchedRecord(
                sequence=plan.target.sequence,
                target=joint_target,
                dispatched_at_s=claim.started_at_s,
                owner=plan.target.owner,
            )
            self._dispatched_records[index] = record
            self._confirmed_references[index] = plan.proposed_references[index]
            try:
                now = self._now()
            except Exception:
                self._record_dispatch_failure(index, CommunicationFailure.CLOCK_FAILURE)
                self._dispatch_claim = None
                return self._rejected(DecisionCode.FAULT_LATCHED)

            housekeeping = self._housekeeping(now)
            still_current = (
                self._prepared_plan is plan
                and self._admitted_target is plan.target
                and self._state in (State.ARMED, State.MOVING)
                and not self._faults
                and owner_tokens_match(self._current_owner, plan.target.owner)
            )
            if still_current and housekeeping is None:
                self._next_dispatch_index = index + 1
                self._state = State.MOVING
            self._dispatch_claim = None
            return self._accepted()

        cause = (
            CommunicationFailure.PREWRITE_DEADLINE
            if result is WriteResult.PREWRITE_DEADLINE
            else CommunicationFailure.DRIVER_FAILURE
        )
        self._record_dispatch_failure(index, cause)
        self._dispatch_claim = None
        return self._rejected(DecisionCode.FAULT_LATCHED)

    def stop(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        self._revoke_authority()
        if self._state is State.FAULT or bool(self._faults):
            self._state = State.FAULT
        else:
            self._state = State.STOPPED
        return self._accepted()

    def disconnect(self) -> Decision:
        self._state = State.DISCONNECTED
        self._source = None
        self._clear_observations()
        self._confirmed_references = [None for _ in self._specs]
        self._revoke_authority()
        return self._accepted()

    def snapshot(self) -> Snapshot:
        received = [joint.received_at for joint in self._observations]
        now = self._now() if any(value is not None for value in received) else None
        ages = tuple(
            None if value is None else self._age(value, now)
            for value in received
        )
        faults = tuple(self._faults[spec.name] for spec in self._specs
                       if spec.name in self._faults)
        return Snapshot(
            state=self._state,
            joint_names=tuple(spec.name for spec in self._specs),
            joints=tuple(self._observations),
            source=self._source,
            fault_latched=bool(self._faults),
            feedback_ages_s=ages,
            faults=faults,
            admitted_target=self._admitted_target,
            prepared_plan=self._prepared_plan,
            dispatched_records=tuple(self._dispatched_records),
            dispatch_attempts=tuple(self._dispatch_attempts),
            last_sequence=self._last_sequence,
            latest_owner=self._latest_owner,
            current_owner=self._current_owner,
            confirmed_references=tuple(self._confirmed_references),
        )

```

### joint_reference.py complete
```
"""Pure joint reference validation and canonical packet preparation."""

from dataclasses import dataclass
from fractions import Fraction
import math
from im6014_codec import (
    command,
    command_with_raw_position,
    decode_command,
    project_position_raw,
    project_speed_raw,
    raw_to_position,
    raw_to_rpm,
)
from joint_contract import (
    DecisionCode,
    JointSpec,
    JointTrajectoryReference,
    Target,
)
from joint_mapping import JointTarget, OutputSample

__all__ = (
    "prepare_reference_joint",
    "shape_reference_joint",
    "prepare_complete_reference",
    "validate_target_vector",
    "ReferenceFailure",
    "ReferenceBatchResult",
)


@dataclass(frozen=True)
class ReferenceFailure:
    code: DecisionCode
    joint_index: int | None

    def __post_init__(self) -> None:
        if not isinstance(self.code, DecisionCode):
            raise ValueError("reference failure code must be a DecisionCode")
        if self.joint_index is not None and (
            type(self.joint_index) is not int or self.joint_index < 0
        ):
            raise ValueError("joint_index must be a nonnegative integer or None")


@dataclass(frozen=True)
class ReferenceBatchResult:
    joint_targets: tuple[JointTarget, ...] | None
    packets: tuple[bytes, ...] | None
    proposed_references: tuple[JointTrajectoryReference, ...] | None
    failures: tuple[ReferenceFailure, ...]

    def __post_init__(self) -> None:
        if type(self.failures) is not tuple or any(
            not isinstance(failure, ReferenceFailure) for failure in self.failures
        ):
            raise ValueError("failures must be a tuple of ReferenceFailure")
        if self.failures:
            if any(
                value is not None
                for value in (self.joint_targets, self.packets, self.proposed_references)
            ):
                raise ValueError("a failed batch cannot expose a partial plan")
            indices = [failure.joint_index for failure in self.failures]
            if len(indices) != len(set(indices)):
                raise ValueError("a batch can report at most one failure per joint")
            return

        if (
            type(self.joint_targets) is not tuple
            or type(self.packets) is not tuple
            or type(self.proposed_references) is not tuple
            or not self.joint_targets
            or len(self.joint_targets) != len(self.packets)
            or len(self.joint_targets) != len(self.proposed_references)
        ):
            raise ValueError("a successful batch requires complete parallel tuples")
        if any(not isinstance(target, JointTarget) for target in self.joint_targets):
            raise ValueError("every batch target must be a JointTarget")
        if any(type(packet) is not bytes for packet in self.packets):
            raise ValueError("every batch packet must be immutable bytes")
        if any(not isinstance(ref, JointTrajectoryReference) for ref in self.proposed_references):
            raise ValueError("every batch reference must be a JointTrajectoryReference")

    @property
    def ready(self) -> bool:
        return not self.failures


def prepare_reference_joint(
    spec: JointSpec, target: JointTarget
) -> tuple[DecisionCode | None, JointTarget | None, bytes | None]:
    """Validate a request and bind its actual decoded command to canonical bytes."""
    if not isinstance(spec, JointSpec) or not isinstance(target, JointTarget):
        return DecisionCode.INVALID_ARGUMENT, None, None
    if target.q_rad < spec.q_min_rad or target.q_rad > spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
    if abs(target.dq_rad_s) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None

    try:
        output = spec.mapping.to_output(target)
        # Validate the original mapped request through the ordinary codec before
        # projecting its position onto an inward representable grid point.
        command(
            spec.motor_id,
            mode=1,
            rpm=output.rpm,
            kd=output.kd,
            torque=output.tau_nm,
            watchdog=True,
            position=output.q_rad,
            kp=output.kp,
        )
        raw_position = project_position_raw(
            target.q_rad,
            spec.q_min_rad,
            spec.q_max_rad,
            lambda output_q: spec.mapping.from_output(
                OutputSample(output_q, 0.0, 0.0)
            ).q_rad,
            spec.mapping.direction,
        )
        if raw_position is None:
            return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None

        raw_rpm = project_speed_raw(
            target.dq_rad_s,
            -spec.v_max_rad_s,
            spec.v_max_rad_s,
            lambda output_rpm: spec.mapping.from_output(
                OutputSample(0.0, output_rpm, 0.0)
            ).dq_rad_s,
            spec.mapping.direction,
        )
        if raw_rpm is None:
            return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.INVALID_ARGUMENT, None, None

    try:
        packet = command_with_raw_position(
            spec.motor_id,
            raw_position,
            mode=1,
            rpm=output.rpm,
            kd=output.kd,
            torque=output.tau_nm,
            watchdog=True,
            kp=output.kp,
            raw_rpm=raw_rpm,
        )
        decoded = decode_command(packet)
        actual_output = spec.mapping.from_output(
            OutputSample(
                decoded["position_rad"], decoded["rpm"], decoded["torque_nm"]
            )
        )
        gain_scale = spec.mapping.reduction ** 2
        actual_target = JointTarget(
            q_rad=actual_output.q_rad,
            dq_rad_s=actual_output.dq_rad_s,
            tau_nm=actual_output.tau_nm,
            kp=decoded["kp"] * gain_scale,
            kd=decoded["kd"] * gain_scale,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.INVALID_ARGUMENT, None, None

    if not spec.q_min_rad <= actual_target.q_rad <= spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None
    if abs(actual_target.dq_rad_s) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None
    return None, actual_target, packet


def validate_target_vector(
    specs: tuple[JointSpec, ...], target: Target
) -> tuple[ReferenceFailure, ...]:
    """Validate every admitted joint request before replacing the current goal."""
    if not isinstance(target, Target) or len(target.joints) != len(specs):
        return (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)

    failures: list[ReferenceFailure] = []
    for index, (spec, joint_target) in enumerate(zip(specs, target.joints)):
        code, _, _ = prepare_reference_joint(spec, joint_target)
        if code is not None:
            failures.append(ReferenceFailure(code, index))
    return tuple(failures)


def shape_reference_joint(
    spec: JointSpec,
    target: JointTarget,
    confirmed_ref: JointTrajectoryReference,
    now: float,
    max_reference_gap_s: float,
) -> tuple[
    DecisionCode | None,
    JointTarget | None,
    JointTrajectoryReference | None,
    bytes | None,
]:
    """Shape one discrete reference point and retain its exact emitted command."""
    if (
        not isinstance(spec, JointSpec)
        or not isinstance(target, JointTarget)
        or not isinstance(confirmed_ref, JointTrajectoryReference)
    ):
        return DecisionCode.INVALID_ARGUMENT, None, None, None

    normalized: list[float] = []
    for val in (
        target.q_rad,
        target.dq_rad_s,
        target.tau_nm,
        target.kp,
        target.kd,
        now,
        max_reference_gap_s,
    ):
        if isinstance(val, bool) or not isinstance(val, (int, float)):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        try:
            numeric = float(val)
        except (OverflowError, TypeError, ValueError):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        if not math.isfinite(numeric):
            return DecisionCode.INVALID_ARGUMENT, None, None, None
        normalized.append(numeric)
    (
        goal_q,
        goal_dq,
        goal_tau,
        goal_kp,
        goal_kd,
        now,
        max_reference_gap_s,
    ) = normalized
    if max_reference_gap_s <= 0.0:
        return DecisionCode.INVALID_ARGUMENT, None, None, None

    if goal_q < spec.q_min_rad or goal_q > spec.q_max_rad:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
    if abs(goal_dq) > spec.v_max_rad_s:
        return DecisionCode.SPEED_OUT_OF_BOUNDS, None, None, None

    h = now - confirmed_ref.sample_time_s
    if not math.isfinite(h) or h < 0.0:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if h > max_reference_gap_s:
        return DecisionCode.REFERENCE_GAP_EXCEEDED, None, None, None

    if h == 0.0:
        if not confirmed_ref.is_emitted:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if target != confirmed_ref.requested_goal:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        if (
            confirmed_ref.emitted_target is None
            or confirmed_ref.packet is None
        ):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
        return (
            None,
            confirmed_ref.emitted_target,
            confirmed_ref,
            confirmed_ref.packet,
        )

    # Use exact rational arithmetic over the stored finite float-domain values.
    # The sample cadence is the actual float subtraction above, not a decimal
    # interpretation of either timestamp.
    try:
        h_exact = Fraction(h)
        q_prev_exact = Fraction(confirmed_ref.q_rad)
        v_prev_pos_exact = Fraction(confirmed_ref.position_step_velocity_rad_s)
        v_prev_enc_exact = Fraction(confirmed_ref.encoded_velocity_rad_s)
        q_min_exact = Fraction(spec.q_min_rad)
        q_max_exact = Fraction(spec.q_max_rad)
        v_max_exact = Fraction(spec.v_max_rad_s)
        a_max_exact = Fraction(spec.a_max_rad_s2)

        v_pos_lo = (q_min_exact - q_prev_exact) / h_exact
        v_pos_hi = (q_max_exact - q_prev_exact) / h_exact
        v_acc_lo = v_prev_pos_exact - a_max_exact * h_exact
        v_acc_hi = v_prev_pos_exact + a_max_exact * h_exact

        v_lo = max(-v_max_exact, v_pos_lo, v_acc_lo)
        v_hi = min(v_max_exact, v_pos_hi, v_acc_hi)
        if v_lo > v_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        # q and dq jointly define a one-step objective; q does not replace dq.
        v_desired = (Fraction(goal_q) - q_prev_exact) / h_exact + Fraction(goal_dq)
        v_projected = max(v_lo, min(v_hi, v_desired))
        q_continuous = q_prev_exact + v_projected * h_exact
        q_next_lo = q_prev_exact + v_lo * h_exact
        q_next_hi = q_prev_exact + v_hi * h_exact
        if q_next_lo > q_next_hi or not q_next_lo <= q_continuous <= q_next_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        q_wanted = float(q_continuous)
        q_lower = float(q_next_lo)
        q_upper = float(q_next_hi)
        if not all(math.isfinite(value) for value in (q_wanted, q_lower, q_upper)):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        v_enc_lo = max(-v_max_exact, v_prev_enc_exact - a_max_exact * h_exact)
        v_enc_hi = min(v_max_exact, v_prev_enc_exact + a_max_exact * h_exact)
        if v_enc_lo > v_enc_hi:
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

        v_enc_desired = Fraction(goal_dq)
        v_enc_projected = max(v_enc_lo, min(v_enc_hi, v_enc_desired))
        v_enc_wanted = float(v_enc_projected)
        v_enc_lower = float(v_enc_lo)
        v_enc_upper = float(v_enc_hi)
        if not all(math.isfinite(value) for value in (v_enc_wanted, v_enc_lower, v_enc_upper)):
            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        output_req = spec.mapping.to_output(
            JointTarget(goal_q, goal_dq, goal_tau, goal_kp, goal_kd)
        )
        command(
            spec.motor_id,
            mode=1,
            rpm=output_req.rpm,
            kd=output_req.kd,
            torque=output_req.tau_nm,
            watchdog=True,
            position=output_req.q_rad,
            kp=output_req.kp,
        )
        raw_pos = project_position_raw(
            q_wanted,
            q_lower,
            q_upper,
            lambda out_q: spec.mapping.from_output(OutputSample(out_q, 0.0, 0.0)).q_rad,
            spec.mapping.direction,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    if raw_pos is None:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    def mapped_position(raw_position: int) -> float:
        return spec.mapping.from_output(
            OutputSample(raw_to_position(raw_position), 0.0, 0.0)
        ).q_rad

    try:
        q_emitted = mapped_position(raw_pos)
        q_emitted_exact = Fraction(q_emitted)
        position_step_velocity = (q_emitted_exact - q_prev_exact) / h_exact
        safe_position = (
            q_min_exact <= q_emitted_exact <= q_max_exact
            and q_next_lo <= q_emitted_exact <= q_next_hi
        )
        safe_step = (
            abs(position_step_velocity) <= v_max_exact
            and abs(position_step_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
        )
        if not safe_position or not safe_step:
            if q_emitted_exact < q_next_lo or position_step_velocity < v_lo:
                raw_step = spec.mapping.direction
            elif q_emitted_exact > q_next_hi or position_step_velocity > v_hi:
                raw_step = -spec.mapping.direction
            else:
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_candidate = raw_pos + raw_step
            candidate_q = mapped_position(raw_candidate)
            candidate_q_exact = Fraction(candidate_q)
            candidate_velocity = (candidate_q_exact - q_prev_exact) / h_exact
            if not (
                q_min_exact <= candidate_q_exact <= q_max_exact
                and q_next_lo <= candidate_q_exact <= q_next_hi
                and abs(candidate_velocity) <= v_max_exact
                and abs(candidate_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
            ):
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_pos = raw_candidate
            q_emitted = candidate_q
            q_emitted_exact = candidate_q_exact
            position_step_velocity = candidate_velocity
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        raw_rpm = project_speed_raw(
            v_enc_wanted,
            v_enc_lower,
            v_enc_upper,
            lambda out_rpm: spec.mapping.from_output(OutputSample(0.0, out_rpm, 0.0)).dq_rad_s,
            spec.mapping.direction,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    if raw_rpm is None:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    def mapped_speed(raw_s: int) -> float:
        return spec.mapping.from_output(
            OutputSample(0.0, raw_to_rpm(raw_s), 0.0)
        ).dq_rad_s

    try:
        v_emitted_enc = mapped_speed(raw_rpm)
        v_emitted_enc_exact = Fraction(v_emitted_enc)
        safe_enc = (
            abs(v_emitted_enc_exact) <= v_max_exact
            and abs(v_emitted_enc_exact - v_prev_enc_exact) <= a_max_exact * h_exact
            and v_enc_lo <= v_emitted_enc_exact <= v_enc_hi
        )
        if not safe_enc:
            if v_emitted_enc_exact < v_enc_lo:
                raw_rpm_step = spec.mapping.direction
            elif v_emitted_enc_exact > v_enc_hi:
                raw_rpm_step = -spec.mapping.direction
            else:
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_rpm_cand = raw_rpm + raw_rpm_step
            cand_v_enc = mapped_speed(raw_rpm_cand)
            cand_v_enc_exact = Fraction(cand_v_enc)
            if not (
                abs(cand_v_enc_exact) <= v_max_exact
                and abs(cand_v_enc_exact - v_prev_enc_exact) <= a_max_exact * h_exact
                and v_enc_lo <= cand_v_enc_exact <= v_enc_hi
            ):
                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
            raw_rpm = raw_rpm_cand
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    try:
        packet = command_with_raw_position(
            spec.motor_id,
            raw_pos,
            mode=1,
            kd=output_req.kd,
            torque=output_req.tau_nm,
            watchdog=True,
            kp=output_req.kp,
            raw_rpm=raw_rpm,
        )
        decoded = decode_command(packet)
        actual_output = spec.mapping.from_output(
            OutputSample(decoded["position_rad"], decoded["rpm"], decoded["torque_nm"])
        )
        gain_scale = spec.mapping.reduction ** 2
        actual_target = JointTarget(
            q_rad=actual_output.q_rad,
            dq_rad_s=actual_output.dq_rad_s,
            tau_nm=actual_output.tau_nm,
            kp=decoded["kp"] * gain_scale,
            kd=decoded["kd"] * gain_scale,
        )
    except (ArithmeticError, TypeError, ValueError):
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    actual_q_exact = Fraction(actual_target.q_rad)
    actual_position_step_velocity = (actual_q_exact - q_prev_exact) / h_exact
    actual_v_enc_exact = Fraction(actual_target.dq_rad_s)
    if not q_min_exact <= actual_q_exact <= q_max_exact:
        return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
    if not q_next_lo <= actual_q_exact <= q_next_hi:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if v_desired != 0 and actual_target.q_rad == confirmed_ref.q_rad:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_v_enc_exact) > v_max_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_v_enc_exact - v_prev_enc_exact) > a_max_exact * h_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_position_step_velocity) > v_max_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
    if abs(actual_position_step_velocity - v_prev_pos_exact) > a_max_exact * h_exact:
        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None

    proposed_ref = JointTrajectoryReference(
        q_rad=actual_target.q_rad,
        position_step_velocity_rad_s=actual_position_step_velocity,
        encoded_velocity_rad_s=actual_target.dq_rad_s,
        sample_time_s=now,
        is_emitted=True,
        requested_goal=JointTarget(goal_q, goal_dq, goal_tau, goal_kp, goal_kd),
        emitted_target=actual_target,
        packet=packet,
    )
    return None, actual_target, proposed_ref, packet


def prepare_complete_reference(
    specs: tuple[JointSpec, ...],
    target: Target,
    confirmed_references: tuple[JointTrajectoryReference, ...],
    now: float,
    max_reference_gap_s: float,
) -> ReferenceBatchResult:
    """Shape all joints and report every failed index without exposing a partial plan."""
    if (
        type(specs) is not tuple
        or not specs
        or any(not isinstance(spec, JointSpec) for spec in specs)
        or not isinstance(target, Target)
        or len(target.joints) != len(specs)
        or type(confirmed_references) is not tuple
        or len(confirmed_references) != len(specs)
    ):
        return ReferenceBatchResult(
            None, None, None, (ReferenceFailure(DecisionCode.INVALID_ARGUMENT, None),)
        )

    actual_targets: list[JointTarget] = []
    packets: list[bytes] = []
    proposed_references: list[JointTrajectoryReference] = []
    failures: list[ReferenceFailure] = []

    for index, (spec, joint_target, conf_ref) in enumerate(
        zip(specs, target.joints, confirmed_references)
    ):
        code, actual_target, prop_ref, packet = shape_reference_joint(
            spec, joint_target, conf_ref, now, max_reference_gap_s
        )
        if code is not None or actual_target is None or prop_ref is None or packet is None:
            failures.append(
                ReferenceFailure(code or DecisionCode.CONSTRAINT_VIOLATION, index)
            )
            continue
        actual_targets.append(actual_target)
        packets.append(packet)
        proposed_references.append(prop_ref)

    if failures:
        return ReferenceBatchResult(None, None, None, tuple(failures))
    return ReferenceBatchResult(
        tuple(actual_targets), tuple(packets), tuple(proposed_references), ()
    )

```

### joint_mapping.py complete
```
from dataclasses import dataclass
import math


def _finite(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a real int or float")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def _result(value, name, nonzero_inputs=None):
    if not math.isfinite(value):
        raise ValueError(f"{name} result must be finite")
    if nonzero_inputs and value == 0.0 and all(item != 0.0 for item in nonzero_inputs):
        raise ValueError(f"{name} result underflowed")
    return value


def _multiply(name, *values):
    result = 1.0
    for index, value in enumerate(values):
        result *= value
        _result(result, name, values[:index + 1])
    return result


def _divide(numerator, denominator, name):
    try:
        result = numerator / denominator
    except (OverflowError, ZeroDivisionError) as exc:
        raise ValueError(f"{name} result is not representable") from exc
    return _result(result, name, (numerator,))


def _add(left, right, name):
    return _result(left + right, name)


def _subtract(left, right, name):
    return _result(left - right, name)


@dataclass(frozen=True)
class JointMap:
    reduction: float
    direction: int
    zero_output_rad: float

    def __post_init__(self):
        reduction = _finite(self.reduction, "reduction")
        if reduction <= 0.0:
            raise ValueError("reduction must be positive")
        if type(self.direction) is not int or self.direction not in (-1, 1):
            raise ValueError("direction must be the integer -1 or 1")
        object.__setattr__(self, "reduction", reduction)
        object.__setattr__(self, "zero_output_rad", _finite(self.zero_output_rad, "zero_output_rad"))

    def to_output(self, target: "JointTarget") -> "OutputTarget":
        if not isinstance(target, JointTarget):
            raise ValueError("target must be a JointTarget")

        signed_reduction = _multiply("signed reduction", float(self.direction), self.reduction)
        q_rad = _add(
            self.zero_output_rad,
            _multiply("output position", signed_reduction, target.q_rad),
            "output position",
        )
        output_rad_s = _multiply("output velocity", signed_reduction, target.dq_rad_s)
        rpm = _divide(_multiply("output speed", output_rad_s, 60.0), math.tau, "output speed")
        tau_nm = _divide(
            _multiply("output torque", float(self.direction), target.tau_nm),
            self.reduction,
            "output torque",
        )
        kp = _divide(_divide(target.kp, self.reduction, "output kp"), self.reduction, "output kp")
        kd = _divide(_divide(target.kd, self.reduction, "output kd"), self.reduction, "output kd")
        return OutputTarget(q_rad=q_rad, rpm=rpm, tau_nm=tau_nm, kp=kp, kd=kd)

    def from_output(self, sample: "OutputSample") -> "JointSample":
        if not isinstance(sample, OutputSample):
            raise ValueError("sample must be an OutputSample")

        q_delta = _subtract(sample.q_rad, self.zero_output_rad, "joint position")
        q_rad = _divide(
            _multiply("joint position", float(self.direction), q_delta),
            self.reduction,
            "joint position",
        )
        output_rad_s = _divide(
            _multiply("joint velocity", sample.rpm, math.tau),
            60.0,
            "joint velocity",
        )
        dq_rad_s = _divide(
            _multiply("joint velocity", float(self.direction), output_rad_s),
            self.reduction,
            "joint velocity",
        )
        tau_nm = _multiply("joint torque", float(self.direction), self.reduction, sample.tau_nm)
        return JointSample(q_rad=q_rad, dq_rad_s=dq_rad_s, tau_nm=tau_nm)


@dataclass(frozen=True)
class JointTarget:
    q_rad: float
    dq_rad_s: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputTarget:
    q_rad: float
    rpm: float
    tau_nm: float
    kp: float
    kd: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm", "kp", "kd"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))
        if self.kp < 0.0 or self.kd < 0.0:
            raise ValueError("kp and kd must be nonnegative")


@dataclass(frozen=True)
class OutputSample:
    q_rad: float
    rpm: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "rpm", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))


@dataclass(frozen=True)
class JointSample:
    q_rad: float
    dq_rad_s: float
    tau_nm: float

    def __post_init__(self):
        for name in ("q_rad", "dq_rad_s", "tau_nm"):
            object.__setattr__(self, name, _finite(getattr(self, name), name))

```

### im6014_codec.py complete
```
import math
import struct
from collections.abc import Callable

RATIO = 38 / 3
RPM_MIN = -32768 / 64 / RATIO * 60
RPM_MAX = 32767 / 64 / RATIO * 60
POSITION_MIN = -2147483648 / 32768 / RATIO * math.tau
POSITION_MAX = 2147483647 / 32768 / RATIO * math.tau
RAW_POSITION_MIN = -2147483648
RAW_POSITION_MAX = 2147483647
RAW_RPM_MIN = -32768
RAW_RPM_MAX = 32767


def raw_to_position(raw_position):
    if type(raw_position) is not int or not RAW_POSITION_MIN <= raw_position <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return raw_position / 32768 / RATIO * math.tau


def position_to_raw(position):
    position = _finite_control(position, 'Position')
    return _signed_raw(position / math.tau * RATIO * 32768,
                       RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')


def raw_to_rpm(raw_rpm):
    if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
        raise ValueError('raw_rpm must be a signed 16-bit integer')
    return raw_rpm / 64 / RATIO * 60


def rpm_to_raw(rpm):
    rpm = _finite_control(rpm, 'Speed')
    return _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')


def _motor_id(value, name='Individual ID'):
    if type(value) is not int or not 0 <= value <= 14:
        raise ValueError(f'{name} must be an integer from 0 to 14')
    return value


def _finite_control(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f'{name} must be a finite int or float')
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError(f'{name} must be finite') from error
    if not math.isfinite(result):
        raise ValueError(f'{name} must be finite')
    return result


def _signed_raw(value, minimum, maximum, name):
    raw = round(value)
    if not minimum <= raw <= maximum:
        raise ValueError(f'{name} cannot be represented by the motor protocol')
    return raw


def _torque_raw(value):
    return _signed_raw(value / RATIO * 2560, -32768, 32767, 'Feedforward torque')


def _kp_raw(value):
    return _signed_raw(value / RATIO ** 2 * 12800, -32768, 32767, 'Kp')


def _kd_raw(value):
    return _signed_raw(value / RATIO ** 2 * 51200, -32768, 32767, 'Kd')


def _raw_position(value):
    if type(value) is not int or not RAW_POSITION_MIN <= value <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return value


def crc32(data):
    if len(data) % 4:
        raise ValueError('CRC input must contain complete four-byte words')
    crc = 0xFFFFFFFF
    for start in range(0, len(data), 4):
        for byte in data[start:start + 4][::-1]:
            crc ^= byte << 24
            for _ in range(8):
                crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    return crc


def command(motor_id, mode=0, rpm=0, kd=0, torque=0, watchdog=True, position=0, kp=0):
    position = _finite_control(position, 'Position')
    if not POSITION_MIN <= position <= POSITION_MAX:
        raise ValueError('Position cannot be encoded in the motor protocol')
    if mode == 0 and position != 0.0:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    position_raw = _signed_raw(position / math.tau * RATIO * 32768,
                               RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')
    return command_with_raw_position(
        motor_id,
        position_raw,
        mode=mode,
        rpm=rpm,
        kd=kd,
        torque=torque,
        watchdog=watchdog,
        kp=kp,
    )


def command_with_raw_position(
    motor_id, raw_position, mode=0, rpm=0, kd=0, torque=0, watchdog=True, kp=0, raw_rpm=None
):
    """Encode a command while preserving an already selected position grid code."""
    motor_id = _motor_id(motor_id)
    raw_position = _raw_position(raw_position)
    if type(mode) is not int or mode not in (0, 1):
        raise ValueError('Individual ID 0–14 and Stop/FOC modes only')
    if type(watchdog) is not bool:
        raise ValueError('Watchdog must be a bool')
    rpm, kd, torque, kp = (
        _finite_control(value, name) for value, name in
        ((rpm, 'Speed'), (kd, 'Kd'), (torque, 'Feedforward torque'),
         (kp, 'Kp'))
    )
    if not RPM_MIN <= rpm <= RPM_MAX:
        raise ValueError('Speed cannot be encoded in the motor protocol; this is not a rated-speed limit')
    if not 0 <= kd <= 6 or not 0 <= kp <= 30 or not -3.5 <= torque <= 3.5:
        raise ValueError('Bench limits: Kd 0–6, Kp 0–30, feedforward torque ±3.5 Nm')
    torque_raw = _torque_raw(torque)
    if raw_rpm is not None:
        if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
            raise ValueError('raw_rpm must be a signed 16-bit integer')
        rpm_raw = raw_rpm
    else:
        rpm_raw = _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')
    kp_raw = _kp_raw(kp)
    kd_raw = _kd_raw(kd)
    if mode == 0 and (rpm or kd or torque or raw_position or kp or (raw_rpm is not None and raw_rpm != 0)) or mode == 1 and not watchdog:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    raw = b'\xfe\xee' + bytes([motor_id | mode << 4 | int(watchdog) << 7, 0])
    raw += struct.pack('<hhihh', torque_raw, rpm_raw, raw_position, kp_raw, kd_raw)
    return raw + struct.pack('<I', crc32(raw))


def project_position_raw(
    wanted_q,
    q_min,
    q_max,
    map_decoded_position: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw position whose mapped decoded value is in bounds.

    ``map_decoded_position`` maps decoded actuator radians to the caller's
    position domain. ``direction`` declares whether that mapping increases or
    decreases as the raw position code increases. Bounds are closed.
    """
    wanted_q = _finite_control(wanted_q, 'Wanted position')
    q_min = _finite_control(q_min, 'Minimum position')
    q_max = _finite_control(q_max, 'Maximum position')
    if q_min > q_max:
        raise ValueError('Minimum position must not exceed maximum position')
    if not callable(map_decoded_position):
        raise ValueError('Position mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Position mapping direction must be -1 or 1')

    ordered_min = direction * (q_min if direction == 1 else q_max)
    ordered_max = direction * (q_max if direction == 1 else q_min)
    ordered_wanted = direction * wanted_q

    def mapped(raw_position):
        decoded = raw_to_position(raw_position)
        try:
            result = map_decoded_position(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Position mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped position')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_POSITION_MIN
        right = RAW_POSITION_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_POSITION_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def project_speed_raw(
    wanted_dq,
    v_min,
    v_max,
    map_decoded_speed: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw speed whose mapped decoded value is in bounds.

    ``map_decoded_speed`` maps decoded actuator RPM to the caller's
    speed domain. ``direction`` declares whether that mapping increases or
    decreases as the raw speed code increases. Bounds are closed.
    """
    wanted_dq = _finite_control(wanted_dq, 'Wanted speed')
    v_min = _finite_control(v_min, 'Minimum speed')
    v_max = _finite_control(v_max, 'Maximum speed')
    if v_min > v_max:
        raise ValueError('Minimum speed must not exceed maximum speed')
    if not callable(map_decoded_speed):
        raise ValueError('Speed mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Speed mapping direction must be -1 or 1')

    ordered_min = direction * (v_min if direction == 1 else v_max)
    ordered_max = direction * (v_max if direction == 1 else v_min)
    ordered_wanted = direction * wanted_dq

    def mapped(raw_speed):
        decoded = raw_to_rpm(raw_speed)
        try:
            result = map_decoded_speed(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Speed mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped speed')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_RPM_MIN
        right = RAW_RPM_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_RPM_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def feedback(raw, motor_id):
    motor_id = _motor_id(motor_id, 'Expected motor ID')
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Feedback frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Feedback frame must be a bytes-like buffer') from error
    if len(raw) != 26 or raw[:2] != b'\xfc\xee':
        raise RuntimeError('Invalid feedback length/header')
    if struct.unpack('<I', raw[22:])[0] != crc32(raw[2:22]):
        raise RuntimeError('Feedback CRC mismatch')
    m, td, tw, v, tq, sp, pos, err, flags, _, _ = struct.unpack('<BbBBhhiIHBB', raw[2:22])
    if m & 15 != motor_id or (m >> 4) & 7 not in (0, 1):
        raise RuntimeError('Feedback ID/mode mismatch')
    return dict(id=m & 15, mode=(m >> 4) & 7, timeout=m >> 7,
                driver_c=td, winding_c=tw, voltage=v / 2,
                torque_nm=tq / 2560 * RATIO, rpm=sp / 64 / RATIO * 60,
                position_rad=pos / 32768 / RATIO * math.tau,
                errors=err, warnings=(flags >> 13) & 7, raw=raw.hex())


def decode_command(raw):
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Command frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Command frame must be a bytes-like buffer') from error
    if len(raw) != 20 or raw[:2] != b'\xfe\xee':
        raise ValueError('Invalid command length/header')
    if struct.unpack('<I', raw[16:])[0] != crc32(raw[:16]):
        raise ValueError('Command CRC mismatch')
    m = raw[2]
    motor_id = m & 0x0F
    mode = (m >> 4) & 0x07
    watchdog = bool(m & 0x80)
    if motor_id > 14 or mode not in (0, 1) or raw[3] != 0:
        raise ValueError('Invalid command ID, mode, or reserved byte')
    if mode == 1 and not watchdog:
        raise ValueError('FOC command requires watchdog')
    tq, sp, pos, kp, kd = struct.unpack('<hhihh', raw[4:16])
    if mode == 0 and (tq or sp or pos or kp or kd):
        raise ValueError('Stop command must have zero targets')
    decoded = dict(
        motor_id=motor_id,
        mode=mode,
        watchdog=watchdog,
        raw_torque=tq,
        raw_rpm=sp,
        raw_position=pos,
        raw_kp=kp,
        raw_kd=kd,
        torque_nm=tq / 2560 * RATIO,
        rpm=sp / 64 / RATIO * 60,
        position_rad=pos / 32768 / RATIO * math.tau,
        kp=kp * (RATIO ** 2) / 12800,
        kd=kd * (RATIO ** 2) / 51200,
        raw=raw.hex(),
    )
    if not _torque_raw(-3.5) <= tq <= _torque_raw(3.5):
        raise ValueError('Feedforward torque is outside the canonical command range')
    if not 0 <= kp <= _kp_raw(30.0) or not 0 <= kd <= _kd_raw(6.0):
        raise ValueError('Gain is outside the canonical command range')
    return decoded

```

### docs/joint-api.md complete
```
# Joint mapping

The bench GUI and CLI use actuator output units. The mapping API converts external joint units before packet encoding. It does not open a serial port.

```python
from joint_mapping import JointMap, JointTarget, OutputSample

mapping = JointMap(reduction=3, direction=-1, zero_output_rad=0.25)
output = mapping.to_output(JointTarget(-0.5, 2, 12, 36, 9))
joint = mapping.from_output(OutputSample(output.q_rad, output.rpm, output.tau_nm))
```

This example produces an output position of 1.75 rad, speed of about -57.2958 rpm, torque of -4 Nm, Kp of 4 and Kd of 1. Reverse conversion recovers the original position, speed and torque. The resulting torque exceeds the bench encoder's ±3.5 Nm policy, so encoding it rejects the command. Mapping never clips a value to make it pass.

`JointTarget` uses rad, rad/s and Nm. `OutputTarget` uses rad, rpm and Nm. The offset is in actuator output radians. The internal motor reduction stays inside the codec. Ideal gain conversion assumes compatible stiffness and damping definitions. Friction, backlash, efficiency and physical calibration remain unmeasured.

Run a single offline acceptance check from the repository root:

```sh
.venv/bin/python -B scripts/check_milestone.py B11
```

The command prints the path to its receipt and raw logs under `evidence/runs`. The test checks ratios 1, 3 and 6 in both directions, nonzero offsets, independent numeric anchors and invalid values.

## Passive port inspection

```python
from im6014_port import PortConfig, inspect_port
from spin_5rpm import PORT

report = inspect_port(PortConfig(PORT, 6_000_000), ports=())
```

`ports=()` makes this example use only the configured by-id basename. The report names its evidence source and does not establish communication with the motor. Normal inspection can also read passive OS enumeration metadata. Known wrong serial numbers or interfaces reject with expected and observed values. Unknown metadata stays explicitly unverified.

For an alternate adapter route, set both `expected_serial=None` and `expected_channel=None`. This removes the FTDI identity assertion. It does not bypass later device ownership checks or establish motor communication. The bench GUI and CLI default to the recorded FTDI serial and interface 3.

## Diagnostic capture

`PacketCapture` holds at most 256 records by default. Each record contains capped packet prefixes, allowlisted decoded fields, a fixed outcome code, and explicit source and connection metadata. Exported snapshots own their lists and dictionaries. Exception messages, environment values and arbitrary serial-object fields are excluded. An unavailable or regressing capture end clock exports `ended_s=None` and preserves the exchange result or original error. An invalid start clock rejects before exchange.

The GUI includes its ring in the existing JSON snapshot. The CLI enables it in `main`; direct `run(bus, args, log)` callers retain the original uncaptured behavior. Tests opt in with `fixture` provenance. A `physical` label records the caller's declaration and does not independently prove device identity.

## Cooperating bus ownership

Both real bench open sites use `open_managed_port(PortConfig(...), serial_factory=...)`. It checks passive identity before device acquisition and construction. A successful result owns `bus`; call `close()` and inspect its boolean result. `False` means ownership remains held because closure was not confirmed. Retry cleanup before reconnecting. A context manager raises `PortCloseError` on an otherwise normal exit with unconfirmed close; its `managed_port` remains available for cleanup.

This API opens hardware when given a motor path. Its acceptance tests use Linux PTYs exclusively. The device lease coordinates these workbench clients; it cannot exclude a raw client that ignores the lock.

When passive identity metadata is incomplete, the default route reports it as unverified and still permits device acquisition; known mismatches reject. The serial factory must expose the pyserial `is_open` status for confirmed cleanup. A missing status retains the lease. Neither passive inspection nor opening establishes CRC-valid motor communication.

## Controller lifecycle and freshness

`JointCore` owns a fixed ordered set of unique `JointSpec` names and motor IDs. Its states and immutable `Snapshot` are transport-free; `connected(SourceIdentity(...))` records a declaration and never opens hardware. `Decision` evaluates to its `accepted` value.

Connect, check, and arm are distinct steps. `receive(id, JointSample(...), MotorHealth(...))` stamps each valid observation with the core's monotonic clock. `checked()` needs fresh healthy Stop-mode feedback from every active joint. `arm()` requires fresh healthy Stop-mode feedback. The configurable maximum age defaults to 0.5 seconds; this software policy is not a measured loop-rate guarantee. Snapshot `feedback_ages_s` preserves joint order and uses `None` before receipt. Timestamp zero is valid. Unknown IDs and invalid records do not refresh timestamps.

Call `tick()` to fault READY, ARMED, or MOVING when feedback ages out. Stop, disconnect/reconnect, and healthy packets do not clear a fault latch. Recovery requires `begin_check(acknowledge_fault=True)` followed by fresh healthy Stop feedback and successful `checked()`. The check clears observations first. Target dispatch, attributed fault records and command ordering are the next milestones.

## Attributed faults

`Snapshot.faults` holds immutable `JointFault` records in configured joint order. `affected_joints` derives their names. Error and warning masks accumulate by bitwise OR, and watchdog timeout and stale flags latch. Communication codes are fixed `CommunicationFailure` enum values; they do not imply an actuator watchdog timeout. Current healthy feedback clears the current communication observation while the cause remains latched. Stop and reconnect retain causes. Only an explicitly acknowledged, complete, fresh, healthy Stop check clears them. Each core stores at most one record per configured joint and a unique first-occurrence union of fixed communication codes; its size is bounded by the finite enum. `communication_error` is the most recent cause; `communication_errors` is not a chronological event history. A supplied most-recent code must belong to that union.

When opening fails and cleanup cannot confirm closure, `open_managed_port` raises `PortCloseError` with `managed_port` for retry and the original error as `__cause__`. Context exit uses the same exception when closure fails, retaining any body exception as its cause. If cleanup succeeds, the original exception propagates normally.

## Latest target and command expiry

`Target(sequence, joints, window, owner)` contains an immutable complete tuple of `JointTarget` values in configured order, a required station-issued `IntentWindow(id, created_at_s, expires_at_s)`, and the current `OwnerToken`. `JointCore.issue_window(valid_for_s)` issues the latest offered window with a monotonic ID and bounded duration (`max_window_s`, default 1.0s). `submit_target` first expires or faults an existing goal as needed, then checks the full owner token, validates the incoming window against the latest offered window, checks expiry (exact equality with expiry is expired), checks mapped output codec representability, and enforces monotonic command sequence ordering before admitting the goal. A rejected replacement keeps an existing goal only while that goal remains valid.

`consume_target` is deleted in favor of explicit refresh lifecycle: `prepare_refresh()`, `claim_dispatch(plan_id, index)`, and `dispatch_result(plan_id, index, result)`. An admitted goal is refreshed repeatedly until its window expires. Preparing a plan proposes a refresh vector without dispatching. Each `RefreshPlan` contains an exact-count tuple of immutable, validated canonical packet bytes; the adapter writes those bytes unchanged. `joint_targets` records the actual full joint reference decoded from those packets, while `target` preserves the admitted request. `claim_dispatch` verifies freshness, health, goal expiry, and ordered joint index immediately before each write. Only one claim may await an outcome; the core blocks another joint claim, plan preparation, and reconnect until the station reports that claim's actual transport result. Stop, expiry, target replacement, disconnect, or fault can invalidate the plan without discarding that in-flight receipt. `exchange` reports the write result once after the driver outcome; successful returns are deadline-checked before feedback. If the deadline expires after the pre-write hook grants a claim but before `bus.write`, it reports `WriteResult.PREWRITE_DEADLINE`: the software made no write call for that claim. This does not establish motor state or physical protection. `WriteResult.PARTIAL` means the driver returned a positive short count. `WriteResult.FAILED` means the driver raised or returned an invalid count, so byte delivery may be unknown. `Snapshot.dispatch_attempts` holds the latest outcome per joint. `dispatch_result` commits a dispatched record only for a complete write. A dispatched record's `dispatched_at_s` is the valid claim/write start time, not a fabricated completion timestamp. A complete write followed by invalid or regressing core time preserves the complete record and attempt, then faults with `CommunicationFailure.CLOCK_FAILURE` without restoring motion. `WriteResult.PREWRITE_DEADLINE` faults with `CommunicationFailure.PREWRITE_DEADLINE`; `PARTIAL` and `FAILED` fault with `DRIVER_FAILURE`, preserving any prior complete record. A late receipt for an invalidated plan is recorded but cannot restore motion or change `DISCONNECTED`; once it settles, an explicit reconnect is allowed. Reconnect still requires a new owner, acknowledged fresh healthy Stop check, and explicit arm. When an admitted goal expires, housekeeping withdraws it, invalidates pending plans, and disarms the core to `STOPPED` (latched fault preserved), requiring a new check and arm cycle. Sequence watermarks survive consumption, stop, fault, and disconnect.

### Offline controller example

```python
from joint_contract import IntentWindow, JointSpec, MotorHealth, OwnerToken, SourceIdentity, State, Target, WriteResult
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget

clock_time = [0.0]
core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, 40.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
assert core.begin_connect()
assert core.connected(SourceIdentity("fixture", "example", 1))
owner = core.claim_owner("example-client")
assert core.begin_check()
assert core.receive(0, JointSample(0, 0, 0), MotorHealth(0, 0, 0, False))
assert core.checked()
assert core.arm(owner)
window = core.issue_window(0.5)
target = Target(6, (JointTarget(.1, 1, -6, 18, 4.5),), window=window, owner=owner)
assert core.submit_target(target)
clock_time[0] += 0.05
plan = core.prepare_refresh()
assert plan is not None
assert core.claim_dispatch(plan.plan_id, 0)
assert core.dispatch_result(plan.plan_id, 0, WriteResult.COMPLETE)
assert core.snapshot().state is State.MOVING
assert core.snapshot().dispatched_records[0].sequence == 6
assert core.stop()
assert core.snapshot().last_sequence == 6
```

This example performs no serial operations. A station adapter must validate its own physical setup and own packet transmission when later milestones add one.

## Core and ownership limits

The injected core clock must be finite and monotonic. Invalid or regressing time rejects operations that need a fresh gate; snapshots also require that clock contract. If a complete write receipt arrives after its end clock becomes invalid, the core preserves that known write and claim timestamp, then latches `CommunicationFailure.CLOCK_FAILURE` and withdraws motion until acknowledged recovery. The default clock is `time.monotonic`. Sequence `2**64 - 1` exhausts that core's stream. Start a new core for a new stream; reconnecting or acknowledging a fault never resets ordering.

### Owner generations

`JointCore` generates a fresh unpredictable random 16-byte hex epoch per instance/process via `secrets.token_hex(16)` with no persisted global state. A monotonic generation counter starts at 1 and ranges through uint64. `claim_owner(connection_id)` returns a frozen `OwnerToken(epoch, generation, connection_id)`. `connection_id` is an immutable non-empty string bounded to 64 characters and identifies the client connection; `SourceIdentity` separately identifies the motor connection. The core assumes trusted station callers; the station/server binds its actual client connection identity rather than trusting unverified JSON payload attributes, with no authentication claims beyond that boundary.

`arm(owner)` and `Target` require an exact `OwnerToken` class and matching immutable epoch, generation, and connection ID fields. Token-bearing boundary records reject subclasses. An owner mismatch returns `DecisionCode.INVALID_OWNER` after lifecycle state checks. Stop, any latched joint fault, disconnect, expired goals, and explicit takeover revoke active authority (`current_owner` becomes `None`), withdraw pending goals/plans and offered windows, and never auto-rearm. A claim during checking, ready, armed, or moving state, or a takeover of an existing owner on a connected core, places the core in `STOPPED` (while preserving `FAULT` and `DISCONNECTED`), requiring a fresh stop check and explicit arm call with the new token. Reconnecting requires claiming a fresh generation. Fault recovery also requires a new claim before checking and arming.

Durable attempt and dispatched records retain the original `OwnerToken` stamped at plan creation; an in-flight receipt completing after authority revocation preserves the actual write record with its original owner attribution without transitioning the core to `MOVING`. `Snapshot.latest_owner` retains the most recently issued token after revocation, while `Snapshot.current_owner` is `None` unless that token currently has authority. Bounded O(1) storage retains only these two tokens. When the uint64 generation space is exhausted, a new claim revokes authority, stops the core (or preserves `FAULT`/`DISCONNECTED`), and raises `OverflowError` without wrapping; start a fresh core to obtain a new epoch.

The fixed per-user lock namespace under `/tmp` coordinates cooperating processes. A hostile local user can pre-create the name and deny access; validation fails closed. An administrator must remove a foreign-owned obstruction. Lockfiles persist to preserve flock inode identity, including after device-number reuse. Do not delete them while clients may be running. No automatic pruning or hostile-local-user availability guarantee is supplied.

## Joint Position Limits

Every `JointSpec` requires explicit, immutable, finite position bounds `q_min_rad <= q_max_rad` and non-empty `limits_provenance` documenting the software threshold origin. These are fixture software limits, not physical calibration. Position requests are evaluated against inclusive bounds: exact lower and upper endpoints are accepted. Requests outside them return `DecisionCode.POSITION_OUT_OF_BOUNDS` and preserve any still-valid admitted goal, sequence watermark, owner, and window. Mapped requests must first pass the ordinary canonical codec; an unencodable mapped request returns `INVALID_ARGUMENT` and is never clamped into range. A fresh measured position outside the bounds, including during `CHECKING`, latches the attributed `JointFault.position_limit` cause and faults the core before motion. Simultaneous motor-health causes remain in the same joint fault record. `claim_dispatch` rechecks every fresh measured position and the actual prepared reference before each write. Recovery requires a new owner and an explicitly acknowledged fresh healthy Stop check with every measured position within the inclusive bounds; incoming targets cannot clear a fault. The codec owns the bounded raw position grid search through a monotonic decoded-domain callback and direction. It selects an inward representable endpoint, serializes that exact raw integer without float re-encoding, and decodes the complete canonical packet to populate actual position, velocity, feedforward, and gain reference fields. Stop packets are valid decoder inputs; mode, ID, watchdog, reserved byte, header, and CRC are checked. Repeated refreshes write the cached packet bytes unchanged.

## Speed- and acceleration-bounded trajectory reference and gap policy

Every `JointSpec` requires an explicit, finite positive maximum reference speed `v_max_rad_s` and maximum reference acceleration `a_max_rad_s2`. `JointCore` requires an explicit, finite positive `max_reference_gap_s` policy. All values describe software fixture policy unless calibrated separately.

Upon a successful healthy checked Stop, the controller initializes an unemitted trajectory reference for each joint with position equal to the checked feedback sample, zero exact velocity derivative, and timestamp equal to the sample time (`is_emitted=False`). The anchor has no cached command and cannot dispatch at $h=0$.

Preparing a refresh plan does not advance confirmed history. A `RefreshPlan` always carries one proposed reference, decoded command target, and immutable canonical packet per joint. Only a complete actual write commits that joint's proposed reference. Failed or partial writes leave its prior reference unchanged. Reference `sample_time_s` is the preparation time; `JointDispatchedRecord.dispatched_at_s` remains the actual claim/write start time.

For $h=0$, a previously emitted reference can refresh only when the admitted joint goal is unchanged. The core reuses that reference, decoded target, and exact packet bytes, including its prior position-step derivative and feedforward values; it does not encode the values again or advance their sample time. A changed goal at $h=0$ is rejected with an attributed constraint fault. If $h > \text{max\_reference\_gap\_s}$, motion is withdrawn and the controller drops to `STOPPED` (`REFERENCE_GAP_EXCEEDED`).

For $h>0$, the pure reference step intersects the speed interval $[-V,V]$, acceleration interval $[v_{\text{prev}}-A\cdot h, v_{\text{prev}}+A\cdot h]$, and position interval $[(q_{\min}-q_{\text{prev}})/h,(q_{\max}-q_{\text{prev}})/h]$. It projects the one-step objective $v_{\text{desired}} = (q_{\text{goal}}-q_{\text{prev}})/h + \dot{q}_{\text{goal}}$ into that closed intersection. The objective combines the requested position correction over this sample with velocity feedforward; it is not a continuous trajectory law.

The selected endpoint is projected inward to a representable point on the canonical codec grid. Position-step velocity is the exact rational $(q_{\text{emitted,next}}-q_{\text{emitted,prev}})/h$, where the stored finite float values and computed float difference $h$ are interpreted exactly. The independently decoded wire velocity feedforward has its own history and must satisfy both $|v|\leq V$ and $|v-v_{\text{prev,enc}}|\leq A\cdot h$. Neither stream is substituted for the other, and wire velocity is not used in position algebra. Reversal preserves previous velocity and crosses zero under the same acceleration bound.

An exactly zero objective is a stationary reference request even when position and feedforward terms cancel. For a nonzero objective, if no representable position step satisfies the closed bounds, the controller produces no mode-1 write and Stops with `DecisionCode.CONSTRAINT_VIOLATION`, attributed to each joint whose shaping failed. It does not carry hidden fractional motion or relax a bound. These are samplewise software reference limits; they do not promise a continuous motor trajectory, physical acceleration, or certified braking.

```

### Complete C11 author diff, including all modified tests
```diff
diff --git a/docs/joint-api.md b/docs/joint-api.md
index 7159a22..8efebf2 100644
--- a/docs/joint-api.md
+++ b/docs/joint-api.md
@@ -77,7 +77,7 @@ from joint_controller import JointCore
 from joint_mapping import JointMap, JointSample, JointTarget
 
 clock_time = [0.0]
-core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
+core = JointCore((JointSpec("J1", 0, JointMap(3, -1, .25), -2.0, 2.0, 10.0, 40.0, "fixture: software position limits"),), clock=lambda: clock_time[0], max_reference_gap_s=0.5)
 assert core.begin_connect()
 assert core.connected(SourceIdentity("fixture", "example", 1))
 owner = core.claim_owner("example-client")
@@ -119,9 +119,9 @@ The fixed per-user lock namespace under `/tmp` coordinates cooperating processes
 
 Every `JointSpec` requires explicit, immutable, finite position bounds `q_min_rad <= q_max_rad` and non-empty `limits_provenance` documenting the software threshold origin. These are fixture software limits, not physical calibration. Position requests are evaluated against inclusive bounds: exact lower and upper endpoints are accepted. Requests outside them return `DecisionCode.POSITION_OUT_OF_BOUNDS` and preserve any still-valid admitted goal, sequence watermark, owner, and window. Mapped requests must first pass the ordinary canonical codec; an unencodable mapped request returns `INVALID_ARGUMENT` and is never clamped into range. A fresh measured position outside the bounds, including during `CHECKING`, latches the attributed `JointFault.position_limit` cause and faults the core before motion. Simultaneous motor-health causes remain in the same joint fault record. `claim_dispatch` rechecks every fresh measured position and the actual prepared reference before each write. Recovery requires a new owner and an explicitly acknowledged fresh healthy Stop check with every measured position within the inclusive bounds; incoming targets cannot clear a fault. The codec owns the bounded raw position grid search through a monotonic decoded-domain callback and direction. It selects an inward representable endpoint, serializes that exact raw integer without float re-encoding, and decodes the complete canonical packet to populate actual position, velocity, feedforward, and gain reference fields. Stop packets are valid decoder inputs; mode, ID, watchdog, reserved byte, header, and CRC are checked. Repeated refreshes write the cached packet bytes unchanged.
 
-## Speed-bounded trajectory reference and gap policy
+## Speed- and acceleration-bounded trajectory reference and gap policy
 
-Every `JointSpec` requires an explicit, finite positive maximum reference speed `v_max_rad_s`. `JointCore` requires an explicit, finite positive `max_reference_gap_s` policy. Both values describe software fixture policy unless calibrated separately.
+Every `JointSpec` requires an explicit, finite positive maximum reference speed `v_max_rad_s` and maximum reference acceleration `a_max_rad_s2`. `JointCore` requires an explicit, finite positive `max_reference_gap_s` policy. All values describe software fixture policy unless calibrated separately.
 
 Upon a successful healthy checked Stop, the controller initializes an unemitted trajectory reference for each joint with position equal to the checked feedback sample, zero exact velocity derivative, and timestamp equal to the sample time (`is_emitted=False`). The anchor has no cached command and cannot dispatch at $h=0$.
 
@@ -129,8 +129,8 @@ Preparing a refresh plan does not advance confirmed history. A `RefreshPlan` alw
 
 For $h=0$, a previously emitted reference can refresh only when the admitted joint goal is unchanged. The core reuses that reference, decoded target, and exact packet bytes, including its prior position-step derivative and feedforward values; it does not encode the values again or advance their sample time. A changed goal at $h=0$ is rejected with an attributed constraint fault. If $h > \text{max\_reference\_gap\_s}$, motion is withdrawn and the controller drops to `STOPPED` (`REFERENCE_GAP_EXCEEDED`).
 
-For $h>0$, the pure reference step intersects the speed interval $[-V,V]$ and position interval $[(q_{\min}-q_{\text{prev}})/h,(q_{\max}-q_{\text{prev}})/h]$. It projects the one-step objective $v_{\text{desired}} = (q_{\text{goal}}-q_{\text{prev}})/h + \dot{q}_{\text{goal}}$ into that intersection. The objective combines the requested position correction over this sample with velocity feedforward; it is not a continuous trajectory law.
+For $h>0$, the pure reference step intersects the speed interval $[-V,V]$, acceleration interval $[v_{\text{prev}}-A\cdot h, v_{\text{prev}}+A\cdot h]$, and position interval $[(q_{\min}-q_{\text{prev}})/h,(q_{\max}-q_{\text{prev}})/h]$. It projects the one-step objective $v_{\text{desired}} = (q_{\text{goal}}-q_{\text{prev}})/h + \dot{q}_{\text{goal}}$ into that closed intersection. The objective combines the requested position correction over this sample with velocity feedforward; it is not a continuous trajectory law.
 
-The selected endpoint is projected inward to a representable point on the canonical codec grid. Position-step velocity is the exact rational $(q_{\text{emitted,next}}-q_{\text{emitted,prev}})/h$, where the stored finite float values and computed float difference $h$ are interpreted exactly. The independently decoded wire velocity feedforward has its own history and must also satisfy $|v|\leq V$. Neither stream is substituted for the other, and wire velocity is not used in position algebra.
+The selected endpoint is projected inward to a representable point on the canonical codec grid. Position-step velocity is the exact rational $(q_{\text{emitted,next}}-q_{\text{emitted,prev}})/h$, where the stored finite float values and computed float difference $h$ are interpreted exactly. The independently decoded wire velocity feedforward has its own history and must satisfy both $|v|\leq V$ and $|v-v_{\text{prev,enc}}|\leq A\cdot h$. Neither stream is substituted for the other, and wire velocity is not used in position algebra. Reversal preserves previous velocity and crosses zero under the same acceleration bound.
 
 An exactly zero objective is a stationary reference request even when position and feedforward terms cancel. For a nonzero objective, if no representable position step satisfies the closed bounds, the controller produces no mode-1 write and Stops with `DecisionCode.CONSTRAINT_VIOLATION`, attributed to each joint whose shaping failed. It does not carry hidden fractional motion or relax a bound. These are samplewise software reference limits; they do not promise a continuous motor trajectory, physical acceleration, or certified braking.
diff --git a/joint_contract.py b/joint_contract.py
index 24291d2..8b6e1d4 100644
--- a/joint_contract.py
+++ b/joint_contract.py
@@ -87,6 +87,7 @@ class JointSpec:
     q_min_rad: float
     q_max_rad: float
     v_max_rad_s: float
+    a_max_rad_s2: float
     limits_provenance: str
 
     def __post_init__(self) -> None:
@@ -120,6 +121,15 @@ class JointSpec:
         if not math.isfinite(v_max_val) or v_max_val <= 0.0:
             raise ValueError("v_max_rad_s must be finite and positive")
 
+        if isinstance(self.a_max_rad_s2, bool) or not isinstance(self.a_max_rad_s2, (int, float)):
+            raise ValueError("a_max_rad_s2 must be a finite positive real number")
+        try:
+            a_max_val = float(self.a_max_rad_s2)
+        except (OverflowError, TypeError, ValueError) as exc:
+            raise ValueError("acceleration limit must be finite") from exc
+        if not math.isfinite(a_max_val) or a_max_val <= 0.0:
+            raise ValueError("a_max_rad_s2 must be finite and positive")
+
         if (
             type(self.limits_provenance) is not str
             or not self.limits_provenance.strip()
@@ -130,6 +140,7 @@ class JointSpec:
         object.__setattr__(self, "q_min_rad", min_val)
         object.__setattr__(self, "q_max_rad", max_val)
         object.__setattr__(self, "v_max_rad_s", v_max_val)
+        object.__setattr__(self, "a_max_rad_s2", a_max_val)
 
 @dataclass(frozen=True)
 class JointFault:
diff --git a/joint_controller.py b/joint_controller.py
index 2ad2b80..e91bd4e 100644
--- a/joint_controller.py
+++ b/joint_controller.py
@@ -788,14 +788,30 @@ class JointCore:
             self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
             self.stop()
             return False
+        h_ref = prop_ref.sample_time_s - conf_ref.sample_time_s
+        h_ref_exact = Fraction(h_ref)
+        a_max_exact = Fraction(spec.a_max_rad_s2)
+        v_max_exact = Fraction(spec.v_max_rad_s)
+        v_prev_pos = Fraction(conf_ref.position_step_velocity_rad_s)
+        v_prev_enc = Fraction(conf_ref.encoded_velocity_rad_s)
+
         if (
-            abs(prop_ref.position_step_velocity_rad_s) > Fraction(spec.v_max_rad_s)
-            or abs(Fraction(prop_ref.encoded_velocity_rad_s)) > Fraction(spec.v_max_rad_s)
+            abs(prop_ref.position_step_velocity_rad_s) > v_max_exact
+            or abs(Fraction(prop_ref.encoded_velocity_rad_s)) > v_max_exact
         ):
             self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
             self.stop()
             return False
 
+        if prop_ref.sample_time_s > conf_ref.sample_time_s:
+            if (
+                abs(prop_ref.position_step_velocity_rad_s - v_prev_pos) > a_max_exact * h_ref_exact
+                or abs(Fraction(prop_ref.encoded_velocity_rad_s) - v_prev_enc) > a_max_exact * h_ref_exact
+            ):
+                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
+                self.stop()
+                return False
+
         self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
         return True
 
diff --git a/joint_reference.py b/joint_reference.py
index 3ee0806..84bd6e6 100644
--- a/joint_reference.py
+++ b/joint_reference.py
@@ -10,6 +10,7 @@ from im6014_codec import (
     project_position_raw,
     project_speed_raw,
     raw_to_position,
+    raw_to_rpm,
 )
 from joint_contract import (
     DecisionCode,
@@ -274,14 +275,20 @@ def shape_reference_joint(
     try:
         h_exact = Fraction(h)
         q_prev_exact = Fraction(confirmed_ref.q_rad)
+        v_prev_pos_exact = Fraction(confirmed_ref.position_step_velocity_rad_s)
+        v_prev_enc_exact = Fraction(confirmed_ref.encoded_velocity_rad_s)
         q_min_exact = Fraction(spec.q_min_rad)
         q_max_exact = Fraction(spec.q_max_rad)
         v_max_exact = Fraction(spec.v_max_rad_s)
+        a_max_exact = Fraction(spec.a_max_rad_s2)
 
         v_pos_lo = (q_min_exact - q_prev_exact) / h_exact
         v_pos_hi = (q_max_exact - q_prev_exact) / h_exact
-        v_lo = max(-v_max_exact, v_pos_lo)
-        v_hi = min(v_max_exact, v_pos_hi)
+        v_acc_lo = v_prev_pos_exact - a_max_exact * h_exact
+        v_acc_hi = v_prev_pos_exact + a_max_exact * h_exact
+
+        v_lo = max(-v_max_exact, v_pos_lo, v_acc_lo)
+        v_hi = min(v_max_exact, v_pos_hi, v_acc_hi)
         if v_lo > v_hi:
             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
 
@@ -289,8 +296,8 @@ def shape_reference_joint(
         v_desired = (Fraction(goal_q) - q_prev_exact) / h_exact + Fraction(goal_dq)
         v_projected = max(v_lo, min(v_hi, v_desired))
         q_continuous = q_prev_exact + v_projected * h_exact
-        q_next_lo = max(q_min_exact, q_prev_exact - v_max_exact * h_exact)
-        q_next_hi = min(q_max_exact, q_prev_exact + v_max_exact * h_exact)
+        q_next_lo = q_prev_exact + v_lo * h_exact
+        q_next_hi = q_prev_exact + v_hi * h_exact
         if q_next_lo > q_next_hi or not q_next_lo <= q_continuous <= q_next_hi:
             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
 
@@ -299,6 +306,19 @@ def shape_reference_joint(
         q_upper = float(q_next_hi)
         if not all(math.isfinite(value) for value in (q_wanted, q_lower, q_upper)):
             return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+
+        v_enc_lo = max(-v_max_exact, v_prev_enc_exact - a_max_exact * h_exact)
+        v_enc_hi = min(v_max_exact, v_prev_enc_exact + a_max_exact * h_exact)
+        if v_enc_lo > v_enc_hi:
+            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+
+        v_enc_desired = Fraction(goal_dq)
+        v_enc_projected = max(v_enc_lo, min(v_enc_hi, v_enc_desired))
+        v_enc_wanted = float(v_enc_projected)
+        v_enc_lower = float(v_enc_lo)
+        v_enc_upper = float(v_enc_hi)
+        if not all(math.isfinite(value) for value in (v_enc_wanted, v_enc_lower, v_enc_upper)):
+            return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
     except (ArithmeticError, TypeError, ValueError):
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
 
@@ -342,11 +362,14 @@ def shape_reference_joint(
             q_min_exact <= q_emitted_exact <= q_max_exact
             and q_next_lo <= q_emitted_exact <= q_next_hi
         )
-        safe_step = abs(position_step_velocity) <= v_max_exact
+        safe_step = (
+            abs(position_step_velocity) <= v_max_exact
+            and abs(position_step_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
+        )
         if not safe_position or not safe_step:
-            if q_emitted_exact < q_next_lo or position_step_velocity < -v_max_exact:
+            if q_emitted_exact < q_next_lo or position_step_velocity < v_lo:
                 raw_step = spec.mapping.direction
-            elif q_emitted_exact > q_next_hi or position_step_velocity > v_max_exact:
+            elif q_emitted_exact > q_next_hi or position_step_velocity > v_hi:
                 raw_step = -spec.mapping.direction
             else:
                 return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
@@ -358,6 +381,7 @@ def shape_reference_joint(
                 q_min_exact <= candidate_q_exact <= q_max_exact
                 and q_next_lo <= candidate_q_exact <= q_next_hi
                 and abs(candidate_velocity) <= v_max_exact
+                and abs(candidate_velocity - v_prev_pos_exact) <= a_max_exact * h_exact
             ):
                 return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
             raw_pos = raw_candidate
@@ -369,9 +393,9 @@ def shape_reference_joint(
 
     try:
         raw_rpm = project_speed_raw(
-            goal_dq,
-            -spec.v_max_rad_s,
-            spec.v_max_rad_s,
+            v_enc_wanted,
+            v_enc_lower,
+            v_enc_upper,
             lambda out_rpm: spec.mapping.from_output(OutputSample(0.0, out_rpm, 0.0)).dq_rad_s,
             spec.mapping.direction,
         )
@@ -381,6 +405,39 @@ def shape_reference_joint(
     if raw_rpm is None:
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
 
+    def mapped_speed(raw_s: int) -> float:
+        return spec.mapping.from_output(
+            OutputSample(0.0, raw_to_rpm(raw_s), 0.0)
+        ).dq_rad_s
+
+    try:
+        v_emitted_enc = mapped_speed(raw_rpm)
+        v_emitted_enc_exact = Fraction(v_emitted_enc)
+        safe_enc = (
+            abs(v_emitted_enc_exact) <= v_max_exact
+            and abs(v_emitted_enc_exact - v_prev_enc_exact) <= a_max_exact * h_exact
+            and v_enc_lo <= v_emitted_enc_exact <= v_enc_hi
+        )
+        if not safe_enc:
+            if v_emitted_enc_exact < v_enc_lo:
+                raw_rpm_step = spec.mapping.direction
+            elif v_emitted_enc_exact > v_enc_hi:
+                raw_rpm_step = -spec.mapping.direction
+            else:
+                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+            raw_rpm_cand = raw_rpm + raw_rpm_step
+            cand_v_enc = mapped_speed(raw_rpm_cand)
+            cand_v_enc_exact = Fraction(cand_v_enc)
+            if not (
+                abs(cand_v_enc_exact) <= v_max_exact
+                and abs(cand_v_enc_exact - v_prev_enc_exact) <= a_max_exact * h_exact
+                and v_enc_lo <= cand_v_enc_exact <= v_enc_hi
+            ):
+                return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+            raw_rpm = raw_rpm_cand
+    except (ArithmeticError, TypeError, ValueError):
+        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+
     try:
         packet = command_with_raw_position(
             spec.motor_id,
@@ -409,16 +466,21 @@ def shape_reference_joint(
 
     actual_q_exact = Fraction(actual_target.q_rad)
     actual_position_step_velocity = (actual_q_exact - q_prev_exact) / h_exact
+    actual_v_enc_exact = Fraction(actual_target.dq_rad_s)
     if not q_min_exact <= actual_q_exact <= q_max_exact:
         return DecisionCode.POSITION_OUT_OF_BOUNDS, None, None, None
     if not q_next_lo <= actual_q_exact <= q_next_hi:
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
     if v_desired != 0 and actual_target.q_rad == confirmed_ref.q_rad:
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
-    if abs(Fraction(actual_target.dq_rad_s)) > v_max_exact:
+    if abs(actual_v_enc_exact) > v_max_exact:
+        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+    if abs(actual_v_enc_exact - v_prev_enc_exact) > a_max_exact * h_exact:
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
     if abs(actual_position_step_velocity) > v_max_exact:
         return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
+    if abs(actual_position_step_velocity - v_prev_pos_exact) > a_max_exact * h_exact:
+        return DecisionCode.CONSTRAINT_VIOLATION, None, None, None
 
     proposed_ref = JointTrajectoryReference(
         q_rad=actual_target.q_rad,
diff --git a/scripts/check_milestone.py b/scripts/check_milestone.py
index 884c7c9..26366ab 100644
--- a/scripts/check_milestone.py
+++ b/scripts/check_milestone.py
@@ -22,6 +22,7 @@ CHECKS = {
     'C08': 'test_controller_owner',
     'C09': 'test_controller_limits.PositionLimitTests',
     'C10': 'test_controller_limits.ReferenceSpeedTests',
+    'C11': 'test_controller_limits.ReferenceAccelerationTests',
 }
 
 
diff --git a/test_controller.py b/test_controller.py
index e050075..a7dc0a5 100644
--- a/test_controller.py
+++ b/test_controller.py
@@ -108,8 +108,8 @@ class DeterministicClock:
 class FeedbackAgeTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
         )
 
     def _ready_station(self, clock, *, feedback_max_age_s=1.0):
@@ -315,8 +315,8 @@ class ControllerStateTests(unittest.TestCase):
     def setUp(self):
         self.clock = lambda: 0.0
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
         )
 
 
@@ -326,18 +326,18 @@ class ControllerStateTests(unittest.TestCase):
             JointCore((), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
             JointCore((
-                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, "fixture: software position limits"),
-                JointSpec("J1", 1, mapping, -2.0, 2.0, 10.0, "fixture: software position limits"),
+                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+                JointSpec("J1", 1, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
             ), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
             JointCore((
-                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, "fixture: software position limits"),
-                JointSpec("J2", 0, mapping, -2.0, 2.0, 10.0, "fixture: software position limits"),
+                JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+                JointSpec("J2", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
             ), max_reference_gap_s=1.0)
         with self.assertRaises(ValueError):
-            JointSpec("J1", True, mapping, -2.0, 2.0, 10.0, "fixture: software position limits")
+            JointSpec("J1", True, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits")
 
-        supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, "fixture: software position limits")]
+        supplied = [JointSpec("J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: software position limits")]
         core = JointCore(supplied, clock=self.clock, max_reference_gap_s=1.0)
         supplied.clear()
         self.assertEqual(tuple(spec.name for spec in core.joint_specs), ("J1",))
@@ -553,8 +553,8 @@ class ControllerStateTests(unittest.TestCase):
 class JointFaultTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
         )
 
     def _ready_core(self, clock=None, *, feedback_max_age_s=1.0):
@@ -875,8 +875,8 @@ class JointFaultTests(unittest.TestCase):
 
     def test_independent_second_core_unchanged_by_fault(self):
         specs2 = (
-            JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
-            JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
+            JointSpec("J3", 2, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J4", 3, JointMap(1, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
         )
         clock = DeterministicClock(0.0)
         core1 = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
diff --git a/test_controller_expiry.py b/test_controller_expiry.py
index bff4156..8c485f1 100644
--- a/test_controller_expiry.py
+++ b/test_controller_expiry.py
@@ -29,8 +29,8 @@ SOURCE = SourceIdentity("fixture", "expiry-test", 1)
 class ControllerExpiryTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
diff --git a/test_controller_limits.py b/test_controller_limits.py
index ed472dd..2eb20ba 100644
--- a/test_controller_limits.py
+++ b/test_controller_limits.py
@@ -65,8 +65,8 @@ class PositionLimitTests(unittest.TestCase):
     def setUp(self):
         self.clock = DeterministicClock(0.0)
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1.0, 2.0, 100.0, "fixture: software position limits J1"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -0.5, 0.5, 100.0, "fixture: software position limits J2"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1.0, 2.0, 100.0, 500.0, "fixture: software position limits J1"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -0.5, 0.5, 100.0, 500.0, "fixture: software position limits J2"),
         )
         self.valid_sample_j1 = JointSample(0.1, 0.0, 0.0)
         self.valid_sample_j2 = JointSample(0.0, 0.0, 0.0)
@@ -193,6 +193,7 @@ class PositionLimitTests(unittest.TestCase):
                 -1.0,
                 1.0,
                 100.0,
+                500.0,
                 "fixture: software limits negative direction",
             ),
             JointSpec(
@@ -202,6 +203,7 @@ class PositionLimitTests(unittest.TestCase):
                 -0.5,
                 0.5,
                 100.0,
+                500.0,
                 "fixture: software limits positive direction",
             ),
         )
@@ -267,6 +269,7 @@ class PositionLimitTests(unittest.TestCase):
             grid_pos,
             grid_pos,
             10.0,
+            100.0,
             "fixture: exact grid point interval",
         )
         found_code = self._project(spec_zero_width, grid_pos)
@@ -286,6 +289,7 @@ class PositionLimitTests(unittest.TestCase):
             mid - 1e-9,
             mid + 1e-9,
             10.0,
+            100.0,
             "fixture: empty grid interval",
         )
         found_none = self._project(spec_empty_grid, mid)
@@ -312,54 +316,72 @@ class PositionLimitTests(unittest.TestCase):
 
         # q_min_rad > q_max_rad
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 1.0, 0.0, 10.0, "fixture: invalid min max")
+            JointSpec("J1", 0, mapping, 1.0, 0.0, 10.0, 100.0, "fixture: invalid min max")
 
         # non-numeric / bool types
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, True, 1.0, 10.0, "fixture: bool min")
+            JointSpec("J1", 0, mapping, True, 1.0, 10.0, 100.0, "fixture: bool min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0.0, False, 10.0, "fixture: bool max")
+            JointSpec("J1", 0, mapping, 0.0, False, 10.0, 100.0, "fixture: bool max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, "0.0", 1.0, 10.0, "fixture: str min")
+            JointSpec("J1", 0, mapping, "0.0", 1.0, 10.0, 100.0, "fixture: str min")
 
         # infinite / NaN
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, float("-inf"), 1.0, 10.0, "fixture: neg inf min")
+            JointSpec("J1", 0, mapping, float("-inf"), 1.0, 10.0, 100.0, "fixture: neg inf min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0.0, float("inf"), 10.0, "fixture: inf max")
+            JointSpec("J1", 0, mapping, 0.0, float("inf"), 10.0, 100.0, "fixture: inf max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, float("nan"), 1.0, 10.0, "fixture: nan min")
+            JointSpec("J1", 0, mapping, float("nan"), 1.0, 10.0, 100.0, "fixture: nan min")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, 0, 10**400, 10.0, "fixture: overflowing max")
+            JointSpec("J1", 0, mapping, 0, 10**400, 10.0, 100.0, "fixture: overflowing max")
 
         # v_max_rad_s <= 0 or not finite
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 0.0, "fixture: zero v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 0.0, 100.0, "fixture: zero v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, -10.0, "fixture: negative v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, -10.0, 100.0, "fixture: negative v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, float("inf"), "fixture: inf v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, float("inf"), 100.0, "fixture: inf v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, float("nan"), "fixture: nan v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, float("nan"), 100.0, "fixture: nan v_max")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, "10.0", "fixture: str v_max")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, "10.0", 100.0, "fixture: str v_max")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, True, 100.0, "fixture: bool v_max")
+
+        # a_max_rad_s2 <= 0 or not finite
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 0.0, "fixture: zero a_max")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, -10.0, "fixture: negative a_max")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("inf"), "fixture: inf a_max")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, float("nan"), "fixture: nan a_max")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "10.0", "fixture: str a_max")
+        with self.assertRaises(ValueError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, True, "fixture: bool a_max")
 
         # invalid provenance
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "   ")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "   ")
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 123)
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, 123)
         with self.assertRaises(ValueError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, "x" * 257)
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, "x" * 257)
 
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0)
         with self.assertRaises(TypeError):
             JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0)
         with self.assertRaises(TypeError):
-            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, provenance="legacy alias")
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0)
+        with self.assertRaises(TypeError):
+            JointSpec("J1", 0, mapping, -1.0, 1.0, 10.0, 100.0, provenance="legacy alias")
 
         # JointFault position_limit type validation
         with self.assertRaises(ValueError):
@@ -508,7 +530,7 @@ class PositionLimitTests(unittest.TestCase):
         self.assertFalse(core.snapshot().fault_latched)
 
     def test_codec_rounding_overshoot_produces_inward_actual_safe_endpoint(self):
-        spec = JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -0.1, 0.1, 10.0, "fixture: rounding overshoot test")
+        spec = JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -0.1, 0.1, 10.0, 100.0, "fixture: rounding overshoot test")
         target = JointTarget(0.1, 0.0, 0.0, 1.0, 0.1)
 
         requested_output = spec.mapping.to_output(target)
@@ -695,7 +717,7 @@ class PositionLimitTests(unittest.TestCase):
     def test_actual_reference_matches_every_canonical_wire_field(self):
         mapping = JointMap(3.0, -1, 0.25)
         spec = JointSpec(
-            "J1", 0, mapping, -2.0, 2.0, 10.0, "fixture: canonical reference test"
+            "J1", 0, mapping, -2.0, 2.0, 10.0, 100.0, "fixture: canonical reference test"
         )
         requested = JointTarget(0.321, 0.123, 0.321, 1.234, 0.123)
 
@@ -715,7 +737,7 @@ class PositionLimitTests(unittest.TestCase):
 
     def test_unencodable_mapped_request_is_invalid_not_projected_into_range(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8,
             "fixture: wide software position limits",
         )
         code, actual, packet = prepare_reference_joint(
@@ -727,7 +749,7 @@ class PositionLimitTests(unittest.TestCase):
 
     def test_mapping_overflow_is_invalid_argument(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1e-308, 1, 0.0), -1.0, 1.0, 10.0,
+            "J1", 0, JointMap(1e-308, 1, 0.0), -1.0, 1.0, 10.0, 100.0,
             "fixture: mapping overflow limits",
         )
         code, actual, packet = prepare_reference_joint(
@@ -876,7 +898,7 @@ class PositionLimitTests(unittest.TestCase):
             with self.subTest(result=result):
                 clock = DeterministicClock(0.0)
                 spec = JointSpec(
-                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0,
+                    "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0,
                     "fixture: late receipt limits",
                 )
                 core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
@@ -941,7 +963,7 @@ class PositionLimitTests(unittest.TestCase):
 
         clock = EndClock(0.0)
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0,
             "fixture: late complete limits",
         )
         core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
@@ -997,6 +1019,7 @@ class PositionLimitTests(unittest.TestCase):
                 q - half_width,
                 q + half_width,
                 1e8,
+                1e8,
                 "fixture: seeded software limits",
             )
             output_velocity = rng.uniform(-0.5, 0.5)
@@ -1056,6 +1079,7 @@ class ReferenceSpeedTests(unittest.TestCase):
             -2.0,
             2.0,
             1.0,  # v_max_rad_s = 1.0 rad/s
+            1000.0,  # a_max_rad_s2 = 1000.0 rad/s2
             "fixture: speed limit test J1",
         )
         self.spec2 = JointSpec(
@@ -1065,6 +1089,7 @@ class ReferenceSpeedTests(unittest.TestCase):
             -1.0,
             1.0,
             2.0,  # v_max_rad_s = 2.0 rad/s
+            1000.0,  # a_max_rad_s2 = 1000.0 rad/s2
             "fixture: speed limit test J2",
         )
         self.specs = (self.spec1, self.spec2)
@@ -1503,7 +1528,7 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_zero_objective_cancellation_is_not_quantization_stall(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0,
             "fixture: zero-objective cancellation test",
         )
         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
@@ -1522,7 +1547,7 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_finite_extreme_objective_uses_exact_projection_without_overflow(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.5e308,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.5e308, 1.5e308,
             "fixture: finite extreme objective",
         )
         anchor = JointTrajectoryReference(-1.0, Fraction(0), 0.0, 0.0, False)
@@ -1543,7 +1568,7 @@ class ReferenceSpeedTests(unittest.TestCase):
 
     def test_oversized_integer_time_inputs_fail_closed_without_raising(self):
         spec = JointSpec(
-            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0,
+            "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 1.0, 100.0,
             "fixture: oversized integer time",
         )
         anchor = JointTrajectoryReference(0.0, Fraction(0), 0.0, 0.0, False)
@@ -1562,11 +1587,11 @@ class ReferenceSpeedTests(unittest.TestCase):
         clock = DeterministicClock(0.0)
         specs = (
             JointSpec(
-                "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001,
+                "J1", 0, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0,
                 "fixture: tiny-cadence stall J1",
             ),
             JointSpec(
-                "J2", 1, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001,
+                "J2", 1, JointMap(1.0, 1, 0.0), -1.0, 1.0, 0.001, 10.0,
                 "fixture: tiny-cadence hold J2",
             ),
         )
@@ -1620,5 +1645,509 @@ class ReferenceSpeedTests(unittest.TestCase):
         self.assertFalse(core.claim_dispatch(plan.plan_id, 0))
 
 
+class ReferenceAccelerationTests(unittest.TestCase):
+    def setUp(self):
+        self.clock = DeterministicClock(10.0)
+        self.spec1 = JointSpec(
+            "J1",
+            0,
+            JointMap(1.0, 1, 0.0),
+            -2.0,
+            2.0,
+            2.0,  # v_max = 2.0 rad/s
+            4.0,  # a_max = 4.0 rad/s2
+            "fixture: acceleration test J1",
+        )
+        self.spec2 = JointSpec(
+            "J2",
+            1,
+            JointMap(1.0, 1, 0.0),
+            -2.0,
+            2.0,
+            3.0,  # v_max = 3.0 rad/s
+            6.0,  # a_max = 6.0 rad/s2
+            "fixture: acceleration test J2",
+        )
+        self.specs = (self.spec1, self.spec2)
+        self.sample1 = JointSample(0.0, 0.0, 0.0)
+        self.sample2 = JointSample(0.0, 0.0, 0.0)
+
+    def _armed_station(self, max_reference_gap_s=1.0):
+        core = JointCore(self.specs, clock=self.clock, max_reference_gap_s=max_reference_gap_s)
+        station = FakeStation(core)
+        self.assertTrue(station.connect().accepted)
+        owner = station.claim("accel-tester")
+        self.assertTrue(core.begin_check().accepted)
+        self.assertTrue(core.receive(0, self.sample1, HEALTHY_STOP).accepted)
+        self.assertTrue(core.receive(1, self.sample2, HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner).accepted)
+        return core, station, owner
+
+    def assert_acceleration_certificate(self, previous, current, spec):
+        h = current.sample_time_s - previous.sample_time_s
+        self.assertGreater(h, 0.0)
+        h_exact = Fraction(h)
+        exact_position_step_velocity = (
+            Fraction(current.q_rad) - Fraction(previous.q_rad)
+        ) / h_exact
+        self.assertEqual(
+            current.position_step_velocity_rad_s,
+            exact_position_step_velocity,
+        )
+        self.assertIsInstance(current.position_step_velocity_rad_s, Fraction)
+
+        exact_speed_limit = Fraction(spec.v_max_rad_s)
+        self.assertLessEqual(abs(exact_position_step_velocity), exact_speed_limit)
+        self.assertLessEqual(
+            abs(Fraction(current.encoded_velocity_rad_s)), exact_speed_limit
+        )
+
+        exact_accel_limit = Fraction(spec.a_max_rad_s2)
+        prev_pos_v = Fraction(previous.position_step_velocity_rad_s)
+        prev_enc_v = Fraction(previous.encoded_velocity_rad_s)
+        curr_enc_v = Fraction(current.encoded_velocity_rad_s)
+
+        self.assertLessEqual(
+            abs(exact_position_step_velocity - prev_pos_v),
+            exact_accel_limit * h_exact,
+        )
+        self.assertLessEqual(
+            abs(curr_enc_v - prev_enc_v),
+            exact_accel_limit * h_exact,
+        )
+
+    def test_exact_acceleration_equality(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        target = Target(
+            1,
+            (
+                JointTarget(1.0, 2.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+        anchor = core.snapshot().confirmed_references[0]
+
+        # Cadence h = 0.25s. Max velocity step = a_max * h = 4.0 * 0.25 = 1.0 rad/s
+        self.clock.value += 0.25
+        plan = station.refresh()
+        self.assertIsNotNone(plan)
+
+        ref1 = core.snapshot().confirmed_references[0]
+        self.assert_acceleration_certificate(anchor, ref1, self.spec1)
+        # Position step velocity should be bounded by exactly a_max * h = 1.0 rad/s
+        self.assertLessEqual(ref1.position_step_velocity_rad_s, Fraction(1, 1))
+        self.assertGreater(ref1.position_step_velocity_rad_s, Fraction(0, 1))
+
+    def test_repeated_positive_progression_up_to_v_max(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(2.0)
+        target = Target(
+            1,
+            (
+                JointTarget(1.8, 2.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+
+        prev_ref = core.snapshot().confirmed_references[0]
+        velocities = []
+
+        # Step at h = 0.1s. a_max * h = 0.4 rad/s per step until v_max = 2.0 rad/s
+        for _ in range(8):
+            self.clock.value += 0.1
+            plan = station.refresh()
+            self.assertIsNotNone(plan)
+            curr_ref = core.snapshot().confirmed_references[0]
+            self.assert_acceleration_certificate(prev_ref, curr_ref, self.spec1)
+            self.assertGreater(curr_ref.q_rad, prev_ref.q_rad)
+            velocities.append(float(curr_ref.position_step_velocity_rad_s))
+            prev_ref = curr_ref
+
+        # Check progressive acceleration up to v_max
+        self.assertTrue(all(velocities[i] <= velocities[i + 1] + 1e-9 for i in range(4)))
+        self.assertAlmostEqual(velocities[-1], self.spec1.v_max_rad_s, delta=0.05)
+
+    def test_reversal_crosses_zero_under_acceleration_bound(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(2.0)
+        # Accelerate forward first
+        t_fwd = Target(
+            1,
+            (
+                JointTarget(1.5, 2.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t_fwd).accepted)
+        for _ in range(4):
+            self.clock.value += 0.1
+            self.assertIsNotNone(station.refresh())
+
+        fwd_ref = core.snapshot().confirmed_references[0]
+        self.assertGreater(fwd_ref.position_step_velocity_rad_s, Fraction(1, 1))
+
+        # Command reversal toward negative
+        t_rev = Target(
+            2,
+            (
+                JointTarget(-1.5, -2.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t_rev).accepted)
+
+        prev_ref = fwd_ref
+        reversal_velocities = []
+        crossed_zero = False
+        for _ in range(8):
+            self.clock.value += 0.1
+            plan = station.refresh()
+            self.assertIsNotNone(plan)
+            curr_ref = core.snapshot().confirmed_references[0]
+            self.assert_acceleration_certificate(prev_ref, curr_ref, self.spec1)
+            v_curr = float(curr_ref.position_step_velocity_rad_s)
+            v_prev = float(prev_ref.position_step_velocity_rad_s)
+            # Must decelerate smoothly: step delta bounded by a_max * h = 0.4
+            self.assertLessEqual(v_curr - v_prev, 1e-9)
+            self.assertGreaterEqual(v_curr - v_prev, -0.40001)
+            if v_prev > 0 and v_curr <= 0:
+                crossed_zero = True
+            reversal_velocities.append(v_curr)
+            prev_ref = curr_ref
+
+        self.assertTrue(crossed_zero)
+        self.assertLess(reversal_velocities[-1], 0.0)
+
+    def test_mixed_h_cadence_scaling(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(2.0)
+        target = Target(
+            1,
+            (
+                JointTarget(1.5, 2.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+
+        prev_ref = core.snapshot().confirmed_references[0]
+        for h in (0.05, 0.02, 0.1, 0.03):
+            self.clock.value += h
+            plan = station.refresh()
+            self.assertIsNotNone(plan)
+            curr_ref = core.snapshot().confirmed_references[0]
+            self.assert_acceleration_certificate(prev_ref, curr_ref, self.spec1)
+            prev_ref = curr_ref
+
+    def test_velocity_previous_retained_near_q_limit(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(2.0)
+        # Advance joint close to q_max (2.0)
+        target = Target(
+            1,
+            (
+                JointTarget(1.98, 1.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+
+        prev_ref = core.snapshot().confirmed_references[0]
+        for _ in range(10):
+            self.clock.value += 0.1
+            plan = station.refresh()
+            if plan is None:
+                break
+            curr_ref = core.snapshot().confirmed_references[0]
+            self.assert_acceleration_certificate(prev_ref, curr_ref, self.spec1)
+            self.assertLessEqual(curr_ref.q_rad, self.spec1.q_max_rad)
+            prev_ref = curr_ref
+
+        # State should either be MOVING or READY, not FAULT from q overshoot
+        self.assertIn(core.snapshot().state, (State.MOVING, State.READY))
+        self.assertLessEqual(core.snapshot().confirmed_references[0].q_rad, self.spec1.q_max_rad)
+
+    def test_position_and_acceleration_incompatible_withdraws_instead_of_q_clamp(self):
+        # Anchor at 1.99 with large positive velocity 10.0 rad/s
+        spec = JointSpec(
+            "J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 10.0,
+            "fixture: incompatible limits",
+        )
+        anchor = JointTrajectoryReference(
+            q_rad=1.99,
+            position_step_velocity_rad_s=Fraction(10, 1),
+            encoded_velocity_rad_s=10.0,
+            sample_time_s=0.0,
+            is_emitted=True,
+        )
+        target = JointTarget(2.0, 0.0, 0.0, 1.0, 0.1)
+
+        # In h = 0.01:
+        # v_pos_hi = (2.0 - 1.99) / 0.01 = 1.0 rad/s
+        # v_acc_lo = 10.0 - 10.0 * 0.01 = 9.9 rad/s
+        # v_acc_lo (9.9) > v_pos_hi (1.0) -> empty intersection!
+        code, emitted, ref, packet = shape_reference_joint(
+            spec, target, anchor, 0.01, 1.0
+        )
+        self.assertIs(code, DecisionCode.CONSTRAINT_VIOLATION)
+        self.assertIsNone(emitted)
+        self.assertIsNone(ref)
+        self.assertIsNone(packet)
+
+        # In core: empty intersection must cause constraint fault and Stop, never clamp to 2.0
+        clock = DeterministicClock(0.0)
+        core = JointCore((spec,), clock=clock, max_reference_gap_s=1.0)
+        station = FakeStation(core)
+        self.assertTrue(station.connect().accepted)
+        owner = station.claim("incompatible-tester")
+        self.assertTrue(core.begin_check().accepted)
+        self.assertTrue(core.receive(0, JointSample(1.99, 0.0, 0.0), HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner).accepted)
+
+        # Hack confirmed reference to have 10 rad/s prior velocity
+        core._confirmed_references[0] = anchor
+        window = station.issue_window(1.0)
+        self.assertTrue(station.submit(Target(1, (target,), window=window, owner=owner)).accepted)
+        clock.value = 0.01
+
+        self.assertIsNone(core.prepare_refresh())
+        snap = core.snapshot()
+        self.assertIs(snap.state, State.FAULT)
+        self.assertTrue(snap.fault_latched)
+        self.assertTrue(snap.faults[0].constraint_fault)
+        self.assertEqual(snap.affected_joints, ("J1",))
+
+    def test_quantization_edge_and_cadence_boundary(self):
+        # Case A: Tiny cadence h = 1e-10 with nonzero objective
+        clock = DeterministicClock(0.0)
+        core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
+        station = FakeStation(core)
+        self.assertTrue(station.connect().accepted)
+        owner = station.claim("quantization-tester")
+        self.assertTrue(core.begin_check().accepted)
+        self.assertTrue(core.receive(0, self.sample1, HEALTHY_STOP).accepted)
+        self.assertTrue(core.receive(1, self.sample2, HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner).accepted)
+        window = station.issue_window(1.0)
+
+        # Nonzero objective cannot make a representable position step in 1e-10 s
+        t_tiny = Target(
+            1,
+            (
+                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(t_tiny).accepted)
+        clock.value = 10.0 + 1e-10
+
+        self.assertIsNone(core.prepare_refresh())
+        snap = core.snapshot()
+        self.assertIs(snap.state, State.FAULT)
+        self.assertTrue(snap.faults[0].constraint_fault)
+
+        # Case B: Deliberate hold (v_desired == 0, goal_q == current_q) is valid
+        clock2 = DeterministicClock(10.0)
+        core2 = JointCore(self.specs, clock=clock2, max_reference_gap_s=1.0)
+        station2 = FakeStation(core2)
+        self.assertTrue(station2.connect().accepted)
+        owner2 = station2.claim("hold-tester")
+        self.assertTrue(core2.begin_check().accepted)
+        self.assertTrue(core2.receive(0, self.sample1, HEALTHY_STOP).accepted)
+        self.assertTrue(core2.receive(1, self.sample2, HEALTHY_STOP).accepted)
+        self.assertTrue(core2.checked().accepted)
+        self.assertTrue(station2.arm(owner2).accepted)
+        window2 = station2.issue_window(1.0)
+
+        t_hold = Target(
+            1,
+            (
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window2,
+            owner=owner2,
+        )
+        self.assertTrue(station2.submit(t_hold).accepted)
+        clock2.value = 10.05
+        plan = station2.refresh()
+        self.assertIsNotNone(plan)
+        self.assertEqual(core2.snapshot().confirmed_references[0].q_rad, 0.0)
+
+    def test_independently_bounded_encoded_and_position_velocities(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        target = Target(
+            1,
+            (
+                JointTarget(0.2, 1.0, 0.0, 1.0, 0.1),
+                JointTarget(0.1, 0.5, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+        self.clock.value += 0.05
+        plan = station.refresh()
+        self.assertIsNotNone(plan)
+
+        ref0 = core.snapshot().confirmed_references[0]
+        # Position step velocity is exact Fraction
+        self.assertIsInstance(ref0.position_step_velocity_rad_s, Fraction)
+        # Encoded motor velocity is float
+        self.assertIsInstance(ref0.encoded_velocity_rad_s, float)
+        # Both satisfy their respective bounds
+        self.assertLessEqual(abs(ref0.position_step_velocity_rad_s), Fraction(self.spec1.v_max_rad_s))
+        self.assertLessEqual(abs(Fraction(ref0.encoded_velocity_rad_s)), Fraction(self.spec1.v_max_rad_s))
+        h_exact = Fraction(0.05)
+        self.assertLessEqual(
+            abs(ref0.position_step_velocity_rad_s),
+            Fraction(self.spec1.a_max_rad_s2) * h_exact,
+        )
+        self.assertLessEqual(
+            abs(Fraction(ref0.encoded_velocity_rad_s)),
+            Fraction(self.spec1.a_max_rad_s2) * h_exact,
+        )
+
+    def test_partial_multi_joint_failure(self):
+        clock = DeterministicClock(10.0)
+        core = JointCore(self.specs, clock=clock, max_reference_gap_s=1.0)
+        station = FakeStation(core)
+        self.assertTrue(station.connect().accepted)
+        owner = station.claim("multi-tester")
+        self.assertTrue(core.begin_check().accepted)
+        self.assertTrue(core.receive(0, self.sample1, HEALTHY_STOP).accepted)
+        self.assertTrue(core.receive(1, self.sample2, HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner).accepted)
+        window = station.issue_window(1.0)
+
+        # J1 requests impossible step under tiny cadence; J2 requests hold
+        target = Target(
+            1,
+            (
+                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
+                JointTarget(0.0, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+        clock.value = 10.0 + 1e-10
+
+        self.assertIsNone(core.prepare_refresh())
+        snap = core.snapshot()
+        self.assertIs(snap.state, State.FAULT)
+        self.assertEqual(snap.affected_joints, ("J1",))
+        self.assertTrue(snap.faults[0].constraint_fault)
+
+    def test_stop_and_check_reinitialization(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        target = Target(
+            1,
+            (
+                JointTarget(0.2, 1.0, 0.0, 1.0, 0.1),
+                JointTarget(0.2, 1.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+        self.clock.value += 0.05
+        self.assertIsNotNone(station.refresh())
+
+        ref_active = core.snapshot().confirmed_references[0]
+        self.assertGreater(ref_active.position_step_velocity_rad_s, Fraction(0))
+
+        # Stop controller
+        self.assertTrue(station.stop().accepted)
+        self.assertIs(core.snapshot().state, State.STOPPED)
+
+        # Check and re-arm with fresh sample
+        owner2 = station.claim("rearm-tester")
+        self.assertTrue(core.begin_check(acknowledge_fault=True).accepted)
+        self.clock.value += 0.1
+        self.assertTrue(core.receive(0, JointSample(ref_active.q_rad, 0.0, 0.0), HEALTHY_STOP).accepted)
+        self.assertTrue(core.receive(1, JointSample(0.0, 0.0, 0.0), HEALTHY_STOP).accepted)
+        self.assertTrue(core.checked().accepted)
+        self.assertTrue(station.arm(owner2).accepted)
+
+        # Reinitialized references must have velocity == 0.0
+        ref_reinit = core.snapshot().confirmed_references[0]
+        self.assertEqual(ref_reinit.position_step_velocity_rad_s, 0.0)
+        self.assertEqual(ref_reinit.encoded_velocity_rad_s, 0.0)
+        self.assertFalse(ref_reinit.is_emitted)
+
+    def test_h0_refresh_and_fresh_anchor(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        target = Target(
+            1,
+            (
+                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
+                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+        # Fresh stop anchor at h = 0 cannot dispatch write
+        self.assertIsNone(core.prepare_refresh())
+        self.assertIs(core.snapshot().state, State.FAULT)
+
+    def test_final_write_gate_rechecks_acceleration_bound(self):
+        core, station, owner = self._armed_station()
+        window = station.issue_window(1.0)
+        target = Target(
+            1,
+            (
+                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
+                JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
+            ),
+            window=window,
+            owner=owner,
+        )
+        self.assertTrue(station.submit(target).accepted)
+        self.clock.value += 0.05
+        plan = core.prepare_refresh()
+        self.assertIsNotNone(plan)
+
+        # Tamper proposed reference to violate acceleration bound
+        bad_ref = replace(
+            plan.proposed_references[0],
+            position_step_velocity_rad_s=Fraction(100, 1),
+        )
+        tampered_refs = (bad_ref, plan.proposed_references[1])
+        core._prepared_plan = replace(plan, proposed_references=tampered_refs)
+
+        # Gate must deny write and latch constraint fault
+        self.assertFalse(core.claim_dispatch(plan.plan_id, 0))
+        snap = core.snapshot()
+        self.assertTrue(snap.fault_latched)
+        self.assertTrue(snap.faults[0].constraint_fault)
+
+
 if __name__ == "__main__":
     unittest.main()
+
diff --git a/test_controller_owner.py b/test_controller_owner.py
index f597296..08419ae 100644
--- a/test_controller_owner.py
+++ b/test_controller_owner.py
@@ -27,8 +27,8 @@ class ControllerOwnerTests(unittest.TestCase):
     def setUp(self):
         self.clock = DeterministicClock(0.0)
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, "fixture: software position limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -2.0, 2.0, 10.0, 100.0, "fixture: software position limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),
diff --git a/test_controller_targets.py b/test_controller_targets.py
index 3c19502..ffdac0a 100644
--- a/test_controller_targets.py
+++ b/test_controller_targets.py
@@ -21,8 +21,8 @@ from test_controller import DeterministicClock, FakeStation, SAMPLE, HEALTHY_STO
 class LatestTargetTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
 
     def test_ten_thousand_accepted_updates_leave_one_newest_target_and_repeated_refresh(self):
@@ -273,8 +273,8 @@ class LatestTargetTests(unittest.TestCase):
         self.assertEqual(core.snapshot().last_sequence, 1)
 
         specs_ratio = (
-            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(reduction=1.0, direction=1, zero_output_rad=0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(reduction=1.0, direction=1, zero_output_rad=0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         core_ratio = JointCore(specs_ratio, clock=clock, max_reference_gap_s=1.0)
         station_ratio = FakeStation(core_ratio)
@@ -295,8 +295,8 @@ class LatestTargetTests(unittest.TestCase):
     def test_successful_fake_adapter_uses_actual_codec_foc_packets_with_independent_expected_mappings(self):
         clock = DeterministicClock(0.0)
         specs = (
-            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25), -1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(reduction=2.0, direction=1, zero_output_rad=0.1), -1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(reduction=3.0, direction=-1, zero_output_rad=0.25), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(reduction=2.0, direction=1, zero_output_rad=0.1), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         core = JointCore(specs, clock=clock, max_reference_gap_s=1.0)
         station = FakeStation(core)
@@ -529,8 +529,8 @@ class LatestTargetTests(unittest.TestCase):
 class CommandSequenceTests(unittest.TestCase):
     def setUp(self):
         self.specs = (
-            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
-            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J1", 0, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
+            JointSpec("J2", 1, JointMap(1.0, 1, 0.0), -1e8, 1e8, 1e8, 1e8, "fixture: wide test limits"),
         )
         self.valid_joints = (
             JointTarget(0.1, 0.0, 0.0, 1.0, 0.1),

```

### Parent actual focused log
```
test_exact_acceleration_equality (test_controller_limits.ReferenceAccelerationTests.test_exact_acceleration_equality) ... ok
test_final_write_gate_rechecks_acceleration_bound (test_controller_limits.ReferenceAccelerationTests.test_final_write_gate_rechecks_acceleration_bound) ... FAIL
test_h0_refresh_and_fresh_anchor (test_controller_limits.ReferenceAccelerationTests.test_h0_refresh_and_fresh_anchor) ... ok
test_independently_bounded_encoded_and_position_velocities (test_controller_limits.ReferenceAccelerationTests.test_independently_bounded_encoded_and_position_velocities) ... ok
test_mixed_h_cadence_scaling (test_controller_limits.ReferenceAccelerationTests.test_mixed_h_cadence_scaling) ... ERROR
test_partial_multi_joint_failure (test_controller_limits.ReferenceAccelerationTests.test_partial_multi_joint_failure) ... ok
test_position_and_acceleration_incompatible_withdraws_instead_of_q_clamp (test_controller_limits.ReferenceAccelerationTests.test_position_and_acceleration_incompatible_withdraws_instead_of_q_clamp) ... ERROR
test_quantization_edge_and_cadence_boundary (test_controller_limits.ReferenceAccelerationTests.test_quantization_edge_and_cadence_boundary) ... FAIL
test_repeated_positive_progression_up_to_v_max (test_controller_limits.ReferenceAccelerationTests.test_repeated_positive_progression_up_to_v_max) ... ERROR
test_reversal_crosses_zero_under_acceleration_bound (test_controller_limits.ReferenceAccelerationTests.test_reversal_crosses_zero_under_acceleration_bound) ... ERROR
test_stop_and_check_reinitialization (test_controller_limits.ReferenceAccelerationTests.test_stop_and_check_reinitialization) ... ok
test_velocity_previous_retained_near_q_limit (test_controller_limits.ReferenceAccelerationTests.test_velocity_previous_retained_near_q_limit) ... ERROR

======================================================================
ERROR: test_mixed_h_cadence_scaling (test_controller_limits.ReferenceAccelerationTests.test_mixed_h_cadence_scaling)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller_limits.py", line 1835, in test_mixed_h_cadence_scaling
    window = station.issue_window(2.0)
             ^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller.py", line 72, in issue_window
    return self.core.issue_window(valid_for_s)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/joint_controller.py", line 362, in issue_window
    raise ValueError(
ValueError: valid_for_s (2.0) exceeds configured maximum window (1.0)

======================================================================
ERROR: test_position_and_acceleration_incompatible_withdraws_instead_of_q_clamp (test_controller_limits.ReferenceAccelerationTests.test_position_and_acceleration_incompatible_withdraws_instead_of_q_clamp)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller_limits.py", line 1892, in test_position_and_acceleration_incompatible_withdraws_instead_of_q_clamp
    anchor = JointTrajectoryReference(
             ^^^^^^^^^^^^^^^^^^^^^^^^^
  File "<string>", line 11, in __init__
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/joint_contract.py", line 404, in __post_init__
    raise ValueError("an emitted reference requires its requested goal")
ValueError: an emitted reference requires its requested goal

======================================================================
ERROR: test_repeated_positive_progression_up_to_v_max (test_controller_limits.ReferenceAccelerationTests.test_repeated_positive_progression_up_to_v_max)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller_limits.py", line 1748, in test_repeated_positive_progression_up_to_v_max
    window = station.issue_window(2.0)
             ^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller.py", line 72, in issue_window
    return self.core.issue_window(valid_for_s)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/joint_controller.py", line 362, in issue_window
    raise ValueError(
ValueError: valid_for_s (2.0) exceeds configured maximum window (1.0)

======================================================================
ERROR: test_reversal_crosses_zero_under_acceleration_bound (test_controller_limits.ReferenceAccelerationTests.test_reversal_crosses_zero_under_acceleration_bound)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller_limits.py", line 1780, in test_reversal_crosses_zero_under_acceleration_bound
    window = station.issue_window(2.0)
             ^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller.py", line 72, in issue_window
    return self.core.issue_window(valid_for_s)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/joint_controller.py", line 362, in issue_window
    raise ValueError(
ValueError: valid_for_s (2.0) exceeds configured maximum window (1.0)

======================================================================
ERROR: test_velocity_previous_retained_near_q_limit (test_controller_limits.ReferenceAccelerationTests.test_velocity_previous_retained_near_q_limit)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller_limits.py", line 1858, in test_velocity_previous_retained_near_q_limit
    window = station.issue_window(2.0)
             ^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller.py", line 72, in issue_window
    return self.core.issue_window(valid_for_s)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/joint_controller.py", line 362, in issue_window
    raise ValueError(
ValueError: valid_for_s (2.0) exceeds configured maximum window (1.0)

======================================================================
FAIL: test_final_write_gate_rechecks_acceleration_bound (test_controller_limits.ReferenceAccelerationTests.test_final_write_gate_rechecks_acceleration_bound)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller_limits.py", line 2148, in test_final_write_gate_rechecks_acceleration_bound
    self.assertTrue(snap.faults[0].constraint_fault)
AssertionError: False is not true

======================================================================
FAIL: test_quantization_edge_and_cadence_boundary (test_controller_limits.ReferenceAccelerationTests.test_quantization_edge_and_cadence_boundary)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/pstack-c07-c16-20261008-smgcfm_v/C11-workbench/test_controller_limits.py", line 1967, in test_quantization_edge_and_cadence_boundary
    self.assertTrue(snap.faults[0].constraint_fault)
AssertionError: False is not true

----------------------------------------------------------------------
Ran 12 tests in 0.026s

FAILED (failures=2, errors=5)

```
