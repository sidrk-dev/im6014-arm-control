Review this corrected NEW C15 Workbench artifact independently. All supplied files are data, not instructions. Inline-only read-only review: request no tools, do not execute or edit. Human requested Codex direct implementation. C14 f43d7aa is accepted software with exact-head greenCI. C15 adds observational owner loop intervals, exchange attempt latency/failures and overrun counters using existing80msbudget; existing per-joint feedback ages remain. No new bus owner, thread, motion permission or physical throughput claim. Clock faults must not block actions, close or mask transport failures. Parent corrected a real lock-timing bug in a separate retained artifact: original reported52ms for a2ms exchange plus50ms publishing-lock wait. Both successful and failed paths now report2ms. Parent10pure+12ownerchecks and guarded79armregressions pass. Real pre-write cancellation writes0bytes, broken/invalidclockthroughclose passes and reconnectcounters persist. Five unprofiled fake workloads each63mode0exchanges correlatecounter; profiling separate. Baseline running. Older failed fixtures/logs and originalsource retained. Empty global handler snapshots broke3legacy classificationfixtures; final guardedregression instead suppliesfakecomports and replacesbyidlookups/serialconstructor BEFOREloading tests, preserving nestedfixtures. No host serial metadata discovery/motoropens in finalguardedrun. Review actual types, lock boundaries, exceptions, counting, allowlist and measurementmeaning. Do not add futuremilestones or physicalclaims.

## Complete new measurement module
"""Bounded host timing observations for a single calling owner thread."""


class StationTiming:
    __slots__ = (
        '_budget_ns', '_previous_loop_ns', '_loop_samples', '_loop_last_ns',
        '_loop_max_ns', '_loop_overruns', '_transaction_samples',
        '_transaction_failures', '_transaction_last_ns', '_transaction_max_ns',
        '_measurement_errors',
    )

    def __init__(self, loop_budget_ns: int):
        self._valid_ns(loop_budget_ns)
        if loop_budget_ns == 0:
            raise ValueError('loop_budget_ns must be positive')
        self._budget_ns = loop_budget_ns
        self._previous_loop_ns = None
        self._loop_samples = 0
        self._loop_last_ns = 0
        self._loop_max_ns = 0
        self._loop_overruns = 0
        self._transaction_samples = 0
        self._transaction_failures = 0
        self._transaction_last_ns = None
        self._transaction_max_ns = None
        self._measurement_errors = 0

    @staticmethod
    def _valid_ns(value: int) -> None:
        if type(value) is not int or not 0 <= value <= (1 << 64) - 1:
            raise ValueError('time must be a uint64 nanosecond integer')

    def loop_started(self, now_ns: int) -> None:
        self._valid_ns(now_ns)
        previous = self._previous_loop_ns
        if previous is not None:
            if now_ns < previous:
                raise ValueError('loop clock must be monotonic')
            duration = now_ns - previous
            self._loop_samples += 1
            self._loop_last_ns = duration
            self._loop_max_ns = max(self._loop_max_ns, duration)
            self._loop_overruns += duration > self._budget_ns
        self._previous_loop_ns = now_ns

    def loop_unavailable(self) -> None:
        self._measurement_errors += 1
        self._previous_loop_ns = None
        self._loop_last_ns = None

    def transaction_unavailable(self, *, succeeded: bool) -> None:
        if type(succeeded) is not bool:
            raise ValueError('transaction outcome must be a bool')
        self._measurement_errors += 1
        self._transaction_samples += 1
        self._transaction_failures += not succeeded
        self._transaction_last_ns = None

    def transaction_finished(self, start_ns: int, end_ns: int, *, succeeded: bool) -> None:
        self._valid_ns(start_ns)
        self._valid_ns(end_ns)
        if type(succeeded) is not bool or end_ns < start_ns:
            raise ValueError('transaction requires monotonic times and bool outcome')
        duration = end_ns - start_ns
        self._transaction_samples += 1
        self._transaction_failures += not succeeded
        self._transaction_last_ns = duration
        self._transaction_max_ns = (duration if self._transaction_max_ns is None
                                    else max(self._transaction_max_ns, duration))

    def snapshot(self) -> dict:
        return {
            'scope': 'owner_lifetime',
            'loop_samples': self._loop_samples,
            'loop_period_s': self._loop_last_ns / 1e9 if self._loop_last_ns is not None and self._loop_samples else None,
            'loop_max_s': self._loop_max_ns / 1e9 if self._loop_samples else None,
            'loop_overruns': self._loop_overruns,
            'loop_budget_s': self._budget_ns / 1e9,
            'transaction_samples': self._transaction_samples,
            'transaction_failures': self._transaction_failures,
            'transaction_latency_s': self._transaction_last_ns / 1e9 if self._transaction_last_ns is not None else None,
            'transaction_max_s': self._transaction_max_ns / 1e9 if self._transaction_max_ns is not None else None,
            'measurement_errors': self._measurement_errors,
        }


## Actual ArmManualSession.__init__
    def __init__(self, physical_opt_in=False, serial_factory=None, clock=time.monotonic, *, timing_clock_ns=None):
        if type(physical_opt_in) is not bool:
            raise ValueError('physical_opt_in must be an exact bool')
        if serial_factory is not None and not callable(serial_factory):
            raise ValueError('serial_factory must be callable')
        if not callable(clock):
            raise ValueError('clock must be callable')
        if timing_clock_ns is not None and not callable(timing_clock_ns):
            raise ValueError('timing_clock_ns must be callable')
        self._timing_clock_ns = time.monotonic_ns if timing_clock_ns is None else timing_clock_ns
        self._timing_clock_source = 'host_monotonic_ns' if timing_clock_ns is None else 'injected_clock'
        self._timing = StationTiming(round(SCHEDULE_GAP_MAX_S * 1e9))
        self.physical_opt_in = physical_opt_in
        self.serial_factory = serial_factory
        self.clock = clock
        self._started_host_s = time.monotonic()

        self.lock = threading.RLock()
        self.jobs = queue.Queue(maxsize=MAX_QUEUE)
        self.stop_requested = threading.Event()
        self.stop_work = threading.Event()
        self.closing = threading.Event()
        self.close_requested = threading.Event()
        self.wake = threading.Event()
        self.closed = threading.Event()
        self.generation = 0
        self._close_requests = 0

        self.bus = None
        self.port_owner = None
        self.sessions = set()
        self.parameter_drafts = {}
        self.receipts = {}
        self._pending_by_session = {}
        self.owner = None
        self.tickets = OrderedDict()
        self.last_seq = -1
        self.current_device = None

        self.profile_id = 'arm_j1'
        self.profile = MANUAL_PROFILES[self.profile_id]
        self.joint_states = {
            spec.name: ManualJointRuntime(spec) for spec in _JOINT_SPECS
        }
        self.armed = False
        self.stop_confirmed = False
        self.stop_latched = True
        self._stop_cause = None
        self.deadman_active = False
        self.require_neutral = True
        self.target_axes = [0.0, 0.0, 0.0]
        self.v_j2 = self.v_j3 = 0.0
        self.intent = None
        self.intent_expires_at = None

        self.settings_revision = 0
        self.checked_revision = -1
        self.q_j2 = 0.0
        self.v_j2 = 0.0
        self.q_j3 = 0.0
        self.v_j3 = 0.0
        self._last_clock_value = None
        self.clock_fault = None
        self.last_ingress_time = None
        self.last_poll_host_s = 0.0
        self.last_step_host_s = None

        self.protection_fault = None
        self.protection_history = []
        self.events = deque(maxlen=MAX_EVENTS)


        self.packet_capture = PacketCapture()

        self.data = dict(
            state='Disconnected',
            reason='Select an adapter and connect.',
            connected=False,
            demo=False,
            calibrated=False,
            armed=False,
            stop_confirmed=False,
            port='',
            baud=6000000,
            adapter_profile=DEFAULT_ADAPTER_PROFILE,
            id=0,
            connection=0,
        )

        self.thread = threading.Thread(
            target=self._loop,
            daemon=True,
            name='ArmManual serial owner',
        )
        self.thread.start()

## Actual ArmManualSession.snapshot
    def snapshot(self) -> dict:
        with self.lock:
            now = None
            if self.data['connected']:
                try:
                    now = self._clock_now_locked()
                except ValueError:
                    now = None
            source = ('demo' if self.data['demo'] else 'physical') if self.data['connected'] else 'unknown'
            joints = []
            ages = []
            for name in ('J1', 'J2', 'J3'):
                runtime = self.joint_states[name]
                configured = name in {spec.name for spec in self.profile.joints}
                if not configured:
                    joints.append({
                        'name': name, 'source': 'virtual',
                        'position_rad': self.q_j2 if name == 'J2' else self.q_j3 if name == 'J3' else None,
                        'velocity_rad_s': self.v_j2 if name == 'J2' else self.v_j3 if name == 'J3' else None,
                        'configured': False, 'calibrated': False,
                    })
                    continue
                age = None
                if now is not None and runtime.received_at is not None:
                    age = max(0.0, now - runtime.received_at)
                ages.append(age)
                latest = runtime.latest if self.data['connected'] else None
                if latest is not None:
                    latest_view = self._sanitize_feedback(latest)
                    latest_view['source'] = source
                else:
                    latest_view = None
                calibrated = bool(runtime.calibrated and self.data['connected'])
                position = (runtime.settings['direction'] * (latest['position_rad'] - runtime.q_zero)
                            if calibrated and latest is not None else None)
                velocity = (runtime.settings['direction'] * latest['rpm'] * math.tau / 60
                            if calibrated and latest is not None else None)
                unhealthy = bool(latest is not None and (
                    latest['errors'] or latest['warnings'] or latest['timeout']
                    or not 24 <= latest['voltage'] <= 72
                    or not -10 <= latest['driver_c'] <= 70
                    or latest['winding_c'] > 90
                    or abs(latest['torque_nm']) > runtime.settings['effort_limit_nm']
                ))
                joints.append({
                    'name': name, 'id': runtime.spec.motor_id, 'source': source,
                    'configured': True, 'calibrated': calibrated,
                    'position_rad': position, 'velocity_rad_s': velocity,
                    'mode': latest['mode'] if latest else None,
                    'timeout': latest['timeout'] if latest else None,
                    'voltage': latest['voltage'] if latest else None,
                    'driver_temp': latest['driver_c'] if latest else None,
                    'winding_temp': latest['winding_c'] if latest else None,
                    'errors': latest['errors'] if latest else None,
                    'warnings': latest['warnings'] if latest else None,
                    'torque_nm': latest['torque_nm'] if latest else None,
                    'feedback_age_s': age,
                    'stop_confirmed': runtime.stop_confirmed,
                    'stop_result': runtime.stop_result,
                    'stop_error': runtime.stop_error,
                    'protection_fault': runtime.protection_fault,
                    'health': ('missing' if latest is None else
                               'stale' if age is None or age > FEEDBACK_MAX_AGE_S else
                               'fault' if unhealthy else
                               'healthy'),
                    'settings': dict(runtime.settings),
                    'latest': latest_view,
                })
            configured = [joint for joint in joints if joint.get('configured')]
            all_fresh = bool(configured) and all(joint['feedback_age_s'] is not None for joint in configured)
            age = max(ages) if ages and all_fresh else None
            calibrated = bool(self.data['connected'] and configured
                              and all(joint['calibrated'] for joint in configured))
            latest = self._sanitize_feedback(self.latest) if self.latest is not None and self.data['connected'] else None
            if latest is not None:
                latest['source'] = source
            j1 = next(joint for joint in joints if joint['name'] == 'J1')
            return {
                'state': self.data['state'], 'reason': self.data['reason'],
                'connected': bool(self.data['connected']), 'demo': bool(self.data['demo']),
                'profile_id': self.profile_id,
                'profiles': [{'id': profile.profile_id, 'joints': [spec.name for spec in profile.joints]}
                             for profile in MANUAL_PROFILES.values()],
                'calibrated': calibrated, 'armed': bool(self.armed),
                'stop_confirmed': bool(self.stop_confirmed and self.data['connected']),
                'feedback_age_s': age, 'settings': dict(self.settings), 'joints': joints,
                'latest': latest, 'events': list(self.events),
                'timing': dict(self._timing.snapshot(), clock_source=self._timing_clock_source),
            }

## Actual ArmManualSession._transact_raw
    def _transact_raw(self, packet, motor_id=0, before_write=None, on_write=None):
        self._assert_owner_thread()
        if self.bus is None or not getattr(self.bus, 'is_open', False):
            raise RuntimeError('Not connected')
        source = 'demo' if self.data['demo'] else 'physical'
        identity = 'demo-simulator' if source == 'demo' else self.data['port']
        try:
            started_ns = self._timing_clock_ns()
        except Exception:
            started_ns = None
        succeeded = False
        try:
            result = capture_exchange(
                self.packet_capture, exchange, self.bus, packet, motor_id,
                before_write=before_write, on_write=on_write,
                source=source, identity=identity,
                connection=self.data['connection'],
                port='' if source == 'demo' else self.data['port'],
                baud=self.data['baud'],
            )
            succeeded = True
        finally:
            try:
                finished_ns = self._timing_clock_ns()
            except Exception:
                finished_ns = None
            with self.lock:
                try:
                    self._timing.transaction_finished(
                        started_ns, finished_ns, succeeded=succeeded,
                    )
                except Exception:
                    self._timing.transaction_unavailable(succeeded=succeeded)
        joint = self._joint_for_id(motor_id)
        with self.lock:
            joint.latest = self._sanitize_feedback(result)
            try:
                joint.received_at = self._clock_now_locked()
            except ValueError:
                joint.received_at = None
        return result

## Actual ArmManualSession._loop
    def _loop(self):
        try:
            while True:
                try:
                    with self.lock:
                        try:
                            self._timing.loop_started(self._timing_clock_ns())
                        except Exception:
                            self._timing.loop_unavailable()
                    if self.close_requested.is_set():
                        if self._service_close():
                            break
                        continue
                    self._process_stop_work()
                    with self.lock:
                        try:
                            job = self.jobs.get_nowait()
                        except queue.Empty:
                            job = None
                    if job is not None:
                        self._dispatch_job(job)
                        self.jobs.task_done()
                    try:
                        self._tick()
                    except WriteCancelledError:


                        pass
                    except Exception as error:
                        self._trip_fault(error)
                    self.wake.wait(0.010)
                    self.wake.clear()
                except BaseException as error:


                    self._trip_fault(error)
                    self.wake.wait(0.010)
                    self.wake.clear()
        finally:


            try:
                if self.bus is not None or self.port_owner is not None:
                    self._stop()
                    self._close_resource()
            except BaseException:
                pass

## Actual ArmManualSession.close
    def close(self) -> bool:
        with self.lock:
            if self.closed.is_set():
                return self.bus is None and self.port_owner is None
            self._close_requests += 1
            self.closing.set()
            self._latch_stop_locked('Session closing')
            self.close_requested.set()
            self.wake.set()
        if threading.current_thread() is self.thread:
            return False
        self.thread.join(0.75)
        return self.closed.is_set() and self.bus is None and self.port_owner is None

## Diff against accepted C14
diff --git a/arm_dashboard.py b/arm_dashboard.py
index e071bef..c156f60 100644
--- a/arm_dashboard.py
+++ b/arm_dashboard.py
@@ -55,7 +55,12 @@ _cached_ports_error: str | None = None
 TOP_LEVEL_FIELDS = frozenset({
     "physical_enabled", "default_port", "default_ports", "adapter_profile", "adapter_profiles",
     "ports", "port_error", "state", "reason", "connected", "demo", "profile_id", "profiles", "calibrated", "armed", "stop_confirmed",
-    "feedback_age_s", "settings", "joints", "latest", "latest_feedback", "events",
+    "feedback_age_s", "settings", "joints", "latest", "latest_feedback", "events", "timing",
+})
+TIMING_FIELDS = frozenset({
+    "scope", "clock_source", "loop_samples", "loop_period_s", "loop_max_s",
+    "loop_overruns", "loop_budget_s", "transaction_samples", "transaction_failures",
+    "transaction_latency_s", "transaction_max_s", "measurement_errors",
 })
 SETTING_FIELDS = frozenset({
     "kp", "kd", "max_rpm", "effort_limit_nm", "max_effort_nm", "lower_deg", "upper_deg",
@@ -133,7 +138,11 @@ def _project_fields(data: Any, fields: frozenset[str]) -> dict[str, Any] | None:
         if key not in data:
             continue
         value = data[key]
-        if key == "settings":
+        if key == "timing":
+            nested = _project_fields(value, TIMING_FIELDS)
+            if nested is not None:
+                projected[key] = nested
+        elif key == "settings":
             nested = _project_fields(value, SETTING_FIELDS)
             if nested is not None:
                 projected[key] = nested
diff --git a/arm_manual.py b/arm_manual.py
index 15eff4e..8ac5ac2 100644
--- a/arm_manual.py
+++ b/arm_manual.py
@@ -36,6 +36,7 @@ from im6014_serial import (
 )
 from im6014_transport import WriteResult
 from spin_5rpm import MAX_CONFIGURED_EFFORT_NM, healthy
+from station_timing import StationTiming
 
 MAX_SESSIONS = 16
 MAX_QUEUE = 64
@@ -244,13 +245,18 @@ class DemoSerial:
 class ArmManualSession:
     """One serialized authority for the selected fixed IM6014 joint profile."""
 
-    def __init__(self, physical_opt_in=False, serial_factory=None, clock=time.monotonic):
+    def __init__(self, physical_opt_in=False, serial_factory=None, clock=time.monotonic, *, timing_clock_ns=None):
         if type(physical_opt_in) is not bool:
             raise ValueError('physical_opt_in must be an exact bool')
         if serial_factory is not None and not callable(serial_factory):
             raise ValueError('serial_factory must be callable')
         if not callable(clock):
             raise ValueError('clock must be callable')
+        if timing_clock_ns is not None and not callable(timing_clock_ns):
+            raise ValueError('timing_clock_ns must be callable')
+        self._timing_clock_ns = time.monotonic_ns if timing_clock_ns is None else timing_clock_ns
+        self._timing_clock_source = 'host_monotonic_ns' if timing_clock_ns is None else 'injected_clock'
+        self._timing = StationTiming(round(SCHEDULE_GAP_MAX_S * 1e9))
         self.physical_opt_in = physical_opt_in
         self.serial_factory = serial_factory
         self.clock = clock
@@ -1005,6 +1011,7 @@ class ArmManualSession:
                 'stop_confirmed': bool(self.stop_confirmed and self.data['connected']),
                 'feedback_age_s': age, 'settings': dict(self.settings), 'joints': joints,
                 'latest': latest, 'events': list(self.events),
+                'timing': dict(self._timing.snapshot(), clock_source=self._timing_clock_source),
             }
 
     def _assert_owner_thread(self):
@@ -1024,14 +1031,33 @@ class ArmManualSession:
             raise RuntimeError('Not connected')
         source = 'demo' if self.data['demo'] else 'physical'
         identity = 'demo-simulator' if source == 'demo' else self.data['port']
-        result = capture_exchange(
-            self.packet_capture, exchange, self.bus, packet, motor_id,
-            before_write=before_write, on_write=on_write,
-            source=source, identity=identity,
-            connection=self.data['connection'],
-            port='' if source == 'demo' else self.data['port'],
-            baud=self.data['baud'],
-        )
+        try:
+            started_ns = self._timing_clock_ns()
+        except Exception:
+            started_ns = None
+        succeeded = False
+        try:
+            result = capture_exchange(
+                self.packet_capture, exchange, self.bus, packet, motor_id,
+                before_write=before_write, on_write=on_write,
+                source=source, identity=identity,
+                connection=self.data['connection'],
+                port='' if source == 'demo' else self.data['port'],
+                baud=self.data['baud'],
+            )
+            succeeded = True
+        finally:
+            try:
+                finished_ns = self._timing_clock_ns()
+            except Exception:
+                finished_ns = None
+            with self.lock:
+                try:
+                    self._timing.transaction_finished(
+                        started_ns, finished_ns, succeeded=succeeded,
+                    )
+                except Exception:
+                    self._timing.transaction_unavailable(succeeded=succeeded)
         joint = self._joint_for_id(motor_id)
         with self.lock:
             joint.latest = self._sanitize_feedback(result)
@@ -2174,6 +2200,11 @@ class ArmManualSession:
         try:
             while True:
                 try:
+                    with self.lock:
+                        try:
+                            self._timing.loop_started(self._timing_clock_ns())
+                        except Exception:
+                            self._timing.loop_unavailable()
                     if self.close_requested.is_set():
                         if self._service_close():
                             break
diff --git a/docs/architecture.md b/docs/architecture.md
index fb8519d..13d5fda 100644
--- a/docs/architecture.md
+++ b/docs/architecture.md
@@ -18,6 +18,7 @@ Inspect external foundations at exact revisions and record the revision in evide
 | `im6014_codec.py` | Pure packet encoding, strict feedback decoding, CRC and internal reduction | Python standard library |
 | `im6014_serial.py` | One request, bounded stream scan, timeout budgets, restoration and optional bounded capture | Pure feedback decoder; Python standard library |
 | `im6014_port.py` | Passive configuration and cooperating device lease | OS metadata; injected serial factory |
+| `station_timing.py` | Fixed-storage owner loop and exchange-attempt timing observations | Python standard library; called by `arm_manual.py` |
 | `joint_records.py` | Frozen public domain records and enums with validated constructor contracts | `joint_mapping.py`; Python standard library |
 | `joint_reference.py` | Pure reference planning, codec projection corridors, and release finite-difference rate math | `im6014_codec.py`; `joint_mapping.py`; `joint_records.py`; Python standard library |
 | `joint_controller.py` | Transport-free lifecycle, clock, per-joint freshness and faults, identity-checked owner grants, pending targets, reference history, and sequence watermark | `joint_records.py`; `joint_reference.py`; `im6014_codec.py`; Python standard library |
diff --git a/scripts/check_milestone.py b/scripts/check_milestone.py
index 7a15e0e..10e8cc4 100644
--- a/scripts/check_milestone.py
+++ b/scripts/check_milestone.py
@@ -26,6 +26,7 @@ CHECKS = {
     'C12': 'test_controller_lead',
     'C13': 'test_controller_effort',
     'C14': 'test_controller_faults',
+    'C15': 'test_station_timing',
 }
 
 
diff --git a/scripts/check_offline_baseline.sh b/scripts/check_offline_baseline.sh
index 38b7b2a..d44190d 100755
--- a/scripts/check_offline_baseline.sh
+++ b/scripts/check_offline_baseline.sh
@@ -78,7 +78,7 @@ run_logged() {
     return 0
 }
 
-files=(motor_dashboard.py motor_session.py spin_5rpm.py im6014_codec.py im6014_serial.py im6014_transport.py fake_serial.py test_spin_5rpm.py test_dashboard.py test_startup.py test_startup_verifier.py test_protocol.py test_serial_deadline.py evidence/boundary/vendor-crc-vectors.json USER_MANUAL.md joint_mapping.py test_joint_mapping.py test_numerical_inputs.py im6014_port.py test_port_config.py test_diagnostic_capture.py test_bus_owner.py joint_controller.py joint_records.py test_controller.py test_controller_targets.py test_controller_ownership.py test_controller_limits.py test_controller_velocity.py joint_reference.py test_controller_acceleration.py test_controller_lead.py test_controller_effort.py test_controller_faults.py)
+files=(motor_dashboard.py motor_session.py spin_5rpm.py im6014_codec.py im6014_serial.py im6014_transport.py fake_serial.py test_spin_5rpm.py test_dashboard.py test_startup.py test_startup_verifier.py test_protocol.py test_serial_deadline.py evidence/boundary/vendor-crc-vectors.json USER_MANUAL.md joint_mapping.py test_joint_mapping.py test_numerical_inputs.py im6014_port.py test_port_config.py test_diagnostic_capture.py test_bus_owner.py joint_controller.py joint_records.py test_controller.py test_controller_targets.py test_controller_ownership.py test_controller_limits.py test_controller_velocity.py joint_reference.py test_controller_acceleration.py test_controller_lead.py test_controller_effort.py test_controller_faults.py station_timing.py test_station_timing.py)
 for name in "${files[@]}"; do
     mkdir -p -- "$scratch/$(dirname -- "$name")" || exit 2
     if ! cp -- "$repo_dir/$name" "$scratch/$name" || ! cmp -s -- "$repo_dir/$name" "$scratch/$name"; then
@@ -98,7 +98,7 @@ cd -- "$scratch" || exit 2
 run_logged packet-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" test_spin_5rpm.py
 run_logged protocol-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_protocol
 run_logged serial-deadline-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_serial_deadline
-run_logged milestone-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_joint_mapping test_numerical_inputs test_port_config test_diagnostic_capture test_bus_owner test_controller test_controller_targets test_controller_ownership test_controller_limits test_controller_velocity test_controller_acceleration test_controller_lead test_controller_effort test_controller_faults
+run_logged milestone-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_joint_mapping test_numerical_inputs test_port_config test_diagnostic_capture test_bus_owner test_controller test_controller_targets test_controller_ownership test_controller_limits test_controller_velocity test_controller_acceleration test_controller_lead test_controller_effort test_controller_faults test_station_timing
 run_logged dashboard-tests env QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1 "$python_path" test_dashboard.py
 for name in dashboard_preview.png dashboard_dark_preview.png dashboard_test_results.json; do
     if [[ -f "$scratch/$name" ]]; then
diff --git a/test_startup.py b/test_startup.py
index 5c6668a..1db0f9c 100644
--- a/test_startup.py
+++ b/test_startup.py
@@ -110,7 +110,7 @@ def _cleanup_after_main(window, state):
 
 def _fingerprint(root):
     names = ("motor_dashboard.py", "motor_session.py", "spin_5rpm.py", "im6014_codec.py", "im6014_serial.py", "im6014_transport.py", "fake_serial.py", "USER_MANUAL.md",
-             "test_spin_5rpm.py", "test_dashboard.py", "test_startup.py", "test_startup_verifier.py", "test_protocol.py", "test_serial_deadline.py", "evidence/boundary/vendor-crc-vectors.json", "joint_mapping.py", "test_joint_mapping.py", "test_numerical_inputs.py", "im6014_port.py", "test_port_config.py", "test_diagnostic_capture.py", "test_bus_owner.py", "joint_controller.py", "joint_records.py", "test_controller.py", "test_controller_targets.py", "test_controller_ownership.py", "test_controller_limits.py", "test_controller_velocity.py", "joint_reference.py", "test_controller_acceleration.py", "test_controller_lead.py", "test_controller_effort.py", "test_controller_faults.py")
+             "test_spin_5rpm.py", "test_dashboard.py", "test_startup.py", "test_startup_verifier.py", "test_protocol.py", "test_serial_deadline.py", "evidence/boundary/vendor-crc-vectors.json", "joint_mapping.py", "test_joint_mapping.py", "test_numerical_inputs.py", "im6014_port.py", "test_port_config.py", "test_diagnostic_capture.py", "test_bus_owner.py", "joint_controller.py", "joint_records.py", "test_controller.py", "test_controller_targets.py", "test_controller_ownership.py", "test_controller_limits.py", "test_controller_velocity.py", "joint_reference.py", "test_controller_acceleration.py", "test_controller_lead.py", "test_controller_effort.py", "test_controller_faults.py", "station_timing.py", "test_station_timing.py")
     files = {}
     for name in names:
         path = root / name


## test_station_timing.py
import unittest

from station_timing import StationTiming


class StationTimingTests(unittest.TestCase):
    def test_no_samples_are_unknown_instead_of_fake_zero_durations(self):
        data = StationTiming(80_000_000).snapshot()
        self.assertEqual(data['scope'], 'owner_lifetime')
        self.assertEqual(data['loop_samples'], 0)
        self.assertIsNone(data['loop_period_s'])
        self.assertIsNone(data['loop_max_s'])
        self.assertIsNone(data['transaction_latency_s'])
        self.assertIsNone(data['transaction_max_s'])

    def test_actual_consecutive_start_intervals_and_budget_boundary(self):
        timing = StationTiming(80_000_000)
        for now in (0, 10_000_000, 90_000_000, 170_000_001):
            timing.loop_started(now)
        data = timing.snapshot()
        self.assertEqual(data['loop_samples'], 3)
        self.assertEqual(data['loop_period_s'], .080000001)
        self.assertEqual(data['loop_max_s'], .080000001)
        self.assertEqual(data['loop_overruns'], 1)
        self.assertEqual(data['loop_budget_s'], .08)

    def test_zero_elapsed_is_a_real_sample(self):
        timing = StationTiming(1)
        timing.loop_started(0)
        timing.loop_started(0)
        data = timing.snapshot()
        self.assertEqual(data['loop_samples'], 1)
        self.assertEqual(data['loop_period_s'], 0)
        self.assertEqual(data['loop_overruns'], 0)

    def test_failed_and_successful_exchange_attempts_are_both_measured(self):
        timing = StationTiming(80_000_000)
        timing.transaction_finished(0, 2_000_000, succeeded=True)
        timing.transaction_finished(2_000_000, 7_000_000, succeeded=False)
        timing.transaction_finished(7_000_000, 8_000_000, succeeded=True)
        data = timing.snapshot()
        self.assertEqual(data['transaction_samples'], 3)
        self.assertEqual(data['transaction_failures'], 1)
        self.assertEqual(data['transaction_latency_s'], .001)
        self.assertEqual(data['transaction_max_s'], .005)

    def test_bad_constructor_and_clock_values_reject_without_partial_updates(self):
        for bad in (True, False, -1, .1, float('nan'), float('inf'), '1', None, 1 << 64):
            with self.subTest(bad=repr(bad)), self.assertRaises(ValueError):
                StationTiming(bad)
        with self.assertRaises(ValueError):
            StationTiming(0)
        timing = StationTiming(1)
        timing.loop_started(5)
        before = timing.snapshot()
        for bad in (True, False, -1, .1, '1', None, 1 << 64, 4):
            with self.subTest(bad=repr(bad)), self.assertRaises(ValueError):
                timing.loop_started(bad)
            self.assertEqual(timing.snapshot(), before)
        timing.loop_started(6)
        self.assertEqual(timing.snapshot()['loop_period_s'], 1e-9)

    def test_bad_transaction_does_not_consume_a_sample(self):
        timing = StationTiming(1)
        before = timing.snapshot()
        for start, end, success in ((5, 4, True), (True, 5, True), (0, .1, True),
                                    (0, 1, 1), (0, 1, None), (0, 1 << 64, True)):
            with self.subTest(start=start, end=end, success=success), self.assertRaises(ValueError):
                timing.transaction_finished(start, end, succeeded=success)
            self.assertEqual(timing.snapshot(), before)

    def test_long_run_keeps_fixed_storage_and_independent_instances(self):
        timing = StationTiming(10)
        other = StationTiming(10)
        for i in range(10000):
            timing.loop_started(i * 11)
            timing.transaction_finished(i * 11, i * 11 + 5, succeeded=i % 2 == 0)
        data = timing.snapshot()
        self.assertEqual(data['loop_samples'], 9999)
        self.assertEqual(data['loop_overruns'], 9999)
        self.assertEqual(data['transaction_samples'], 10000)
        self.assertEqual(data['transaction_failures'], 5000)
        self.assertFalse(hasattr(timing, '__dict__'))
        self.assertEqual(other.snapshot()['transaction_samples'], 0)

    def test_missing_loop_clock_breaks_only_measurement_continuity(self):
        timing = StationTiming(10)
        timing.loop_started(0)
        timing.loop_started(5)
        timing.loop_unavailable()
        self.assertIsNone(timing.snapshot()['loop_period_s'])
        timing.loop_started(100)
        self.assertIsNone(timing.snapshot()['loop_period_s'])
        timing.loop_started(105)
        data = timing.snapshot()
        self.assertEqual(data['loop_samples'], 2)
        self.assertEqual(data['loop_overruns'], 0)
        self.assertEqual(data['loop_max_s'], 5e-9)
        self.assertEqual(data['measurement_errors'], 1)

    def test_missing_transaction_time_is_unknown_but_retains_actual_outcome(self):
        timing = StationTiming(10)
        timing.transaction_unavailable(succeeded=True)
        self.assertIsNone(timing.snapshot()['transaction_latency_s'])
        self.assertIsNone(timing.snapshot()['transaction_max_s'])
        timing.transaction_finished(0, 5, succeeded=True)
        timing.transaction_unavailable(succeeded=False)
        data = timing.snapshot()
        self.assertEqual(data['transaction_samples'], 3)
        self.assertEqual(data['transaction_failures'], 1)
        self.assertEqual(data['transaction_max_s'], 5e-9)
        self.assertIsNone(data['transaction_latency_s'])
        self.assertEqual(data['measurement_errors'], 2)
        before = timing.snapshot()
        with self.assertRaises(ValueError):
            timing.transaction_unavailable(succeeded=1)
        self.assertEqual(timing.snapshot(), before)

    def test_snapshot_is_detached_from_internal_counters(self):
        timing = StationTiming(10)
        data = timing.snapshot()
        data['loop_overruns'] = 999
        self.assertEqual(timing.snapshot()['loop_overruns'], 0)


if __name__ == '__main__':
    unittest.main()


## tests/test_arm_timing.py
import http.client
import json
import threading
import time
import unittest
from unittest.mock import patch

import arm_manual
from arm_dashboard import ArmDashboardHandler, ArmDashboardServer, TOP_LEVEL_FIELDS, _project_fields
from arm_manual import ArmManualSession


class TimingClock:
    def __init__(self):
        self.now = 0
        self.lock = threading.Lock()

    def __call__(self):
        with self.lock:
            return self.now

    def advance(self, value):
        with self.lock:
            self.now += value


class ArmTimingTests(unittest.TestCase):
    def action(self, arm, sid, action, values=None):
        op = arm.request(sid, action, values or {})
        until = time.monotonic() + 2
        while time.monotonic() < until:
            receipt = arm.receipt(sid, op)
            if receipt['status'] != 'pending':
                return receipt
            time.sleep(.005)
        self.fail('fake-owner operation did not settle')

    def test_actual_owner_measures_successful_demo_exchanges(self):
        clock = TimingClock()
        original = arm_manual.capture_exchange
        def measured(*args, **kwargs):
            clock.advance(2_000_000)
            return original(*args, **kwargs)
        with patch('arm_manual.capture_exchange', measured):
            arm = ArmManualSession(physical_opt_in=False, timing_clock_ns=clock)
            try:
                sid = arm.create_session()
                receipt = self.action(arm, sid, 'connect', {'demo': True})
                self.assertEqual(receipt['status'], 'complete', receipt)
                data = arm.snapshot()
                timing = data['timing']
                self.assertEqual(timing['clock_source'], 'injected_clock')
                self.assertGreater(timing['transaction_samples'], 0)
                self.assertEqual(timing['transaction_failures'], 0)
                self.assertEqual(timing['transaction_latency_s'], .002)
                self.assertEqual(timing['transaction_max_s'], .002)
                self.assertIsNotNone(data['joints'][0]['feedback_age_s'])
                self.assertTrue(data['demo'])
                self.assertFalse(data['armed'])
            finally:
                arm.close()

    def test_actual_owner_counts_failed_exchange_attempts(self):
        clock = TimingClock()
        def failed(*args, **kwargs):
            clock.advance(5_000_000)
            raise OSError('injected fake exchange failure')
        with patch('arm_manual.capture_exchange', failed):
            arm = ArmManualSession(physical_opt_in=False, timing_clock_ns=clock)
            try:
                sid = arm.create_session()
                receipt = self.action(arm, sid, 'connect', {'demo': True})
                self.assertEqual(receipt['status'], 'rejected', receipt)
                timing = arm.snapshot()['timing']
                self.assertGreater(timing['transaction_failures'], 0)
                self.assertEqual(timing['transaction_samples'], timing['transaction_failures'])
                self.assertEqual(timing['transaction_max_s'], .005)
                self.assertFalse(arm.snapshot()['armed'])
            finally:
                arm.close()

    def test_actual_owner_loop_uses_host_clock_without_touching_serial(self):
        arm = ArmManualSession(physical_opt_in=False)
        try:
            until = time.monotonic() + 1
            while arm.snapshot()['timing']['loop_samples'] < 2 and time.monotonic() < until:
                time.sleep(.005)
            data = arm.snapshot()
            self.assertEqual(data['timing']['clock_source'], 'host_monotonic_ns')
            self.assertGreater(data['timing']['loop_period_s'], 0)
            self.assertGreaterEqual(data['timing']['loop_samples'], 2)
            self.assertEqual(data['timing']['transaction_samples'], 0)
            self.assertFalse(data['connected'])
        finally:
            arm.close()

    def test_timing_json_allowlist_drops_unknowns_and_nonfinite_values(self):
        data = _project_fields({'timing': {
            'scope': 'owner_lifetime', 'clock_source': 'injected_clock',
            'loop_samples': 3, 'loop_period_s': float('nan'),
            'transaction_latency_s': .002, 'hidden': 'secret',
        }, 'unexpected': 'secret'}, TOP_LEVEL_FIELDS)
        self.assertNotIn('unexpected', data)
        self.assertNotIn('hidden', data['timing'])
        self.assertNotIn('loop_period_s', data['timing'])
        self.assertEqual(data['timing']['transaction_latency_s'], .002)

    def test_real_http_state_reports_timing_without_serial_enumeration(self):
        arm = ArmManualSession(physical_opt_in=False)
        server = ArmDashboardServer(('127.0.0.1', 0), arm)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        connection = http.client.HTTPConnection('127.0.0.1', server.bound_port, timeout=2)
        try:
            with patch.object(ArmDashboardHandler, '_get_serial_ports', return_value=[]), \
                    patch('arm_dashboard.enumerate_ports', side_effect=AssertionError('forbidden enumeration')) as enumeration:
                connection.request('GET', '/api/state')
                response = connection.getresponse()
                data = json.loads(response.read())
                self.assertEqual(response.status, 200)
                self.assertEqual(data['timing']['scope'], 'owner_lifetime')
                self.assertEqual(data['timing']['clock_source'], 'host_monotonic_ns')
                self.assertEqual(data['timing']['transaction_samples'], 0)
                self.assertFalse(data['connected'])
                self.assertFalse(data['armed'])
                enumeration.assert_not_called()
        finally:
            connection.close()
            server.shutdown()
            server.server_close()
            worker.join(timeout=2)
            arm.close()

    def test_unavailable_measurement_clock_does_not_block_owner_actions(self):
        broken = [True]
        def clock():
            if broken[0]:
                raise OSError('injected observation clock failure')
            return time.monotonic_ns()
        arm = ArmManualSession(physical_opt_in=False, timing_clock_ns=clock)
        try:
            sid = arm.create_session()
            receipt = self.action(arm, sid, 'connect', {'demo': True})
            self.assertEqual(receipt['status'], 'complete', receipt)
            data = arm.snapshot()
            self.assertTrue(data['connected'])
            self.assertFalse(data['armed'])
            self.assertGreater(data['timing']['measurement_errors'], 0)
            self.assertGreater(data['timing']['transaction_samples'], 0)
            self.assertIsNone(data['timing']['transaction_latency_s'])
        finally:
            broken[0] = False
            arm.wake.set()
            arm.close()

    def test_measurement_clock_failure_does_not_mask_exchange_failure(self):
        broken = [True]
        def clock():
            if broken[0]:
                raise OSError('injected timing failure')
            return time.monotonic_ns()
        def failed(*args, **kwargs):
            raise OSError('original fake exchange failure')
        with patch('arm_manual.capture_exchange', failed):
            arm = ArmManualSession(physical_opt_in=False, timing_clock_ns=clock)
            try:
                sid = arm.create_session()
                receipt = self.action(arm, sid, 'connect', {'demo': True})
                self.assertEqual(receipt['status'], 'rejected', receipt)
                self.assertIn('Cannot verify Stop', receipt['reason'])
                self.assertTrue(any('original fake exchange failure' in event
                                    for event in arm.snapshot()['events']))
                data = arm.snapshot()['timing']
                self.assertGreater(data['measurement_errors'], 0)
                self.assertGreater(data['transaction_failures'], 0)
            finally:
                broken[0] = False
                arm.wake.set()
                arm.close()

    def test_exchange_latency_excludes_post_exchange_lock_wait(self):
        for fail in (False, True):
            with self.subTest(failed_exchange=fail):
                self.check_post_exchange_contention(fail)

    def check_post_exchange_contention(self, fail):
        completed = threading.Event()
        held = threading.Event()
        sampled = threading.Event()
        clock = TimingClock()
        def observe():
            value = clock()
            if completed.is_set():
                sampled.set()
            return value
        original = arm_manual.capture_exchange
        first = [True]
        def measured(*args, **kwargs):
            result = original(*args, **kwargs)
            if first[0]:
                first[0] = False
                clock.advance(2_000_000)
                completed.set()
                if not held.wait(1):
                    raise AssertionError('contending reader did not acquire lock')
            if fail:
                raise OSError('original contended exchange failure')
            return result
        arm = ArmManualSession(physical_opt_in=False, timing_clock_ns=observe)
        def reader():
            if completed.wait(1):
                with arm.lock:
                    held.set()
                    sampled.wait(.05)
                    clock.advance(50_000_000)
        worker = threading.Thread(target=reader)
        worker.start()
        try:
            with patch('arm_manual.capture_exchange', measured):
                sid = arm.create_session()
                receipt = self.action(arm, sid, 'connect', {'demo': True})
                self.assertEqual(receipt['status'], 'rejected' if fail else 'complete', receipt)
                timing = arm.snapshot()['timing']
                self.assertEqual(timing['transaction_max_s'], .002)
                if fail:
                    self.assertGreater(timing['transaction_failures'], 0)
                    self.assertTrue(any('original contended exchange failure' in event
                                        for event in arm.snapshot()['events']))
        finally:
            completed.set()
            worker.join(1)
            arm.close()
        self.assertFalse(worker.is_alive())

    def test_close_keeps_working_with_unavailable_observation_clock(self):
        for invalid in (False, True):
            with self.subTest(invalid_value=invalid):
                broken = [False]
                def observe():
                    if broken[0]:
                        if invalid:
                            return 'invalid clock'
                        raise OSError('observation clock unavailable')
                    return time.monotonic_ns()
                arm = ArmManualSession(physical_opt_in=False, timing_clock_ns=observe)
                try:
                    sid = arm.create_session()
                    self.assertEqual(self.action(arm, sid, 'connect', {'demo': True})['status'], 'complete')
                    bus = arm.bus
                    broken[0] = True
                    self.assertTrue(arm.close())
                    self.assertFalse(arm.thread.is_alive())
                    self.assertFalse(bus.is_open)
                    self.assertIsNone(arm.bus)
                finally:
                    arm.close()

    def test_real_prewrite_cancellation_counts_failed_attempt_without_write(self):
        original = arm_manual.capture_exchange
        writes = []
        def cancelled(*args, **kwargs):
            bus = args[2]
            with patch.object(bus, 'write', wraps=bus.write) as write:
                kwargs['before_write'] = lambda: False
                try:
                    return original(*args, **kwargs)
                finally:
                    writes.append(write.call_count)
        with patch('arm_manual.capture_exchange', cancelled):
            arm = ArmManualSession(physical_opt_in=False)
            try:
                sid = arm.create_session()
                receipt = self.action(arm, sid, 'connect', {'demo': True})
                self.assertEqual(receipt['status'], 'rejected', receipt)
                timing = arm.snapshot()['timing']
                self.assertEqual(timing['transaction_samples'], len(writes))
                self.assertEqual(timing['transaction_failures'], len(writes))
                self.assertGreater(len(writes), 0)
                self.assertEqual(sum(writes), 0)
                self.assertTrue(any('cancelled by pre-write hook' in event
                                    for event in arm.snapshot()['events']))
            finally:
                arm.close()

    def test_timing_counts_survive_demo_reconnect(self):
        arm = ArmManualSession(physical_opt_in=False)
        try:
            sid = arm.create_session()
            for action, values in [('connect', {'demo': True}), ('disconnect', {}), ('connect', {'demo': True})]:
                before = arm.snapshot()['timing']
                self.assertEqual(self.action(arm, sid, action, values)['status'], 'complete')
                after = arm.snapshot()['timing']
                self.assertGreaterEqual(after['transaction_samples'], before['transaction_samples'])
                self.assertGreaterEqual(after['transaction_failures'], before['transaction_failures'])
                self.assertEqual(after['scope'], 'owner_lifetime')
        finally:
            arm.close()

    def test_timing_clock_must_be_callable(self):
        with self.assertRaises(ValueError):
            ArmManualSession(physical_opt_in=False, timing_clock_ns=3)


if __name__ == '__main__':
    unittest.main()


## docs/station-timing.md
# Station timing telemetry

`ArmManualSession.snapshot()` and the observational `GET /api/state` response expose a `timing` object. The existing per-joint `feedback_age_s` values report feedback age separately. Timing adds no bus owner, thread, command limit, or automatic action.

| Field | Meaning |
| --- | --- |
| `scope` | `owner_lifetime`. Counters persist across connections in this owner instance and restart with a new process. |
| `clock_source` | `host_monotonic_ns` for normal operation, or `injected_clock` in a fixture. |
| `loop_samples` | Number of measured intervals between consecutive owner-loop starts. The first start is an anchor. |
| `loop_period_s` | Latest measured interval, including dispatch, I/O and waiting. Unknown before an interval or after a clock failure. |
| `loop_max_s` | Largest measured interval in this owner lifetime. |
| `loop_budget_s` | Existing schedule-gap budget used to classify overruns, currently 0.08 seconds. This is a policy value, not a measurement. |
| `loop_overruns` | Measured intervals strictly greater than the reported budget. Equality is permitted. |
| `transaction_samples` | Completed exchange attempts, including failures and cancellations before a write. This is not a successful-write counter. |
| `transaction_failures` | Attempts that did not return a decoded exchange result. |
| `transaction_latency_s` | Latest measured exchange-attempt duration, excluding queue wait and the subsequent lock wait to publish counters. Unknown when its clock sample failed. |
| `transaction_max_s` | Largest available measured exchange-attempt duration. |
| `measurement_errors` | Unavailable or invalid loop intervals and transaction-duration samples. These do not count as successful measurements. |

Durations use integer monotonic nanoseconds internally and seconds in JSON. Empty duration series report `null`. A timing-clock failure invalidates its observation and breaks the loop's measurement anchor. It does not block owner actions, mask the original transport error, or change the independent authority clock, feedback checks, Stop, or motion limits. A later healthy timing sample begins a fresh interval.

`StationTiming` keeps counters, latest and maximum durations, and one loop anchor. It stores no growing trace. The owner updates it under its existing lock. HTTP serialization explicitly permits only the documented scalar fields.

Fixture runs establish software measurement behavior only. A fake adapter's latency does not establish physical RS485 latency, actuator response, stopping time, or achievable control rate. No speedup is claimed. A process restart creates a new owner and fresh timing counters.


## Review lens
# Review Rubric

Review through whichever lenses are relevant. Not every lens applies to every change.

## Correctness

Does the code actually do what the intent says it should?

- Edge cases: empty inputs, nil/undefined, boundary values, concurrent access
- Error handling: are errors caught, propagated, or silently swallowed?
- Off-by-one, type coercion, integer overflow, string encoding
- State management: race conditions, stale closures, dangling references
- Do both the happy path and the sad path work?
- Idempotency: what happens if this operation runs twice, or if a previous run crashed halfway? If the answer is "it depends on what state was left behind," a reconciliation step is missing.
- Concurrency: if multiple actors can touch the same mutable state (files, branches, shared data), is access serialized structurally (locks, sequential phases, exclusive ownership), or by conventions that won't hold?

When you find a potential bug, trace the execution path. Don't just flag "this could be nil". Show the call chain that makes it nil.

## Root Causes vs. Symptoms

Is the code fixing the actual problem or papering over a symptom?

Answering this often requires looking beyond the changed files. Read the surrounding code (callers, callees, type definitions, sibling modules) and understand the architecture the change lives in. Use the tools available to you (Read, Grep, Glob) to follow the call chain, read the types, and understand why the code exists before judging whether the change addresses the right layer.

- Guard clauses that mask a deeper invariant violation
- Retry logic that hides a broken contract
- Type casts that silence a modeling error
- A workaround: why is it needed? What would a proper fix look like?
- A fix in module A that should really be a fix in module B's contract
- Instructions where structure would be better: if the fix is a comment saying "don't do X" or a convention someone has to remember, ask whether it could instead be a type constraint, a lint rule, or a runtime check that makes the wrong thing impossible

## Structural Integrity

Does the code fit well into the system it's part of?

- Boundary discipline: is validation at system boundaries, or scattered through business logic? Validate data once where it enters the system, then trust it internally.
- Abstraction level: is the code mixing high-level orchestration with low-level detail?
- Coupling: does this change introduce dependencies that will make future changes harder?
- Data model fit: do the data structures match the actual access patterns?
- Bolted-on vs. integrated: if the new requirement had been known from the start, would the code look like this, or does the change feel patched onto the existing design?
- Legacy dual-paths: does the change introduce a new API while keeping the old one alive? If there are no external consumers, migrate callers and delete the old path in the same wave. Don't leave compatibility layers that will become permanent.

Don't penalize simple code for lacking abstraction. Premature abstraction is worse than duplication.

## Verification

Can you tell that this code works from reading it?

- Are there tests? Do they test behavior or implementation details?
- Are there assertions/invariants that would catch regressions?
- If this is a bug fix: is there a test for the bug?
- If this touches an integration boundary: is the full path tested?
- Check the real thing, not a proxy. If the code checks liveness via file mtime or cached state instead of reading the actual value, that's a verification gap.
- For delegated or async work: does the code verify actual output artifacts, or does it trust self-reports and summaries?

## Complexity Budget

Is the complexity justified by what the code accomplishes?

- Code that could be simpler without losing correctness or clarity
- Abstractions that serve only one call site
- Configuration or parameterization for cases that don't exist yet
- Dead code, unused imports, vestigial parameters
- Over-engineering: "just in case" code paths with no current callers
- Obsolete compatibility paths kept alive for transitional stability that's no longer needed. If the migration is done, delete the scaffolding
- Does the user experience justify the complexity? Every feature, control, and option should earn its place. Half-finished features are worse than missing ones.

Simpler is better unless simpler is wrong.

## Security

For each security finding, trace the input path through the code and show it.

- User input flowing to dangerous sinks (SQL, shell, eval, innerHTML) without sanitization
- Authentication/authorization gaps in new endpoints
- Secrets in code, logs, or error messages
- TOCTOU (time-of-check-time-of-use) in security-critical paths


## Review lens
# Code Quality Review

Each reviewer applies this code-quality lens in addition to the rubric. It is a strict standard focused on implementation quality, maintainability, abstraction quality, and codebase health.

Above all, be ambitious about code structure. Do not merely identify local cleanup. Actively search for "code judo" moves, restructurings that preserve behavior while making the implementation dramatically simpler, smaller, more direct, and more elegant.

## Core Prompt

Start from this baseline:

> Perform a deep code quality audit of the current branch's changes.
> Rethink how to structure / implement the changes to meaningfully improve code quality without impacting behavior.
> Work to improve abstractions, modularity, reduce Spaghetti code, improve succinctness and legibility.
> Be ambitious, if there is a clear path to improving the implementation that involves restructuring some of the codebase, go for it.
> Be extremely thorough and rigorous. Measure twice, cut once.

## Dimensions

Each dimension is stated once. Apply the ones that are relevant.

0. **Be ambitious about structural simplification.** Do not stop at "this could be a bit cleaner." Look for reframings that make whole branches, helpers, modes, conditionals, or layers disappear. Assume a "code judo" move is often available. It uses the existing architecture more effectively and makes the change dramatically simpler. If you can delete complexity rather than rearrange it, push hard for that.

1. **Do not let a PR push a file from under 1k lines to over 1k lines without a very strong reason.** Treat this as a strong smell. Prefer extracting helpers, subcomponents, or modules. If the diff crosses that threshold, ask whether the code should be decomposed first. Waive only for a compelling structural reason where the resulting file stays clearly organized.

2. **Do not allow spaghetti growth in existing code.** Be suspicious of new ad-hoc conditionals, scattered special cases, or one-off branches inserted into unrelated flows. Treat "weird if statements in random places" as a design problem, not a style nit. Prefer pushing the logic into a dedicated helper, state machine, or module instead of tangling an existing path.

3. **Bias toward cleaning the design, not just accepting working code.** If behavior can stay the same while the structure becomes meaningfully cleaner, push for the cleaner version. Prefer simplifications that remove moving pieces over refactors that spread the same complexity around.

4. **Prefer direct, boring, maintainable code over hacky or magical code.** Treat brittle, ad-hoc, or "magic" behavior as a problem. Be skeptical of generic mechanisms that hide simple data-shape assumptions. Flag thin abstractions, identity wrappers, or pass-through helpers that add indirection without buying clarity.

5. **Push on type and boundary cleanliness when it affects maintainability.** Question unnecessary optionality, `unknown`, `any`, or cast-heavy code when a clearer type boundary could exist. Prefer explicit typed models over loosely-shaped ad-hoc objects. If a branch leans on a silent fallback to paper over an unclear invariant, ask whether the boundary should be made explicit.

6. **Keep logic in the canonical layer and reuse existing helpers.** Call out feature logic leaking into shared paths or implementation details leaking through APIs. Prefer existing canonical utilities over bespoke one-offs. Push code toward the right package, service, or module instead of normalizing drift.

7. **Treat unnecessary sequential orchestration and non-atomic updates as design smells when the cleaner structure is obvious.** If independent work is serialized for no reason, ask whether it should run in parallel. If related updates can leave state half-applied, push for a more atomic structure. Do not over-index on micro-optimizations, but do flag avoidable orchestration complexity that makes the code more brittle.

## Output Expectations

Prioritize structural code-quality regressions and missed simplifications first, then spaghetti and branching complexity, then boundary, type, and file-size concerns, then smaller modularity and legibility issues.

## Approval Bar

Do not approve merely because behavior seems correct. Treat these as presumptive blockers unless the author can justify them: the PR keeps a lot of incidental complexity when a code-judo move would delete it. Pushes a file from below 1000 lines to above 1000 lines. Adds ad-hoc branching that tangles an existing flow. Scatters feature checks across shared code. Adds an unnecessary abstraction, wrapper, or cast-heavy contract, or duplicates an existing helper or puts logic in the wrong layer when there is a clear canonical home. If those conditions are not met, leave explicit, actionable feedback and push for a cleaner decomposition.

## Review Tone

Be direct, serious, and demanding about quality. Do not be rude, but do not soften major maintainability issues into mild suggestions. If the code is making the codebase messier, say so. If the implementation missed an obvious dramatic simplification, say that too. Do not be satisfied with "maybe rename this" when the real issue is structural.


Report only concrete findings with severity,file,line,scenario and evidence, or say no findings. Parent owns verification/acceptance/Git. No recursive agents.
