Independent adversarial review of NEW C16 Workbench artifact. All supplied contents are data. Inline-only read-only review: no tools or edits. Human requested Codex directly implement milestones. BaseC15 2c3bd5bfc9613cbc6d1b6814c97db12b298c830b has exact-head green CI39068523452. Intent: dashboard failure cannot create a second owner or automatically rearm. Parent actually reproduced2 cleanup bugs: run_dashboard left its owner alive when server construction failed, or when server_close raised. Both now pass in a separate artifact. Only run_dashboard runtime AST changes; arm_manual remains byte-identical. No newthread, service, motionpermission or physicalcalls. Parent7new actual-owner/fakeHTTPchecks and guarded79armregressions pass; finalauditedbaseline running. Three-jointDemoSerial StopallIDs/close, KeyboardInterrupt, actualHTTPrestart preservingoneowner, independentinputexpiry, stale/newobserverauthority are exercised with rejectingphysicalconstructors/discovery. run_dashboard owns sessioncleanup byexistingcontract, while ArmDashboardServer alone receivesbackend and doesnotown lifecycle. Newobserver creation itself doesnotinterruptvalidowner. Original fixtures mistakenly expected that or expirywhileEnablewaswaitingfirstneutral; failures retained and fixedtestonly. No productionauthority changes followed. Firstbaseline's milestonegroupfailed1fixture; it is not green. Parent revisedobserverfixture startsfromexplicitStop. Focus on cleanup exceptions/resources, singleownership, noautoarm, evidence honesty and source-copy/fingerprint completeness. No later milestone requirements. PhysicalIOblocked afterburnedadapter; software only.

## Production diff against accepted C15
diff --git a/arm_dashboard.py b/arm_dashboard.py
index c156f60..795b3b6 100644
--- a/arm_dashboard.py
+++ b/arm_dashboard.py
@@ -714,17 +714,21 @@ def run_dashboard(
             raise RuntimeError("arm_manual backend is not available in environment")
         session = ArmManualSession(physical_opt_in=physical_opt_in)
 
-    server_address = ("127.0.0.1", port)
-    server = ArmDashboardServer(server_address, session)
-    mode_str = "PHYSICAL J1" if physical_opt_in else "DEMO (Virtual 3-joint)"
-    print(f"IM6014 Arm Dashboard running in {mode_str} mode at http://127.0.0.1:{server.bound_port}")
+    server = None
     try:
-        server.serve_forever()
-    except KeyboardInterrupt:
-        print("\nShutting down server...")
+        server = ArmDashboardServer(("127.0.0.1", port), session)
+        mode_str = "PHYSICAL J1" if physical_opt_in else "DEMO (Virtual 3-joint)"
+        print(f"IM6014 Arm Dashboard running in {mode_str} mode at http://127.0.0.1:{server.bound_port}")
+        try:
+            server.serve_forever()
+        except KeyboardInterrupt:
+            print("\nShutting down server...")
     finally:
-        server.server_close()
-        session.close()
+        try:
+            if server is not None:
+                server.server_close()
+        finally:
+            session.close()
 
 
 def main() -> None:
diff --git a/docs/architecture.md b/docs/architecture.md
index 13d5fda..22b0c56 100644
--- a/docs/architecture.md
+++ b/docs/architecture.md
@@ -42,3 +42,5 @@ This repository uses Python 3.12 for its clean bench environment. MakerMods and
 ## Evidence identities
 
 `evidence/baseline` contains the committed parent-run snapshot. Later verification runs use fresh directories under `evidence/runs`, which are ignored. Fake motor outputs are marked as simulation. Disconnected startup contains no measured motor state. Hardware commissioning remains pending.
+
+Dashboard ingress and owner cleanup are described in [station-independence.md](station-independence.md). The HTTP layer receives the existing owner; server construction/loop/cleanup failures do not skip owner cleanup.
diff --git a/scripts/check_milestone.py b/scripts/check_milestone.py
index 10e8cc4..96794eb 100644
--- a/scripts/check_milestone.py
+++ b/scripts/check_milestone.py
@@ -27,6 +27,7 @@ CHECKS = {
     'C13': 'test_controller_effort',
     'C14': 'test_controller_faults',
     'C15': 'test_station_timing',
+    'C16': 'test_station_independence',
 }
 
 
diff --git a/scripts/check_offline_baseline.sh b/scripts/check_offline_baseline.sh
index d44190d..beba3c3 100755
--- a/scripts/check_offline_baseline.sh
+++ b/scripts/check_offline_baseline.sh
@@ -78,7 +78,7 @@ run_logged() {
     return 0
 }
 
-files=(motor_dashboard.py motor_session.py spin_5rpm.py im6014_codec.py im6014_serial.py im6014_transport.py fake_serial.py test_spin_5rpm.py test_dashboard.py test_startup.py test_startup_verifier.py test_protocol.py test_serial_deadline.py evidence/boundary/vendor-crc-vectors.json USER_MANUAL.md joint_mapping.py test_joint_mapping.py test_numerical_inputs.py im6014_port.py test_port_config.py test_diagnostic_capture.py test_bus_owner.py joint_controller.py joint_records.py test_controller.py test_controller_targets.py test_controller_ownership.py test_controller_limits.py test_controller_velocity.py joint_reference.py test_controller_acceleration.py test_controller_lead.py test_controller_effort.py test_controller_faults.py station_timing.py test_station_timing.py)
+files=(motor_dashboard.py motor_session.py spin_5rpm.py im6014_codec.py im6014_serial.py im6014_transport.py fake_serial.py test_spin_5rpm.py test_dashboard.py test_startup.py test_startup_verifier.py test_protocol.py test_serial_deadline.py evidence/boundary/vendor-crc-vectors.json USER_MANUAL.md joint_mapping.py test_joint_mapping.py test_numerical_inputs.py im6014_port.py test_port_config.py test_diagnostic_capture.py test_bus_owner.py joint_controller.py joint_records.py test_controller.py test_controller_targets.py test_controller_ownership.py test_controller_limits.py test_controller_velocity.py joint_reference.py test_controller_acceleration.py test_controller_lead.py test_controller_effort.py test_controller_faults.py station_timing.py test_station_timing.py arm_manual.py arm_dashboard.py test_station_independence.py)
 for name in "${files[@]}"; do
     mkdir -p -- "$scratch/$(dirname -- "$name")" || exit 2
     if ! cp -- "$repo_dir/$name" "$scratch/$name" || ! cmp -s -- "$repo_dir/$name" "$scratch/$name"; then
@@ -98,7 +98,7 @@ cd -- "$scratch" || exit 2
 run_logged packet-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" test_spin_5rpm.py
 run_logged protocol-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_protocol
 run_logged serial-deadline-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_serial_deadline
-run_logged milestone-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_joint_mapping test_numerical_inputs test_port_config test_diagnostic_capture test_bus_owner test_controller test_controller_targets test_controller_ownership test_controller_limits test_controller_velocity test_controller_acceleration test_controller_lead test_controller_effort test_controller_faults test_station_timing
+run_logged milestone-tests env PYTHONDONTWRITEBYTECODE=1 "$python_path" -m unittest -v test_joint_mapping test_numerical_inputs test_port_config test_diagnostic_capture test_bus_owner test_controller test_controller_targets test_controller_ownership test_controller_limits test_controller_velocity test_controller_acceleration test_controller_lead test_controller_effort test_controller_faults test_station_timing test_station_independence
 run_logged dashboard-tests env QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1 "$python_path" test_dashboard.py
 for name in dashboard_preview.png dashboard_dark_preview.png dashboard_test_results.json; do
     if [[ -f "$scratch/$name" ]]; then
diff --git a/test_startup.py b/test_startup.py
index 1db0f9c..1b73697 100644
--- a/test_startup.py
+++ b/test_startup.py
@@ -110,7 +110,7 @@ def _cleanup_after_main(window, state):
 
 def _fingerprint(root):
     names = ("motor_dashboard.py", "motor_session.py", "spin_5rpm.py", "im6014_codec.py", "im6014_serial.py", "im6014_transport.py", "fake_serial.py", "USER_MANUAL.md",
-             "test_spin_5rpm.py", "test_dashboard.py", "test_startup.py", "test_startup_verifier.py", "test_protocol.py", "test_serial_deadline.py", "evidence/boundary/vendor-crc-vectors.json", "joint_mapping.py", "test_joint_mapping.py", "test_numerical_inputs.py", "im6014_port.py", "test_port_config.py", "test_diagnostic_capture.py", "test_bus_owner.py", "joint_controller.py", "joint_records.py", "test_controller.py", "test_controller_targets.py", "test_controller_ownership.py", "test_controller_limits.py", "test_controller_velocity.py", "joint_reference.py", "test_controller_acceleration.py", "test_controller_lead.py", "test_controller_effort.py", "test_controller_faults.py", "station_timing.py", "test_station_timing.py")
+             "test_spin_5rpm.py", "test_dashboard.py", "test_startup.py", "test_startup_verifier.py", "test_protocol.py", "test_serial_deadline.py", "evidence/boundary/vendor-crc-vectors.json", "joint_mapping.py", "test_joint_mapping.py", "test_numerical_inputs.py", "im6014_port.py", "test_port_config.py", "test_diagnostic_capture.py", "test_bus_owner.py", "joint_controller.py", "joint_records.py", "test_controller.py", "test_controller_targets.py", "test_controller_ownership.py", "test_controller_limits.py", "test_controller_velocity.py", "joint_reference.py", "test_controller_acceleration.py", "test_controller_lead.py", "test_controller_effort.py", "test_controller_faults.py", "station_timing.py", "test_station_timing.py", "arm_manual.py", "arm_dashboard.py", "test_station_independence.py")
     files = {}
     for name in names:
         path = root / name


## Complete test_station_independence.py
"""Actual owner lifecycle under fake dashboard failures; no physical I/O."""

from contextlib import ExitStack
import http.client
import json
import threading
import time
import unittest
from unittest.mock import Mock, patch

import arm_dashboard
from arm_dashboard import ArmDashboardHandler, ArmDashboardServer, run_dashboard
from arm_manual import ArmManualSession, INGRESS_LEASE_S
from im6014_codec import decode_command


class StationIndependenceTests(unittest.TestCase):
    def setUp(self):
        self.guards = ExitStack()
        self.addCleanup(self.guards.close)
        self.serial = self.guards.enter_context(patch(
            'serial.Serial', side_effect=AssertionError('physical serial forbidden')))
        self.ports = self.guards.enter_context(patch(
            'arm_dashboard.enumerate_ports', side_effect=AssertionError('port discovery forbidden')))
        self.guards.enter_context(patch.object(ArmDashboardHandler, '_get_serial_ports', return_value=[]))
        self.managed = self.guards.enter_context(patch(
            'arm_manual.open_managed_port', side_effect=AssertionError('physical owner forbidden')))
        self.arm = ArmManualSession(physical_opt_in=False)
        self.addCleanup(self.arm.close)
        self.sid = self.arm.create_session()

    def tearDown(self):
        self.serial.assert_not_called()
        self.ports.assert_not_called()
        self.managed.assert_not_called()

    def wait_for(self, condition):
        end = time.monotonic() + 2
        while time.monotonic() < end:
            if condition():
                return
            time.sleep(.005)
        self.fail('fake owner did not reach the expected state')

    def action(self, action, values=None):
        ticket = self.arm.issue_ticket(self.sid) if action == 'arm' else None
        op = self.arm.request(self.sid, action, values or {}, ticket=ticket)
        self.wait_for(lambda: self.arm.receipt(self.sid, op)['status'] != 'pending')
        receipt = self.arm.receipt(self.sid, op)
        self.assertEqual(receipt['status'], 'complete', receipt)

    def ready(self, profile='arm_j1'):
        self.action('connect', {'demo': True, 'profile_id': profile})
        self.action('ack', {'supported': True})
        names = ('J1', 'J2', 'J3') if profile == 'arm_j1_j2_j3' else ('J1',)
        for name in names:
            self.action('check')
            self.action('calibrate', {'joint': name, 'known_angle_deg': 0, 'direction': 1,
                                      'lower_deg': -80, 'upper_deg': 80})
        self.action('check')
        self.action('arm', {'supported': True})

    def moving(self, profile='arm_j1'):
        self.ready(profile)
        bus = self.arm.bus
        packets = []
        write = bus.write
        def record(packet):
            packets.append((threading.current_thread(), decode_command(packet)))
            return write(packet)
        bus.write = record
        self.arm.submit(self.sid, self.arm.issue_ticket(self.sid), 1, False, [0, 0, 0], 'keyboard')
        self.arm.submit(self.sid, self.arm.issue_ticket(self.sid), 2, True, [.2, 0, 0], 'keyboard')
        self.wait_for(lambda: any(p['mode'] == 1 for _, p in packets))
        return bus, packets

    def test_bind_failure_closes_the_implicitly_created_owner(self):
        owners = []
        def create(**kwargs):
            owner = ArmManualSession(physical_opt_in=False)
            owners.append(owner)
            return owner
        try:
            with patch.object(arm_dashboard, 'ArmManualSession', side_effect=create), \
                    patch.object(arm_dashboard, 'ArmDashboardServer', side_effect=OSError('fake bind failure')):
                with self.assertRaisesRegex(OSError, 'fake bind failure'):
                    run_dashboard(port=0)
            self.assertEqual(len(owners), 1)
            self.assertFalse(owners[0].thread.is_alive())
            self.assertTrue(owners[0].closed.is_set())
        finally:
            for owner in owners:
                owner.close()

    def test_bind_failure_closes_the_supplied_owner_without_constructing_another(self):
        with patch.object(arm_dashboard, 'ArmManualSession', side_effect=AssertionError('second owner')), \
                patch.object(arm_dashboard, 'ArmDashboardServer', side_effect=OSError('fake bind failure')):
            with self.assertRaisesRegex(OSError, 'fake bind failure'):
                run_dashboard(port=0, session=self.arm)
        self.assertFalse(self.arm.thread.is_alive())

    def test_http_loop_failure_stops_all_three_ids_and_closes_the_actual_owner(self):
        bus, packets = self.moving('arm_j1_j2_j3')
        server = Mock(bound_port=0)
        server.serve_forever.side_effect = RuntimeError('fake dashboard crash')
        with patch.object(arm_dashboard, 'ArmManualSession', side_effect=AssertionError('second owner')), \
                patch.object(arm_dashboard, 'ArmDashboardServer', return_value=server):
            with self.assertRaisesRegex(RuntimeError, 'fake dashboard crash'):
                run_dashboard(port=0, session=self.arm)
        server.server_close.assert_called_once()
        self.assertEqual({p['motor_id'] for _, p in packets if p['mode'] == 0}, {0, 1, 2})
        self.assertFalse(self.arm.thread.is_alive())
        self.assertFalse(bus.is_open)
        self.assertIsNone(self.arm.bus)
        self.assertFalse(self.arm.snapshot()['armed'])
        self.assertEqual(packets[-1][1]['mode'], 0)
        self.assertTrue(all(owner is self.arm.thread for owner, _ in packets))

    def test_server_cleanup_failure_cannot_skip_actual_owner_close(self):
        bus, packets = self.moving()
        server = Mock(bound_port=0)
        server.server_close.side_effect = OSError('fake server cleanup failure')
        with patch.object(arm_dashboard, 'ArmDashboardServer', return_value=server):
            with self.assertRaisesRegex(OSError, 'fake server cleanup failure'):
                run_dashboard(port=0, session=self.arm)
        self.assertFalse(self.arm.thread.is_alive())
        self.assertFalse(bus.is_open)
        self.assertEqual(packets[-1][1]['mode'], 0)

    def test_keyboard_interrupt_uses_the_same_stop_and_close_path(self):
        self.ready()
        bus = self.arm.bus
        server = Mock(bound_port=0)
        server.serve_forever.side_effect = KeyboardInterrupt
        with patch.object(arm_dashboard, 'ArmDashboardServer', return_value=server):
            run_dashboard(port=0, session=self.arm)
        self.assertFalse(self.arm.thread.is_alive())
        self.assertFalse(bus.is_open)
        self.assertFalse(self.arm.snapshot()['armed'])

    def start_http(self):
        server = ArmDashboardServer(('127.0.0.1', 0), self.arm)
        worker = threading.Thread(target=lambda: server.serve_forever(poll_interval=.005))
        worker.start()
        self.addCleanup(worker.join, 1)
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        return server

    def get_state(self, server):
        connection = http.client.HTTPConnection('127.0.0.1', server.bound_port, timeout=1)
        try:
            connection.request('GET', '/api/state')
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            return json.loads(response.read())
        finally:
            connection.close()

    def test_http_restart_preserves_one_owner_and_cannot_renew_stale_input(self):
        bus, packets = self.moving()
        owner = self.arm.thread
        ticket = self.arm.issue_ticket(self.sid)
        old = self.start_http()
        self.assertTrue(self.get_state(old)['connected'])
        old.shutdown()
        old.server_close()
        self.wait_for(lambda: not self.arm.snapshot()['armed'])
        self.wait_for(lambda: self.arm.snapshot()['stop_confirmed'])
        self.assertTrue(owner.is_alive())
        self.assertIs(self.arm.bus, bus)
        boundary = len(packets)
        with patch.object(arm_dashboard, 'ArmManualSession', side_effect=AssertionError('second owner')):
            new = self.start_http()
            for _ in range(3):
                data = self.get_state(new)
                self.assertTrue(data['connected'])
                self.assertFalse(data['armed'])
            with self.assertRaises(ValueError):
                self.arm.submit(self.sid, ticket, 3, True, [.2, 0, 0], 'keyboard')
            time.sleep(INGRESS_LEASE_S + .02)
            self.assertFalse(self.get_state(new)['armed'])
        self.assertIs(self.arm.thread, owner)
        self.assertTrue(all(thread is owner for thread, _ in packets))
        self.assertTrue(all(packet['mode'] == 0 for _, packet in packets[boundary:]))

    def test_new_http_observer_cannot_inherit_control_or_rearm_stopped_owner(self):
        self.ready()
        ticket = self.arm.issue_ticket(self.sid)
        self.arm.stop(self.sid, 'explicit operator Stop before observer restart')
        self.wait_for(lambda: self.arm.snapshot()['stop_confirmed'])
        server = self.start_http()
        connection = http.client.HTTPConnection('127.0.0.1', server.bound_port, timeout=1)
        try:
            body = b'{}'
            connection.request('POST', '/api/session', body=body,
                               headers={'Content-Type': 'application/json',
                                        'Origin': f'http://127.0.0.1:{server.bound_port}'})
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            new_sid = json.loads(response.read())['session']
        finally:
            connection.close()
        self.assertNotEqual(new_sid, self.sid)
        self.assertFalse(self.get_state(server)['armed'])
        with self.assertRaises(ValueError):
            self.arm.submit(new_sid, self.arm.issue_ticket(new_sid), 1, True, [.2, 0, 0], 'keyboard')
        with self.assertRaises(ValueError):
            self.arm.submit(self.sid, ticket, 1, True, [.2, 0, 0], 'keyboard')


if __name__ == '__main__':
    unittest.main()


## Complete docs/station-independence.md
# Dashboard and owner lifecycle

`ArmManualSession` owns the serial worker. `ArmDashboardServer` receives that owner and handles HTTP ingress; restarting this HTTP layer with the same supplied owner does not construct another worker or connection.

`run_dashboard` owns cleanup of its supplied or internally created session. A server bind failure closes that owner. A failure in the HTTP loop closes the server and owner. A failure during server cleanup still attempts owner cleanup. Existing owner close behavior determines whether Stop and resource closure were confirmed; this wrapper does not fabricate confirmation or automatically rearm.

Input expiry runs in the owner. A disconnected browser cannot renew its input lease. Restarting the HTTP layer and reading state cannot rearm a stopped owner, renew an old ticket or transfer authority to a new observer session. Opening an observer session does not itself interrupt an existing valid owner. Movement requires the existing explicit Enable flow.

`test_station_independence.py` uses the actual owner with DemoSerial, rejecting physical constructors and discovery. It checks server construction and cleanup failures, three-joint Stop attempts, keyboard interruption, owner-thread write identity, input expiry without HTTP, HTTP restart and observer authority. Existing C01 checks cover cooperating port exclusion separately.

These results establish software behavior. They do not establish physical stopping time or communication with replacement hardware. Pure JointCore integration with this production owner remains a separate task.


## Unchanged actual owner __init__
    def __init__(self, physical_opt_in=False, serial_factory=None, clock=time.monotonic, *, timing_clock_ns=None):
        if type(physical_opt_in) is not bool:
            raise ValueError('physical_opt_in must be an exact bool')
        if serial_factory is not None and not callable(serial_factory):
            raise ValueError('serial_factory must be callable')
        if not callable(clock):
            raise ValueError('clock must be callable')
        if timing_clock_ns is not None and not callable(timing_clock_ns):
            raise ValueError('timing_clock_ns must be callable')
        self._timing_clock_ns = time.monotonic_ns if timing_clock_ns is None else timing_clock_ns
        self._timing_clock_source = 'host_monotonic_ns' if timing_clock_ns is None else 'injected_clock'
        self._timing = StationTiming(round(SCHEDULE_GAP_MAX_S * 1e9))
        self.physical_opt_in = physical_opt_in
        self.serial_factory = serial_factory
        self.clock = clock
        self._started_host_s = time.monotonic()

        self.lock = threading.RLock()
        self.jobs = queue.Queue(maxsize=MAX_QUEUE)
        self.stop_requested = threading.Event()
        self.stop_work = threading.Event()
        self.closing = threading.Event()
        self.close_requested = threading.Event()
        self.wake = threading.Event()
        self.closed = threading.Event()
        self.generation = 0
        self._close_requests = 0

        self.bus = None
        self.port_owner = None
        self.sessions = set()
        self.parameter_drafts = {}
        self.receipts = {}
        self._pending_by_session = {}
        self.owner = None
        self.tickets = OrderedDict()
        self.last_seq = -1
        self.current_device = None

        self.profile_id = 'arm_j1'
        self.profile = MANUAL_PROFILES[self.profile_id]
        self.joint_states = {
            spec.name: ManualJointRuntime(spec) for spec in _JOINT_SPECS
        }
        self.armed = False
        self.stop_confirmed = False
        self.stop_latched = True
        self._stop_cause = None
        self.deadman_active = False
        self.require_neutral = True
        self.target_axes = [0.0, 0.0, 0.0]
        self.v_j2 = self.v_j3 = 0.0
        self.intent = None
        self.intent_expires_at = None

        self.settings_revision = 0
        self.checked_revision = -1
        self.q_j2 = 0.0
        self.v_j2 = 0.0
        self.q_j3 = 0.0
        self.v_j3 = 0.0
        self._last_clock_value = None
        self.clock_fault = None
        self.last_ingress_time = None
        self.last_poll_host_s = 0.0
        self.last_step_host_s = None

        self.protection_fault = None
        self.protection_history = []
        self.events = deque(maxlen=MAX_EVENTS)


        self.packet_capture = PacketCapture()

        self.data = dict(
            state='Disconnected',
            reason='Select an adapter and connect.',
            connected=False,
            demo=False,
            calibrated=False,
            armed=False,
            stop_confirmed=False,
            port='',
            baud=6000000,
            adapter_profile=DEFAULT_ADAPTER_PROFILE,
            id=0,
            connection=0,
        )

        self.thread = threading.Thread(
            target=self._loop,
            daemon=True,
            name='ArmManual serial owner',
        )
        self.thread.start()

## Unchanged actual owner create_session
    def create_session(self) -> str:
        with self.lock:
            if len(self.sessions) >= MAX_SESSIONS:
                raise RuntimeError('Maximum sessions reached')
            session = secrets.token_hex(16)
            self.sessions.add(session)
            self.receipts[session] = OrderedDict()
            self._pending_by_session[session] = 0
            return session

## Unchanged actual owner close
    def close(self) -> bool:
        with self.lock:
            if self.closed.is_set():
                return self.bus is None and self.port_owner is None
            self._close_requests += 1
            self.closing.set()
            self._latch_stop_locked('Session closing')
            self.close_requested.set()
            self.wake.set()
        if threading.current_thread() is self.thread:
            return False
        self.thread.join(0.75)
        return self.closed.is_set() and self.bus is None and self.port_owner is None

## Unchanged actual owner _service_close
    def _service_close(self):
        with self.lock:
            if not self.close_requested.is_set():
                return False
            request_count = self._close_requests
            self.close_requested.clear()
            self.stop_work.clear()
            self.wake.clear()
        self._drain_rejected_jobs('Session closing')
        if self.bus is not None or self.port_owner is not None:
            self._stop()
            close_ok = self._close_resource()
        else:
            close_ok = True
        if close_ok:
            self._mark_disconnected('Session closed.')
            self.closed.set()
            return True
        with self.lock:
            self.data.update(
                state='Fault — serial close unconfirmed',
                reason='Serial close failed; bus and managed ownership remain for retry.',
                connected=True,
            )
            if self._close_requests == request_count:
                self.close_requested.clear()
        self.wake.wait()
        return False

## Unchanged actual owner _stop
    def _stop(self):
        self._assert_owner_thread()
        with self.lock:
            self.armed = False
            self.data['armed'] = False
            self.deadman_active = False
            self.require_neutral = True
            self.target_axes = [0.0, 0.0, 0.0]
            self.intent = None
            self.intent_expires_at = None
        for joint in self.configured_joints:
            joint.stop_confirmed = False
            joint.stop_result = 'pending'
            joint.stop_error = None
        if self.bus is None or not getattr(self.bus, 'is_open', False):
            self._record_stop_result(False)
            return False
        if not self.data['demo'] and not (
            self.port_owner is not None and getattr(self.port_owner, 'verified', False)
        ):
            self._record_stop_result(False)
            return False
        failures = {}
        for _ in range(3):
            for joint in self.configured_joints:
                if joint.stop_confirmed:
                    continue
                try:
                    reply = self._transact_raw(
                        command(joint.spec.motor_id, 0, 0, 0, 0, True),
                        motor_id=joint.spec.motor_id,
                    )
                    if reply['mode'] != 0:
                        raise RuntimeError('Motor has not confirmed mode-0 Stop')
                    joint.stop_confirmed = True
                    joint.stop_result = 'confirmed'
                    joint.stop_error = None
                    failures.pop(joint.spec.name, None)
                    joint.last_poll_host_s = time.monotonic()
                except Exception as error:
                    failures[joint.spec.name] = error
                    joint.stop_confirmed = False
                    joint.stop_result = 'unconfirmed'
                    joint.stop_error = (str(error) or type(error).__name__)[:160]
        self.last_poll_host_s = time.monotonic()
        result = all(joint.stop_confirmed for joint in self.configured_joints)
        with self.lock:
            self.stop_confirmed = bool(result and self.data['connected'])
            self.data['stop_confirmed'] = self.stop_confirmed
        if not result:
            summary = '; '.join(f'{name}: {error}' for name, error in failures.items())
            self._event('STOP NOT CONFIRMED: ' + summary[:200])
        return result

## Unchanged actual owner _tick
    def _tick(self):
        self._assert_owner_thread()
        if self.bus is None or not self.data['connected'] or not getattr(self.bus, 'is_open', False):
            return
        if self.closing.is_set():
            return
        host_now = time.monotonic()

        if self.armed:
            if self.last_step_host_s is None:
                self.last_step_host_s = host_now
            cycle_gap = host_now - self.last_step_host_s
            self.last_step_host_s = host_now
            if cycle_gap > SCHEDULE_GAP_MAX_S:
                self._trip_fault(RuntimeError(
                    f'Schedule gap exceeded {SCHEDULE_GAP_MAX_S * 1000:.0f}ms'
                ))
                return
            cycle_dt = min(PER_STEP_DT_MAX_S, max(0.0, cycle_gap))
            with self.lock:
                now = self._clock_now_locked()
                intent = self._fresh_mode1_intent(now)
                axes = tuple(self.target_axes)
                deadman = self.deadman_active
            for joint in self.configured_joints:
                age = self._fresh_feedback_age(now, joint)
                if joint.latest is None or age is None or age > FEEDBACK_MAX_AGE_S:
                    self._trip_fault(RuntimeError(f'Feedback stale for {joint.spec.name}; Stop and re-check required'))
                    return
                if joint.latest.get('mode') not in (0, 1):
                    self._trip_fault(RuntimeError(f'{joint.spec.name} reported unsupported feedback mode'))
                    return
                if joint.foc_entered and joint.latest['mode'] != 1:
                    self._trip_fault(RuntimeError(f'{joint.spec.name} left FOC; Stop and re-check required'))
                    return
            if self.intent is not None and self.intent_expires_at is not None and now >= self.intent_expires_at:
                self._trip_loss('Input ticket lease expired; Stop and re-check required')
                return

            modes = [joint.latest['mode'] for joint in self.configured_joints]
            if any(mode == 0 for mode in modes):
                if any(mode == 1 for mode in modes) and not deadman:
                    self._trip_loss('FOC entry was interrupted before every selected joint entered mode 1')
                    return
                physical_moving = deadman and any(abs(axes[index]) > 1e-4
                                                  for index in range(len(self.configured_joints)))
                if physical_moving and intent is not None:
                    for joint in self.configured_joints:
                        if joint.latest['mode'] == 0:
                            self._enter_foc(joint, intent)
                            joint.last_step_host_s = time.monotonic()
                            if self.stop_requested.is_set():
                                return
                    return
                if intent is not None:
                    self._advance_virtual_joints(axes, deadman, cycle_dt)
                if all(mode == 0 for mode in modes) and host_now - self.last_poll_host_s >= 0.050:
                    self._poll_stop()
                return

            if intent is None:
                self._trip_loss('Valid live input intent unavailable; Stop and re-check required')
                return
            for index, joint in enumerate(self.configured_joints):
                last_step = joint.last_step_host_s if joint.last_step_host_s is not None else host_now
                gap = host_now - last_step
                if gap > SCHEDULE_GAP_MAX_S:
                    self._trip_fault(RuntimeError(
                        f'{joint.spec.name} schedule gap exceeded {SCHEDULE_GAP_MAX_S * 1000:.0f}ms'
                    ))
                    return
                dt = min(PER_STEP_DT_MAX_S, max(0.0, gap))
                if dt <= 0:
                    continue
                packet, decoded, next_v, ideal_q, joint_q = self._build_motion_packet(
                    joint, axes[index], dt,
                )
                reply = self._send_mode1(
                    joint, packet, decoded, intent, 1, 'jog', expected_axis=axes[index]
                )
                self._check_motion_reply(joint, reply, joint_q)
                with self.lock:
                    joint.q_ref = joint_q
                    joint.q_ideal = ideal_q
                    joint.v_ref = next_v
                    joint.last_reference_raw = decoded['raw_position']
                    joint.last_step_host_s = time.monotonic()
                    if self.stop_requested.is_set():
                        return
            self._advance_virtual_joints(axes, deadman, cycle_dt)
            with self.lock:
                moving = any(abs(axis) > 1e-4 for axis in self.target_axes)
                braking = any(abs(joint.v_ref) > 1e-5 for joint in self.configured_joints)
                self.data['state'] = 'Jogging' if moving else 'Armed · braking' if braking else 'Armed · holding'
                self.data['reason'] = ('Manual jogging active' if moving else
                                       'Motion input released; braking to zero' if braking else
                                       'Motion input released; holding position')
            return

        poll_interval = 0.050
        if host_now - self.last_poll_host_s >= poll_interval:
            self._poll_stop()

## Review lens
# Review Rubric

Review through whichever lenses are relevant. Not every lens applies to every change.

## Correctness

Does the code actually do what the intent says it should?

- Edge cases: empty inputs, nil/undefined, boundary values, concurrent access
- Error handling: are errors caught, propagated, or silently swallowed?
- Off-by-one, type coercion, integer overflow, string encoding
- State management: race conditions, stale closures, dangling references
- Do both the happy path and the sad path work?
- Idempotency: what happens if this operation runs twice, or if a previous run crashed halfway? If the answer is "it depends on what state was left behind," a reconciliation step is missing.
- Concurrency: if multiple actors can touch the same mutable state (files, branches, shared data), is access serialized structurally (locks, sequential phases, exclusive ownership), or by conventions that won't hold?

When you find a potential bug, trace the execution path. Don't just flag "this could be nil". Show the call chain that makes it nil.

## Root Causes vs. Symptoms

Is the code fixing the actual problem or papering over a symptom?

Answering this often requires looking beyond the changed files. Read the surrounding code (callers, callees, type definitions, sibling modules) and understand the architecture the change lives in. Use the tools available to you (Read, Grep, Glob) to follow the call chain, read the types, and understand why the code exists before judging whether the change addresses the right layer.

- Guard clauses that mask a deeper invariant violation
- Retry logic that hides a broken contract
- Type casts that silence a modeling error
- A workaround: why is it needed? What would a proper fix look like?
- A fix in module A that should really be a fix in module B's contract
- Instructions where structure would be better: if the fix is a comment saying "don't do X" or a convention someone has to remember, ask whether it could instead be a type constraint, a lint rule, or a runtime check that makes the wrong thing impossible

## Structural Integrity

Does the code fit well into the system it's part of?

- Boundary discipline: is validation at system boundaries, or scattered through business logic? Validate data once where it enters the system, then trust it internally.
- Abstraction level: is the code mixing high-level orchestration with low-level detail?
- Coupling: does this change introduce dependencies that will make future changes harder?
- Data model fit: do the data structures match the actual access patterns?
- Bolted-on vs. integrated: if the new requirement had been known from the start, would the code look like this, or does the change feel patched onto the existing design?
- Legacy dual-paths: does the change introduce a new API while keeping the old one alive? If there are no external consumers, migrate callers and delete the old path in the same wave. Don't leave compatibility layers that will become permanent.

Don't penalize simple code for lacking abstraction. Premature abstraction is worse than duplication.

## Verification

Can you tell that this code works from reading it?

- Are there tests? Do they test behavior or implementation details?
- Are there assertions/invariants that would catch regressions?
- If this is a bug fix: is there a test for the bug?
- If this touches an integration boundary: is the full path tested?
- Check the real thing, not a proxy. If the code checks liveness via file mtime or cached state instead of reading the actual value, that's a verification gap.
- For delegated or async work: does the code verify actual output artifacts, or does it trust self-reports and summaries?

## Complexity Budget

Is the complexity justified by what the code accomplishes?

- Code that could be simpler without losing correctness or clarity
- Abstractions that serve only one call site
- Configuration or parameterization for cases that don't exist yet
- Dead code, unused imports, vestigial parameters
- Over-engineering: "just in case" code paths with no current callers
- Obsolete compatibility paths kept alive for transitional stability that's no longer needed. If the migration is done, delete the scaffolding
- Does the user experience justify the complexity? Every feature, control, and option should earn its place. Half-finished features are worse than missing ones.

Simpler is better unless simpler is wrong.

## Security

For each security finding, trace the input path through the code and show it.

- User input flowing to dangerous sinks (SQL, shell, eval, innerHTML) without sanitization
- Authentication/authorization gaps in new endpoints
- Secrets in code, logs, or error messages
- TOCTOU (time-of-check-time-of-use) in security-critical paths


## Review lens
# Code Quality Review

Each reviewer applies this code-quality lens in addition to the rubric. It is a strict standard focused on implementation quality, maintainability, abstraction quality, and codebase health.

Above all, be ambitious about code structure. Do not merely identify local cleanup. Actively search for "code judo" moves, restructurings that preserve behavior while making the implementation dramatically simpler, smaller, more direct, and more elegant.

## Core Prompt

Start from this baseline:

> Perform a deep code quality audit of the current branch's changes.
> Rethink how to structure / implement the changes to meaningfully improve code quality without impacting behavior.
> Work to improve abstractions, modularity, reduce Spaghetti code, improve succinctness and legibility.
> Be ambitious, if there is a clear path to improving the implementation that involves restructuring some of the codebase, go for it.
> Be extremely thorough and rigorous. Measure twice, cut once.

## Dimensions

Each dimension is stated once. Apply the ones that are relevant.

0. **Be ambitious about structural simplification.** Do not stop at "this could be a bit cleaner." Look for reframings that make whole branches, helpers, modes, conditionals, or layers disappear. Assume a "code judo" move is often available. It uses the existing architecture more effectively and makes the change dramatically simpler. If you can delete complexity rather than rearrange it, push hard for that.

1. **Do not let a PR push a file from under 1k lines to over 1k lines without a very strong reason.** Treat this as a strong smell. Prefer extracting helpers, subcomponents, or modules. If the diff crosses that threshold, ask whether the code should be decomposed first. Waive only for a compelling structural reason where the resulting file stays clearly organized.

2. **Do not allow spaghetti growth in existing code.** Be suspicious of new ad-hoc conditionals, scattered special cases, or one-off branches inserted into unrelated flows. Treat "weird if statements in random places" as a design problem, not a style nit. Prefer pushing the logic into a dedicated helper, state machine, or module instead of tangling an existing path.

3. **Bias toward cleaning the design, not just accepting working code.** If behavior can stay the same while the structure becomes meaningfully cleaner, push for the cleaner version. Prefer simplifications that remove moving pieces over refactors that spread the same complexity around.

4. **Prefer direct, boring, maintainable code over hacky or magical code.** Treat brittle, ad-hoc, or "magic" behavior as a problem. Be skeptical of generic mechanisms that hide simple data-shape assumptions. Flag thin abstractions, identity wrappers, or pass-through helpers that add indirection without buying clarity.

5. **Push on type and boundary cleanliness when it affects maintainability.** Question unnecessary optionality, `unknown`, `any`, or cast-heavy code when a clearer type boundary could exist. Prefer explicit typed models over loosely-shaped ad-hoc objects. If a branch leans on a silent fallback to paper over an unclear invariant, ask whether the boundary should be made explicit.

6. **Keep logic in the canonical layer and reuse existing helpers.** Call out feature logic leaking into shared paths or implementation details leaking through APIs. Prefer existing canonical utilities over bespoke one-offs. Push code toward the right package, service, or module instead of normalizing drift.

7. **Treat unnecessary sequential orchestration and non-atomic updates as design smells when the cleaner structure is obvious.** If independent work is serialized for no reason, ask whether it should run in parallel. If related updates can leave state half-applied, push for a more atomic structure. Do not over-index on micro-optimizations, but do flag avoidable orchestration complexity that makes the code more brittle.

## Output Expectations

Prioritize structural code-quality regressions and missed simplifications first, then spaghetti and branching complexity, then boundary, type, and file-size concerns, then smaller modularity and legibility issues.

## Approval Bar

Do not approve merely because behavior seems correct. Treat these as presumptive blockers unless the author can justify them: the PR keeps a lot of incidental complexity when a code-judo move would delete it. Pushes a file from below 1000 lines to above 1000 lines. Adds ad-hoc branching that tangles an existing flow. Scatters feature checks across shared code. Adds an unnecessary abstraction, wrapper, or cast-heavy contract, or duplicates an existing helper or puts logic in the wrong layer when there is a clear canonical home. If those conditions are not met, leave explicit, actionable feedback and push for a cleaner decomposition.

## Review Tone

Be direct, serious, and demanding about quality. Do not be rude, but do not soften major maintainability issues into mild suggestions. If the code is making the codebase messier, say so. If the implementation missed an obvious dramatic simplification, say that too. Do not be satisfied with "maybe rename this" when the real issue is structural.


Report concrete findings with severity/file/line/reproduction, or no findings. Parent owns checks and Git. No recursiveagents.
