import sys,time,json
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from arm_station import ArmStation,ConnectAction
from arm_fixture import ArmPacketFixture
from im6014_codec import decode_command
def connected():
 f=ArmPacketFixture();s=ArmStation(fixture=f);a=s.register_session();s.start_loop();s.request(ConnectAction(),a);until=time.monotonic()+2
 while s.snapshot().lifecycle_state!='connected' and time.monotonic()<until:time.sleep(.005)
 assert s.snapshot().lifecycle_state=='connected';return f,s
f,s=connected();before=len(f.writes)
def fail(*args,**kwargs):raise RuntimeError('parent injected executor failure')
s._step_once=fail;until=time.monotonic()+2
while not s.snapshot().executor_failed and time.monotonic()<until:time.sleep(.005)
s._loop_thread.join(1);view=s.snapshot();out={'executorFailure':{'executorFailed':view.executor_failed,'logicalStop':view.stop_logical,'stopConfirmed':view.stop_confirmed,'stopPending':view.stop_pending,'actualNewMode0IDs':[decode_command(p)['motor_id'] for p in f.writes[before:] if decode_command(p)['mode']==0],'transportStillOpen':f.is_open,'threadAlive':s._loop_thread.is_alive()}}
f,s=connected();s.stop_loop();start=time.monotonic();closed=s.close();out['closeAfterStopLoop']={'closed':closed,'elapsedRealSeconds':time.monotonic()-start,'threadAlive':s._loop_thread.is_alive(),'transportStillOpen':f.is_open}
Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
