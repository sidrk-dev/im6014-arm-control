## Findings

### 1. [critical] Disconnect / close never releases `owner_session_id`, new owner can never connect
**Location**: `arm_station.py: _handle_lifecycle_action` `DisconnectAction` branch, `_execute_close`, `request` lifecycle `NOT_OWNER` gate
**Finding**: Successful `DisconnectAction` increments generation and revokes ingress but never sets `_owner_session_id = None`. Same for `_execute_close`. `request()` rejects any lifecycle from a different session while `_owner_session_id is not None`.
**Evidence**: Disconnect branch sets `_owner_generation += 1`, calls `_revoke_ingress_locked`, clears `_current_core_owner`, `_hold_*`, phases, then finishes receipt — no clearing of `_owner_session_id`. `_execute_close` also leaves it. `test_failed_close_keeps_owner_and_retry_confirms_close` asserts retained owner after successful close, and `test_fault_and_protection_history_survive_disconnect_and_reconnect` only reconnects with the same session, so the leak is hidden. Reproduction logic: owner A Connect/Check/Arm → `request(DisconnectAction(), A)` + `step()` → `register_session(B)` + `request(ConnectAction(), B)` returns `NOT_OWNER` forever, even though station is `DISCONNECTED`. Same after `close() == True`. This contradicts triage row 6 “successful release invalidates authority” — generation bump without owner release bricks multi-client use.
**Suggestion**: Clear `_owner_session_id` on successful Disconnect and on confirmed close; keep it on failed close only.

### 2. [critical] Failed Connect permanently reserves ownership
**Location**: `arm_station.py: request` lifecycle reservation, `_handle_lifecycle_action` `ConnectAction` rejects
**Finding**: `request()` assigns `_owner_session_id` + `_owner_generation += 1` at ingress when `None`, before queueing. Rejected Connect paths (`INVALID_STATE`, `INVALID_SOURCE`, `COMMISSIONING_BLOCKED/REQUIRED`) never unwind it.
**Evidence**: Fixture Connect reject branch calls `_finish_receipt(... REJECTED ...)` and returns, owner stays. Physical Connect reject does the same. Triage row 7 requires “unwind failed Connect” and separate reservation/active ownership. Repro: fresh station, session A queues `ConnectAction(source_kind="physical", draft=bad)` → `step()` rejects but `snapshot().owner_session_id == A`; session B then gets `NOT_OWNER` for fixture Connect. No test covers failed-first-Connect + second-client recovery.
**Suggestion**: Do not assign owner at `request()` time; assign only on accepted Connect execution, or explicitly unwind on reject.

### 3. [critical] `_execute_stop` silently drops admitted `JogIntent` receipt
**Location**: `arm_station.py: _execute_stop`, `_revoke_ingress_locked`, `_apply_intent`
**Finding**: `_revoke_ingress_locked` converts `_pending_intent` to `STOP_PREEMPTED` receipt, but `_execute_stop` — the executor path that actually runs on every Stop/close — does `_pending_intent = None` with no receipt update.
**Evidence**: `_execute_stop` clears `_ticket`, `_latest_intent`, `_pending_intent` and publishes, no `_new_receipt_locked`. So an ingress-`accepted` Jog is left as `accepted` though never submitted to Core. `_apply_intent` has the companion hole: `if state not in (ARMED, MOVING): return` with no `_finish_receipt`, leaving the same false-accepted receipt. Repro: Arm → `issue_ticket` + `request(JogIntent) == accepted` → `request(StopAction)` before next `step()` → `_step_once` takes priority Stop → `_execute_stop` drops pending → `_receipts[招生]` still `ACCEPTED` though goal was never dispatched.
**Suggestion**: Route all executor drops through the revoke path or finish the pending receipt as superseded/rejected.

### 4. [warning] `_arm_transition` leaks on Core/clock exception, permanently blocks input
**Location**: `arm_station.py: _handle_lifecycle_action` `ArmAction` branch, `_step_once`
**Finding**: `_arm_transition = True` is set under lock, cleared only on normal return paths. `_step_once` `finally` clears `_lifecycle_in_progress` but not `_arm_transition`.
**Evidence**: Arm path calls `core.arm`, `submit_targets`, `refresh_ready_anchor` (which calls `claim_owner/begin_check/checked`), all of which can raise `ValueError` on clock regression. Exception propagates out of `_handle_lifecycle_action`, `_arm_transition` stays `True`, and every later `JogIntent` is rejected `LIFECYCLE_BUSY`. No test injects clock failure during Arm.
**Suggestion**: `try/finally` for `_arm_transition`, or make it local to the step.

### 5. [warning] Snapshot exposes raw `owner_session_id` capability
**Location**: `arm_station.py: ArmStationSnapshot.owner_session_id`, `snapshot()`, `_publish`, `_publish_ingress_locked`
**Finding**: Published immutable view returns the raw random session id to any caller thread. A04 contract explicitly warns raw `owner_session_id` may itself be a session capability and requires `mine/another/none` label plus allowlisted observational fields.
**Evidence**: `snapshot()` is lock-only, callable by any thread, returns `owner_session_id` verbatim. `register_session` ids are `secrets.token_hex(16)`; handle forgery needs id+timestamp so this alone does not forge, but it leaks owner identity to non-owners with no redaction. No test checks non-owner snapshot redaction.
**Suggestion**: Stop exposing raw id in A02 snapshot or document as owner-only; A04 must map to label.

### 6. [warning] Receipt bound unproven; ticket flood test is vacuous
**Location**: `arm_station.py: MAX_RECEIPTS`, `test_arm_station.py: test_ticket_is_canonical_single_use_and_bounded`
**Finding**: Test issues 1000 tickets (which create no receipts) then 3 `JogIntent` requests and asserts `len(_receipts) <= 64`. That cannot prove receipt bounding.
**Evidence**: `issue_ticket` creates no `RequestReceipt`; only `request()` does. The test never queues >64 lifecycle/Jog receipts, never checks eviction of `_latest_receipt` vs evicted dict entries. Unbounded `_next_request_id` growth plus retained `_latest_receipt` pointing at evicted id is untested. Triage row 3 “bounded canonical ingress” is therefore only half-verified.
**Suggestion**: Add lifecycle-queue + Jog flood asserting dict length cap and latest-pointer coherence.

### 7. [warning] Dead-man `False` with no hold still returns `HOLDING / ACCEPTED`
**Location**: `arm_station.py: _apply_intent` deadman-False branch
**Finding**: If `state in (ARMED, MOVING)` and `intent.deadman is False` and `_hold_targets is None`, code skips submit and still `_finish_receipt(... ACCEPTED, HOLDING ...)`.
**Evidence**: Branch: `if hold_targets is not None: submit...; _finish_receipt(ACCEPTED,HOLDING)`. After Arm success hold is set, but after `_capture_release_hold` failure-stop, after Core expiry-withdraw, or after a prior `NO_ELAPSED_TIME`/`NEUTRAL_REQUIRED` without hold refresh, `None` is reachable while still ARMED for one slot. Caller sees confirmed hold though nothing was re-affirmed by Core.
**Suggestion**: Reject or re-derive hold when `None`; do not report `HOLDING`.

### 8. [warning] Unbounded J2/J3 travel codified as valid
**Location**: `arm_station.py: validate_physical_draft`, `test_arm_station.py: test_physical_draft_finite_boundaries...`
**Finding**: Validator requires finite positive limits and non-guessed provenance but no plausibility ceiling. Test explicitly blesses `q_max-q_min > tau` (draft uses ±10 rad ≈ ±573°) as valid.
**Evidence**: Loop checks `v_max/a_max/lead/effort >0`, `kp/kd >=0`, ordered `q_min<q_max`, J1 inside model bounds — J2/J3 accept any finite range. Intent says “no guessed cap,” but operator typo (`10.0` vs `1.0`) becomes accepted commissioning input for A03. Pure finite-ness without range sanity is a maintainability footgun.
**Suggestion**: Keep A02 refusal, but add explicit absurd-travel warning tier or require J2/J3 provenance to state measured method/range.

### 9. [warning] `_step_once` triplicated Stop/close polling; `_handle_lifecycle_action` is a god-branch
**Location**: `arm_station.py: _step_once`, `_handle_lifecycle_action`, file size ~76KB
**Finding**: Same expired-lease → take-stop → take-close → execute-stop/close block appears three times in one method; lifecycle handler mixes Connect/Check/Arm/Disconnect/physical in one ~150-line branch. File crosses the 1k-line smell with ingress, executor, Core glue, physical validation, and snapshot publishing tangled.
**Evidence**: Copy-pasted `now = _now(); expired...; reason = _take_priority_stop(); close_id...` before lifecycle, after lifecycle, and after input. Arm stale-anchor path nests `_refresh_ready_anchor` (Stop+claim+check) inside Arm, duplicating Check logic. Code-judo move is available: single `drain_preemptions()` helper + split per-action handlers + extract physical-draft module.
**Suggestion**: Extract preemption drain, per-action executors, and snapshot builder; keep station file under limit.

### 10. [warning] Executor-failure timestamp uses stale `_last_time_s`
**Location**: `arm_station.py: _record_executor_failure`
**Finding**: Calls `_request_stop_locked("executor_failure", self._last_time_s)` instead of fresh `_now()`.
**Evidence**: `_last_time_s` is the last successful `_now()` before the crashing step; with deterministic or halted clocks it can be arbitrarily stale, mis-ordering generation/expiry accounting and `stop_pending` attribution. Test `test_background_executor_exception_records_logical_stop` uses real time so it passes, hiding the staleness.
**Suggestion**: Capture fresh time (or explicitly document fallback) before revoking.

### 11. [nit] Device-epoch is mutated before revocation; provenance filter is substring-trivial
**Location**: `arm_station.py: request` `DEVICE_EPOCH_CHANGED`, `validate_physical_draft` provenance check
**Finding**: On epoch change code does `_device_epoch = new; _request_stop(...)`, so post-Stop snapshot advertises the untrusted epoch that caused revocation. Provenance rejects only substrings `guessed/default/assumed`, bypassed by `defau1t`, `guess`, `presumed`.
**Evidence**: Both are one-liners in supplied source; no test asserts post-revoke epoch value or provenance bypass. Low severity but shows boundary sloppiness.
**Suggestion**: Preserve last-trusted epoch on revoke; use tokenized provenance denylist or require enumerated method.
