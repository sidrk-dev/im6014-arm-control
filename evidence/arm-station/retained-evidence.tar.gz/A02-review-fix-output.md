# A02 review-fix handoff

Edited only `arm_station.py`, `arm_fixture.py`, and `test_arm_station.py` in `/tmp/arm-a02-review-fix-20261009`.

## Changes

- Release the station owner after confirmed Disconnect or a confirmed close when Stop is confirmed; clear the initial ownership reservation after a failed initial Connect. Owner release atomically invalidates tickets and queued work, advances the generation, and resets the next owner's intent sequence and device epoch. Failed or unconfirmed Stop/close retains ownership.
- Clear `_arm_transition` in `finally`. An exception during lifecycle execution receives a terminal `EXECUTOR_FAILED` receipt and triggers executor-owned Stop handling.
- On executor failure, attempt a bounded mode 0 exchange for every motor, independently, including when Core time is invalid. Record write result, feedback mode/receipt, outcome, and confirmation per motor. Invalid Core timing cannot produce a fresh confirmation. Close is attempted on the executor; an unconfirmed close keeps that executor available for an explicit retry.
- Route `stop_loop()` through Stop and close on the background executor. Repeated calls after a confirmed close are idempotent.
- Add bounded lifecycle receipt retention and immutable `receipt(request_id)` lookup results with `present`, `expired`, and `unknown` states.
- Return terminal `NOT_ARMED` and `NO_HOLD_TARGET` input receipts; report `hold_unavailable` when no hold target exists.
- Rename the J2/J3 fixture bounds to `SYNTHETIC_J2_*_RAD` and `SYNTHETIC_J3_*_RAD`.
- Add regression cases for denied-request receipt floods, successful Disconnect ownership transfer, failed physical Connect reservation release, failed Stop feedback, invalid Core clock, close retry, `stop_loop()` close, Arm exceptions, and missing hold/nonarmed receipts.

## Verification

Only read-only source and assignment inspection was performed with `rg`, `sed`, and `cat`. No tests, execution checks, Git operations, network access, or hardware actions were run; the authored tests are unrun and parent-owned checks are requested below.

Stale-client reclaim after an owner becomes unavailable while Stop or close remains unconfirmed is left open for A03/A04. This change does not let a different registered client silently take over that owner.

```pstack-handoff
{"task":"A02-review-fix","checkpoint":"A02-review-fixed","operation":"run-checks","files":["arm_station.py","arm_fixture.py","test_arm_station.py"],"checks":["A02-fixture-lifecycle","A02-station-boundary","A02-offline-regression"],"summary":"Run the requested parent-owned checks against these three scoped files, inspect any failures, and preserve the safe ownership, Stop, and close boundaries."}
```
