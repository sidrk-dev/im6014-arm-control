import sys,json,dataclasses
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from arm_station import *
from arm_station import MAX_RECEIPTS
from arm_fixture import ArmPacketFixture
class Clock:
 def __init__(self):self.value=10.
 def __call__(self):return self.value
 def advance(self):self.value+=.02
def setup(armed=False):
 c=Clock();s=ArmStation(clock=c,fixture=ArmPacketFixture(clock=c));a=s.register_session()
 def step():c.advance();return s.step()
 for action in ([ConnectAction(),CheckAction(),ArmAction()] if armed else [ConnectAction()]):s.request(action,a);step()
 return c,s,a,step
out={}
c,s,a,step=setup();s.request(DisconnectAction(),a);step();b=s.register_session();receipt=s.request(ConnectAction(),b)
out['disconnectSecondOwner']={'ownerRetained':s.snapshot().owner_session_id==a.session_id,'secondReceipt':dataclasses.asdict(receipt)}
c=Clock();s=ArmStation(clock=c,fixture=ArmPacketFixture(clock=c));a=s.register_session();s.request(ConnectAction(source_kind='physical'),a);c.advance();s.step();b=s.register_session();receipt=s.request(ConnectAction(),b)
out['rejectedConnectSecondOwner']={'ownerRetained':s.snapshot().owner_session_id==a.session_id,'secondReceipt':dataclasses.asdict(receipt)}
c,s,a,step=setup(True);ticket=s.issue_ticket(a,1);receipt=s.request(JogIntent(1,(0,0,0),False,True,'test',ticket),a);s.request(StopAction(),a);step();out['pendingJogStopReceipt']=dataclasses.asdict(s._receipts[receipt.request_id])
c,s,a,step=setup();s.request(CheckAction(),a);step();s.request(ArmAction(),a)
orig=s._core.arm
def fail(*args,**kwargs):raise ValueError('parent injected arm failure')
s._core.arm=fail
try:step()
except ValueError:pass
out['armExceptionTransition']={'armTransition':s._arm_transition,'lifecycleInProgress':s._lifecycle_in_progress}
c,s,a,step=setup();
for i in range(1000):s.request(object(),a)
out['receiptFlood']={'count':len(s._receipts),'max':MAX_RECEIPTS,'latestPresent':s._latest_receipt.request_id in s._receipts,'latestMatches':s._latest_receipt==s._receipts.get(s._latest_receipt.request_id)}
Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
