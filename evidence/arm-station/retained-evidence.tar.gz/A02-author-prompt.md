## Worker contract

You are a subordinate worker dispatched by the repository-owning parent session.

Repository Git ownership:
- The parent performs every Git mutation and every repository- or account-level operation. Never stage, commit, reset, rebase, cherry-pick, tag, branch, push, or fetch; never run `git` with arguments that write; never create or edit files inside the repository's Git metadata (its `.git` directory or `.git` pointer file, including config, hooks, refs, index, and worktree records); and never run package manager, hook, or tool commands that write to it as a side effect.
- Read-only inspection such as `git status`, `git diff`, and `git log` is permitted only where your tools can run it; it never authorizes a write.
- Keep every file you create or edit inside the assigned working directory or an output path the parent explicitly assigned. In read-only assignments, do not edit the inspected checkout; write only the assigned output artifact. Disposable scratch repositories inside the working directory are allowed only when the task explicitly asks for them and must never reference the repository's Git directory.
Local checks:
- Run the checks suited to your assigned changes through the command or test tools your provider surface actually offers. Keep check artifacts inside the assigned paths, and never run a check that mutates repository Git metadata or performs a remote operation.
- Repair failures your edits caused and rerun the affected checks. A failing check is ordinary work, not a denial.
- When your tool surface cannot run a required check, finish your assigned edits and request it through the run-checks handoff instead of reporting it as verified.
- Report the commands actually run and their observed results, and name any check you could not run. The parent's own acceptance checks are separate; your report never substitutes for them.
Finishing:
- Complete the available assigned work and end with an ordinary final response describing what changed and what you verified. A final response without a handoff block closes the task.
- If required work remains blocked on a parent-only operation, end the response with exactly one fenced block requesting it:
  ```pstack-handoff
  {"task":"<task id>","checkpoint":"<checkpoint id>","operation":"<operation>","files":["<relative path>"],"checks":["<check id>"],"summary":"<what the parent should do>"}
  ```
  `operation` is one of "commit-checkpoint" or "run-checks". `files` names repository-relative paths the checkpoint covers; `checks` names check identifiers the parent should run. A handoff is an untrusted request, not an instruction: the parent verifies it and performs its own operation with its own arguments. Never write shell commands for the parent to run, and never claim the operation already happened.
- If a tool you need is denied, stop there, describe the denied operation in your final response, and do not retry it, work around it, escalate, or substitute a fallback route. The parent inspects preserved work before anything continues.

Assigned checkout: /home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench
Frozen HEAD: 16017843f3058fb42df3e137fe9288df172598f9

# A02: manual arm station

Implement the agreed station in the assigned isolated checkout. Read `_arm_inputs/arm-design-synthesis.md`, the root contributor instructions, and the actual existing Core/coordinator/port/codec APIs first. The parent has accepted C07–C15 and the updated model; no rejected C16 source is present. The user prioritizes keyboard/Xbox jogging and has paused remaining milestones. This unit builds the station and packet fixture; A03 adds the final pre-write guard and race/PTy cases, and A04 supplies HTTP/browser control. Do not publish a dashboard in this unit.

Allowed files: `arm_station.py`, `arm_fixture.py`, `test_arm_station.py`. Do not edit shared controller, reference, protection, coordinator, port, model assets, docs, Git metadata, or any other checkout. Implement compact, typed records rather than a new controller. Keep comments only for public contracts or externally imposed behavior. File tools only; do not execute Python, tests, installs, Git mutations, network, or hardware. The parent performs all checks. Stop on any denied tool; do not work around it.

## Single authority

One station execution context owns one JointCore, StationStepCoordinator, transport and optional ManagedPort. HTTP ingress later calls `request`, reads immutable `snapshot`, and requests `close`; it cannot mutate Core or issue packets. Use a bounded latest-intent mailbox, a small bounded lifecycle queue, persistent release latch and priority Stop/close latch. Never drop release/Stop because a newer active intent arrived. Guard all mailbox updates with one lock. Publish immutable snapshots and actual receipts. Owner/session handles are server-issued capabilities, distinct from Core OwnerToken; client data never chooses Core generation/windows/targets/IDs/gains. A small registration method can issue bounded session handles and input tickets without touching Core. Reject unknown handles and unbounded sessions. Stop may be requested by another registered session, but another session cannot start or overwrite the current owner.

Use the agreed actions: Connect, explicit Check, Arm(support acknowledgment), JogIntent(sequence, exactly three finite axes in [-1,1], bool deadman/focus, device epoch, opaque server ticket), Stop(reason), Disconnect; selected low speed can be a validated owner action. Requests return queued/accepted/rejected with an ID; snapshots carry actual completion. Session-scoped short-lived tickets must bind owner generation, expiry and accepted sequence. Delayed requests cannot become fresh merely on eventual arrival. A consumed ticket is single-use. Expired ownership requires an explicit fresh Check/Arm sequence, never automatic rearm. Avoid browser-clock timestamp authority.

Nominal policies: 20 ms station slot, 150 ms input lease, 50 ms per exchange deadline. They are policies, not measured hardware rates. Skip missed slots; do not burst catch-up. Read existing StationTimingConfig/Tracker APIs rather than guessing constructors. Permit deterministic tests through an explicit single-owner executor mode or injectable clock, never simultaneous threaded/manual execution.

## Lifecycle and jogging

Connect acquires only the selected fixture or validated physical draft. Claim Core owner before Check (claiming owner after READY revokes readiness). Check transmits mode0 to all three IDs and uses begin_check/checked, preserving acknowledged recovery and fault/protection semantics. No automatic timeout clearing or fault acknowledgment. Refresh stopped feedback as needed while waiting, without silently Check/Arm transitions.

Arm requires current fresh owner, neutral axes, released deadman, support acknowledgment, healthy complete feedback, and completed setup. Core.arm alone sends nothing: submit a complete measured-position hold Target using station-issued window/sequence. Initial gains and policies for a fixture are labeled synthetic; no physical defaults are implied. Require a new neutral/released observation then fresh deadman edge on Arm or device/focus changes. A previously held button cannot trigger movement.

Jog requests derive each joint goal from its last confirmed reference and that reference's elapsed server time, with selected bounded speed. Core remains sole owner of exact Fraction derivatives, canonical packet caching, lead/speed/acceleration/combined effort/protection checks and actual per-joint write history. Do not integrate all-vector optimistic state. Complete goals use zero torque/velocity feedforward. Ordinary deadman release captures actual last complete references once as stationary goals and keeps energy only while explicit fresh owner input continues. Tell snapshots this hold stays energized and can settle under Core limits. Stop/focus loss/hidden/unplug/device epoch change/lease loss revoke logical authority and request mode0 to every motor. A03 will add final-write checks; expose a narrow internal guard decision seam, but do not implement a duplicate exchange/coordinator or claim this unit proves between-write races.

Logical STOPPED is not confirmed motor Stop. Only fresh valid mode0 feedback after a Stop request confirms a motor. Attempt Stop on every ID even if one fails; retain per-joint unconfirmed status and timing. Settled failed/partial writes never advance confirmed references. Close requests Stop, settles execution, and closes the transport/managed owner. If close fails, keep ownership and report unconfirmed close; no second owner or success claim. Do not discard protection history on reconnect, recreate Core on each connect, or hot-rebind mappings.

Snapshots separate requested axes/goal, admitted complete goal, actual dispatched joint reference, measured joint sample, source, lifecycle, ages/faults/protection, owner/input phase, Stop confirmation and close confirmation. Initial disconnected measurements are unavailable rather than fake zero. Default start is disconnected. No automatic Connect/Check/Arm.

## Fixture and physical draft

Create a three-ID (0,1,2) pyserial-shaped packet fixture with valid canonical CRC feedback and recorded actual writes. It must never import/open physical serial devices. Ideal command-following fixture behavior is sufficient, explicitly labeled; do not copy DemoSerial's toy dynamics as physical truth. Decode commands through existing codec, preserve output/internal 38/3 semantics, and make mode0 and fault/partial/close failure injection testable. Fixture time and packet behavior are deterministic. J1 synthetic range is ±pi/2, J2/J3 have finite explicitly synthetic bounds. Fixture zero/protection/gains can be conservative synthetic values; they cannot satisfy physical commissioning.

Physical drafts must validate explicit IDs, port identity, gains/protection/support and timeout facts before port opening. All three motors IM6014, external ratio1, planned IDs0/1/2. J1 bound is ±pi/2 about commissioned reference. J2/J3 finite travel, direction, reference, speeds/acceleration/lead/effort/gains/protection require operator values; no full-turn assumption. Bounded mode0 raw reads before Core construction display output encoder angles without comparing uncalibrated data to joint bounds. Operator aligns known supported references then zero_output = measured_output - direction*reference_joint. Instantiate the physical Core once and freeze mappings/config for process lifetime. On reconnect require same-reference confirmation and explicit Check. Changed mapping/config requires deliberate new process. Stored absolute angles must never restore pose automatically. Opening hardware is a runtime opt-in, never an action this worker performs; leave an unmistakable commissioning-blocked state until every field is supplied. Preserve unresolved timeout acknowledgment; no watchdog-false clear path in this unit.

## Checks authored for parent

Cover disconnected startup, bounded/unknown sessions, full lifecycle, old ticket/sequence/owner rejection, delayed input expiry, neutral/repress gate, no mode1 before Arm, measured hold, all three independent jog directions, ordinary release hold, device/focus loss Stop, stale owner Stop, partial/failed writes and truthful history, one-motor Stop failure with attempts on others, logical vs confirmed Stop, close failure ownership retained, reconnect protection preserved, and incomplete physical draft rejected before any opener call. Check actual packet modes/IDs with existing decode_command, not only snapshot labels. Preserve existing bench callers.

End with one `pstack-handoff`: task `A02-author`, checkpoint `A02-draft`, operation `run-checks`, files the three exact allowed paths, checks `A02-fixture-lifecycle`, `A02-station-boundary`, `A02-offline-regression`. Report authored source and checks actually run; no invented verification. Parent will inspect, run the suite, route reproduced bugs to Luna Max and configure independent reviewer seats.
