"""Unit tests covering ArmStation and ArmPacketFixture boundaries and lifecycle.

Verifies disconnected startup, bounded sessions, lifecycle transitions,
tickets, input expiry, neutral/repress gates, measured hold, jog directions,
focus/device epoch revocation, stop confirmations, close failure,
and physical draft commissioning validations.
"""

import math
import unittest

from arm_fixture import (
    ArmPacketFixture,
    create_synthetic_arm_specs,
    make_feedback_packet,
)
from arm_station import (
    ArmAction,
    ArmStation,
    CheckAction,
    ConnectAction,
    DisconnectAction,
    DispatchGuardOutcome,
    InputTicket,
    JogIntent,
    PhysicalDraft,
    PhysicalJointDraft,
    SessionHandle,
    SetSpeedAction,
    StopAction,
    compute_zero_output,
    read_uncalibrated_raw_angles,
    validate_physical_draft,
)
from im6014_codec import decode_command
from im6014_port import PortConfig
from joint_contract import DecisionCode, State
from joint_protection import ProtectionPolicy


class DeterministicClock:
    """Explicitly controlled monotonic clock for testing."""

    def __init__(self, start: float = 0.0) -> None:
        self.value = float(start)

    def __call__(self) -> float:
        return self.value

    def advance(self, seconds: float) -> float:
        self.value += float(seconds)
        return self.value


class TestArmStation(unittest.TestCase):
    """Test suite verifying ArmStation contract and behavior."""

    def setUp(self) -> None:
        self.clock = DeterministicClock(10.0)
        self.fixture = ArmPacketFixture(clock=self.clock)
        self.station = ArmStation(clock=self.clock, fixture=self.fixture)

    def test_disconnected_startup(self) -> None:
        snap = self.station.snapshot()
        self.assertEqual(snap.lifecycle_state, "disconnected")
        self.assertIsNone(snap.source)
        self.assertEqual(snap.measured_sample, (None, None, None))
        self.assertEqual(snap.measured_health, (None, None, None))
        self.assertEqual(snap.feedback_ages_s, (None, None, None))
        self.assertEqual(snap.confirmed_reference, (None, None, None))
        self.assertEqual(snap.dispatched_reference, (None, None, None))
        self.assertIsNone(snap.admitted_goal)
        self.assertIsNone(snap.requested_axes)
        self.assertFalse(snap.hold_energized)
        self.assertFalse(snap.commissioning_blocked)
        self.assertEqual(len(self.fixture.writes), 0)

    def test_bounded_unknown_sessions(self) -> None:
        sessions = [self.station.register_session(f"client-{i}") for i in range(16)]
        self.assertEqual(len(sessions), 16)
        with self.assertRaises(RuntimeError):
            self.station.register_session("client-17")

        unknown_handle = SessionHandle(session_id="unknown-session", created_at_s=10.0)
        receipt = self.station.request(StopAction(), unknown_handle)
        self.assertEqual(receipt.status, "rejected")
        self.assertEqual(receipt.code, "UNKNOWN_SESSION")

    def test_stop_by_another_registered_session_and_no_overwrite(self) -> None:
        session_a = self.station.register_session("session-a")
        session_b = self.station.register_session("session-b")

        rc = self.station.request(ConnectAction(), session_a)
        self.assertEqual(rc.status, "queued")
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, "connected")
        self.assertEqual(self.station.snapshot().owner_session_id, session_a.session_id)

        rc_b = self.station.request(CheckAction(), session_b)
        self.assertEqual(rc_b.status, "rejected")
        self.assertEqual(rc_b.code, "NOT_OWNER")

        rc_conn = self.station.request(ConnectAction(), session_b)
        self.assertEqual(rc_conn.status, "rejected")
        self.assertEqual(rc_conn.code, "NOT_OWNER")

        rc_stop = self.station.request(StopAction(reason="external_stop"), session_b)
        self.assertEqual(rc_stop.status, "accepted")
        self.assertEqual(rc_stop.code, "STOP_QUEUED")
        self.station.step()
        self.assertTrue(self.station.snapshot().stop_logical)

    def test_full_lifecycle(self) -> None:
        session = self.station.register_session("owner")

        self.station.request(ConnectAction(), session)
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, "connected")

        self.station.request(CheckAction(), session)
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, "ready")
        self.assertTrue(self.station.snapshot().stop_confirmed)

        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()
        self.assertIn(self.station.snapshot().lifecycle_state, ("armed", "moving"))
        self.assertTrue(self.station.snapshot().hold_energized)
        self.assertEqual(self.station.snapshot().input_phase, "holding")

        self.clock.advance(0.020)
        t1 = self.station.issue_ticket(session, 1)
        self.station.request(
            JogIntent(
                sequence=1,
                axes=(1.0, 0.0, 0.0),
                deadman=True,
                focus=True,
                device_epoch="ep1",
                ticket=t1,
            ),
            session,
        )
        self.station.step()
        self.assertEqual(self.station.snapshot().input_phase, "jogging")

        self.clock.advance(0.020)
        t2 = self.station.issue_ticket(session, 2)
        self.station.request(
            JogIntent(
                sequence=2,
                axes=(0.0, 0.0, 0.0),
                deadman=False,
                focus=True,
                device_epoch="ep1",
                ticket=t2,
            ),
            session,
        )
        self.station.step()
        self.assertTrue(self.station.snapshot().hold_energized)
        self.assertEqual(self.station.snapshot().input_phase, "holding")

        self.station.request(StopAction(), session)
        self.station.step()
        self.assertTrue(self.station.snapshot().stop_logical)
        self.assertTrue(self.station.snapshot().stop_confirmed)

        self.station.request(DisconnectAction(), session)
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, "disconnected")

    def test_old_ticket_sequence_owner_rejection(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        self.clock.advance(0.020)
        t1 = self.station.issue_ticket(session, 1)
        rc1 = self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        self.assertEqual(rc1.status, "accepted")

        rc1_reuse = self.station.request(
            JogIntent(2, (1.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        self.assertEqual(rc1_reuse.status, "rejected")
        self.assertEqual(rc1_reuse.code, "INVALID_TICKET")

        t2 = self.station.issue_ticket(session, 2)
        rc2 = self.station.request(
            JogIntent(2, (1.0, 0.0, 0.0), True, True, "ep1", t2), session
        )
        self.assertEqual(rc2.status, "accepted")

        t3 = self.station.issue_ticket(session, 1)
        rc3 = self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, True, "ep1", t3), session
        )
        self.assertEqual(rc3.status, "rejected")
        self.assertEqual(rc3.code, "DUPLICATE_OR_OLDER")

        session_b = self.station.register_session("other")
        bad_ticket = InputTicket(
            ticket_id="fake-ticket",
            session_id=session_b.session_id,
            owner_generation=1,
            created_at_s=self.clock(),
            expires_at_s=self.clock() + 0.150,
            bound_sequence=3,
        )
        rc_b = self.station.request(
            JogIntent(3, (1.0, 0.0, 0.0), True, True, "ep1", bad_ticket), session
        )
        self.assertEqual(rc_b.status, "rejected")
        self.assertEqual(rc_b.code, "INVALID_TICKET")

    def test_delayed_input_expiry(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        t1 = self.station.issue_ticket(session, 1)
        self.clock.advance(0.200)
        rc = self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        self.assertEqual(rc.status, "rejected")
        self.assertEqual(rc.code, "TICKET_EXPIRED")

        t2 = self.station.issue_ticket(session, 2)
        rc2 = self.station.request(
            JogIntent(2, (1.0, 0.0, 0.0), True, True, "ep1", t2), session
        )
        self.assertEqual(rc2.status, "accepted")
        self.station.step()
        self.assertEqual(self.station.snapshot().input_phase, "jogging")

        self.clock.advance(0.160)
        self.station.step()
        self.assertEqual(self.station.core.snapshot().state, State.STOPPED)
        self.assertEqual(self.station.snapshot().input_phase, "lease_expired")

        last_three = self.fixture.writes[-3:]
        for p in last_three:
            self.assertEqual(decode_command(p)["mode"], 0)

    def test_neutral_repress_gate(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()

        t1 = self.station.issue_ticket(session, 1)
        self.station.request(
            JogIntent(1, (0.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        rc_arm_held = self.station.request(
            ArmAction(support_acknowledgment=True), session
        )
        self.station.step()
        self.assertEqual(rc_arm_held.status, "queued")
        self.assertEqual(self.station.snapshot().lifecycle_state, "ready")

        t2 = self.station.issue_ticket(session, 2)
        self.station.request(
            JogIntent(2, (0.5, 0.0, 0.0), False, True, "ep1", t2), session
        )
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, "ready")

        t3 = self.station.issue_ticket(session, 3)
        self.station.request(
            JogIntent(3, (0.0, 0.0, 0.0), False, True, "ep1", t3), session
        )
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()
        self.assertIn(self.station.snapshot().lifecycle_state, ("armed", "moving"))

    def test_no_mode1_before_arm(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()

        self.assertGreater(len(self.fixture.writes), 0)
        for packet in self.fixture.writes:
            decoded = decode_command(packet)
            self.assertEqual(decoded["mode"], 0)

    def test_measured_hold(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()

        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        goals = self.station.snapshot().admitted_goal
        self.assertIsNotNone(goals)
        self.assertEqual(len(goals), 3)
        for g in goals:
            self.assertEqual(g.dq_rad_s, 0.0)
            self.assertEqual(g.tau_nm, 0.0)

    def test_all_three_independent_jog_directions(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        self.clock.advance(0.020)
        t1 = self.station.issue_ticket(session, 1)
        self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        self.station.step()
        decoded_0 = decode_command(self.fixture.writes[-3])
        self.assertEqual(decoded_0["motor_id"], 0)
        self.assertEqual(decoded_0["mode"], 1)
        self.assertGreater(decoded_0["position_rad"], 0.0)

        self.clock.advance(0.020)
        t2 = self.station.issue_ticket(session, 2)
        self.station.request(
            JogIntent(2, (0.0, -1.0, 0.0), True, True, "ep1", t2), session
        )
        self.station.step()
        decoded_1 = decode_command(self.fixture.writes[-2])
        self.assertEqual(decoded_1["motor_id"], 1)
        self.assertEqual(decoded_1["mode"], 1)
        self.assertLess(decoded_1["position_rad"], 0.0)

        self.clock.advance(0.020)
        t3 = self.station.issue_ticket(session, 3)
        self.station.request(
            JogIntent(3, (0.0, 0.0, 1.0), True, True, "ep1", t3), session
        )
        self.station.step()
        decoded_2 = decode_command(self.fixture.writes[-1])
        self.assertEqual(decoded_2["motor_id"], 2)
        self.assertEqual(decoded_2["mode"], 1)
        self.assertGreater(decoded_2["position_rad"], 0.0)

    def test_ordinary_release_hold(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        self.clock.advance(0.020)
        t1 = self.station.issue_ticket(session, 1)
        self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        self.station.step()

        self.clock.advance(0.020)
        t2 = self.station.issue_ticket(session, 2)
        self.station.request(
            JogIntent(2, (0.0, 0.0, 0.0), False, True, "ep1", t2), session
        )
        self.station.step()

        snap = self.station.snapshot()
        self.assertTrue(snap.hold_energized)
        self.assertEqual(snap.input_phase, "holding")

    def test_device_focus_loss_stop(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        self.clock.advance(0.020)
        t1 = self.station.issue_ticket(session, 1)
        rc = self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, False, "ep1", t1), session
        )
        self.assertEqual(rc.status, "rejected")
        self.assertEqual(rc.code, "FOCUS_LOST")
        self.station.step()
        self.assertEqual(self.station.core.snapshot().state, State.STOPPED)

        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        t2 = self.station.issue_ticket(session, 2)
        rc2 = self.station.request(
            JogIntent(2, (1.0, 0.0, 0.0), True, True, "ep2", t2), session
        )
        self.assertEqual(rc2.status, "rejected")
        self.assertEqual(rc2.code, "DEVICE_EPOCH_CHANGED")
        self.station.step()
        self.assertEqual(self.station.core.snapshot().state, State.STOPPED)

    def test_partial_failed_writes_and_truthful_history(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        self.fixture.inject_partial_write = 10
        self.clock.advance(0.020)
        t1 = self.station.issue_ticket(session, 1)
        self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        self.station.step()

        self.assertEqual(self.station.core.snapshot().state, State.FAULT)
        self.assertIsNone(self.station.core.snapshot().confirmed_references[0].packet)

    def test_one_motor_stop_failure_attempts_on_others_and_logical_vs_confirmed(
        self,
    ) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        self.fixture.inject_stop_failure_ids = {1}
        self.station.request(StopAction(), session)
        self.station.step()

        last_three = self.fixture.writes[-3:]
        for p in last_three:
            self.assertEqual(decode_command(p)["mode"], 0)

        snap = self.station.snapshot()
        self.assertTrue(snap.stop_logical)
        self.assertFalse(snap.stop_confirmed)
        self.assertEqual(snap.per_joint_stop_confirmed, (True, False, True))

    def test_close_failure_retains_ownership(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()

        self.fixture.fail_close = True
        result = self.station.close()
        self.assertFalse(result)

        snap = self.station.snapshot()
        self.assertTrue(snap.close_attempted)
        self.assertTrue(snap.close_unconfirmed)
        self.assertFalse(snap.close_confirmed)
        self.assertEqual(snap.owner_session_id, session.session_id)

        session_b = self.station.register_session("second")
        rc = self.station.request(ConnectAction(), session_b)
        self.assertEqual(rc.status, "rejected")
        self.assertEqual(rc.code, "NOT_OWNER")

    def test_reconnect_protection_preserved(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        self.fixture.inject_temperatures = {0: (90, 30)}
        self.clock.advance(0.020)
        t1 = self.station.issue_ticket(session, 1)
        self.station.request(
            JogIntent(1, (0.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        self.station.step()

        self.assertTrue(self.station.snapshot().fault_latched)

        self.station.request(DisconnectAction(), session)
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, "disconnected")

        self.station.request(ConnectAction(), session)
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, "connected")
        self.assertTrue(self.station.snapshot().fault_latched)

        rc_no_ack = self.station.request(CheckAction(acknowledge_fault=False), session)
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, "connected")
        self.assertEqual(
            self.station.snapshot().latest_receipt.code,
            DecisionCode.FAULT_ACK_REQUIRED.value,
        )

    def test_incomplete_physical_draft_rejected_before_opener(self) -> None:
        session = self.station.register_session("owner")

        incomplete_draft = PhysicalDraft(
            port_config=PortConfig("/dev/ttyUSB0", 6_000_000, "FT123", 1),
            support_acknowledged=True,
            timeout_facts_acknowledged=True,
            allow_hardware_opt_in=True,
            joints=(
                PhysicalJointDraft(
                    motor_id=0,
                    name="J1 base",
                    direction=1,
                    reference_joint_rad=0.0,
                    zero_output_rad=0.0,
                    q_min_rad=-1.0,
                    q_max_rad=1.0,
                    v_max_rad_s=1.0,
                    a_max_rad_s2=2.0,
                    max_lead_rad=0.5,
                    max_effort_nm=2.0,
                    kp=3.0,
                    kd=0.2,
                    protection=ProtectionPolicy(85, 70, 105, 90, 1.0, 1.0, 0.5),
                    limits_provenance="draft",
                ),
            ),
        )

        is_valid, errors = validate_physical_draft(incomplete_draft)
        self.assertFalse(is_valid)
        self.assertIn("Physical arm requires exactly 3 joints, found 1", errors[0])

        self.station.request(
            ConnectAction(source_kind="physical", draft=incomplete_draft), session
        )
        self.station.step()

        snap = self.station.snapshot()
        self.assertTrue(snap.commissioning_blocked)
        self.assertEqual(snap.lifecycle_state, "disconnected")

    def test_decode_command_actual_packets(self) -> None:
        session = self.station.register_session("owner")
        self.station.request(ConnectAction(), session)
        self.station.step()
        self.station.request(CheckAction(), session)
        self.station.step()
        self.station.request(ArmAction(support_acknowledgment=True), session)
        self.station.step()

        self.assertGreater(len(self.fixture.writes), 0)
        for raw_pkt in self.fixture.writes:
            decoded = decode_command(raw_pkt)
            self.assertIn(decoded["motor_id"], (0, 1, 2))
            self.assertIn(decoded["mode"], (0, 1))
            if decoded["mode"] == 1:
                self.assertTrue(decoded["watchdog"])

    def test_dispatch_guard_seam(self) -> None:
        guard_calls = []

        def custom_guard(plan_id, joint_idx, plan):
            guard_calls.append((plan_id, joint_idx))
            return DispatchGuardOutcome.REPLACE_HOLD

        station_guarded = ArmStation(
            clock=self.clock, fixture=self.fixture, dispatch_guard=custom_guard
        )
        session = station_guarded.register_session("owner")
        station_guarded.request(ConnectAction(), session)
        station_guarded.step()
        station_guarded.request(CheckAction(), session)
        station_guarded.step()
        station_guarded.request(ArmAction(support_acknowledgment=True), session)
        station_guarded.step()

        self.clock.advance(0.020)
        t1 = station_guarded.issue_ticket(session, 1)
        station_guarded.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, True, "ep1", t1), session
        )
        station_guarded.step()

        self.assertGreater(len(guard_calls), 0)
        self.assertTrue(station_guarded.snapshot().hold_energized)

    def test_lifecycle_queue_capacity(self) -> None:
        session = self.station.register_session("owner")
        for i in range(16):
            rc = self.station.request(ConnectAction(), session)
            self.assertEqual(rc.status, "queued")
        rc_overflow = self.station.request(ConnectAction(), session)
        self.assertEqual(rc_overflow.status, "rejected")
        self.assertEqual(rc_overflow.code, "QUEUE_FULL")


if __name__ == "__main__":
    unittest.main()
