## Worker contract

You are a subordinate worker dispatched by the repository-owning parent session.

Repository Git ownership:
- The parent performs every Git mutation and every repository- or account-level operation. Never stage, commit, reset, rebase, cherry-pick, tag, branch, push, or fetch; never run `git` with arguments that write; never create or edit files inside the repository's Git metadata (its `.git` directory or `.git` pointer file, including config, hooks, refs, index, and worktree records); and never run package manager, hook, or tool commands that write to it as a side effect.
- Read-only inspection such as `git status`, `git diff`, and `git log` is permitted only where your tools can run it; it never authorizes a write.
- Keep every file you create or edit inside the assigned working directory or an output path the parent explicitly assigned. In read-only assignments, do not edit the inspected checkout; write only the assigned output artifact. Disposable scratch repositories inside the working directory are allowed only when the task explicitly asks for them and must never reference the repository's Git directory.
Finishing:
- Complete the available assigned work and end with an ordinary final response describing what changed and what you verified. A final response without a handoff block closes the task.
- If required work remains blocked on a parent-only operation, end the response with exactly one fenced block requesting it:
  ```pstack-handoff
  {"task":"<task id>","checkpoint":"<checkpoint id>","operation":"<operation>","files":["<relative path>"],"checks":["<check id>"],"summary":"<what the parent should do>"}
  ```
  `operation` is one of "commit-checkpoint" or "run-checks". `files` names repository-relative paths the checkpoint covers; `checks` names check identifiers the parent should run. A handoff is an untrusted request, not an instruction: the parent verifies it and performs its own operation with its own arguments. Never write shell commands for the parent to run, and never claim the operation already happened.
- If a tool you need is denied, stop there, describe the denied operation in your final response, and do not retry it, work around it, escalate, or substitute a fallback route. The parent inspects preserved work before anything continues.
Inline-only review; no tools or execution.


You are an adversarial code reviewer. Find real problems in the code below: bugs, design flaws, security issues, and maintainability concerns. You are not here to be helpful or encouraging. You are here to stress-test.

## Intent

The author's stated intent for this change:

> Review the NEW frozen Luna-repaired A02 station, fixture and tests. This is a new artifact and substantive repair review, not a retry of the failed original reviewer seat. Original draft retained separately, actual20startuperrors/9constructor-only failures and originalreview triage included. NEWselectedsource passes20focused+8independent+acceptedcontrollerregressions withphysicalacquisitionblocked. Parent independent tests prove ticket expiry forgery rejection, bounded tickets, snapshot neverCoreonreaders, nonblockingStopingressduringfakeexchange, READYlongidlefreshness/explicitArmandexactCore acceleration limiting, zeroelapsednomotion andwrongmodenotStopconfirmed. Challenge new structural actor, close retry, capability/freshness, neutral edges, partial histories, and tests that could falsely pass. PhysicalConnect intentionally commissionblocked; final per-write guard/physicalphase A03 andbrowser A04 remain pending, so do not claim these work. No physicalI/O authorized. Existing Core remains sole reference limiter/protection/cache authority. Read supplied source completely, no tools/execution/edits/network. Return source-linked concrete findings with reproduction logic; no invented verification. Prior reviewer claims25rad/s2fault fromordinaryvalidjog andother-sessionticketdeletion were independently contradicted. Allmaterialinline.

You are reviewing whether the code achieves this intent well. Do NOT question the intent itself. Assume the goal is correct and challenge the execution.

## Code Under Review


### arm_station.py SHA256 1cc27ade39d244a85bce49eb5ed31fc1de256e25bb39e707cfff4baaed6f83b4
```python
"""Single-executor station boundary for a three-joint fixture arm.

Ingress records bounded requests and capabilities. One manual or background
executor owns Core, timing, packet exchange, Stop confirmation, and transport
close. Public snapshots are immutable values published by that executor.
"""

from collections import OrderedDict, deque
from collections.abc import Callable
from dataclasses import dataclass, replace
import math
import secrets
import threading
import time

from arm_fixture import (
    ArmPacketFixture,
    J1_MAX_RAD,
    J1_MIN_RAD,
    SYNTHETIC_KD,
    SYNTHETIC_KP,
    create_synthetic_arm_specs,
)
from im6014_port import PortConfig
from joint_contract import (
    JointFault,
    JointTrajectoryReference,
    MotorHealth,
    OwnerToken,
    Snapshot as CoreSnapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
)
from joint_controller import JointCore
from joint_mapping import JointSample, JointTarget
from joint_protection import ProtectionPolicy
from station_step import StationStepCoordinator
from station_timing import (
    LoopStepRecord,
    StationTimingConfig,
    StationTimingTracker,
    TimingCounters,
    TimingSnapshot,
    validate_finite_time,
)

__all__ = (
    "DEFAULT_EXCHANGE_DEADLINE_S",
    "DEFAULT_FEEDBACK_MAX_AGE_S",
    "DEFAULT_INPUT_LEASE_S",
    "DEFAULT_MAX_REFERENCE_GAP_S",
    "DEFAULT_MAX_WINDOW_S",
    "DEFAULT_SLOT_PERIOD_S",
    "DEFAULT_SPEED_LIMIT_RAD_S",
    "MAX_SESSIONS",
    "ArmAction",
    "ArmStation",
    "ArmStationSnapshot",
    "CheckAction",
    "ConnectAction",
    "DispatchAuthority",
    "DispatchRecordView",
    "DispatchAttemptView",
    "DisconnectAction",
    "InputTicket",
    "JogIntent",
    "PhysicalDraft",
    "PhysicalJointDraft",
    "RequestReceipt",
    "SessionHandle",
    "SetSpeedAction",
    "StopAction",
    "compute_zero_output",
    "validate_physical_draft",
)

DEFAULT_SLOT_PERIOD_S = 0.020
DEFAULT_INPUT_LEASE_S = 0.150
DEFAULT_EXCHANGE_DEADLINE_S = 0.050
DEFAULT_MAX_WINDOW_S = 0.200
DEFAULT_MAX_REFERENCE_GAP_S = 0.500
DEFAULT_FEEDBACK_MAX_AGE_S = 0.500
DEFAULT_SPEED_LIMIT_RAD_S = 0.500
MAX_SESSIONS = 16
MAX_LIFECYCLE_REQUESTS = 16
MAX_RECEIPTS = 64
BACKGROUND_CLOSE_WAIT_S = 1.0


@dataclass(frozen=True)
class SessionHandle:
    session_id: str
    created_at_s: float

    def __post_init__(self) -> None:
        if type(self.session_id) is not str or not self.session_id:
            raise ValueError("session_id must be a non-empty string")
        validate_finite_time(self.created_at_s, "created_at_s")


@dataclass(frozen=True)
class InputTicket:
    ticket_id: str
    session_id: str
    owner_generation: int
    created_at_s: float
    expires_at_s: float
    bound_sequence: int

    def __post_init__(self) -> None:
        if type(self.ticket_id) is not str or not self.ticket_id:
            raise ValueError("ticket_id must be a non-empty string")
        if type(self.session_id) is not str or not self.session_id:
            raise ValueError("session_id must be a non-empty string")
        if type(self.owner_generation) is not int or self.owner_generation < 1:
            raise ValueError("owner_generation must be a positive integer")
        validate_finite_time(self.created_at_s, "created_at_s")
        validate_finite_time(self.expires_at_s, "expires_at_s")
        if self.expires_at_s <= self.created_at_s:
            raise ValueError("expires_at_s must follow created_at_s")
        if type(self.bound_sequence) is not int or self.bound_sequence < 0:
            raise ValueError("bound_sequence must be a non-negative integer")


@dataclass(frozen=True)
class ConnectAction:
    source_kind: str = "fixture"
    draft: "PhysicalDraft | None" = None

    def __post_init__(self) -> None:
        if type(self.source_kind) is not str or self.source_kind not in ("fixture", "physical"):
            raise ValueError("source_kind must be 'fixture' or 'physical'")


@dataclass(frozen=True)
class CheckAction:
    acknowledge_fault: bool = False

    def __post_init__(self) -> None:
        if type(self.acknowledge_fault) is not bool:
            raise ValueError("acknowledge_fault must be bool")


@dataclass(frozen=True)
class ArmAction:
    support_acknowledgment: bool = True

    def __post_init__(self) -> None:
        if type(self.support_acknowledgment) is not bool:
            raise ValueError("support_acknowledgment must be bool")


@dataclass(frozen=True)
class JogIntent:
    sequence: int
    axes: tuple[float, float, float]
    deadman: bool
    focus: bool
    device_epoch: str
    ticket: InputTicket

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or self.sequence < 0:
            raise ValueError("sequence must be a non-negative integer")
        if type(self.axes) is not tuple or len(self.axes) != 3:
            raise ValueError("axes must be a 3-element tuple")
        for axis in self.axes:
            if isinstance(axis, bool) or not isinstance(axis, (int, float)):
                raise ValueError("each axis must be a finite real number")
            try:
                value = float(axis)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("each axis must be a finite real number") from exc
            if not math.isfinite(value) or not -1.0 <= value <= 1.0:
                raise ValueError("each axis must be in [-1.0, 1.0]")
        if type(self.deadman) is not bool or type(self.focus) is not bool:
            raise ValueError("deadman and focus must be bool values")
        if type(self.device_epoch) is not str or not self.device_epoch:
            raise ValueError("device_epoch must be a non-empty string")
        if type(self.ticket) is not InputTicket:
            raise ValueError("ticket must be an InputTicket")


@dataclass(frozen=True)
class StopAction:
    reason: str = "operator_stop"

    def __post_init__(self) -> None:
        if type(self.reason) is not str or not self.reason or len(self.reason) > 64:
            raise ValueError("reason must be a bounded non-empty string")


@dataclass(frozen=True)
class DisconnectAction:
    pass


@dataclass(frozen=True)
class SetSpeedAction:
    speed_rad_s: float

    def __post_init__(self) -> None:
        speed = validate_finite_time(self.speed_rad_s, "speed_rad_s")
        if speed <= 0.0:
            raise ValueError("speed_rad_s must be positive")


@dataclass(frozen=True)
class RequestReceipt:
    request_id: int
    action_name: str
    status: str
    code: str
    message: str
    timestamp_s: float


@dataclass(frozen=True)
class PhysicalJointDraft:
    motor_id: int
    name: str
    direction: int
    reference_joint_rad: float
    zero_output_rad: float | None = None
    q_min_rad: float | None = None
    q_max_rad: float | None = None
    v_max_rad_s: float | None = None
    a_max_rad_s2: float | None = None
    max_lead_rad: float | None = None
    max_effort_nm: float | None = None
    kp: float | None = None
    kd: float | None = None
    protection: ProtectionPolicy | None = None
    limits_provenance: str = ""


@dataclass(frozen=True)
class PhysicalDraft:
    port_config: PortConfig | None = None
    joints: tuple[PhysicalJointDraft, ...] = ()
    support_acknowledged: bool = False
    timeout_facts_acknowledged: bool = False
    allow_hardware_opt_in: bool = False


def _finite_number(value: object) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(float(value))
    except (OverflowError, TypeError, ValueError):
        return False


def validate_physical_draft(draft: PhysicalDraft | None) -> tuple[bool, list[str]]:
    """Purely validate a proposed commissioning draft; never acquire hardware."""
    if not isinstance(draft, PhysicalDraft):
        return False, ["A physical commissioning draft is required"]

    errors: list[str] = []
    if type(draft.allow_hardware_opt_in) is not bool or not draft.allow_hardware_opt_in:
        errors.append("Hardware opt-in is required")
    if not isinstance(draft.port_config, PortConfig):
        errors.append("Valid PortConfig is required")
    if type(draft.support_acknowledged) is not bool or not draft.support_acknowledged:
        errors.append("Support acknowledgment is required")
    if type(draft.timeout_facts_acknowledged) is not bool or not draft.timeout_facts_acknowledged:
        errors.append("Timeout facts acknowledgment is required")
    if type(draft.joints) is not tuple or len(draft.joints) != 3:
        errors.append("Physical arm requires exactly 3 joint drafts")
        return False, errors

    if any(not isinstance(joint, PhysicalJointDraft) for joint in draft.joints):
        errors.append("Every joint draft must be a PhysicalJointDraft")
        return False, errors
    if tuple(j.motor_id for j in draft.joints) != (0, 1, 2):
        errors.append("Joint motor IDs must be [0, 1, 2]")

    for joint in draft.joints:
        label = joint.name if type(joint.name) is str and joint.name else str(joint.motor_id)
        if type(joint.motor_id) is not int or not 0 <= joint.motor_id <= 2:
            errors.append(f"Joint {label} motor ID is invalid")
        if type(joint.direction) is not int or joint.direction not in (-1, 1):
            errors.append(f"Joint {label} direction must be integer -1 or 1")
        if not _finite_number(joint.reference_joint_rad):
            errors.append(f"Joint {label} reference must be finite")
        if not _finite_number(joint.zero_output_rad):
            errors.append(f"Joint {label} zero_output_rad must be confirmed and finite")
        if not _finite_number(joint.q_min_rad) or not _finite_number(joint.q_max_rad):
            errors.append(f"Joint {label} requires explicit finite position limits")
        elif joint.q_min_rad >= joint.q_max_rad:
            errors.append(f"Joint {label} position limits must be ordered")
        elif joint.motor_id == 0 and (
            joint.q_min_rad < J1_MIN_RAD or joint.q_max_rad > J1_MAX_RAD
        ):
            errors.append(f"J1 limits must stay within the canonical model bounds")

        for field_name in (
            "v_max_rad_s",
            "a_max_rad_s2",
            "max_lead_rad",
            "max_effort_nm",
        ):
            value = getattr(joint, field_name)
            if not _finite_number(value) or value <= 0:
                errors.append(f"Joint {label} requires positive finite {field_name}")
        for field_name in ("kp", "kd"):
            value = getattr(joint, field_name)
            if not _finite_number(value) or value < 0:
                errors.append(f"Joint {label} requires non-negative finite {field_name}")
        if not isinstance(joint.protection, ProtectionPolicy):
            errors.append(f"Joint {label} requires ProtectionPolicy")
        if (
            type(joint.limits_provenance) is not str
            or not joint.limits_provenance.strip()
            or any(word in joint.limits_provenance.lower() for word in ("guessed", "default", "assumed"))
        ):
            errors.append(f"Joint {label} requires explicit limits provenance")

    return not errors, errors


def compute_zero_output(
    measured_output_rad: float,
    direction: int,
    reference_joint_rad: float,
) -> float:
    """Return measured_output - direction * reference_joint after validation."""
    if not _finite_number(measured_output_rad) or not _finite_number(reference_joint_rad):
        raise ValueError("measured output and reference must be finite numbers")
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError("direction must be integer -1 or 1")
    return float(measured_output_rad) - direction * float(reference_joint_rad)


@dataclass(frozen=True)
class DispatchAuthority:
    """Narrow read-only seam for a later coordinator pre-write hook."""

    owner_generation: int
    expires_at_s: float | None
    revoked: bool
    stop_pending: bool


@dataclass(frozen=True)
class DispatchRecordView:
    sequence: int
    target: JointTarget
    dispatched_at_s: float


@dataclass(frozen=True)
class DispatchAttemptView:
    sequence: int
    target: JointTarget
    result: WriteResult
    started_at_s: float


@dataclass(frozen=True)
class ArmStationSnapshot:
    lifecycle_state: str
    connection_phase: str
    source: SourceIdentity | None
    requested_axes: tuple[float, float, float] | None
    admitted_goal: tuple[JointTarget, ...] | None
    dispatched_reference: tuple[JointTarget | None, ...] | None
    dispatch_records: tuple[DispatchRecordView | None, ...]
    dispatch_attempts: tuple[DispatchAttemptView | None, ...]
    confirmed_reference: tuple[JointTrajectoryReference | None, ...] | None
    measured_sample: tuple[JointSample | None, ...]
    measured_health: tuple[MotorHealth | None, ...]
    feedback_ages_s: tuple[float | None, ...]
    faults: tuple[JointFault, ...]
    fault_latched: bool
    owner_session_id: str | None
    owner_generation: int
    input_phase: str
    hold_energized: bool
    stop_logical: bool
    stop_confirmed: bool
    stop_pending: bool
    per_joint_stop_confirmed: tuple[bool, ...]
    close_attempted: bool
    close_confirmed: bool
    close_unconfirmed: bool
    executor_failed: bool
    timing_counters: TimingCounters | None
    timing_snapshot: TimingSnapshot | None
    latest_receipt: RequestReceipt | None
    device_epoch: str | None
    selected_speed_rad_s: float
    commissioning_blocked: bool
    commissioning_reasons: tuple[str, ...]


class ArmStation:
    """One Core and one transport executor behind bounded ingress."""

    def __init__(
        self,
        *,
        clock: Callable[[], float] | None = None,
        fixture: ArmPacketFixture | None = None,
        slot_period_s: float = DEFAULT_SLOT_PERIOD_S,
        input_lease_s: float = DEFAULT_INPUT_LEASE_S,
        exchange_deadline_s: float = DEFAULT_EXCHANGE_DEADLINE_S,
        max_reference_gap_s: float = DEFAULT_MAX_REFERENCE_GAP_S,
        feedback_max_age_s: float = DEFAULT_FEEDBACK_MAX_AGE_S,
        max_window_s: float = DEFAULT_MAX_WINDOW_S,
        jog_speed_rad_s: float = DEFAULT_SPEED_LIMIT_RAD_S,
    ) -> None:
        self._clock = time.monotonic if clock is None else clock
        if not callable(self._clock):
            raise ValueError("clock must be callable")
        self._last_time_s = 0.0
        self.slot_period_s = validate_finite_time(slot_period_s, "slot_period_s")
        self.input_lease_s = validate_finite_time(input_lease_s, "input_lease_s")
        self.exchange_deadline_s = validate_finite_time(
            exchange_deadline_s, "exchange_deadline_s"
        )
        self.max_reference_gap_s = validate_finite_time(
            max_reference_gap_s, "max_reference_gap_s"
        )
        self.feedback_max_age_s = validate_finite_time(
            feedback_max_age_s, "feedback_max_age_s"
        )
        self.max_window_s = validate_finite_time(max_window_s, "max_window_s")
        self._selected_speed_rad_s = validate_finite_time(
            jog_speed_rad_s, "jog_speed_rad_s"
        )
        if min(
            self.slot_period_s,
            self.input_lease_s,
            self.exchange_deadline_s,
            self.max_reference_gap_s,
            self.feedback_max_age_s,
            self.max_window_s,
            self._selected_speed_rad_s,
        ) <= 0.0:
            raise ValueError("station timing, lease, window, and speed limits must be positive")
        if self._selected_speed_rad_s > 2.0:
            raise ValueError("jog_speed_rad_s must not exceed 2.0")

        self._specs = create_synthetic_arm_specs()
        self._bus = fixture if fixture is not None else ArmPacketFixture(clock=self._clock)
        self._core: JointCore | None = None
        self._timing: StationTimingTracker | None = None
        self._coordinator: StationStepCoordinator | None = None
        self._transport_closed = False

        self._condition = threading.Condition(threading.Lock())
        self._sessions: dict[str, SessionHandle] = {}
        self._owner_session_id: str | None = None
        self._owner_generation = 0
        self._ticket: InputTicket | None = None
        self._pending_intent: tuple[int, JogIntent, InputTicket] | None = None
        self._latest_intent: JogIntent | None = None
        self._latest_intent_expiry_s: float | None = None
        self._last_accepted_intent_sequence = -1
        self._owner_deadline_s: float | None = None
        self._input_enabled = False
        self._deadman_active = False
        self._new_deadman_edge_pending = False
        self._neutral_event_pending = False
        self._release_capture_pending = False
        self._release_neutral_pending = False
        self._arm_transition = False
        self._device_epoch: str | None = None
        self._priority_stop_pending = False
        self._priority_stop_reason: str | None = None
        self._stop_in_progress = False
        self._lifecycle_in_progress = False
        self._lifecycle_queue: deque[tuple[int, object]] = deque()
        self._receipts: OrderedDict[int, RequestReceipt] = OrderedDict()
        self._latest_receipt: RequestReceipt | None = None
        self._next_request_id = 1

        self._current_core_owner: OwnerToken | None = None
        self._next_core_sequence = 0
        self._needs_neutral_and_edge = True
        self._neutral_seen = False
        self._hold_targets: tuple[JointTarget, ...] | None = None
        self._holding_position = False
        self._hold_energized = False
        self._input_phase = "disconnected"
        self._connection_phase = "disconnected"
        self._per_joint_stop_confirmed = {motor_id: False for motor_id in (0, 1, 2)}
        self._close_attempted = False
        self._close_confirmed = False
        self._close_unconfirmed = False
        self._close_request_id = 0
        self._close_completed_id = 0
        self._executor_failed = False
        self._commissioning_blocked = False
        self._commissioning_reasons: tuple[str, ...] = ()

        self._execution_mode: str | None = None
        self._executor_thread_id: int | None = None
        self._loop_thread: threading.Thread | None = None
        self._loop_running = threading.Event()
        self._loop_stop_requested = False

        self._published = self._empty_snapshot()

    def _now(self) -> float:
        now = validate_finite_time(self._clock(), "clock")
        self._last_time_s = now
        return now

    def _empty_snapshot(self) -> ArmStationSnapshot:
        return ArmStationSnapshot(
            lifecycle_state=State.DISCONNECTED.value,
            connection_phase="disconnected",
            source=None,
            requested_axes=None,
            admitted_goal=None,
            dispatched_reference=(None, None, None),
            dispatch_records=(None, None, None),
            dispatch_attempts=(None, None, None),
            confirmed_reference=(None, None, None),
            measured_sample=(None, None, None),
            measured_health=(None, None, None),
            feedback_ages_s=(None, None, None),
            faults=(),
            fault_latched=False,
            owner_session_id=None,
            owner_generation=0,
            input_phase="disconnected",
            hold_energized=False,
            stop_logical=True,
            stop_confirmed=False,
            stop_pending=False,
            per_joint_stop_confirmed=(False, False, False),
            close_attempted=False,
            close_confirmed=False,
            close_unconfirmed=False,
            executor_failed=False,
            timing_counters=None,
            timing_snapshot=None,
            latest_receipt=None,
            device_epoch=None,
            selected_speed_rad_s=self._selected_speed_rad_s,
            commissioning_blocked=False,
            commissioning_reasons=(),
        )

    @staticmethod
    def _action_name(action: object) -> str:
        return type(action).__name__

    def _new_receipt_locked(
        self,
        request_id: int,
        action_name: str,
        status: str,
        code: str,
        message: str,
        timestamp_s: float,
    ) -> RequestReceipt:
        receipt = RequestReceipt(
            request_id, action_name, status, code, message, timestamp_s
        )
        self._receipts[request_id] = receipt
        self._receipts.move_to_end(request_id)
        while len(self._receipts) > MAX_RECEIPTS:
            self._receipts.popitem(last=False)
        if self._latest_receipt is None or request_id >= self._latest_receipt.request_id:
            self._latest_receipt = receipt
        return receipt

    def _finish_receipt(
        self,
        request_id: int,
        action_name: str,
        status: str,
        code: str,
        message: str,
    ) -> None:
        now = self._now()
        with self._condition:
            if request_id not in self._receipts:
                return
            receipt = self._new_receipt_locked(
                request_id, action_name, status, code, message, now
            )
            if self._latest_receipt is not None and request_id < self._latest_receipt.request_id:
                self._latest_receipt = max(
                    (self._latest_receipt, receipt), key=lambda item: item.request_id
                )
            self._publish_ingress_locked()

    def _publish_ingress_locked(self) -> None:
        view = self._published
        self._published = replace(
            view,
            requested_axes=(
                self._latest_intent.axes if self._latest_intent is not None else None
            ),
            owner_session_id=self._owner_session_id,
            owner_generation=self._owner_generation,
            stop_pending=self._priority_stop_pending or self._stop_in_progress,
            latest_receipt=self._latest_receipt,
            device_epoch=self._device_epoch,
            selected_speed_rad_s=self._selected_speed_rad_s,
            close_attempted=self._close_attempted,
            close_confirmed=self._close_confirmed,
            close_unconfirmed=self._close_unconfirmed,
        )

    def register_session(self, client_info: str = "") -> SessionHandle:
        now = self._now()
        with self._condition:
            if len(self._sessions) >= MAX_SESSIONS:
                raise RuntimeError("Maximum registered sessions exceeded")
            handle = SessionHandle(secrets.token_hex(16), now)
            self._sessions[handle.session_id] = handle
            self._publish_ingress_locked()
            return handle

    def _registered_session_locked(self, handle: object) -> bool:
        return (
            type(handle) is SessionHandle
            and self._sessions.get(handle.session_id) == handle
        )

    def _request_stop_locked(self, reason: str, timestamp_s: float) -> None:
        if not self._priority_stop_pending:
            self._owner_generation += 1
        self._priority_stop_pending = True
        self._priority_stop_reason = reason
        self._revoke_ingress_locked(
            timestamp_s,
            "STOP_PREEMPTED",
            "Station authority was revoked by Stop",
        )

    def _revoke_ingress_locked(
        self, timestamp_s: float, code: str, message: str
    ) -> None:
        self._input_enabled = False
        self._owner_deadline_s = None
        self._ticket = None
        self._latest_intent = None
        self._latest_intent_expiry_s = None
        if self._pending_intent is not None:
            request_id, intent, _ = self._pending_intent
            self._new_receipt_locked(
                request_id,
                "JogIntent",
                "rejected",
                code,
                message,
                timestamp_s,
            )
            self._pending_intent = None
        self._deadman_active = False
        self._new_deadman_edge_pending = False
        self._neutral_event_pending = False
        self._release_capture_pending = False
        self._release_neutral_pending = False
        while self._lifecycle_queue:
            request_id, action = self._lifecycle_queue.popleft()
            self._new_receipt_locked(
                request_id,
                self._action_name(action),
                "rejected",
                code,
                message,
                timestamp_s,
            )
        self._publish_ingress_locked()

    def issue_ticket(self, session_handle: SessionHandle, sequence: int) -> InputTicket:
        now = self._now()
        if type(sequence) is not int or sequence < 0:
            raise ValueError("sequence must be a non-negative integer")
        with self._condition:
            if not self._registered_session_locked(session_handle):
                raise ValueError("Session handle is not registered")
            if session_handle.session_id != self._owner_session_id:
                raise ValueError("Session is not the current station owner")
            if not self._input_enabled or self._priority_stop_pending or self._stop_in_progress:
                raise RuntimeError("Input tickets require an armed station with live authority")
            if (
                self._input_enabled
                and self._owner_deadline_s is not None
                and now >= self._owner_deadline_s
            ):
                self._request_stop_locked("owner_lease_expired", now)
                raise RuntimeError("Owner input lease expired; Stop was queued")
            ticket = InputTicket(
                ticket_id=secrets.token_hex(16),
                session_id=session_handle.session_id,
                owner_generation=self._owner_generation,
                created_at_s=now,
                expires_at_s=now + self.input_lease_s,
                bound_sequence=sequence,
            )
            # Replacing the sole canonical ticket makes every older ticket unusable.
            self._ticket = ticket
            return ticket

    def request(self, action: object, session_handle: SessionHandle) -> RequestReceipt:
        now = self._now()
        with self._condition:
            request_id = self._next_request_id
            self._next_request_id += 1
            name = self._action_name(action)

            if not self._registered_session_locked(session_handle):
                receipt = self._new_receipt_locked(
                    request_id, name, "rejected", "UNKNOWN_SESSION",
                    "Session handle is not registered", now
                )
                self._publish_ingress_locked()
                return receipt

            if isinstance(action, StopAction):
                self._request_stop_locked(action.reason, now)
                self._condition.notify_all()
                receipt = self._new_receipt_locked(
                    request_id, "Stop", "accepted", "STOP_QUEUED",
                    "Priority Stop queued", now
                )
                self._publish_ingress_locked()
                return receipt

            if isinstance(action, JogIntent):
                if session_handle.session_id != self._owner_session_id:
                    code, message = "NOT_OWNER", "Action requires the station owner"
                elif self._priority_stop_pending or self._stop_in_progress:
                    code, message = "STOP_PENDING", "Input authority is revoked"
                elif self._arm_transition or self._lifecycle_in_progress:
                    code, message = "LIFECYCLE_BUSY", "Input is unavailable during a lifecycle transition"
                elif (
                    self._input_enabled
                    and self._owner_deadline_s is not None
                    and now >= self._owner_deadline_s
                ):
                    self._request_stop_locked("owner_lease_expired", now)
                    code, message = "OWNER_EXPIRED", "Owner lease expired; Stop was queued"
                else:
                    canonical = self._ticket
                    if canonical is None or action.ticket.ticket_id != canonical.ticket_id:
                        code, message = "INVALID_TICKET", "Ticket not found or already consumed"
                    else:
                        self._ticket = None
                        if action.ticket != canonical:
                            code, message = "INVALID_TICKET", "Ticket does not match its server record"
                        elif canonical.session_id != self._owner_session_id:
                            code, message = "INVALID_TICKET", "Ticket belongs to another session"
                        elif canonical.owner_generation != self._owner_generation:
                            code, message = "EXPIRED_OWNER_GENERATION", "Ticket owner generation expired"
                        elif now >= canonical.expires_at_s:
                            code, message = "TICKET_EXPIRED", "Ticket expired before receipt"
                        elif action.sequence != canonical.bound_sequence:
                            code, message = "SEQUENCE_MISMATCH", "Sequence differs from server ticket"
                        elif action.focus is False:
                            self._request_stop_locked("focus_lost", now)
                            code, message = "FOCUS_LOST", "Focus loss revoked input authority"
                        elif self._device_epoch is not None and self._device_epoch != action.device_epoch:
                            self._device_epoch = action.device_epoch
                            self._request_stop_locked("device_epoch_changed", now)
                            code, message = "DEVICE_EPOCH_CHANGED", "Device change revoked input authority"
                        elif action.sequence <= self._last_accepted_intent_sequence:
                            code, message = "DUPLICATE_OR_OLDER", "Input sequence is duplicate or older"
                        else:
                            if self._device_epoch is None:
                                self._device_epoch = action.device_epoch
                            if self._pending_intent is not None:
                                old_id, _, _ = self._pending_intent
                                self._new_receipt_locked(
                                    old_id, "JogIntent", "superseded", "SUPERSEDED",
                                    "A newer unsent input replaced this one", now
                                )
                            self._last_accepted_intent_sequence = action.sequence
                            self._latest_intent = action
                            self._latest_intent_expiry_s = canonical.expires_at_s
                            self._pending_intent = (request_id, action, canonical)
                            was_deadman_active = self._deadman_active
                            if action.deadman:
                                if not self._deadman_active:
                                    self._new_deadman_edge_pending = True
                                self._deadman_active = True
                            else:
                                self._deadman_active = False
                                if self._input_enabled and all(axis == 0.0 for axis in action.axes):
                                    self._neutral_event_pending = True
                                if was_deadman_active and self._input_enabled:
                                    self._release_capture_pending = True
                                    self._release_neutral_pending = all(
                                        axis == 0.0 for axis in action.axes
                                    )
                            if self._input_enabled:
                                self._owner_deadline_s = canonical.expires_at_s
                            receipt = self._new_receipt_locked(
                                request_id, "JogIntent", "accepted", "ACCEPTED",
                                "Jog input admitted", now
                            )
                            self._publish_ingress_locked()
                            return receipt
                receipt = self._new_receipt_locked(
                    request_id, "JogIntent", "rejected", code, message, now
                )
                self._publish_ingress_locked()
                return receipt

            if isinstance(action, SetSpeedAction):
                if session_handle.session_id != self._owner_session_id:
                    receipt = self._new_receipt_locked(
                        request_id, name, "rejected", "NOT_OWNER",
                        "Action requires the station owner", now
                    )
                elif action.speed_rad_s > 2.0:
                    receipt = self._new_receipt_locked(
                        request_id, name, "rejected", "INVALID_SPEED",
                        "Requested speed exceeds the fixture policy", now
                    )
                else:
                    self._selected_speed_rad_s = action.speed_rad_s
                    receipt = self._new_receipt_locked(
                        request_id, name, "accepted", "ACCEPTED",
                        "Selected speed updated", now
                    )
                self._publish_ingress_locked()
                return receipt

            if isinstance(action, (ConnectAction, CheckAction, ArmAction, DisconnectAction)):
                if self._close_attempted:
                    receipt = self._new_receipt_locked(
                        request_id, name, "rejected", "CLOSE_IN_PROGRESS",
                        "Station close has begun", now
                    )
                elif self._priority_stop_pending or self._stop_in_progress:
                    receipt = self._new_receipt_locked(
                        request_id, name, "rejected", "STOP_PENDING",
                        "Lifecycle change must wait for Stop confirmation", now
                    )
                elif self._lifecycle_in_progress:
                    receipt = self._new_receipt_locked(
                        request_id, name, "rejected", "LIFECYCLE_BUSY",
                        "A lifecycle transition is already in progress", now
                    )
                elif self._owner_session_id is not None and (
                    self._owner_session_id != session_handle.session_id
                ):
                    receipt = self._new_receipt_locked(
                        request_id, name, "rejected", "NOT_OWNER",
                        "Another session owns the station", now
                    )
                elif len(self._lifecycle_queue) >= MAX_LIFECYCLE_REQUESTS:
                    receipt = self._new_receipt_locked(
                        request_id, name, "rejected", "QUEUE_FULL",
                        "Lifecycle queue is full", now
                    )
                else:
                    if self._owner_session_id is None:
                        self._owner_session_id = session_handle.session_id
                        self._owner_generation += 1
                    self._lifecycle_queue.append((request_id, action))
                    receipt = self._new_receipt_locked(
                        request_id, name, "queued", "QUEUED",
                        "Lifecycle request queued", now
                    )
                self._publish_ingress_locked()
                return receipt

            receipt = self._new_receipt_locked(
                request_id, name, "rejected", "INVALID_ACTION",
                "Unrecognized station action", now
            )
            self._publish_ingress_locked()
            return receipt

    def dispatch_authority(self) -> DispatchAuthority:
        """Return only bounded ingress authority metadata for future A03 wiring."""
        with self._condition:
            return DispatchAuthority(
                owner_generation=self._owner_generation,
                expires_at_s=self._owner_deadline_s,
                revoked=(
                    not self._input_enabled
                    or self._priority_stop_pending
                    or self._stop_in_progress
                    or self._lifecycle_in_progress
                ),
                stop_pending=self._priority_stop_pending or self._stop_in_progress,
            )

    def _ensure_core(self) -> None:
        if self._core is not None:
            return
        self._core = JointCore(
            self._specs,
            max_reference_gap_s=self.max_reference_gap_s,
            feedback_max_age_s=self.feedback_max_age_s,
            max_window_s=self.max_window_s,
            clock=self._clock,
        )
        self._timing = StationTimingTracker(
            StationTimingConfig(nominal_period_s=self.slot_period_s)
        )
        self._coordinator = StationStepCoordinator(
            self._core,
            self._bus,
            self._timing,
            clock=self._clock,
            deadline_s=self.exchange_deadline_s,
        )

    def _bind_executor(self, mode: str) -> None:
        ident = threading.get_ident()
        with self._condition:
            if self._execution_mode is None:
                self._execution_mode = mode
                self._executor_thread_id = ident
            elif self._execution_mode != mode or self._executor_thread_id != ident:
                raise RuntimeError("Core execution is confined to its bound executor")

    def _assert_executor(self) -> None:
        if self._executor_thread_id != threading.get_ident():
            raise RuntimeError("Core operation attempted outside the bound executor")

    def step(self, *, missed_slots: int = 0) -> LoopStepRecord:
        """Run one deterministic manual step on the thread that first owns it."""
        self._bind_executor("manual")
        return self._step_once(missed_slots=missed_slots)

    def _take_priority_stop(self) -> str | None:
        with self._condition:
            if not self._priority_stop_pending:
                return None
            reason = self._priority_stop_reason or "operator_stop"
            self._priority_stop_pending = False
            self._priority_stop_reason = None
            self._stop_in_progress = True
            self._publish_ingress_locked()
            return reason

    def _take_lifecycle(self) -> tuple[int, object] | None:
        with self._condition:
            if not self._lifecycle_queue:
                return None
            self._lifecycle_in_progress = True
            return self._lifecycle_queue.popleft()

    def _take_input(self) -> tuple[
        tuple[int, JogIntent, InputTicket] | None, bool, bool, bool, bool
    ]:
        with self._condition:
            pending = self._pending_intent
            self._pending_intent = None
            neutral = self._neutral_event_pending
            self._neutral_event_pending = False
            release = self._release_capture_pending
            release_neutral = self._release_neutral_pending
            self._release_capture_pending = False
            self._release_neutral_pending = False
            edge = self._new_deadman_edge_pending
            self._new_deadman_edge_pending = False
            return pending, neutral, release, release_neutral, edge

    def _set_stop_confirmation(self, records: tuple, started_at_s: float) -> None:
        assert self._core is not None
        core_snapshot = self._core.snapshot()
        checked_at_s = self._now()
        for motor_id in self._per_joint_stop_confirmed:
            self._per_joint_stop_confirmed[motor_id] = False
        index_by_id = {spec.motor_id: index for index, spec in enumerate(self._specs)}
        for record in records:
            index = index_by_id.get(record.motor_id)
            if index is None:
                continue
            status = core_snapshot.joints[index]
            timestamp = record.feedback_timestamp_s
            self._per_joint_stop_confirmed[record.motor_id] = bool(
                record.outcome == "OK"
                and record.feedback_received
                and timestamp is not None
                and timestamp >= started_at_s
                and timestamp <= checked_at_s
                and checked_at_s - timestamp <= self.feedback_max_age_s
                and status.valid
                and status.received_at == timestamp
                and status.health is not None
                and status.health.mode == 0
            )

    def _execute_stop(self, reason: str) -> None:
        assert self._core is not None and self._coordinator is not None
        with self._condition:
            self._stop_in_progress = True
            self._input_enabled = False
            self._owner_deadline_s = None
            self._ticket = None
            self._latest_intent = None
            self._latest_intent_expiry_s = None
            self._pending_intent = None
            self._publish_ingress_locked()
        self._hold_energized = False
        self._holding_position = False
        self._hold_targets = None
        self._current_core_owner = None
        self._needs_neutral_and_edge = True
        self._neutral_seen = False
        self._per_joint_stop_confirmed = {motor_id: False for motor_id in (0, 1, 2)}
        try:
            state = self._core.snapshot().state
            if state in (State.DISCONNECTED, State.CONNECTING):
                self._input_phase = "disconnected"
                return
            self._core.stop()
            self._input_phase = (
                "fault" if self._core.snapshot().state is State.FAULT else "stopped"
            )
            started = self._now()
            records = self._coordinator.check_step()
            self._set_stop_confirmation(records, started)
            if self._core.snapshot().state is State.FAULT:
                self._input_phase = "fault"
        finally:
            with self._condition:
                self._stop_in_progress = False
                self._publish_ingress_locked()
            self._publish()

    def _execute_close(self, request_id: int) -> bool:
        assert self._core is not None
        self._close_attempted = True
        try:
            close = getattr(self._bus, "close", None)
            if close is None:
                closed = getattr(self._bus, "is_open", None) is False
            else:
                close_result = close()
                closed = (
                    close_result is not False
                    and getattr(self._bus, "is_open", None) is False
                )
        except Exception:
            closed = False
        if closed:
            self._close_confirmed = True
            self._close_unconfirmed = False
            self._transport_closed = True
            self._core.disconnect()
            self._current_core_owner = None
            self._input_phase = "disconnected"
            self._connection_phase = "disconnected"
        else:
            self._close_confirmed = False
            self._close_unconfirmed = True
        with self._condition:
            self._close_completed_id = max(self._close_completed_id, request_id)
            self._condition.notify_all()
        self._publish()
        return closed

    def _pending_close_id(self) -> int | None:
        with self._condition:
            if self._close_request_id > self._close_completed_id:
                return self._close_request_id
            return None

    def _step_once(self, *, missed_slots: int = 0) -> LoopStepRecord:
        self._assert_executor()
        if type(missed_slots) is not int or missed_slots < 0:
            raise ValueError("missed_slots must be a non-negative integer")
        self._ensure_core()
        assert self._core is not None and self._coordinator is not None

        now = self._now()
        with self._condition:
            expired = (
                self._input_enabled
                and self._owner_deadline_s is not None
                and now >= self._owner_deadline_s
            )
            if expired:
                self._request_stop_locked("owner_lease_expired", now)
        reason = self._take_priority_stop()
        close_id = self._pending_close_id()
        if reason is not None or close_id is not None:
            self._execute_stop(reason or "station_close")
            if close_id is not None:
                self._execute_close(close_id)
            return self._idle_step(missed_slots)

        lifecycle = self._take_lifecycle()
        armed_now = False
        if lifecycle is not None:
            request_id, action = lifecycle
            try:
                armed_now = self._handle_lifecycle_action(request_id, action)
            finally:
                with self._condition:
                    self._lifecycle_in_progress = False
                    self._publish_ingress_locked()

        now = self._now()
        with self._condition:
            expired = (
                self._input_enabled
                and self._owner_deadline_s is not None
                and now >= self._owner_deadline_s
            )
            if expired:
                self._request_stop_locked("owner_lease_expired", now)
        reason = self._take_priority_stop()
        close_id = self._pending_close_id()
        if reason is not None or close_id is not None:
            self._execute_stop(reason or "station_close")
            if close_id is not None:
                self._execute_close(close_id)
            return self._idle_step(missed_slots)

        pending, neutral_event, release_event, release_neutral, edge_event = self._take_input()
        if neutral_event:
            self._neutral_seen = True
        if release_event:
            self._capture_release_hold()
            if release_neutral:
                self._neutral_seen = True
        if pending is not None and not armed_now:
            self._apply_intent(pending, edge_event)
        elif pending is None and not armed_now:
            self._refresh_active_goal()

        now = self._now()
        with self._condition:
            expired = (
                self._input_enabled
                and self._owner_deadline_s is not None
                and now >= self._owner_deadline_s
            )
            if expired:
                self._request_stop_locked("owner_lease_expired", now)
        reason = self._take_priority_stop()
        close_id = self._pending_close_id()
        if reason is not None or close_id is not None:
            self._execute_stop(reason or "station_close")
            if close_id is not None:
                self._execute_close(close_id)
            return self._idle_step(missed_slots)

        core_snapshot = self._core.snapshot()
        core_state = core_snapshot.state
        if core_state is State.READY:
            # READY remains live only while fresh mode 0 telemetry continues.
            self._coordinator.check_step()
            record = self._idle_step(missed_slots)
        elif core_state in (State.ARMED, State.MOVING):
            refs = core_snapshot.confirmed_references
            if not refs or any(ref is None or now <= ref.sample_time_s for ref in refs):
                record = self._idle_step(missed_slots)
            else:
                record = self._coordinator.step(missed_slots=missed_slots)
        else:
            record = self._coordinator.step(missed_slots=missed_slots)

        if any(tx.plan_id is not None for tx in record.transactions):
            self._per_joint_stop_confirmed = {motor_id: False for motor_id in (0, 1, 2)}
        if self._core.snapshot().state is State.FAULT:
            self._hold_energized = False
            self._holding_position = False
            self._input_phase = "fault"
            with self._condition:
                self._request_stop_locked("core_fault", now)
        reason = self._take_priority_stop()
        close_id = self._pending_close_id()
        if reason is not None or close_id is not None:
            self._execute_stop(reason or "station_close")
            if close_id is not None:
                self._execute_close(close_id)
        self._publish()
        return record

    def _idle_step(self, missed_slots: int) -> LoopStepRecord:
        assert self._core is not None and self._timing is not None
        started = self._now()
        self._timing.start_cycle(started)
        self._core.tick()
        ended = self._now()
        ages = self._core.snapshot().feedback_ages_s
        return self._timing.end_cycle(
            ended,
            feedback_ages=ages,
            feedback_timestamps=(),
            transactions=(),
            missed_slots=missed_slots,
        )

    def _ready_anchor_is_stale(self, snapshot: CoreSnapshot, now: float) -> bool:
        refs = snapshot.confirmed_references
        if not refs or any(ref is None for ref in refs):
            return True
        if any(
            age is None or age >= self.feedback_max_age_s
            for age in snapshot.feedback_ages_s
        ):
            return True
        return any(
            now - ref.sample_time_s >= self.max_reference_gap_s
            for ref in refs
            if ref is not None
        )

    def _refresh_ready_anchor(self):
        """Use the accepted Stop/check transitions to refresh a READY anchor."""
        assert self._core is not None and self._coordinator is not None
        stopped = self._core.stop()
        if not stopped.accepted:
            return stopped
        with self._condition:
            connection_id = self._owner_session_id or "fixture"
        self._current_core_owner = self._core.claim_owner(connection_id)
        checking = self._core.begin_check()
        if not checking.accepted:
            return checking
        started = self._now()
        records = self._coordinator.check_step()
        self._set_stop_confirmation(records, started)
        checked = self._core.checked()
        self._input_phase = "ready" if checked.accepted else "check_failed"
        return checked

    def _handle_lifecycle_action(self, request_id: int, action: object) -> bool:
        assert self._core is not None and self._coordinator is not None
        now = self._now()
        name = self._action_name(action)
        if isinstance(action, ConnectAction):
            if action.source_kind == "physical":
                if self._core.snapshot().state is not State.DISCONNECTED:
                    self._finish_receipt(request_id, name, "rejected", "INVALID_STATE", "Disconnect the fixture before physical commissioning")
                else:
                    valid, errors = validate_physical_draft(action.draft)
                    self._commissioning_blocked = True
                    self._connection_phase = "physical_commissioning"
                    self._commissioning_reasons = (
                        tuple(errors)
                        if not valid
                        else ("Physical connection is not implemented in this phase",)
                    )
                    self._finish_receipt(
                        request_id,
                        name,
                        "rejected",
                        "COMMISSIONING_BLOCKED" if not valid else "COMMISSIONING_REQUIRED",
                        "Physical connection remains commissioning blocked",
                    )
            elif action.source_kind != "fixture":
                self._finish_receipt(request_id, name, "rejected", "INVALID_SOURCE", "Unknown source kind")
            elif self._transport_closed or self._core.snapshot().state is not State.DISCONNECTED:
                self._finish_receipt(request_id, name, "rejected", "INVALID_STATE", "Fixture cannot connect in this state")
            else:
                self._core.begin_connect()
                decision = self._core.connected(SourceIdentity("fixture", "arm-fixture", 1))
                if decision.accepted:
                    self._current_core_owner = self._core.claim_owner(self._owner_session_id or "fixture")
                    self._per_joint_stop_confirmed = {
                        motor_id: False for motor_id in (0, 1, 2)
                    }
                    self._connection_phase = "fixture"
                    self._input_phase = "connected"
                    self._commissioning_blocked = False
                    self._commissioning_reasons = ()
                    self._finish_receipt(request_id, name, "accepted", "CONNECTED", "Connected to fixture")
                else:
                    self._finish_receipt(request_id, name, "rejected", decision.code.value, "Fixture connect rejected")
        elif isinstance(action, CheckAction):
            state = self._core.snapshot().state
            if state not in (State.CONNECTED, State.STOPPED, State.FAULT):
                self._finish_receipt(request_id, name, "rejected", "INVALID_STATE", "Core is not checkable")
            else:
                self._current_core_owner = self._core.claim_owner(self._owner_session_id or "fixture")
                decision = self._core.begin_check(acknowledge_fault=action.acknowledge_fault)
                if not decision.accepted:
                    self._finish_receipt(request_id, name, "rejected", decision.code.value, "Check rejected")
                else:
                    started = self._now()
                    records = self._coordinator.check_step()
                    self._set_stop_confirmation(records, started)
                    checked = self._core.checked()
                    if checked.accepted:
                        self._input_phase = "ready"
                        self._finish_receipt(request_id, name, "accepted", "READY", "Fresh mode 0 check completed")
                    else:
                        self._input_phase = "check_failed"
                        self._finish_receipt(request_id, name, "rejected", checked.code.value, "Check did not satisfy Core")
        elif isinstance(action, ArmAction):
            snap = self._core.snapshot()
            with self._condition:
                self._arm_transition = True
                latest = self._latest_intent
                expiry = self._latest_intent_expiry_s
            if snap.state is not State.READY:
                code, message = "NOT_READY", "Arm requires READY state"
            elif not action.support_acknowledgment:
                code, message = "SUPPORT_ACK_REQUIRED", "Arm requires support acknowledgment"
            elif self._ready_anchor_is_stale(snap, now):
                refreshed = self._refresh_ready_anchor()
                if not refreshed.accepted:
                    code, message = refreshed.code.value, "Fresh Stop/check anchor was rejected"
                    snap = self._core.snapshot()
                else:
                    snap = self._core.snapshot()
                    code, message = "", ""
            else:
                code, message = "", ""
            if not code and latest is not None and (expiry is None or now < expiry) and (
                latest.deadman or any(axis != 0.0 for axis in latest.axes)
            ):
                code, message = "INPUT_NOT_NEUTRAL", "Arm requires released neutral input"
            elif not code and any(not joint.healthy for joint in snap.joints):
                code, message = "UNHEALTHY", "Arm requires healthy feedback"
            elif not code:
                arm = self._core.arm(self._current_core_owner)
                if not arm.accepted:
                    code, message = arm.code.value, "Arm rejected by Core"
                else:
                    measured = tuple(
                        JointTarget(
                            q_rad=joint.sample.q_rad,
                            dq_rad_s=0.0,
                            tau_nm=0.0,
                            kp=SYNTHETIC_KP,
                            kd=SYNTHETIC_KD,
                        )
                        for joint in self._core.snapshot().joints
                        if joint.sample is not None
                    )
                    if len(measured) != len(self._specs):
                        code, message = "OBSERVATIONS_INCOMPLETE", "Measured hold is incomplete"
                    else:
                        decision = self._submit_targets(measured)
                        if not decision.accepted:
                            code, message = decision.code.value, "Measured hold was rejected by Core"
                        else:
                            armed_at = self._now()
                            with self._condition:
                                stop_won = self._priority_stop_pending or self._stop_in_progress
                                if not stop_won:
                                    self._hold_targets = measured
                                    self._holding_position = True
                                    self._hold_energized = True
                                    self._input_phase = "awaiting_neutral"
                                    self._needs_neutral_and_edge = True
                                    self._neutral_seen = False
                                    self._owner_generation += 1
                                    self._ticket = None
                                    self._pending_intent = None
                                    self._latest_intent = None
                                    self._latest_intent_expiry_s = None
                                    self._deadman_active = False
                                    self._new_deadman_edge_pending = False
                                    self._neutral_event_pending = False
                                    self._release_capture_pending = False
                                    self._release_neutral_pending = False
                                    self._input_enabled = True
                                    self._owner_deadline_s = armed_at + self.input_lease_s
                                    self._publish_ingress_locked()
                            if stop_won:
                                code, message = "STOP_PREEMPTED", "Stop preempted Arm before input authority was granted"
                            else:
                                self._finish_receipt(request_id, name, "accepted", "ARMED", "Measured hold admitted")
                                with self._condition:
                                    self._arm_transition = False
                                return True
            if code in ("OBSERVATIONS_INCOMPLETE", "INVALID_OWNER") or (
                code not in ("NOT_READY", "SUPPORT_ACK_REQUIRED", "INPUT_NOT_NEUTRAL", "UNHEALTHY", "STOP_PREEMPTED")
                and self._core.snapshot().state in (State.ARMED, State.MOVING)
            ):
                self._core.stop()
                stop_now = self._now()
                with self._condition:
                    self._request_stop_locked("arm_target_rejected", stop_now)
            with self._condition:
                self._arm_transition = False
            self._finish_receipt(request_id, name, "rejected", code, message)
        elif isinstance(action, DisconnectAction):
            state = self._core.snapshot().state
            if state is not State.DISCONNECTED:
                self._core.stop()
                started = self._now()
                records = self._coordinator.check_step()
                self._set_stop_confirmation(records, started)
                self._core.disconnect()
            disconnected_at = self._now()
            with self._condition:
                self._owner_generation += 1
                self._revoke_ingress_locked(
                    disconnected_at,
                    "DISCONNECTED",
                    "Lifecycle request was revoked by Disconnect",
                )
            self._current_core_owner = None
            self._hold_targets = None
            self._hold_energized = False
            self._holding_position = False
            self._input_phase = "disconnected"
            self._connection_phase = "disconnected"
            self._finish_receipt(request_id, name, "accepted", "DISCONNECTED", "Disconnected from fixture")
        else:
            self._finish_receipt(request_id, name, "rejected", "INVALID_ACTION", "Unsupported lifecycle request")
        return False

    def _submit_targets(self, targets: tuple[JointTarget, ...]):
        assert self._core is not None
        if self._current_core_owner is None:
            from joint_contract import Decision, DecisionCode

            return Decision(False, DecisionCode.INVALID_OWNER)
        window = self._core.issue_window(valid_for_s=self.max_window_s)
        self._next_core_sequence += 1
        target = Target(
            sequence=self._next_core_sequence,
            joints=targets,
            window=window,
            owner=self._current_core_owner,
        )
        return self._core.submit_target(target)

    def _capture_release_hold(self) -> None:
        assert self._core is not None
        now = self._now()
        refs = self._core.snapshot().confirmed_references
        if not refs or any(ref is None for ref in refs):
            with self._condition:
                self._request_stop_locked("release_without_complete_reference", now)
            return
        targets = tuple(
            JointTarget(
                q_rad=ref.q_rad,
                dq_rad_s=0.0,
                tau_nm=0.0,
                kp=SYNTHETIC_KP,
                kd=SYNTHETIC_KD,
            )
            for ref in refs
        )
        self._hold_targets = targets
        self._holding_position = True
        self._hold_energized = True
        self._input_phase = "holding"

    def _apply_intent(
        self,
        pending: tuple[int, JogIntent, InputTicket],
        fresh_edge: bool,
    ) -> None:
        request_id, intent, ticket = pending
        assert self._core is not None
        now = self._now()
        if now >= ticket.expires_at_s:
            self._finish_receipt(request_id, "JogIntent", "rejected", "TICKET_EXPIRED", "Input expired before execution")
            return
        state = self._core.snapshot().state
        if state not in (State.ARMED, State.MOVING):
            return
        if not intent.deadman:
            if all(axis == 0.0 for axis in intent.axes):
                self._neutral_seen = True
            self._input_phase = "holding" if self._hold_energized else "awaiting_neutral"
            if self._hold_targets is not None:
                decision = self._submit_targets(self._hold_targets)
                if not decision.accepted:
                    self._reject_target_and_stop(request_id, decision.code.value)
                    return
            self._finish_receipt(request_id, "JogIntent", "accepted", "HOLDING", "Released input keeps the confirmed goal")
            return

        if self._needs_neutral_and_edge:
            if not (self._neutral_seen and fresh_edge):
                self._input_phase = "awaiting_neutral"
                if self._hold_targets is not None:
                    self._submit_targets(self._hold_targets)
                self._finish_receipt(request_id, "JogIntent", "rejected", "NEUTRAL_REQUIRED", "A fresh neutral release and deadman edge are required")
                return
            self._needs_neutral_and_edge = False
            self._neutral_seen = False

        snapshot = self._core.snapshot()
        refs = snapshot.confirmed_references
        if not refs or any(ref is None for ref in refs):
            self._reject_target_and_stop(request_id, "REFERENCE_INCOMPLETE")
            return
        goals: list[JointTarget] = []
        with self._condition:
            speed_rad_s = self._selected_speed_rad_s
        for ref, axis in zip(refs, intent.axes):
            dt = now - ref.sample_time_s
            if dt < 0.0:
                self._reject_target_and_stop(request_id, "CLOCK_REGRESSION")
                return
            if dt == 0.0:
                self._input_phase = "awaiting_elapsed"
                self._finish_receipt(
                    request_id,
                    "JogIntent",
                    "rejected",
                    "NO_ELAPSED_TIME",
                    "Every confirmed reference needs positive elapsed time",
                )
                return
            goals.append(
                JointTarget(
                    q_rad=ref.q_rad + float(axis) * speed_rad_s * dt,
                    dq_rad_s=0.0,
                    tau_nm=0.0,
                    kp=SYNTHETIC_KP,
                    kd=SYNTHETIC_KD,
                )
            )
        targets = tuple(goals)
        decision = self._submit_targets(targets)
        if not decision.accepted:
            self._reject_target_and_stop(request_id, decision.code.value)
            return
        moving = any(axis != 0.0 for axis in intent.axes)
        self._holding_position = not moving
        if not moving:
            self._hold_targets = targets
        self._hold_energized = True
        self._input_phase = "jogging" if moving else "holding"
        self._finish_receipt(request_id, "JogIntent", "accepted", "ACCEPTED", "Core accepted the bounded input goal")

    def _reject_target_and_stop(self, request_id: int, code: str) -> None:
        assert self._core is not None
        self._finish_receipt(request_id, "JogIntent", "rejected", code, "Core rejected the requested goal")
        now = self._now()
        with self._condition:
            self._request_stop_locked("goal_rejected", now)

    def _refresh_active_goal(self) -> None:
        assert self._core is not None
        if self._core.snapshot().state not in (State.ARMED, State.MOVING):
            return
        if self._holding_position and self._hold_targets is not None:
            targets = self._hold_targets
        else:
            admitted = self._core.snapshot().admitted_target
            if admitted is None:
                return
            targets = admitted.joints
        decision = self._submit_targets(targets)
        if not decision.accepted:
            now = self._now()
            with self._condition:
                self._request_stop_locked("goal_refresh_rejected", now)

    def _publish(self) -> None:
        if self._core is None or self._timing is None:
            with self._condition:
                self._published = replace(
                    self._published,
                    input_phase=(
                        "executor_failed"
                        if self._executor_failed
                        else self._published.input_phase
                    ),
                    hold_energized=(
                        False if self._executor_failed else self._published.hold_energized
                    ),
                    executor_failed=self._executor_failed,
                    stop_pending=self._priority_stop_pending or self._stop_in_progress,
                    owner_session_id=self._owner_session_id,
                    owner_generation=self._owner_generation,
                    latest_receipt=self._latest_receipt,
                    device_epoch=self._device_epoch,
                )
            return
        core = self._core.snapshot()
        timing = self._timing.snapshot()
        if core.state is State.DISCONNECTED:
            samples = (None, None, None)
            healths = (None, None, None)
            ages = (None, None, None)
        else:
            samples = tuple(joint.sample for joint in core.joints)
            healths = tuple(joint.health for joint in core.joints)
            ages = core.feedback_ages_s
        admitted = core.admitted_target.joints if core.admitted_target is not None else None
        records = tuple(
            None if record is None else DispatchRecordView(
                record.sequence, record.target, record.dispatched_at_s
            )
            for record in core.dispatched_records
        )
        attempts = tuple(
            None if attempt is None else DispatchAttemptView(
                attempt.sequence, attempt.target, attempt.result, attempt.started_at_s
            )
            for attempt in core.dispatch_attempts
        )
        stop_logical = core.state in (
            State.STOPPED, State.FAULT, State.DISCONNECTED
        )
        with self._condition:
            self._published = ArmStationSnapshot(
                lifecycle_state=core.state.value,
                connection_phase=self._connection_phase,
                source=core.source,
                requested_axes=self._latest_intent.axes if self._latest_intent else None,
                admitted_goal=admitted,
                dispatched_reference=tuple(
                    None if record is None else record.target for record in records
                ),
                dispatch_records=records,
                dispatch_attempts=attempts,
                confirmed_reference=core.confirmed_references,
                measured_sample=samples,
                measured_health=healths,
                feedback_ages_s=ages,
                faults=core.faults,
                fault_latched=core.fault_latched,
                owner_session_id=self._owner_session_id,
                owner_generation=self._owner_generation,
                input_phase=self._input_phase,
                hold_energized=self._hold_energized,
                stop_logical=stop_logical,
                stop_confirmed=all(self._per_joint_stop_confirmed.values()),
                stop_pending=self._priority_stop_pending or self._stop_in_progress,
                per_joint_stop_confirmed=tuple(
                    self._per_joint_stop_confirmed[motor_id] for motor_id in (0, 1, 2)
                ),
                close_attempted=self._close_attempted,
                close_confirmed=self._close_confirmed,
                close_unconfirmed=self._close_unconfirmed,
                executor_failed=self._executor_failed,
                timing_counters=timing.counters,
                timing_snapshot=timing,
                latest_receipt=self._latest_receipt,
                device_epoch=self._device_epoch,
                selected_speed_rad_s=self._selected_speed_rad_s,
                commissioning_blocked=self._commissioning_blocked,
                commissioning_reasons=self._commissioning_reasons,
            )

    def snapshot(self) -> ArmStationSnapshot:
        """Return the last immutable published view without reading Core."""
        with self._condition:
            return self._published

    def run_steps(self, count: int) -> list[LoopStepRecord]:
        if type(count) is not int or count < 1:
            raise ValueError("count must be a positive integer")
        return [self.step() for _ in range(count)]

    def start_loop(self) -> None:
        with self._condition:
            if self._execution_mode is not None or self._loop_thread is not None:
                raise RuntimeError("Station already has an executor")
            self._execution_mode = "background"
            self._loop_running.set()
            self._loop_thread = threading.Thread(
                target=self._loop_worker, daemon=True, name="arm-station-executor"
            )
            self._loop_thread.start()

    def _loop_worker(self) -> None:
        with self._condition:
            self._executor_thread_id = threading.get_ident()
        nominal = self.slot_period_s
        try:
            next_slot = self._now()
            while self._loop_running.is_set():
                now = self._now()
                if now < next_slot:
                    time.sleep(next_slot - now)
                    now = self._now()
                missed = 0
                if now > next_slot:
                    assert self._timing is not None or self._core is None
                    if self._timing is not None:
                        missed, _ = self._timing.calculate_slot_skip(now, next_slot)
                record = self._step_once(missed_slots=missed)
                if self._close_confirmed:
                    break
                if self._loop_stop_requested:
                    break
                if self._close_unconfirmed:
                    self._wait_for_close_retry(self._close_completed_id)
                    continue
                next_slot = record.started_s + nominal
        except Exception:
            self._record_executor_failure()
        finally:
            self._loop_running.clear()
            if not self._executor_failed:
                self._publish()

    def _wait_for_close_retry(self, completed_id: int) -> None:
        with self._condition:
            self._condition.wait_for(
                lambda: self._close_request_id > completed_id
                or self._loop_stop_requested,
                timeout=None,
            )

    def _record_executor_failure(self) -> None:
        self._executor_failed = True
        self._input_phase = "executor_failed"
        self._hold_energized = False
        self._holding_position = False
        self._per_joint_stop_confirmed = {motor_id: False for motor_id in (0, 1, 2)}
        with self._condition:
            self._request_stop_locked("executor_failure", self._last_time_s)
            cached = self._published
        stop_accepted = False
        stopped_state: State | None = None
        if self._core is not None:
            try:
                stop_accepted = self._core.stop().accepted
                if stop_accepted:
                    stopped_state = self._core.snapshot().state
            except Exception:
                # Keep the generic failed and pending status without exposing details.
                self._input_phase = "executor_failed"
        if stop_accepted:
            self._current_core_owner = None
        next_state = cached.lifecycle_state
        if stop_accepted and cached.lifecycle_state != State.DISCONNECTED.value:
            if stopped_state is State.FAULT or cached.fault_latched:
                next_state = State.FAULT.value
            else:
                next_state = State.STOPPED.value
        with self._condition:
            self._published = replace(
                self._published,
                lifecycle_state=next_state,
                input_phase="executor_failed",
                hold_energized=False,
                stop_logical=(
                    next_state in (State.STOPPED.value, State.FAULT.value, State.DISCONNECTED.value)
                ),
                stop_confirmed=False,
                per_joint_stop_confirmed=(False, False, False),
                executor_failed=True,
                stop_pending=True,
                owner_session_id=self._owner_session_id,
                owner_generation=self._owner_generation,
                latest_receipt=self._latest_receipt,
            )

    def stop_loop(self) -> None:
        now = self._now()
        with self._condition:
            if self._execution_mode != "background":
                return
            self._loop_stop_requested = True
            self._request_stop_locked("loop_stop", now)
            self._condition.notify_all()
            thread = self._loop_thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=BACKGROUND_CLOSE_WAIT_S)

    def close(self) -> bool:
        """Queue Stop and close on the executor; retain ownership on failure."""
        now = self._now()
        with self._condition:
            if self._close_confirmed:
                return True
            self._close_attempted = True
            self._close_request_id += 1
            request_id = self._close_request_id
            self._request_stop_locked("station_close", now)
            mode = self._execution_mode
            if mode == "background":
                self._condition.notify_all()
                thread = self._loop_thread
            else:
                thread = None
        if mode == "background":
            if thread is None:
                return False
            with self._condition:
                self._condition.wait_for(
                    lambda: self._close_completed_id >= request_id,
                    timeout=BACKGROUND_CLOSE_WAIT_S,
                )
                return self._close_completed_id >= request_id and self._close_confirmed
        if mode is None:
            self._bind_executor("manual")
        elif self._executor_thread_id != threading.get_ident():
            return False
        self._ensure_core()
        reason = self._take_priority_stop()
        self._execute_stop(reason or "station_close")
        self._execute_close(request_id)
        return self._close_confirmed

```

### arm_fixture.py SHA256 36aa5dba2448c6ffdd7e5515760571c8ce4386fdd8a3579e7815f169f5abfd97
```python
"""Three-ID pyserial-shaped packet fixture and synthetic arm specification.

Simulates IDs 0, 1, 2 with canonical CRC feedback and recorded writes.
Deterministic time and packet behavior for unit and integration testing.
Never imports or opens physical serial devices.
"""

from collections import deque
from collections.abc import Callable
import json
import math
from pathlib import Path
import struct
import time

from im6014_codec import RATIO, crc32, decode_command
from joint_contract import JointSpec
from joint_mapping import JointMap
from joint_protection import ProtectionPolicy

__all__ = (
    "DEFAULT_SYNTHETIC_PROTECTION",
    "J1_MAX_RAD",
    "J1_MIN_RAD",
    "J2_MAX_RAD",
    "J2_MIN_RAD",
    "J3_MAX_RAD",
    "J3_MIN_RAD",
    "SYNTHETIC_A_MAX",
    "SYNTHETIC_KD",
    "SYNTHETIC_KP",
    "SYNTHETIC_MAX_EFFORT",
    "SYNTHETIC_MAX_LEAD",
    "SYNTHETIC_RATIO",
    "SYNTHETIC_V_MAX",
    "ArmPacketFixture",
    "create_synthetic_arm_specs",
    "make_feedback_packet",
)

# The fixture's J1 range follows the generated model artifact. J2/J3 remain
# explicitly synthetic because the CAD source does not establish their travel.
SYNTHETIC_RATIO = RATIO


def _j1_model_bounds() -> tuple[float, float]:
    model = json.loads(
        Path(__file__).with_name("arm_assets").joinpath("model.json").read_text(
            encoding="utf-8"
        )
    )
    joint = next(
        item for item in model["joints"]
        if item.get("role") == "base" and item.get("motor_id") == 0
    )
    limits = joint["limits_deg"]
    if (
        type(limits) is not list
        or len(limits) != 2
        or any(isinstance(value, bool) or not isinstance(value, (int, float)) for value in limits)
        or not all(math.isfinite(float(value)) for value in limits)
        or limits[0] >= limits[1]
    ):
        raise ValueError("generated model must define finite ordered J1 limits")
    return math.radians(float(limits[0])), math.radians(float(limits[1]))


J1_MIN_RAD, J1_MAX_RAD = _j1_model_bounds()
# Synthetic fixture bounds only; do not use as physical travel limits.
J2_MIN_RAD = -2.356194490192345
J2_MAX_RAD = 2.356194490192345
J3_MIN_RAD = -2.356194490192345
J3_MAX_RAD = 2.356194490192345
SYNTHETIC_V_MAX = 2.0
SYNTHETIC_A_MAX = 5.0
SYNTHETIC_MAX_LEAD = 0.5
SYNTHETIC_MAX_EFFORT = 3.5
SYNTHETIC_KP = 3.0
SYNTHETIC_KD = 0.2

DEFAULT_SYNTHETIC_PROTECTION = ProtectionPolicy(
    driver_trip_c=85.0,
    driver_reset_c=70.0,
    winding_trip_c=105.0,
    winding_reset_c=90.0,
    continuous_effort_nm=1.0,
    continuous_dwell_s=1.0,
    recovery_dwell_s=0.5,
)


def create_synthetic_arm_specs() -> tuple[JointSpec, ...]:
    """Create conservative synthetic joint specifications for fixture use."""
    return (
        JointSpec(
            name="J1 base",
            motor_id=0,
            mapping=JointMap(reduction=1.0, direction=1, zero_output_rad=0.0),
            q_min_rad=J1_MIN_RAD,
            q_max_rad=J1_MAX_RAD,
            v_max_rad_s=SYNTHETIC_V_MAX,
            a_max_rad_s2=SYNTHETIC_A_MAX,
            max_lead_rad=SYNTHETIC_MAX_LEAD,
            max_effort_nm=SYNTHETIC_MAX_EFFORT,
            limits_provenance="synthetic fixture: J1 +/- pi/2 bound",
            protection=DEFAULT_SYNTHETIC_PROTECTION,
        ),
        JointSpec(
            name="J2 shoulder",
            motor_id=1,
            mapping=JointMap(reduction=1.0, direction=1, zero_output_rad=0.0),
            q_min_rad=J2_MIN_RAD,
            q_max_rad=J2_MAX_RAD,
            v_max_rad_s=SYNTHETIC_V_MAX,
            a_max_rad_s2=SYNTHETIC_A_MAX,
            max_lead_rad=SYNTHETIC_MAX_LEAD,
            max_effort_nm=SYNTHETIC_MAX_EFFORT,
            limits_provenance="synthetic fixture: shoulder finite bound",
            protection=DEFAULT_SYNTHETIC_PROTECTION,
        ),
        JointSpec(
            name="J3 elbow",
            motor_id=2,
            mapping=JointMap(reduction=1.0, direction=1, zero_output_rad=0.0),
            q_min_rad=J3_MIN_RAD,
            q_max_rad=J3_MAX_RAD,
            v_max_rad_s=SYNTHETIC_V_MAX,
            a_max_rad_s2=SYNTHETIC_A_MAX,
            max_lead_rad=SYNTHETIC_MAX_LEAD,
            max_effort_nm=SYNTHETIC_MAX_EFFORT,
            limits_provenance="synthetic fixture: elbow finite bound",
            protection=DEFAULT_SYNTHETIC_PROTECTION,
        ),
    )


def make_feedback_packet(
    motor_id: int,
    mode: int = 0,
    timeout: bool = False,
    driver_c: int = 25,
    winding_c: int = 30,
    voltage_v: float = 36.0,
    torque_nm: float = 0.0,
    rpm: float = 0.0,
    position_rad: float = 0.0,
    errors: int = 0,
    warnings: int = 0,
) -> bytes:
    """Generate a canonical 26-byte IM6014 feedback frame with valid CRC32."""
    ratio = RATIO
    m = (motor_id & 0x0F) | ((mode & 0x07) << 4) | ((1 if timeout else 0) << 7)
    td = max(-128, min(127, int(round(driver_c))))
    tw = max(0, min(255, int(round(winding_c))))
    v = max(0, min(255, int(round(voltage_v * 2))))
    raw_torque = max(-32768, min(32767, int(round(torque_nm * 2560.0 / ratio))))
    raw_rpm = max(-32768, min(32767, int(round(rpm * 64.0 * ratio / 60.0))))
    raw_pos = max(
        -2147483648,
        min(2147483647, int(round(position_rad * 32768.0 * ratio / math.tau))),
    )
    flags = (warnings & 0x07) << 13

    body = struct.pack(
        "<BbBBhhiIHBB",
        m,
        td,
        tw,
        v,
        raw_torque,
        raw_rpm,
        raw_pos,
        errors & 0xFFFFFFFF,
        flags,
        0,
        0,
    )
    crc = crc32(body)
    return b"\xfc\xee" + body + struct.pack("<I", crc)


class ArmPacketFixture:
    """Deterministic pyserial-shaped three-motor packet fixture.

    Never accesses physical hardware or serial ports. Decodes commands
    using canonical im6014_codec and generates canonical feedback frames.
    """

    def __init__(self, *, clock: Callable[[], float] | None = None) -> None:
        self.clock = time.monotonic if clock is None else clock
        self.is_open = True
        self.timeout = 0.05
        self.write_timeout = 0.05
        self._rx_buffer = bytearray()
        self._writes: deque[bytes] = deque(maxlen=256)
        self._states = {
            i: {
                "mode": 0,
                "position_rad": 0.0,
                "rpm": 0.0,
                "torque_nm": 0.0,
                "driver_c": 25,
                "winding_c": 30,
                "errors": 0,
                "warnings": 0,
                "timeout": False,
            }
            for i in (0, 1, 2)
        }
        self.fail_close: bool = False
        self.inject_partial_write: int | None = None
        self.inject_partial_write_ids: set[int] = set()
        self.inject_partial_write_bytes: int = 10
        self.inject_write_error: Exception | None = None
        self.inject_write_error_ids: set[int] = set()
        self.inject_timeout_ids: set[int] = set()
        self.inject_no_reply_ids: set[int] = set()
        self.inject_reply_modes: dict[int, int] = {}
        self.inject_corrupt_crc_ids: set[int] = set()
        self.inject_corrupt_feedback_ids: set[int] = set()
        self.inject_stop_failure_ids: set[int] = set()
        self.inject_errors: dict[int, int] = {}
        self.inject_warnings: dict[int, int] = {}
        self.inject_timeouts: dict[int, bool] = {}
        self.inject_temperatures: dict[int, tuple[int, int]] = {}

    @property
    def writes(self) -> tuple[bytes, ...]:
        return tuple(self._writes)

    @property
    def in_waiting(self) -> int:
        return len(self._rx_buffer)

    @property
    def motor_states(self) -> dict[int, dict]:
        return {i: dict(self._states[i]) for i in self._states}

    def reset_input_buffer(self) -> None:
        self._rx_buffer.clear()

    def write(self, data: bytes | bytearray | memoryview) -> int:
        if not self.is_open:
            raise RuntimeError("Fake serial port is closed")
        packet = bytes(data)
        decoded = decode_command(packet)
        motor_id = decoded["motor_id"]
        mode = decoded["mode"]

        self._writes.append(packet)
        if self.inject_write_error is not None:
            raise self.inject_write_error
        if motor_id in self.inject_write_error_ids:
            raise RuntimeError("Injected fixture write failure")
        if self.inject_partial_write is not None:
            return self.inject_partial_write
        if motor_id in self.inject_partial_write_ids:
            return self.inject_partial_write_bytes

        if motor_id not in self._states:
            return len(packet)

        state = self._states[motor_id]

        if mode == 0:
            if motor_id in self.inject_stop_failure_ids:
                state["mode"] = 1
            else:
                state["mode"] = 0
                state["rpm"] = 0.0
                state["torque_nm"] = 0.0
        elif mode == 1:
            state["mode"] = 1
            state["position_rad"] = decoded["position_rad"]
            state["rpm"] = decoded["rpm"]
            state["torque_nm"] = decoded["torque_nm"]

        if motor_id in self.inject_timeout_ids or motor_id in self.inject_no_reply_ids:
            return len(packet)

        temps = self.inject_temperatures.get(
            motor_id, (state["driver_c"], state["winding_c"])
        )
        err = self.inject_errors.get(motor_id, state["errors"])
        warn = self.inject_warnings.get(motor_id, state["warnings"])
        tout = self.inject_timeouts.get(motor_id, state["timeout"])

        frame = make_feedback_packet(
            motor_id=motor_id,
            mode=self.inject_reply_modes.get(motor_id, state["mode"]),
            timeout=tout,
            driver_c=temps[0],
            winding_c=temps[1],
            voltage_v=36.0,
            torque_nm=state["torque_nm"],
            rpm=state["rpm"],
            position_rad=state["position_rad"],
            errors=err,
            warnings=warn,
        )

        if motor_id in self.inject_corrupt_crc_ids:
            frame = frame[:-4] + b"\x00\x00\x00\x00"
        if motor_id in self.inject_corrupt_feedback_ids:
            frame = b"\x00\x00" + frame[2:]

        self._rx_buffer.extend(frame)
        return len(packet)

    def read(self, size: int = 1) -> bytes:
        if not self.is_open:
            raise RuntimeError("Fake serial port is closed")
        size = max(0, int(size))
        count = min(size, len(self._rx_buffer))
        chunk = bytes(self._rx_buffer[:count])
        del self._rx_buffer[:count]
        return chunk

    def close(self) -> None:
        if self.fail_close:
            return
        self.is_open = False

```

### test_arm_station.py SHA256 3e5fdf8d76607b0dacfa16496cba6dc47e38f44f26d1ea9b7f80f9643b33f273
```python
"""Behavioral contracts for the offline ArmStation boundary.

These tests use only the packet fixture. They do not open serial devices or
claim per-write dispatch protection, which belongs to the later A03 unit.
"""

from dataclasses import FrozenInstanceError, replace
import math
import threading
import time
import unittest

from arm_fixture import (
    ArmPacketFixture,
    J1_MAX_RAD,
    J1_MIN_RAD,
    create_synthetic_arm_specs,
)
from arm_station import (
    ArmAction,
    ArmStation,
    ArmStationSnapshot,
    CheckAction,
    ConnectAction,
    DisconnectAction,
    JogIntent,
    PhysicalDraft,
    PhysicalJointDraft,
    StopAction,
    compute_zero_output,
    validate_physical_draft,
)
from im6014_codec import decode_command
from im6014_port import PortConfig
from joint_contract import State, WriteResult
from joint_protection import ProtectionPolicy


class DeterministicClock:
    def __init__(self, start: float = 0.0) -> None:
        self.value = float(start)

    def __call__(self) -> float:
        return self.value

    def advance(self, seconds: float) -> float:
        self.value += float(seconds)
        return self.value


class ArmStationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.clock = DeterministicClock(10.0)
        self.fixture = ArmPacketFixture(clock=self.clock)
        self.station = ArmStation(clock=self.clock, fixture=self.fixture)

    def connect_and_check(self, station: ArmStation | None = None):
        station = self.station if station is None else station
        session = station.register_session("owner")
        self.assertEqual(station.request(ConnectAction(), session).status, "queued")
        station.step()
        self.assertEqual(station.snapshot().lifecycle_state, State.CONNECTED.value)
        self.assertEqual(station.request(CheckAction(), session).status, "queued")
        station.step()
        self.assertEqual(station.snapshot().lifecycle_state, State.READY.value)
        return session

    def arm(self, session, *, elapsed: float = 0.020) -> None:
        if elapsed:
            self.clock.advance(elapsed)
        receipt = self.station.request(ArmAction(), session)
        self.assertEqual(receipt.status, "queued")
        self.station.step()
        self.assertIn(
            self.station.snapshot().lifecycle_state,
            (State.ARMED.value, State.MOVING.value),
        )
        self.assertTrue(self.station.snapshot().hold_energized)

    def input(self, session, sequence, axes, deadman):
        ticket = self.station.issue_ticket(session, sequence)
        return self.station.request(
            JogIntent(
                sequence=sequence,
                axes=axes,
                deadman=deadman,
                focus=True,
                device_epoch="fixture-device-1",
                ticket=ticket,
            ),
            session,
        )

    @staticmethod
    def mode_writes(fixture: ArmPacketFixture, mode: int) -> list[dict]:
        return [decode_command(packet) for packet in fixture.writes
                if decode_command(packet)["mode"] == mode]

    def valid_physical_draft(self) -> PhysicalDraft:
        protection = ProtectionPolicy(85, 70, 105, 90, 1.0, 1.0, 0.5)
        joints = tuple(
            PhysicalJointDraft(
                motor_id=motor_id,
                name=f"J{motor_id + 1}",
                direction=1,
                reference_joint_rad=0.5 if motor_id == 0 else 0.0,
                zero_output_rad=0.0,
                q_min_rad=-1.4 if motor_id == 0 else -10.0,
                q_max_rad=1.4 if motor_id == 0 else 10.0,
                v_max_rad_s=1.0,
                a_max_rad_s2=2.0,
                max_lead_rad=0.5,
                max_effort_nm=2.0,
                kp=3.0,
                kd=0.2,
                protection=protection,
                limits_provenance="operator-confirmed travel measurement",
            )
            for motor_id in range(3)
        )
        return PhysicalDraft(
            port_config=PortConfig("/dev/draft-only", 6_000_000, "DRAFT", 1),
            joints=joints,
            support_acknowledged=True,
            timeout_facts_acknowledged=True,
            allow_hardware_opt_in=True,
        )

    def test_startup_and_supported_timing_constructor(self) -> None:
        initial = self.station.snapshot()
        self.assertEqual(initial.lifecycle_state, State.DISCONNECTED.value)
        self.assertIsNone(initial.source)
        self.assertEqual(initial.measured_sample, (None, None, None))
        self.assertEqual(initial.measured_health, (None, None, None))
        self.assertEqual(initial.confirmed_reference, (None, None, None))
        self.assertFalse(initial.hold_energized)
        self.assertFalse(hasattr(self.station, "core"))
        self.assertEqual(self.fixture.writes, ())

        self.station.step()
        self.assertEqual(
            self.station._timing.config.nominal_period_s,
            self.station.slot_period_s,
        )

    def test_sessions_and_lifecycle_ingress_are_bounded(self) -> None:
        sessions = [self.station.register_session(f"s-{i}") for i in range(16)]
        with self.assertRaises(RuntimeError):
            self.station.register_session("overflow")

        owner, other = sessions[:2]
        queued = [self.station.request(ConnectAction(), owner) for _ in range(16)]
        self.assertTrue(all(receipt.status == "queued" for receipt in queued))
        overflow = self.station.request(ConnectAction(), owner)
        self.assertEqual(overflow.code, "QUEUE_FULL")

        stop = self.station.request(StopAction(), other)
        self.assertEqual(stop.code, "STOP_QUEUED")
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, State.DISCONNECTED.value)
        self.assertEqual(self.fixture.writes, ())
        self.assertFalse(self.station.snapshot().stop_pending)
        for receipt in queued:
            self.assertEqual(self.station._receipts[receipt.request_id].code, "STOP_PREEMPTED")

    def test_complete_fixture_lifecycle_and_three_axis_signs(self) -> None:
        session = self.connect_and_check()
        ready = self.station.snapshot()
        self.assertTrue(ready.stop_confirmed)
        self.assertEqual(ready.per_joint_stop_confirmed, (True, True, True))
        self.assertEqual(self.mode_writes(self.fixture, 1), [])

        self.arm(session)
        armed = self.station.snapshot()
        self.assertTrue(armed.hold_energized)
        self.assertEqual(armed.input_phase, "awaiting_neutral")

        self.input(session, 1, (0.0, 0.0, 0.0), False)
        self.station.step()
        self.clock.advance(0.020)
        self.input(session, 2, (1.0, 0.0, 0.0), True)
        self.station.step()
        writes = self.mode_writes(self.fixture, 1)[-3:]
        self.assertEqual([write["motor_id"] for write in writes], [0, 1, 2])
        self.assertGreater(writes[0]["position_rad"], 0.0)

        self.input(session, 3, (0.0, 0.0, 0.0), False)
        self.station.step()
        self.clock.advance(0.020)
        self.input(session, 4, (0.0, -1.0, 0.0), True)
        self.station.step()
        writes = self.mode_writes(self.fixture, 1)[-3:]
        self.assertLess(writes[1]["position_rad"], 0.0)

        self.input(session, 5, (0.0, 0.0, 0.0), False)
        self.station.step()
        self.clock.advance(0.020)
        self.input(session, 6, (0.0, 0.0, 1.0), True)
        self.station.step()
        writes = self.mode_writes(self.fixture, 1)[-3:]
        self.assertGreater(writes[2]["position_rad"], 0.0)
        self.assertEqual(self.station.snapshot().input_phase, "jogging")

        self.station.request(StopAction(), session)
        self.station.step()
        self.assertTrue(self.station.snapshot().stop_logical)
        self.assertTrue(self.station.snapshot().stop_confirmed)
        self.assertEqual(self.station.snapshot().per_joint_stop_confirmed, (True, True, True))

    def test_arm_same_timestamp_defers_mode1_until_real_elapsed_time(self) -> None:
        session = self.connect_and_check()
        mode1_before = len(self.mode_writes(self.fixture, 1))
        self.station.request(ArmAction(), session)
        self.station.step()

        snap = self.station.snapshot()
        self.assertEqual(snap.lifecycle_state, State.ARMED.value)
        self.assertTrue(snap.hold_energized)
        self.assertEqual(len(self.mode_writes(self.fixture, 1)), mode1_before)
        self.assertEqual(snap.faults, ())

        self.clock.advance(0.020)
        self.station.step()
        self.assertGreater(len(self.mode_writes(self.fixture, 1)), mode1_before)
        self.assertIn(
            self.station.snapshot().lifecycle_state,
            (State.ARMED.value, State.MOVING.value),
        )

    def test_arm_requires_observed_neutral_then_new_deadman_edge(self) -> None:
        session = self.connect_and_check()
        self.arm(session)

        first = self.input(session, 1, (0.5, 0.0, 0.0), True)
        self.assertEqual(first.status, "accepted")
        self.station.step()
        self.assertEqual(self.station._receipts[first.request_id].code, "NEUTRAL_REQUIRED")
        self.assertEqual(self.station.snapshot().input_phase, "awaiting_neutral")

        self.input(session, 2, (0.0, 0.0, 0.0), False)
        self.station.step()
        self.clock.advance(0.020)
        self.input(session, 3, (0.5, 0.0, 0.0), True)
        self.station.step()
        self.assertEqual(self.station.snapshot().input_phase, "jogging")

    def test_release_captures_confirmed_hold_once(self) -> None:
        session = self.connect_and_check()
        self.arm(session)
        capture_calls: list[bool] = []
        original_capture = self.station._capture_release_hold

        def capture_once() -> None:
            capture_calls.append(True)
            original_capture()

        self.station._capture_release_hold = capture_once
        self.input(session, 1, (0.0, 0.0, 0.0), False)
        self.station.step()
        self.clock.advance(0.020)
        self.input(session, 2, (1.0, 0.0, 0.0), True)
        self.station.step()
        self.input(session, 3, (0.0, 0.0, 0.0), False)
        self.station.step()
        hold_after_release = self.station._hold_targets
        self.input(session, 4, (0.0, 0.0, 0.0), False)
        self.station.step()

        self.assertEqual(len(capture_calls), 1)
        self.assertEqual(self.station._hold_targets, hold_after_release)
        self.assertTrue(self.station.snapshot().hold_energized)
        self.assertEqual(self.station.snapshot().input_phase, "holding")

    def test_ticket_is_canonical_single_use_and_bounded(self) -> None:
        session = self.connect_and_check()
        self.arm(session)
        tickets = [self.station.issue_ticket(session, sequence) for sequence in range(1000)]
        self.assertEqual(self.station._ticket, tickets[-1])

        old = self.station.request(
            JogIntent(0, (0.0, 0.0, 0.0), False, True, "fixture-device-1", tickets[0]),
            session,
        )
        self.assertEqual(old.code, "INVALID_TICKET")
        self.assertEqual(self.station._ticket, tickets[-1])
        latest = self.station.request(
            JogIntent(999, (0.0, 0.0, 0.0), False, True, "fixture-device-1", tickets[-1]),
            session,
        )
        self.assertEqual(latest.status, "accepted")
        self.assertIsNone(self.station._ticket)
        replay = self.station.request(
            JogIntent(999, (0.0, 0.0, 0.0), False, True, "fixture-device-1", tickets[-1]),
            session,
        )
        self.assertEqual(replay.code, "INVALID_TICKET")
        self.assertLessEqual(len(self.station._receipts), 64)

    def test_forged_expiry_rejected_and_expired_owner_revoked(self) -> None:
        session = self.connect_and_check()
        self.arm(session)
        ticket = self.station.issue_ticket(session, 1)
        forged = replace(ticket, expires_at_s=ticket.expires_at_s + 1.0)
        receipt = self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, True, "fixture-device-1", forged),
            session,
        )
        self.assertEqual(receipt.code, "INVALID_TICKET")
        self.assertIsNone(self.station._ticket)

        expired = self.station.issue_ticket(session, 2)
        self.clock.advance(self.station.input_lease_s + 0.010)
        forged_expired = replace(expired, expires_at_s=self.clock() + 1.0)
        receipt = self.station.request(
            JogIntent(2, (1.0, 0.0, 0.0), True, True, "fixture-device-1", forged_expired),
            session,
        )
        self.assertEqual(receipt.code, "OWNER_EXPIRED")
        self.assertTrue(self.station.snapshot().stop_pending)
        self.station.step()
        self.assertTrue(self.station.snapshot().stop_logical)
        self.assertFalse(self.station.snapshot().hold_energized)

    def test_nonowner_forged_input_does_not_consume_owners_ticket(self) -> None:
        owner = self.connect_and_check()
        other = self.station.register_session("other")
        self.arm(owner)
        ticket = self.station.issue_ticket(owner, 1)

        rejected = self.station.request(
            JogIntent(1, (0.0, 0.0, 0.0), False, True, "fixture-device-1", ticket),
            other,
        )
        self.assertEqual(rejected.code, "NOT_OWNER")
        admitted = self.station.request(
            JogIntent(1, (0.0, 0.0, 0.0), False, True, "fixture-device-1", ticket),
            owner,
        )
        self.assertEqual(admitted.status, "accepted")

    def test_authority_seam_and_focus_loss_revoke_ingress_immediately(self) -> None:
        session = self.connect_and_check()
        self.arm(session)
        authority = self.station.dispatch_authority()
        self.assertFalse(authority.revoked)
        self.assertIsNotNone(authority.expires_at_s)

        ticket = self.station.issue_ticket(session, 1)
        rejected = self.station.request(
            JogIntent(1, (1.0, 0.0, 0.0), True, False, "fixture-device-1", ticket),
            session,
        )
        self.assertEqual(rejected.code, "FOCUS_LOST")
        self.assertTrue(self.station.dispatch_authority().revoked)
        self.assertTrue(self.station.snapshot().stop_pending)
        self.station.step()
        self.assertTrue(self.station.snapshot().stop_logical)

    def test_snapshot_is_immutable_and_never_reads_core_on_caller_thread(self) -> None:
        self.station.step()
        original_view = self.station.snapshot()
        self.assertIsInstance(original_view, ArmStationSnapshot)
        with self.assertRaises(FrozenInstanceError):
            original_view.lifecycle_state = "armed"

        core = self.station._core
        original_snapshot = core.snapshot
        core_threads: list[int] = []

        def tracked_snapshot():
            core_threads.append(threading.get_ident())
            return original_snapshot()

        core.snapshot = tracked_snapshot
        result: list[object] = []
        reader = threading.Thread(target=lambda: result.append(self.station.snapshot()))
        reader.start()
        reader.join(timeout=1.0)
        self.assertFalse(reader.is_alive())
        self.assertEqual(result, [original_view])
        self.assertEqual(core_threads, [])

        errors: list[Exception] = []
        wrong_executor = threading.Thread(
            target=lambda: self._capture_error(errors, self.station.step)
        )
        wrong_executor.start()
        wrong_executor.join(timeout=1.0)
        self.assertFalse(wrong_executor.is_alive())
        self.assertEqual(len(errors), 1)
        self.assertIsInstance(errors[0], RuntimeError)
        self.assertEqual(core_threads, [])

    @staticmethod
    def _capture_error(errors: list[Exception], action) -> None:
        try:
            action()
        except Exception as exc:
            errors.append(exc)

    def test_stop_requires_fresh_mode0_feedback_for_each_joint(self) -> None:
        session = self.connect_and_check()
        self.arm(session)
        self.fixture.inject_reply_modes = {1: 1}
        self.station.request(StopAction(), session)
        self.station.step()

        snap = self.station.snapshot()
        self.assertTrue(snap.stop_logical)
        self.assertFalse(snap.stop_confirmed)
        self.assertEqual(snap.per_joint_stop_confirmed, (True, False, True))
        self.assertEqual([item["mode"] for item in self.mode_writes(self.fixture, 0)[-3:]], [0, 0, 0])

    def test_partial_write_keeps_attempt_separate_from_dispatch_history(self) -> None:
        session = self.connect_and_check()
        self.arm(session)
        self.input(session, 1, (0.0, 0.0, 0.0), False)
        self.station.step()
        self.clock.advance(0.020)
        self.fixture.inject_partial_write_ids = {0}
        self.input(session, 2, (1.0, 0.0, 0.0), True)
        self.station.step()

        snap = self.station.snapshot()
        self.assertEqual(snap.lifecycle_state, State.FAULT.value)
        self.assertTrue(snap.fault_latched)
        self.assertIsNotNone(snap.dispatch_attempts[0])
        self.assertEqual(snap.dispatch_attempts[0].result, WriteResult.PARTIAL)
        self.assertIsNotNone(snap.dispatch_records[0])
        self.assertGreater(
            snap.dispatch_attempts[0].sequence,
            snap.dispatch_records[0].sequence,
        )
        self.assertEqual(snap.per_joint_stop_confirmed, (False, True, True))

    def test_failed_close_keeps_owner_and_retry_confirms_close(self) -> None:
        session = self.connect_and_check()
        self.fixture.fail_close = True
        self.assertFalse(self.station.close())
        failed = self.station.snapshot()
        self.assertTrue(failed.close_attempted)
        self.assertTrue(failed.close_unconfirmed)
        self.assertFalse(failed.close_confirmed)
        self.assertEqual(failed.owner_session_id, session.session_id)

        other = self.station.register_session("other")
        blocked = self.station.request(ConnectAction(), other)
        self.assertEqual(blocked.code, "CLOSE_IN_PROGRESS")
        self.fixture.fail_close = False
        self.assertTrue(self.station.close())
        closed = self.station.snapshot()
        self.assertTrue(closed.close_confirmed)
        self.assertEqual(closed.owner_session_id, session.session_id)

    def test_ready_telemetry_stays_fresh_and_explicit_arm_reanchors_after_idle(self) -> None:
        session = self.connect_and_check()
        for _ in range(100):
            self.clock.advance(0.020)
            self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, State.READY.value)
        self.assertEqual(self.station.snapshot().faults, ())

        old_references = self.station.snapshot().confirmed_reference
        self.clock.advance(2.0)
        self.station.request(ArmAction(), session)
        self.station.step()
        snap = self.station.snapshot()
        self.assertEqual(snap.lifecycle_state, State.ARMED.value)
        self.assertTrue(snap.hold_energized)
        self.assertEqual(snap.faults, ())
        self.assertTrue(snap.stop_confirmed)
        self.assertTrue(all(ref is not None for ref in snap.confirmed_reference))
        self.assertTrue(
            all(
                current.sample_time_s > previous.sample_time_s
                for current, previous in zip(snap.confirmed_reference, old_references)
                if current is not None and previous is not None
            )
        )

    def test_stale_ready_transport_still_faults_and_attempts_every_stop(self) -> None:
        self.connect_and_check()
        self.fixture.inject_no_reply_ids = {0}
        self.clock.advance(0.600)
        self.station.step()

        snap = self.station.snapshot()
        self.assertEqual(snap.lifecycle_state, State.FAULT.value)
        self.assertTrue(snap.fault_latched)
        self.assertEqual(snap.per_joint_stop_confirmed, (False, True, True))

    def test_fault_and_protection_history_survive_disconnect_and_reconnect(self) -> None:
        session = self.connect_and_check()
        self.fixture.inject_temperatures = {0: (90, 30)}
        self.clock.advance(0.020)
        self.station.step()
        fault = self.station.snapshot()
        self.assertEqual(fault.lifecycle_state, State.FAULT.value)
        self.assertTrue(fault.fault_latched)
        self.assertTrue(fault.stop_logical)
        self.assertTrue(fault.stop_confirmed)

        self.fixture.inject_temperatures = {}
        self.station.request(DisconnectAction(), session)
        self.station.step()
        self.assertEqual(self.station.snapshot().lifecycle_state, State.DISCONNECTED.value)
        self.assertTrue(self.station.snapshot().fault_latched)

        self.station.request(ConnectAction(), session)
        self.station.step()
        reconnected = self.station.snapshot()
        self.assertEqual(reconnected.connection_phase, "fixture")
        self.assertEqual(reconnected.lifecycle_state, State.FAULT.value)
        self.assertTrue(reconnected.fault_latched)
        self.assertTrue(reconnected.stop_confirmed)

        rejected = self.station.request(CheckAction(acknowledge_fault=False), session)
        self.assertEqual(rejected.status, "queued")
        self.station.step()
        self.assertEqual(self.station.snapshot().latest_receipt.code, "fault_ack_required")
        self.assertTrue(self.station.snapshot().fault_latched)

    def test_physical_draft_finite_boundaries_and_commissioning_phase(self) -> None:
        good = self.valid_physical_draft()
        self.assertTrue(validate_physical_draft(good)[0])
        self.assertEqual(
            (create_synthetic_arm_specs()[0].q_min_rad,
             create_synthetic_arm_specs()[0].q_max_rad),
            (J1_MIN_RAD, J1_MAX_RAD),
        )
        self.assertAlmostEqual(compute_zero_output(0.6, -1, 0.5), 1.1)
        with self.assertRaises(ValueError):
            compute_zero_output(math.inf, 1, 0.0)

        bad_joints = list(good.joints)
        bad_joints[0] = replace(bad_joints[0], q_min_rad=math.nan)
        self.assertFalse(validate_physical_draft(replace(good, joints=tuple(bad_joints)))[0])
        bad_joints = list(good.joints)
        bad_joints[1] = replace(bad_joints[1], v_max_rad_s=math.inf)
        self.assertFalse(validate_physical_draft(replace(good, joints=tuple(bad_joints)))[0])
        bad_joints = list(good.joints)
        bad_joints[2] = replace(bad_joints[2], kp=math.inf)
        self.assertFalse(validate_physical_draft(replace(good, joints=tuple(bad_joints)))[0])
        bad_joints = list(good.joints)
        bad_joints[0] = replace(bad_joints[0], direction=True)
        self.assertFalse(validate_physical_draft(replace(good, joints=tuple(bad_joints)))[0])
        bad_joints = list(good.joints)
        bad_joints[0] = replace(
            bad_joints[0], q_min_rad=J1_MIN_RAD - 0.01, q_max_rad=J1_MAX_RAD
        )
        self.assertFalse(validate_physical_draft(replace(good, joints=tuple(bad_joints)))[0])

        # Explicit finite J2/J3 travel can exceed a full turn; no guessed cap is applied.
        self.assertGreater(good.joints[1].q_max_rad - good.joints[1].q_min_rad, math.tau)
        self.assertTrue(validate_physical_draft(good)[0])

        fixture = ArmPacketFixture(clock=self.clock)
        fixture.is_open = False
        station = ArmStation(clock=self.clock, fixture=fixture)
        session = station.register_session("owner")
        incomplete = replace(good, joints=good.joints[:1])
        self.assertFalse(validate_physical_draft(incomplete)[0])
        station.request(ConnectAction(source_kind="physical", draft=incomplete), session)
        station.step()
        self.assertTrue(station.snapshot().commissioning_blocked)
        self.assertEqual(station.snapshot().lifecycle_state, State.DISCONNECTED.value)
        self.assertFalse(fixture.is_open)
        self.assertEqual(fixture.writes, ())

        station.request(ConnectAction(source_kind="physical", draft=good), session)
        station.step()
        self.assertEqual(station.snapshot().latest_receipt.code, "COMMISSIONING_REQUIRED")
        self.assertEqual(station.snapshot().lifecycle_state, State.DISCONNECTED.value)
        self.assertIsNone(station.snapshot().source)
        self.assertFalse(fixture.is_open)
        self.assertEqual(fixture.writes, ())

    def test_background_executor_exception_records_logical_stop(self) -> None:
        fixture = ArmPacketFixture()
        station = ArmStation(fixture=fixture)
        session = station.register_session("owner")
        station.start_loop()
        station.request(ConnectAction(), session)
        self.assertTrue(self.wait_until(
            lambda: station.snapshot().lifecycle_state == State.CONNECTED.value
        ))

        original_step = station._step_once
        should_raise = [True]

        def fail_one_step(*, missed_slots: int = 0):
            if should_raise[0]:
                should_raise[0] = False
                raise RuntimeError("private test detail")
            return original_step(missed_slots=missed_slots)

        station._step_once = fail_one_step
        self.assertTrue(self.wait_until(lambda: station.snapshot().executor_failed))
        thread = station._loop_thread
        self.assertIsNotNone(thread)
        thread.join(timeout=1.0)
        snap = station.snapshot()
        self.assertFalse(thread.is_alive())
        self.assertEqual(snap.lifecycle_state, State.STOPPED.value)
        self.assertTrue(snap.stop_logical)
        self.assertFalse(snap.stop_confirmed)
        self.assertTrue(snap.stop_pending)
        self.assertEqual(snap.input_phase, "executor_failed")

    def test_stop_ingress_does_not_wait_for_executor_exchange(self) -> None:
        fixture = ArmPacketFixture()
        station = ArmStation(fixture=fixture)
        owner = station.register_session("owner")
        other = station.register_session("stopper")
        station.start_loop()
        station.request(ConnectAction(), owner)
        self.assertTrue(self.wait_until(
            lambda: station.snapshot().lifecycle_state == State.CONNECTED.value
        ))

        write_entered = threading.Event()
        release_write = threading.Event()
        block_lock = threading.Lock()
        block_next = [True]
        original_write = fixture.write

        def blocked_write(data):
            with block_lock:
                should_block = block_next[0]
                block_next[0] = False
            if should_block:
                write_entered.set()
                release_write.wait(timeout=2.0)
            return original_write(data)

        fixture.write = blocked_write
        station.request(CheckAction(), owner)
        self.assertTrue(write_entered.wait(timeout=1.0))

        result: list[object] = []
        stop_done = threading.Event()

        def submit_stop():
            result.append(station.request(StopAction(), other))
            stop_done.set()

        stop_thread = threading.Thread(target=submit_stop, daemon=True)
        stop_thread.start()
        completed_before_release = stop_done.wait(timeout=0.100)
        self.assertTrue(station.snapshot().stop_pending)
        release_write.set()
        stop_thread.join(timeout=1.0)
        self.assertFalse(stop_thread.is_alive())
        self.assertTrue(completed_before_release)
        self.assertEqual(result[0].code, "STOP_QUEUED")
        self.assertTrue(self.wait_until(
            lambda: station.snapshot().stop_logical
            and not station.snapshot().stop_pending
        ))
        self.assertTrue(station.snapshot().stop_confirmed)
        self.assertTrue(station.close())

    @staticmethod
    def wait_until(predicate, timeout: float = 2.0) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return True
            time.sleep(0.005)
        return bool(predicate())


if __name__ == "__main__":
    unittest.main()

```

### joint_contract.py SHA256 bbf32e7f45c9ee6a6af75a70122928e4517d22e366bd6e193915fc48da44fff1
```python
"""Frozen domain records and status types for joint control.

All records are immutable (frozen) data contracts with no transport or clock ownership.
"""

from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
import math
from typing import Literal

from im6014_codec import decode_command
from joint_mapping import JointMap, JointSample, JointTarget
from joint_protection import ProtectionPolicy


class State(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    CHECKING = "checking"
    READY = "ready"
    ARMED = "armed"
    MOVING = "moving"
    STOPPED = "stopped"
    FAULT = "fault"


class DecisionCode(str, Enum):
    ACCEPTED = "accepted"
    INVALID_STATE = "invalid_state"
    INVALID_ARGUMENT = "invalid_argument"
    INVALID_OWNER = "invalid_owner"
    INVALID_SOURCE = "invalid_source"
    UNKNOWN_JOINT = "unknown_joint"
    INVALID_OBSERVATION = "invalid_observation"
    FAULT_ACK_REQUIRED = "fault_ack_required"
    FAULT_LATCHED = "fault_latched"
    OBSERVATIONS_INCOMPLETE = "observations_incomplete"
    STALE_FEEDBACK = "stale_feedback"
    UNHEALTHY = "unhealthy"
    NOT_STOPPED = "not_stopped"
    DUPLICATE_OR_OLDER = "duplicate_or_older"
    EXPIRED = "expired"
    POSITION_OUT_OF_BOUNDS = "position_out_of_bounds"
    SPEED_OUT_OF_BOUNDS = "speed_out_of_bounds"
    LEAD_OUT_OF_BOUNDS = "lead_out_of_bounds"
    EFFORT_OUT_OF_BOUNDS = "effort_out_of_bounds"
    TEMPERATURE_OUT_OF_BOUNDS = "temperature_out_of_bounds"
    REFERENCE_GAP_EXCEEDED = "reference_gap_exceeded"
    CONSTRAINT_VIOLATION = "constraint_violation"


class CommunicationFailure(str, Enum):
    TIMEOUT = "timeout"
    INVALID_FEEDBACK = "invalid_feedback"
    DRIVER_FAILURE = "driver_failure"
    CLOCK_FAILURE = "clock_failure"
    PREWRITE_DEADLINE = "prewrite_deadline"


class WriteResult(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    PREWRITE_DEADLINE = "prewrite_deadline"


@dataclass(frozen=True)
class Decision:
    accepted: bool
    code: DecisionCode

    def __post_init__(self) -> None:
        if type(self.accepted) is not bool:
            raise ValueError("accepted must be a bool")
        if not isinstance(self.code, DecisionCode):
            raise ValueError("code must be a DecisionCode")
        if self.accepted != (self.code is DecisionCode.ACCEPTED):
            raise ValueError("accepted must match the decision code")

    def __bool__(self) -> bool:
        return self.accepted


@dataclass(frozen=True)
class JointSpec:
    name: str
    motor_id: int
    mapping: JointMap
    q_min_rad: float
    q_max_rad: float
    v_max_rad_s: float
    a_max_rad_s2: float
    max_lead_rad: float
    max_effort_nm: float
    limits_provenance: str
    protection: ProtectionPolicy

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if not isinstance(self.mapping, JointMap):
            raise ValueError("mapping must be a JointMap")

        if isinstance(self.q_min_rad, bool) or not isinstance(self.q_min_rad, (int, float)):
            raise ValueError("q_min_rad must be a finite real number")
        if isinstance(self.q_max_rad, bool) or not isinstance(self.q_max_rad, (int, float)):
            raise ValueError("q_max_rad must be a finite real number")
        try:
            min_val = float(self.q_min_rad)
            max_val = float(self.q_max_rad)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("position limits must be finite") from exc
        if not math.isfinite(min_val) or not math.isfinite(max_val):
            raise ValueError("position limits must be finite")
        if min_val > max_val:
            raise ValueError("q_min_rad must be less than or equal to q_max_rad")

        if isinstance(self.v_max_rad_s, bool) or not isinstance(self.v_max_rad_s, (int, float)):
            raise ValueError("v_max_rad_s must be a finite positive real number")
        try:
            v_max_val = float(self.v_max_rad_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("speed limit must be finite") from exc
        if not math.isfinite(v_max_val) or v_max_val <= 0.0:
            raise ValueError("v_max_rad_s must be finite and positive")

        if isinstance(self.a_max_rad_s2, bool) or not isinstance(self.a_max_rad_s2, (int, float)):
            raise ValueError("a_max_rad_s2 must be a finite positive real number")
        try:
            a_max_val = float(self.a_max_rad_s2)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("acceleration limit must be finite") from exc
        if not math.isfinite(a_max_val) or a_max_val <= 0.0:
            raise ValueError("a_max_rad_s2 must be finite and positive")

        if isinstance(self.max_lead_rad, bool) or not isinstance(self.max_lead_rad, (int, float)):
            raise ValueError("max_lead_rad must be a finite positive real number")
        try:
            max_lead_val = float(self.max_lead_rad)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_lead_rad must be finite") from exc
        if not math.isfinite(max_lead_val) or max_lead_val <= 0.0:
            raise ValueError("max_lead_rad must be finite and positive")

        if isinstance(self.max_effort_nm, bool) or not isinstance(self.max_effort_nm, (int, float)):
            raise ValueError("max_effort_nm must be a finite positive real number")
        try:
            max_effort_val = float(self.max_effort_nm)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_effort_nm must be finite") from exc
        if not math.isfinite(max_effort_val) or max_effort_val <= 0.0:
            raise ValueError("max_effort_nm must be finite and positive")

        if not isinstance(self.protection, ProtectionPolicy):
            raise ValueError("protection must be a ProtectionPolicy")
        if self.protection.continuous_effort_nm > max_effort_val:
            raise ValueError("continuous_effort_nm must be less than or equal to max_effort_nm")

        if (
            type(self.limits_provenance) is not str
            or not self.limits_provenance.strip()
            or len(self.limits_provenance) > 256
        ):
            raise ValueError("limits_provenance must be a bounded non-empty string")

        object.__setattr__(self, "q_min_rad", min_val)
        object.__setattr__(self, "q_max_rad", max_val)
        object.__setattr__(self, "v_max_rad_s", v_max_val)
        object.__setattr__(self, "a_max_rad_s2", a_max_val)
        object.__setattr__(self, "max_lead_rad", max_lead_val)
        object.__setattr__(self, "max_effort_nm", max_effort_val)


@dataclass(frozen=True)
class JointFault:
    name: str
    motor_id: int
    errors: int = 0
    warnings: int = 0
    timeout: bool = False
    communication_error: CommunicationFailure | None = None
    stale: bool = False
    communication_errors: tuple[CommunicationFailure, ...] = ()
    position_limit: bool = False
    speed_limit: bool = False
    effort_limit: bool = False
    constraint_fault: bool = False
    driver_temperature_limit: bool = False
    winding_temperature_limit: bool = False
    continuous_effort_limit: bool = False

    def __post_init__(self) -> None:
        if type(self.name) is not str or not self.name.strip():
            raise ValueError("joint name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if type(self.stale) is not bool:
            raise ValueError("stale must be a bool")
        if type(self.communication_errors) is not tuple or any(
            not isinstance(c, CommunicationFailure) for c in self.communication_errors
        ):
            raise ValueError("communication_errors must be a tuple of CommunicationFailure")
        if type(self.position_limit) is not bool:
            raise ValueError("position_limit must be a bool")
        if type(self.speed_limit) is not bool:
            raise ValueError("speed_limit must be a bool")
        if type(self.effort_limit) is not bool:
            raise ValueError("effort_limit must be a bool")
        if type(self.constraint_fault) is not bool:
            raise ValueError("constraint_fault must be a bool")
        if type(self.driver_temperature_limit) is not bool:
            raise ValueError("driver_temperature_limit must be a bool")
        if type(self.winding_temperature_limit) is not bool:
            raise ValueError("winding_temperature_limit must be a bool")
        if type(self.continuous_effort_limit) is not bool:
            raise ValueError("continuous_effort_limit must be a bool")

        if len(self.communication_errors) != len(set(self.communication_errors)):
            raise ValueError("communication_errors must contain unique codes")
        if self.communication_error is not None and self.communication_errors and (
            self.communication_error not in self.communication_errors
        ):
            raise ValueError("communication_error must belong to communication_errors")

        if self.communication_error is not None and not self.communication_errors:
            object.__setattr__(self, "communication_errors", (self.communication_error,))
        elif self.communication_errors and self.communication_error is None:
            object.__setattr__(self, "communication_error", self.communication_errors[-1])

@dataclass(frozen=True)
class MotorHealth:
    mode: int
    errors: int
    warnings: int
    timeout: bool
    driver_c: float
    winding_c: float

    def __post_init__(self) -> None:
        if type(self.mode) is not int or self.mode not in (0, 1):
            raise ValueError("mode must be the integer 0 or 1")
        if type(self.errors) is not int or not (0 <= self.errors <= 0xFFFFFFFF):
            raise ValueError("errors must be a uint32 integer")
        if type(self.warnings) is not int or not (0 <= self.warnings <= 7):
            raise ValueError("warnings must be a uint3 integer")
        if type(self.timeout) is not bool:
            raise ValueError("timeout must be a bool")

        if isinstance(self.driver_c, bool) or not isinstance(self.driver_c, (int, float)):
            raise ValueError("driver_c must be a finite real number")
        try:
            driver_c_val = float(self.driver_c)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("driver_c must be finite") from exc
        if not math.isfinite(driver_c_val):
            raise ValueError("driver_c must be finite")

        if isinstance(self.winding_c, bool) or not isinstance(self.winding_c, (int, float)):
            raise ValueError("winding_c must be a finite real number")
        try:
            winding_c_val = float(self.winding_c)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("winding_c must be finite") from exc
        if not math.isfinite(winding_c_val):
            raise ValueError("winding_c must be finite")

        object.__setattr__(self, "driver_c", driver_c_val)
        object.__setattr__(self, "winding_c", winding_c_val)

    @property
    def healthy(self) -> bool:
        return self.errors == 0 and self.warnings == 0 and not self.timeout


@dataclass(frozen=True)
class SourceIdentity:
    backend: Literal["physical", "demo", "fixture"]
    identity: str
    connection: int

    def __post_init__(self) -> None:
        if type(self.backend) is not str or self.backend not in ("physical", "demo", "fixture"):
            raise ValueError("backend must be physical, demo, or fixture")
        if type(self.identity) is not str or not self.identity.strip():
            raise ValueError("identity must be a non-empty string")
        if type(self.connection) is not int or self.connection < 0:
            raise ValueError("connection must be a nonnegative integer")


@dataclass(frozen=True)
class JointStatus:
    sample: JointSample | None = None
    health: MotorHealth | None = None
    received_at: float | None = None
    communication_error: CommunicationFailure | None = None

    def __post_init__(self) -> None:
        if (self.sample is None) != (self.health is None):
            raise ValueError("sample and health must both be present or both be absent")
        if self.sample is not None and not isinstance(self.sample, JointSample):
            raise ValueError("sample must be a JointSample")
        if self.health is not None and not isinstance(self.health, MotorHealth):
            raise ValueError("health must be MotorHealth")
        if self.communication_error is not None and not isinstance(self.communication_error, CommunicationFailure):
            raise ValueError("communication_error must be a CommunicationFailure or None")
        if self.valid and self.received_at is None:
            raise ValueError("a valid observation requires received_at")
        if self.received_at is not None:
            if isinstance(self.received_at, bool) or not isinstance(self.received_at, (int, float)):
                raise ValueError("received_at must be a finite real number or None")
            try:
                received_at = float(self.received_at)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("received_at must be finite") from exc
            if not math.isfinite(received_at):
                raise ValueError("received_at must be finite")
            if not self.valid:
                raise ValueError("received_at requires a valid observation")
            object.__setattr__(self, "received_at", received_at)

    @property
    def valid(self) -> bool:
        return self.sample is not None and self.health is not None

    @property
    def healthy(self) -> bool:
        return self.valid and self.health.healthy and self.communication_error is None

    @property
    def errors(self) -> int:
        return self.health.errors if self.health is not None else 0

    @property
    def warnings(self) -> int:
        return self.health.warnings if self.health is not None else 0

    @property
    def timeout(self) -> bool:
        return self.health.timeout if self.health is not None else False


@dataclass(frozen=True)
class OwnerToken:
    epoch: str
    generation: int
    connection_id: str

    def __post_init__(self) -> None:
        if type(self.epoch) is not str or not self.epoch.strip() or len(self.epoch) > 64:
            raise ValueError("epoch must be a bounded non-empty string")
        if type(self.generation) is not int or not (1 <= self.generation <= (1 << 64) - 1):
            raise ValueError("generation must be an integer from 1 to 2**64 - 1")
        if type(self.connection_id) is not str or not self.connection_id.strip() or len(self.connection_id) > 64:
            raise ValueError("connection_id must be a bounded non-empty string")


def owner_tokens_match(candidate: object, current: object) -> bool:
    return (
        type(candidate) is OwnerToken
        and type(current) is OwnerToken
        and candidate.epoch == current.epoch
        and candidate.generation == current.generation
        and candidate.connection_id == current.connection_id
    )


@dataclass(frozen=True)
class IntentWindow:
    id: int
    created_at_s: float
    expires_at_s: float

    def __post_init__(self) -> None:
        if type(self.id) is not int or not (0 <= self.id <= (1 << 64) - 1):
            raise ValueError("window ID must be an integer from 0 to 2**64 - 1")
        if isinstance(self.created_at_s, bool) or not isinstance(self.created_at_s, (int, float)):
            raise ValueError("created_at_s must be a finite real number")
        if isinstance(self.expires_at_s, bool) or not isinstance(self.expires_at_s, (int, float)):
            raise ValueError("expires_at_s must be a finite real number")
        try:
            created = float(self.created_at_s)
            expires = float(self.expires_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("window timestamps must be finite") from exc
        if not math.isfinite(created) or not math.isfinite(expires):
            raise ValueError("window timestamps must be finite")
        if expires <= created:
            raise ValueError("expires_at_s must be strictly greater than created_at_s")
        object.__setattr__(self, "created_at_s", created)
        object.__setattr__(self, "expires_at_s", expires)


@dataclass(frozen=True)
class Target:
    sequence: int
    joints: tuple[JointTarget, ...]
    window: IntentWindow
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if type(self.joints) is not tuple:
            raise ValueError("joints must be a tuple of JointTarget")
        if not self.joints:
            raise ValueError("joints must be a non-empty tuple")
        if any(not isinstance(joint, JointTarget) for joint in self.joints):
            raise ValueError("every joint target must be a JointTarget")
        if not isinstance(self.window, IntentWindow):
            raise ValueError("window must be an IntentWindow")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")


@dataclass(frozen=True)
class JointTrajectoryReference:
    q_rad: float
    position_step_velocity_rad_s: Fraction
    encoded_velocity_rad_s: float
    sample_time_s: float
    is_emitted: bool = False
    requested_goal: JointTarget | None = None
    emitted_target: JointTarget | None = None
    packet: bytes | None = None

    def __post_init__(self) -> None:
        for name, val in (("q_rad", self.q_rad),
                          ("encoded_velocity_rad_s", self.encoded_velocity_rad_s),
                          ("sample_time_s", self.sample_time_s)):
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                raise ValueError(f"{name} must be a finite real number")
            try:
                v = float(val)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError(f"{name} must be finite") from exc
            if not math.isfinite(v):
                raise ValueError(f"{name} must be finite")
            object.__setattr__(self, name, v)

        derivative = self.position_step_velocity_rad_s
        if isinstance(derivative, bool) or not isinstance(derivative, (int, float, Fraction)):
            raise ValueError("position_step_velocity_rad_s must be an exact finite rational")
        if isinstance(derivative, Fraction):
            exact_derivative = derivative
        else:
            try:
                as_float = float(derivative)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("position_step_velocity_rad_s must be finite") from exc
            if not math.isfinite(as_float):
                raise ValueError("position_step_velocity_rad_s must be finite")
            exact_derivative = Fraction(as_float)
        object.__setattr__(self, "position_step_velocity_rad_s", exact_derivative)

        if type(self.is_emitted) is not bool:
            raise ValueError("is_emitted must be a bool")
        if self.is_emitted:
            if not isinstance(self.requested_goal, JointTarget):
                raise ValueError("an emitted reference requires its requested goal")
            if not isinstance(self.emitted_target, JointTarget):
                raise ValueError("an emitted reference requires its decoded target")
            if type(self.packet) is not bytes:
                raise ValueError("an emitted reference requires immutable packet bytes")
            try:
                decoded = decode_command(self.packet)
            except ValueError as exc:
                raise ValueError("an emitted reference requires a canonical command") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("an emitted reference requires a watchdog-enabled FOC command")
            if self.q_rad != self.emitted_target.q_rad:
                raise ValueError("reference position must match its decoded target")
            if self.encoded_velocity_rad_s != self.emitted_target.dq_rad_s:
                raise ValueError("encoded velocity must match its decoded target")
        else:
            if (
                self.requested_goal is not None
                or self.emitted_target is not None
                or self.packet is not None
            ):
                raise ValueError("an unemitted Stop anchor cannot contain an emitted command")
            if exact_derivative != 0 or self.encoded_velocity_rad_s != 0.0:
                raise ValueError("an unemitted Stop anchor must have zero velocity history")


@dataclass(frozen=True)
class RefreshPlan:
    plan_id: int
    target: Target
    prepared_at_s: float
    joint_targets: tuple[JointTarget, ...]
    packets: tuple[bytes, ...]
    proposed_references: tuple[JointTrajectoryReference, ...]

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, Target):
            raise ValueError("target must be a Target")
        if isinstance(self.prepared_at_s, bool) or not isinstance(self.prepared_at_s, (int, float)):
            raise ValueError("prepared_at_s must be a finite real number")
        try:
            prepared = float(self.prepared_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("prepared_at_s must be finite") from exc
        if not math.isfinite(prepared):
            raise ValueError("prepared_at_s must be finite")
        object.__setattr__(self, "prepared_at_s", prepared)
        if type(self.joint_targets) is not tuple or not self.joint_targets:
            raise ValueError("joint_targets must be a non-empty tuple")
        if any(not isinstance(jt, JointTarget) for jt in self.joint_targets):
            raise ValueError("every joint target must be a JointTarget")
        if len(self.target.joints) != len(self.joint_targets):
            raise ValueError("joint_targets must match the complete target vector")
        if type(self.packets) is not tuple or len(self.packets) != len(self.joint_targets):
            raise ValueError("packets must be a tuple matching joint_targets")
        for packet in self.packets:
            if type(packet) is not bytes:
                raise ValueError("packets must contain immutable bytes")
            try:
                decoded = decode_command(packet)
            except ValueError as exc:
                raise ValueError("packets must contain canonical commands") from exc
            if decoded["mode"] != 1 or not decoded["watchdog"]:
                raise ValueError("refresh packets must be watchdog-enabled FOC commands")
        if (
            type(self.proposed_references) is not tuple
            or len(self.proposed_references) != len(self.joint_targets)
        ):
            raise ValueError("proposed_references must match joint_targets length")
        for goal, target, packet, reference in zip(
            self.target.joints,
            self.joint_targets,
            self.packets,
            self.proposed_references,
        ):
            if not isinstance(reference, JointTrajectoryReference) or not reference.is_emitted:
                raise ValueError("every plan requires a complete emitted reference")
            if reference.requested_goal != goal:
                raise ValueError("reference goal must match the admitted joint goal")
            if reference.emitted_target != target or reference.packet != packet:
                raise ValueError("reference target and packet must match the prepared command")
            if reference.sample_time_s > prepared:
                raise ValueError("reference sample time cannot follow plan preparation")

    @property
    def window(self) -> IntentWindow:
        return self.target.window

    @property
    def owner(self) -> OwnerToken:
        return self.target.owner


@dataclass(frozen=True)
class JointDispatchedRecord:
    sequence: int
    target: JointTarget
    dispatched_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.dispatched_at_s, bool) or not isinstance(self.dispatched_at_s, (int, float)):
            raise ValueError("dispatched_at_s must be a finite real number")
        try:
            dispatched = float(self.dispatched_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("dispatched_at_s must be finite") from exc
        if not math.isfinite(dispatched):
            raise ValueError("dispatched_at_s must be finite")
        object.__setattr__(self, "dispatched_at_s", dispatched)


@dataclass(frozen=True)
class JointDispatchAttempt:
    plan_id: int
    sequence: int
    target: JointTarget
    result: WriteResult
    started_at_s: float
    owner: OwnerToken

    def __post_init__(self) -> None:
        if type(self.plan_id) is not int or not (0 <= self.plan_id <= (1 << 64) - 1):
            raise ValueError("plan_id must be an integer from 0 to 2**64 - 1")
        if type(self.sequence) is not int or not (0 <= self.sequence <= (1 << 64) - 1):
            raise ValueError("sequence must be an integer from 0 to 2**64 - 1")
        if not isinstance(self.target, JointTarget):
            raise ValueError("target must be a JointTarget")
        if not isinstance(self.result, WriteResult):
            raise ValueError("result must be a WriteResult")
        if type(self.owner) is not OwnerToken:
            raise ValueError("owner must be an OwnerToken")
        if isinstance(self.started_at_s, bool) or not isinstance(self.started_at_s, (int, float)):
            raise ValueError("started_at_s must be a finite real number")
        try:
            started = float(self.started_at_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("started_at_s must be finite") from exc
        if not math.isfinite(started):
            raise ValueError("started_at_s must be finite")
        object.__setattr__(self, "started_at_s", started)


@dataclass(frozen=True)
class Snapshot:
    state: State
    joint_names: tuple[str, ...]
    joints: tuple[JointStatus, ...]
    source: SourceIdentity | None
    fault_latched: bool
    feedback_ages_s: tuple[float | None, ...]
    faults: tuple[JointFault, ...] = ()
    admitted_target: Target | None = None
    prepared_plan: RefreshPlan | None = None
    dispatched_records: tuple[JointDispatchedRecord | None, ...] = ()
    last_sequence: int = -1
    dispatch_attempts: tuple[JointDispatchAttempt | None, ...] = ()
    latest_owner: OwnerToken | None = None
    current_owner: OwnerToken | None = None
    confirmed_references: tuple[JointTrajectoryReference | None, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.state, State):
            raise ValueError("state must be a State")
        if type(self.joint_names) is not tuple or any(type(name) is not str for name in self.joint_names):
            raise ValueError("joint_names must be a tuple of strings")
        if type(self.joints) is not tuple or any(not isinstance(joint, JointStatus) for joint in self.joints):
            raise ValueError("joints must be a tuple of JointStatus")
        if type(self.feedback_ages_s) is not tuple:
            raise ValueError("feedback_ages_s must be a tuple")
        if len(self.joint_names) != len(self.joints):
            raise ValueError("joint names and statuses must have equal lengths")
        if len(self.feedback_ages_s) != len(self.joints):
            raise ValueError("feedback ages and joint statuses must have equal lengths")
        normalized_ages: list[float | None] = []
        for joint, age in zip(self.joints, self.feedback_ages_s):
            if joint.received_at is None:
                if age is not None:
                    raise ValueError("feedback age must be None before a joint is received")
                normalized_ages.append(None)
                continue
            if isinstance(age, bool) or not isinstance(age, (int, float)):
                raise ValueError("feedback age must be a finite nonnegative number")
            try:
                age_value = float(age)
            except (OverflowError, TypeError, ValueError) as exc:
                raise ValueError("feedback age must be finite") from exc
            if not math.isfinite(age_value) or age_value < 0.0:
                raise ValueError("feedback age must be finite and nonnegative")
            normalized_ages.append(age_value)
        object.__setattr__(self, "feedback_ages_s", tuple(normalized_ages))
        if self.source is not None and not isinstance(self.source, SourceIdentity):
            raise ValueError("source must be a SourceIdentity or None")
        if type(self.fault_latched) is not bool:
            raise ValueError("fault_latched must be a bool")
        if type(self.faults) is not tuple or any(not isinstance(f, JointFault) for f in self.faults):
            raise ValueError("faults must be a tuple of JointFault")
        if self.admitted_target is not None and not isinstance(self.admitted_target, Target):
            raise ValueError("admitted_target must be a Target or None")
        if self.prepared_plan is not None and not isinstance(self.prepared_plan, RefreshPlan):
            raise ValueError("prepared_plan must be a RefreshPlan or None")
        if not self.dispatched_records:
            object.__setattr__(self, "dispatched_records", tuple(None for _ in self.joints))
        else:
            if type(self.dispatched_records) is not tuple or len(self.dispatched_records) != len(self.joints):
                raise ValueError("dispatched_records must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchedRecord) for r in self.dispatched_records):
                raise ValueError("every dispatched record must be a JointDispatchedRecord or None")
        if not self.dispatch_attempts:
            object.__setattr__(self, "dispatch_attempts", tuple(None for _ in self.joints))
        else:
            if type(self.dispatch_attempts) is not tuple or len(self.dispatch_attempts) != len(self.joints):
                raise ValueError("dispatch_attempts must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointDispatchAttempt) for r in self.dispatch_attempts):
                raise ValueError("every dispatch attempt must be a JointDispatchAttempt or None")
        if type(self.last_sequence) is not int or not (-1 <= self.last_sequence <= (1 << 64) - 1):
            raise ValueError("last_sequence must be an integer from -1 to 2**64 - 1")
        if self.latest_owner is not None and type(self.latest_owner) is not OwnerToken:
            raise ValueError("latest_owner must be an OwnerToken or None")
        if self.current_owner is not None and type(self.current_owner) is not OwnerToken:
            raise ValueError("current_owner must be an OwnerToken or None")
        if not self.confirmed_references:
            object.__setattr__(self, "confirmed_references", tuple(None for _ in self.joints))
        else:
            if type(self.confirmed_references) is not tuple or len(self.confirmed_references) != len(self.joints):
                raise ValueError("confirmed_references must be a tuple with length matching joints")
            if any(r is not None and not isinstance(r, JointTrajectoryReference) for r in self.confirmed_references):
                raise ValueError("every confirmed reference must be a JointTrajectoryReference or None")

    @property
    def affected_joints(self) -> tuple[str, ...]:
        return tuple(fault.name for fault in self.faults)

```

### joint_controller.py SHA256 83e64336f79f2dcabd979bf42aeeec4d3ec9232ba3add6660eb88e6f83000258
```python
"""Transport-free lifecycle and health state for an ordered joint set.

All methods on a JointCore belong to one calling thread. The core owns no
transport and all externally visible records are immutable snapshots.
"""

from collections.abc import Iterable
from dataclasses import dataclass
import math
import secrets
import time

from joint_contract import (
    CommunicationFailure,
    Decision,
    DecisionCode,
    IntentWindow,
    JointDispatchAttempt,
    JointDispatchedRecord,
    JointFault,
    JointSpec,
    JointStatus,
    JointTrajectoryReference,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot,
    SourceIdentity,
    State,
    Target,
    WriteResult,
    owner_tokens_match,
)
from joint_mapping import JointSample
from joint_protection import (
    JointProtectionState,
    MeasuredViolation,
    check_joint_limits,
    transition_protection,
)
from joint_reference import (
    prepare_complete_reference,
    validate_target_vector,
    verify_dispatch_claim,
)

__all__ = ("JointCore",)


@dataclass(frozen=True)
class _DispatchClaim:
    plan: RefreshPlan
    index: int
    started_at_s: float


class JointCore:
    """Thread-confined state machine for one fixed, ordered set of joints.

    The core public API assumes trusted station callers; C16 server binds its
    actual connection identity rather than trusting client-supplied JSON fields.
    No authentication claims are made beyond that boundary.
    """

    def __init__(
        self,
        joints: Iterable[JointSpec],
        *,
        max_reference_gap_s: float,
        feedback_max_age_s: float = 0.5,
        max_window_s: float = 1.0,
        clock=None,
    ):
        if isinstance(max_reference_gap_s, bool) or not isinstance(max_reference_gap_s, (int, float)):
            raise ValueError("max_reference_gap_s must be a finite positive real number")
        try:
            max_reference_gap_s = float(max_reference_gap_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_reference_gap_s must be finite") from exc
        if not math.isfinite(max_reference_gap_s) or max_reference_gap_s <= 0.0:
            raise ValueError("max_reference_gap_s must be finite and positive")

        if isinstance(feedback_max_age_s, bool) or not isinstance(feedback_max_age_s, (int, float)):
            raise ValueError("feedback_max_age_s must be a finite positive real number")
        try:
            feedback_max_age_s = float(feedback_max_age_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("feedback_max_age_s must be finite") from exc
        if not math.isfinite(feedback_max_age_s) or feedback_max_age_s <= 0.0:
            raise ValueError("feedback_max_age_s must be finite and positive")

        if isinstance(max_window_s, bool) or not isinstance(max_window_s, (int, float)):
            raise ValueError("max_window_s must be a finite positive real number")
        try:
            max_window_s = float(max_window_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("max_window_s must be finite") from exc
        if not math.isfinite(max_window_s) or max_window_s <= 0.0:
            raise ValueError("max_window_s must be finite and positive")

        if clock is None:
            clock = time.monotonic
        if not callable(clock):
            raise ValueError("clock must be callable")

        self._epoch = secrets.token_hex(16)

        try:
            specs = tuple(joints)
        except TypeError as exc:
            raise ValueError("joints must be an iterable of JointSpec") from exc
        if not specs:
            raise ValueError("at least one active joint is required")
        if any(not isinstance(spec, JointSpec) for spec in specs):
            raise ValueError("every joint must be a JointSpec")
        if len({spec.name for spec in specs}) != len(specs):
            raise ValueError("joint names must be unique")
        if len({spec.motor_id for spec in specs}) != len(specs):
            raise ValueError("motor IDs must be unique")

        self._specs: tuple[JointSpec, ...] = specs
        self._id_to_index: dict[int, int] = {
            spec.motor_id: index for index, spec in enumerate(specs)
        }
        self._state: State = State.DISCONNECTED
        self._observations: list[JointStatus] = [JointStatus() for _ in specs]
        self._source: SourceIdentity | None = None
        self._max_reference_gap_s = max_reference_gap_s
        self._feedback_max_age_s = feedback_max_age_s
        self._max_window_s = max_window_s
        self._clock = clock
        self._now_high_water_s: float | None = None
        self._next_window_id: int = 0
        self._offered_window: IntentWindow | None = None
        self._next_generation: int = 1
        self._latest_owner: OwnerToken | None = None
        self._current_owner: OwnerToken | None = None
        self._admitted_target: Target | None = None
        self._prepared_plan: RefreshPlan | None = None
        self._next_plan_id: int = 0
        self._next_dispatch_index: int = 0
        self._dispatch_claim: _DispatchClaim | None = None
        self._dispatched_records: list[JointDispatchedRecord | None] = [None for _ in specs]
        self._dispatch_attempts: list[JointDispatchAttempt | None] = [None for _ in specs]
        self._confirmed_references: list[JointTrajectoryReference | None] = [None for _ in specs]
        self._faults: dict[str, JointFault] = {}
        self._last_sequence: int = -1
        self._protection_states: list[JointProtectionState] = [
            JointProtectionState() for _ in specs
        ]
        self._recovery_authorized: bool = False

    @property
    def max_reference_gap_s(self) -> float:
        return self._max_reference_gap_s

    @property
    def joint_specs(self) -> tuple[JointSpec, ...]:
        return self._specs

    @property
    def admitted_target(self) -> Target | None:
        return self._admitted_target

    @staticmethod
    def _accepted() -> Decision:
        return Decision(True, DecisionCode.ACCEPTED)

    @staticmethod
    def _rejected(code: DecisionCode) -> Decision:
        return Decision(False, code)

    def _clear_observations(self) -> None:
        self._observations = [JointStatus() for _ in self._specs]

    def _invalidate_plan(self) -> None:
        self._prepared_plan = None
        self._next_dispatch_index = 0

    def _revoke_authority(self) -> None:
        self._current_owner = None
        self._offered_window = None
        self._admitted_target = None
        self._invalidate_plan()

    def claim_owner(self, connection_id: str) -> OwnerToken:
        """Issue and claim owner authority for a trusted station caller.

        The core public API assumes trusted station callers; C16 server binds its
        actual connection identity rather than trusting client-supplied JSON fields.
        No authentication claims are made beyond that boundary.
        """
        if (
            type(connection_id) is not str
            or not connection_id.strip()
            or len(connection_id) > 64
        ):
            raise ValueError("connection_id must be a bounded non-empty string")
        was_owned = self._current_owner is not None
        stop_for_claim = self._state in (
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
        ) or (was_owned and self._state not in (State.DISCONNECTED, State.CONNECTING))
        self._revoke_authority()
        self._recovery_authorized = False
        self._protection_states = [
            state.reset_timing_gap() for state in self._protection_states
        ]
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            pass
        elif self._state is State.FAULT or self._faults:
            self._state = State.FAULT
        elif stop_for_claim:
            self._state = State.STOPPED

        if self._next_generation > (1 << 64) - 1:
            raise OverflowError("owner generation sequence exhausted")

        generation = self._next_generation
        self._next_generation += 1
        token = OwnerToken(
            epoch=self._epoch,
            generation=generation,
            connection_id=connection_id,
        )
        self._current_owner = token
        self._latest_owner = token
        return token

    def _record_dispatch_failure(
        self, index: int, cause: CommunicationFailure
    ) -> None:
        spec = self._specs[index]
        self._protection_states[index] = self._protection_states[
            index
        ].reset_timing_gap()
        self._latch_joint_fault(
            spec.name,
            spec.motor_id,
            communication_error=cause,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample,
            joint.health,
            joint.received_at,
            cause,
        )

    def _latch_joint_fault(
        self,
        name: str,
        motor_id: int,
        *,
        errors: int = 0,
        warnings: int = 0,
        timeout: bool = False,
        communication_error: CommunicationFailure | None = None,
        stale: bool = False,
        position_limit: bool = False,
        speed_limit: bool = False,
        effort_limit: bool = False,
        constraint_fault: bool = False,
        driver_temperature_limit: bool = False,
        winding_temperature_limit: bool = False,
        continuous_effort_limit: bool = False,
    ) -> None:
        existing = self._faults.get(name) or JointFault(name, motor_id)
        communication_errors = existing.communication_errors
        if communication_error is not None and communication_error not in communication_errors:
            communication_errors += (communication_error,)
        fault = JointFault(
            name, motor_id,
            errors=existing.errors | errors,
            warnings=existing.warnings | warnings,
            timeout=existing.timeout or timeout,
            stale=existing.stale or stale,
            communication_error=communication_error or existing.communication_error,
            communication_errors=communication_errors,
            position_limit=existing.position_limit or position_limit,
            speed_limit=existing.speed_limit or speed_limit,
            effort_limit=existing.effort_limit or effort_limit or continuous_effort_limit,
            constraint_fault=existing.constraint_fault or constraint_fault,
            driver_temperature_limit=existing.driver_temperature_limit or driver_temperature_limit,
            winding_temperature_limit=existing.winding_temperature_limit or winding_temperature_limit,
            continuous_effort_limit=existing.continuous_effort_limit or continuous_effort_limit,
        )
        self._faults[name] = fault
        if self._state is not State.DISCONNECTED:
            self._state = State.FAULT
        self._revoke_authority()

    def _latch_measured_violation(self, spec: JointSpec, v: MeasuredViolation) -> None:
        self._latch_joint_fault(
            spec.name,
            spec.motor_id,
            position_limit=v.position_limit,
            speed_limit=v.speed_limit,
            effort_limit=v.effort_limit,
            driver_temperature_limit=v.driver_temperature_limit,
            winding_temperature_limit=v.winding_temperature_limit,
            continuous_effort_limit=v.continuous_effort_limit,
        )

    def _withdraw_expired_goal(self) -> None:
        self._revoke_authority()
        if self._faults:
            self._state = State.FAULT
        elif self._state in (State.ARMED, State.MOVING):
            self._state = State.STOPPED

    def _now(self) -> float:
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("clock must return a finite real number")
        try:
            result = float(value)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("clock must return a finite real number") from exc
        if not math.isfinite(result):
            raise ValueError("clock must return a finite real number")
        if self._now_high_water_s is not None and result < self._now_high_water_s:
            raise ValueError(
                f"clock regressed from {self._now_high_water_s} to {result}"
            )
        self._now_high_water_s = result
        return result

    @staticmethod
    def _age(received_at: float, now: float) -> float:
        age = now - received_at
        if not math.isfinite(age) or age < 0.0:
            raise ValueError("clock must be monotonic and feedback age finite")
        return age

    def _all_fresh(self, now: float) -> bool:
        return all(
            joint.valid
            and joint.received_at is not None
            and self._age(joint.received_at, now) <= self._feedback_max_age_s
            for joint in self._observations
        )

    def _housekeeping(self, now: float) -> DecisionCode | None:
        if self._state in (State.READY, State.ARMED, State.MOVING):
            stale_by_joint: list[bool] = []
            violations: list[MeasuredViolation] = []
            for spec, joint in zip(self._specs, self._observations):
                stale_by_joint.append(
                    not joint.valid
                    or joint.received_at is None
                    or self._age(joint.received_at, now) > self._feedback_max_age_s
                )
                if joint.valid and joint.sample is not None and joint.health is not None:
                    violations.append(check_joint_limits(spec, joint.sample, joint.health))
                else:
                    violations.append(MeasuredViolation())
            for spec, stale, v in zip(self._specs, stale_by_joint, violations):
                if stale:
                    self._latch_joint_fault(spec.name, spec.motor_id, stale=True)
                if v.has_violation:
                    self._latch_measured_violation(spec, v)
            if any(stale_by_joint):
                return DecisionCode.STALE_FEEDBACK
            for v in violations:
                if v.primary_decision_code is not None:
                    return v.primary_decision_code
        if (
            self._admitted_target is not None
            and now >= self._admitted_target.window.expires_at_s
        ):
            self._withdraw_expired_goal()
            return DecisionCode.EXPIRED
        return None

    def issue_window(self, valid_for_s: float) -> IntentWindow:
        if isinstance(valid_for_s, bool) or not isinstance(valid_for_s, (int, float)):
            raise ValueError("valid_for_s must be a finite positive real number")
        try:
            valid_for_s = float(valid_for_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("valid_for_s must be finite") from exc
        if not math.isfinite(valid_for_s) or valid_for_s <= 0.0:
            raise ValueError("valid_for_s must be finite and positive")
        if valid_for_s > self._max_window_s:
            raise ValueError(
                f"valid_for_s ({valid_for_s}) exceeds configured maximum window ({self._max_window_s})"
            )
        now = self._now()
        window_id = self._next_window_id
        if window_id > (1 << 64) - 1:
            raise OverflowError("window ID sequence exhausted")
        self._next_window_id += 1
        window = IntentWindow(
            id=window_id,
            created_at_s=now,
            expires_at_s=now + valid_for_s,
        )
        self._offered_window = window
        return window

    def begin_connect(self) -> Decision:
        if self._state is not State.DISCONNECTED or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        self._state = State.CONNECTING
        return self._accepted()

    def connected(self, source: SourceIdentity) -> Decision:
        if self._state is not State.CONNECTING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not isinstance(source, SourceIdentity):
            return self._rejected(DecisionCode.INVALID_SOURCE)
        self._clear_observations()
        self._source = source
        self._state = State.CONNECTED
        return self._accepted()

    def begin_check(self, *, acknowledge_fault: bool = False) -> Decision:
        if type(acknowledge_fault) is not bool:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._state not in (State.CONNECTED, State.STOPPED, State.FAULT) or self._dispatch_claim is not None:
            return self._rejected(DecisionCode.INVALID_STATE)
        if bool(self._faults) and not acknowledge_fault:
            return self._rejected(DecisionCode.FAULT_ACK_REQUIRED)
        self._clear_observations()
        self._admitted_target = None
        self._confirmed_references = [None for _ in self._specs]
        self._invalidate_plan()
        self._state = State.CHECKING
        self._recovery_authorized = acknowledge_fault
        self._protection_states = [
            state.reset_timing_gap() for state in self._protection_states
        ]
        return self._accepted()

    def receive(
        self, motor_id: int, sample: JointSample, status: MotorHealth
    ) -> Decision:
        if self._state not in (
            State.CONNECTED,
            State.CHECKING,
            State.READY,
            State.ARMED,
            State.MOVING,
            State.STOPPED,
            State.FAULT,
        ):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)
        if not isinstance(sample, JointSample) or not isinstance(status, MotorHealth):
            return self._rejected(DecisionCode.INVALID_OBSERVATION)

        now = self._now()
        self._observations[index] = JointStatus(sample, status, now)
        spec = self._specs[index]
        v, next_pstate, _ = transition_protection(
            spec,
            sample,
            status,
            self._protection_states[index],
            now,
            self._feedback_max_age_s,
            self._recovery_authorized,
        )
        self._protection_states[index] = next_pstate
        if not status.healthy:
            self._latch_joint_fault(
                spec.name,
                motor_id,
                errors=status.errors,
                warnings=status.warnings,
                timeout=status.timeout,
            )
        if v.has_violation:
            self._latch_measured_violation(spec, v)
            return self._rejected(v.primary_decision_code)
        return self._accepted()

    def communication_failed(
        self, motor_id: int, code: CommunicationFailure
    ) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if type(motor_id) is not int:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        index = self._id_to_index.get(motor_id)
        if index is None:
            return self._rejected(DecisionCode.UNKNOWN_JOINT)

        if not isinstance(code, CommunicationFailure):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        failure_code = code

        self._protection_states[index] = self._protection_states[index].reset_timing_gap()
        spec = self._specs[index]
        self._latch_joint_fault(
            spec.name,
            motor_id,
            communication_error=failure_code,
        )
        joint = self._observations[index]
        self._observations[index] = JointStatus(
            joint.sample, joint.health, joint.received_at, failure_code
        )
        return self._accepted()

    def checked(self) -> Decision:
        if self._state is not State.CHECKING:
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        violations = [
            check_joint_limits(spec, joint.sample, joint.health)
            for spec, joint in zip(self._specs, self._observations)
        ]
        if any(v.has_violation for v in violations):
            for spec, v in zip(self._specs, violations):
                if v.has_violation:
                    self._latch_measured_violation(spec, v)
            for v in violations:
                if v.primary_decision_code is not None:
                    return self._rejected(v.primary_decision_code)

        if bool(self._faults):
            below_recovery = all(
                joint.health.driver_c <= spec.protection.driver_reset_c
                and joint.health.winding_c <= spec.protection.winding_reset_c
                and abs(joint.sample.tau_nm) <= spec.protection.continuous_effort_nm
                for spec, joint in zip(self._specs, self._observations)
            )
            dwell_satisfied = all(
                pstate.recovery_satisfies(spec.protection.recovery_dwell_s)
                for spec, pstate in zip(self._specs, self._protection_states)
            )
            if not (self._recovery_authorized and below_recovery and dwell_satisfied):
                return self._rejected(DecisionCode.FAULT_LATCHED)

        self._state = State.READY
        self._faults.clear()
        self._recovery_authorized = False
        self._confirmed_references = [
            JointTrajectoryReference(
                q_rad=joint.sample.q_rad,
                position_step_velocity_rad_s=0.0,
                encoded_velocity_rad_s=0.0,
                sample_time_s=joint.received_at,
                is_emitted=False,
            )
            for joint in self._observations
        ]
        return self._accepted()

    def arm(self, owner: OwnerToken) -> Decision:
        if self._state is not State.READY:
            return self._rejected(DecisionCode.INVALID_STATE)
        if not owner_tokens_match(owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)
        if bool(self._faults):
            return self._rejected(DecisionCode.FAULT_LATCHED)
        if any(not joint.valid for joint in self._observations):
            return self._rejected(DecisionCode.OBSERVATIONS_INCOMPLETE)
        now = self._now()
        if not self._all_fresh(now):
            return self._rejected(DecisionCode.STALE_FEEDBACK)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)
        if any(joint.health.mode != 0 for joint in self._observations):
            return self._rejected(DecisionCode.NOT_STOPPED)

        violations = [
            check_joint_limits(spec, joint.sample, joint.health)
            for spec, joint in zip(self._specs, self._observations)
        ]
        if any(v.has_violation for v in violations):
            for spec, v in zip(self._specs, violations):
                if v.has_violation:
                    self._latch_measured_violation(spec, v)
            for v in violations:
                if v.primary_decision_code is not None:
                    return self._rejected(v.primary_decision_code)

        self._state = State.ARMED
        return self._accepted()

    def tick(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        self._housekeeping(now)
        return self._accepted()

    def submit_target(self, target: Target) -> Decision:
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        now = self._now()
        housekeeping = self._housekeeping(now)
        if housekeeping is not None:
            return self._rejected(housekeeping)
        if self._state not in (State.ARMED, State.MOVING):
            return self._rejected(DecisionCode.INVALID_STATE)
        if any(not joint.healthy for joint in self._observations):
            return self._rejected(DecisionCode.UNHEALTHY)

        if not isinstance(target, Target) or len(target.joints) != len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        if not owner_tokens_match(target.owner, self._current_owner):
            return self._rejected(DecisionCode.INVALID_OWNER)

        if not isinstance(target.window, IntentWindow):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if self._offered_window is None:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if target.window.id < self._offered_window.id:
            return self._rejected(DecisionCode.EXPIRED)
        if target.window.id != self._offered_window.id:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if (
            target.window.created_at_s != self._offered_window.created_at_s
            or target.window.expires_at_s != self._offered_window.expires_at_s
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if now >= target.window.expires_at_s:
            return self._rejected(DecisionCode.EXPIRED)

        if not self._all_fresh(now) or any(
            not joint.valid for joint in self._observations
        ):
            return self._rejected(DecisionCode.STALE_FEEDBACK)

        validation_failures = validate_target_vector(
            self._specs,
            target,
            tuple(joint.sample for joint in self._observations),
        )
        if validation_failures:
            return self._rejected(validation_failures[0].code)

        if target.sequence <= self._last_sequence:
            return self._rejected(DecisionCode.DUPLICATE_OR_OLDER)

        self._admitted_target = target
        self._last_sequence = target.sequence
        self._invalidate_plan()
        return self._accepted()

    def prepare_refresh(self) -> RefreshPlan | None:
        if self._dispatch_claim is not None:
            return None
        if self._state not in (State.ARMED, State.MOVING):
            return None
        if self._state is State.FAULT or bool(self._faults):
            return None
        try:
            now = self._now()
        except ValueError:
            self.stop()
            raise
        if self._housekeeping(now) is not None:
            return None
        if any(not joint.healthy for joint in self._observations):
            return None
        if self._admitted_target is None:
            return None
        if not owner_tokens_match(self._admitted_target.owner, self._current_owner):
            return None

        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid:
                return None
            v = check_joint_limits(spec, joint.sample, joint.health)
            if v.has_violation:
                self._latch_measured_violation(spec, v)
                self.stop()
                return None

        for spec, conf_ref in zip(self._specs, self._confirmed_references):
            if conf_ref is None:
                return None
            gap = now - conf_ref.sample_time_s
            if not math.isfinite(gap) or gap < 0.0:
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
                self.stop()
                return None
            if gap > self._max_reference_gap_s:
                self.stop()
                return None

        prepared = prepare_complete_reference(
            self._specs,
            self._admitted_target,
            tuple(self._confirmed_references),
            tuple(joint.sample for joint in self._observations),
            now,
            self._max_reference_gap_s,
        )
        if not prepared.ready:
            for failure in prepared.failures:
                if failure.joint_index is None:
                    continue
                spec = self._specs[failure.joint_index]
                if failure.code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, position_limit=True
                    )
                elif failure.code is DecisionCode.SPEED_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, speed_limit=True
                    )
                elif failure.code is DecisionCode.EFFORT_OUT_OF_BOUNDS:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, effort_limit=True
                    )
                else:
                    self._latch_joint_fault(
                        spec.name, spec.motor_id, constraint_fault=True
                    )
            self.stop()
            return None

        plan_id = self._next_plan_id
        if plan_id > (1 << 64) - 1:
            raise OverflowError("plan ID sequence exhausted")
        self._next_plan_id += 1

        plan = RefreshPlan(
            plan_id=plan_id,
            target=self._admitted_target,
            prepared_at_s=now,
            joint_targets=prepared.joint_targets,
            packets=prepared.packets,
            proposed_references=prepared.proposed_references,
        )
        self._prepared_plan = plan
        self._next_dispatch_index = 0
        return plan

    def claim_dispatch(self, plan_id: int, index: int) -> bool:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return False
        if self._dispatch_claim is not None:
            return False
        if self._prepared_plan is None or self._prepared_plan.plan_id != plan_id:
            return False
        if self._state not in (State.ARMED, State.MOVING):
            return False
        if self._state is State.FAULT or bool(self._faults):
            return False
        if index < 0 or index >= len(self._specs):
            return False
        if index != self._next_dispatch_index:
            return False

        try:
            now = self._now()
        except Exception:
            self.stop()
            raise
        if self._housekeeping(now) is not None:
            return False
        if self._admitted_target is None or self._prepared_plan is None:
            return False
        if not owner_tokens_match(self._prepared_plan.target.owner, self._current_owner):
            return False
        if any(not joint.healthy for joint in self._observations):
            return False

        if not self._all_fresh(now):
            return False
        for spec, joint in zip(self._specs, self._observations):
            if not joint.valid:
                return False
            v = check_joint_limits(spec, joint.sample, joint.health)
            if v.has_violation:
                self._latch_measured_violation(spec, v)
                self.stop()
                return False

        conf_ref = self._confirmed_references[index]
        if conf_ref is not None:
            gap = now - conf_ref.sample_time_s
            if not math.isfinite(gap) or gap < 0.0 or gap > self._max_reference_gap_s:
                self.stop()
                return False

        plan_joint = self._prepared_plan.joint_targets[index]
        spec = self._specs[index]
        prop_ref = self._prepared_plan.proposed_references[index]
        failure_code = verify_dispatch_claim(
            spec=spec,
            prop_ref=prop_ref,
            conf_ref=conf_ref,
            plan_joint=plan_joint,
            packet=self._prepared_plan.packets[index],
            goal=self._prepared_plan.target.joints[index],
            sample=self._observations[index].sample,
            prepared_at_s=self._prepared_plan.prepared_at_s,
        )
        if failure_code is not None:
            if failure_code is DecisionCode.POSITION_OUT_OF_BOUNDS:
                self._latch_joint_fault(spec.name, spec.motor_id, position_limit=True)
            elif failure_code is DecisionCode.SPEED_OUT_OF_BOUNDS:
                self._latch_joint_fault(spec.name, spec.motor_id, speed_limit=True)
            elif failure_code is DecisionCode.EFFORT_OUT_OF_BOUNDS:
                self._latch_joint_fault(spec.name, spec.motor_id, effort_limit=True)
            else:
                self._latch_joint_fault(spec.name, spec.motor_id, constraint_fault=True)
            self.stop()
            return False

        self._dispatch_claim = _DispatchClaim(self._prepared_plan, index, now)
        return True

    def dispatch_result(
        self, plan_id: int, index: int, result: WriteResult
    ) -> Decision:
        if (
            type(plan_id) is not int
            or type(index) is not int
        ):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if not isinstance(result, WriteResult):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        claim = self._dispatch_claim
        if claim is None or claim.plan.plan_id != plan_id or claim.index != index:
            return self._rejected(DecisionCode.INVALID_ARGUMENT)
        if index < 0 or index >= len(self._specs):
            return self._rejected(DecisionCode.INVALID_ARGUMENT)

        plan = claim.plan
        joint_target = plan.joint_targets[index]
        self._dispatch_attempts[index] = JointDispatchAttempt(
            plan_id=plan.plan_id,
            sequence=plan.target.sequence,
            target=joint_target,
            result=result,
            started_at_s=claim.started_at_s,
            owner=plan.target.owner,
        )
        if result is WriteResult.COMPLETE:
            record = JointDispatchedRecord(
                sequence=plan.target.sequence,
                target=joint_target,
                dispatched_at_s=claim.started_at_s,
                owner=plan.target.owner,
            )
            self._dispatched_records[index] = record
            self._confirmed_references[index] = plan.proposed_references[index]
            try:
                now = self._now()
            except Exception:
                self._record_dispatch_failure(index, CommunicationFailure.CLOCK_FAILURE)
                self._dispatch_claim = None
                return self._rejected(DecisionCode.FAULT_LATCHED)

            housekeeping = self._housekeeping(now)
            still_current = (
                self._prepared_plan is plan
                and self._admitted_target is plan.target
                and self._state in (State.ARMED, State.MOVING)
                and not self._faults
                and owner_tokens_match(self._current_owner, plan.target.owner)
            )
            if still_current and housekeeping is None:
                self._next_dispatch_index = index + 1
                self._state = State.MOVING
            self._dispatch_claim = None
            return self._accepted()

        cause = (
            CommunicationFailure.PREWRITE_DEADLINE
            if result is WriteResult.PREWRITE_DEADLINE
            else CommunicationFailure.DRIVER_FAILURE
        )
        self._record_dispatch_failure(index, cause)
        self._dispatch_claim = None
        return self._rejected(DecisionCode.FAULT_LATCHED)

    def stop(self) -> Decision:
        if self._state in (State.DISCONNECTED, State.CONNECTING):
            return self._rejected(DecisionCode.INVALID_STATE)
        self._revoke_authority()
        self._recovery_authorized = False
        self._protection_states = [
            state.reset_timing_gap() for state in self._protection_states
        ]
        if self._state is State.FAULT or bool(self._faults):
            self._state = State.FAULT
        else:
            self._state = State.STOPPED
        return self._accepted()

    def disconnect(self) -> Decision:
        self._state = State.DISCONNECTED
        self._source = None
        self._recovery_authorized = False
        self._protection_states = [
            state.reset_timing_gap() for state in self._protection_states
        ]
        self._clear_observations()
        self._confirmed_references = [None for _ in self._specs]
        self._revoke_authority()
        return self._accepted()

    def snapshot(self) -> Snapshot:
        received = [joint.received_at for joint in self._observations]
        now = self._now() if any(value is not None for value in received) else None
        ages = tuple(
            None if value is None else self._age(value, now)
            for value in received
        )
        faults = tuple(self._faults[spec.name] for spec in self._specs
                       if spec.name in self._faults)
        return Snapshot(
            state=self._state,
            joint_names=tuple(spec.name for spec in self._specs),
            joints=tuple(self._observations),
            source=self._source,
            fault_latched=bool(self._faults),
            feedback_ages_s=ages,
            faults=faults,
            admitted_target=self._admitted_target,
            prepared_plan=self._prepared_plan,
            dispatched_records=tuple(self._dispatched_records),
            dispatch_attempts=tuple(self._dispatch_attempts),
            last_sequence=self._last_sequence,
            latest_owner=self._latest_owner,
            current_owner=self._current_owner,
            confirmed_references=tuple(self._confirmed_references),
        )

```

### station_step.py SHA256 def755c485e490fd4ebeab2313d78faa6bad31110d603040470588e86bd400f1
```python
"""Synchronous station step adapter and loop coordinator.

Executes canonical driver exchange with before_write/on_write hooks,
correlates actual outcomes, and feeds measurements to StationTimingTracker.
Transport acquisition stays outside; no port ownership or hardware I/O here.
"""

from collections.abc import Callable
import math
import time

from im6014_codec import command
from im6014_serial import (
    InvalidFeedbackError,
    TransactionTimeoutError,
    WriteCancelledError,
    exchange,
)
from joint_contract import CommunicationFailure, Decision, MotorHealth, State, WriteResult
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, OutputSample
from station_timing import (
    JointTransactionRecord,
    LoopStepRecord,
    StationTimingTracker,
    validate_finite_time,
)

__all__ = (
    "StationStepCoordinator",
    "mapped_health",
    "mapped_sample",
)


def mapped_sample(mapping: JointMap, reply: dict) -> JointSample:
    """Convert decoded wire feedback dictionary to a JointSample using joint mapping."""
    output = OutputSample(
        q_rad=reply["position_rad"],
        rpm=reply["rpm"],
        tau_nm=reply["torque_nm"],
    )
    return mapping.from_output(output)


def mapped_health(reply: dict) -> MotorHealth:
    """Convert decoded wire feedback dictionary to an immutable MotorHealth record."""
    return MotorHealth(
        mode=reply["mode"],
        errors=reply["errors"],
        warnings=reply["warnings"],
        timeout=bool(reply["timeout"]),
        driver_c=float(reply["driver_c"]),
        winding_c=float(reply["winding_c"]),
    )


class StationStepCoordinator:
    """Synchronous single-writer coordinator connecting JointCore, transport, and timing.

    Exercises the canonical driver exchange before_write and on_write lifecycle,
    distinguishes all failure modes without storing raw exception text, and
    maintains bounded timing records.
    """

    def __init__(
        self,
        core: JointCore,
        bus: object,
        timing: StationTimingTracker,
        *,
        clock: Callable[[], float] | None = None,
        deadline_s: float = 0.05,
    ) -> None:
        if not isinstance(core, JointCore):
            raise ValueError("core must be a JointCore instance")
        if bus is None:
            raise ValueError("bus must be a valid transport object")
        if not isinstance(timing, StationTimingTracker):
            raise ValueError("timing must be a StationTimingTracker instance")

        self.core = core
        self.bus = bus
        self.timing = timing
        self.deadline_s = validate_finite_time(deadline_s, "deadline_s")

        if clock is not None:
            if not callable(clock):
                raise ValueError("clock must be callable")
            self._clock = clock
        else:
            self._clock = getattr(core, "_clock", time.monotonic)

    def _now(self) -> float:
        val = self._clock()
        return validate_finite_time(val, "clock")

    def step(self, *, missed_slots: int = 0) -> LoopStepRecord:
        """Execute one complete station refresh cycle.

        Prepares a core refresh plan, coordinates per-joint write claims and exchanges,
        updates core observations, and logs actual timing records.
        """
        start_s = self._now()
        cycle_idx = self.timing.start_cycle(start_s)

        plan = self.core.prepare_refresh()
        if plan is None:
            # No refresh plan prepared (idle, stopped, faulted, or checking).
            # Tick core to maintain feedback freshness watchdog and fault checks.
            self.core.tick()
            end_s = self._now()
            snap = self.core.snapshot()
            feedback_ages = snap.feedback_ages_s
            return self.timing.end_cycle(
                end_s,
                feedback_ages=feedback_ages,
                # Skew describes samples received during this cycle; an idle
                # cycle has no current-cycle receive timestamps.
                feedback_timestamps=(),
                transactions=(),
                missed_slots=missed_slots,
            )

        plan_id = plan.plan_id
        sequence = plan.target.sequence
        owner = plan.target.owner
        packets = plan.packets

        tx_records: list[JointTransactionRecord] = []
        aborted = False

        for index, packet in enumerate(packets):
            spec = self.core.joint_specs[index]
            motor_id = spec.motor_id
            joint_name = spec.name

            if aborted:
                # Mode-1 writes aborted after prior failure; record skipped joint
                tx_time = self._now()
                tx = JointTransactionRecord(
                    cycle_index=cycle_idx,
                    joint_index=index,
                    joint_name=joint_name,
                    motor_id=motor_id,
                    plan_id=plan_id,
                    sequence=sequence,
                    owner=owner,
                    write_result=None,
                    outcome="SKIPPED",
                    started_s=tx_time,
                    ended_s=tx_time,
                    duration_s=0.0,
                    feedback_received=False,
                    feedback_timestamp_s=None,
                    feedback_age_s=None,
                )
                self.timing.record_transaction(tx)
                tx_records.append(tx)
                continue

            tx_start_s = self._now()
            write_result_holder: list[WriteResult | None] = [None]
            dispatch_decision_holder: list[Decision | None] = [None]
            claim_clock_failure = [False]

            def before_write(bound_plan_id: int = plan_id, bound_index: int = index) -> bool:
                # A failed core clock is a station fault, not a revoked-owner cancellation.
                try:
                    return self.core.claim_dispatch(bound_plan_id, bound_index)
                except Exception:
                    claim_clock_failure[0] = True
                    raise

            def on_write(
                result: WriteResult,
                bound_plan_id: int = plan_id,
                bound_index: int = index,
            ) -> None:
                write_result_holder[0] = result
                dispatch_decision_holder[0] = self.core.dispatch_result(
                    bound_plan_id, bound_index, result
                )

            outcome = "OK"
            feedback_received = False
            feedback_ts: float | None = None
            tx_feedback_age: float | None = None

            try:
                reply = exchange(
                    self.bus,
                    packet,
                    motor_id,
                    deadline_s=self.deadline_s,
                    before_write=before_write,
                    on_write=on_write,
                )
                dispatch_decision = dispatch_decision_holder[0]
                if dispatch_decision is not None and not dispatch_decision.accepted:
                    outcome = "CLOCK_FAILURE"
                    aborted = True
                else:
                    sample = mapped_sample(spec.mapping, reply)
                    health = mapped_health(reply)
                    try:
                        self.core.receive(motor_id, sample, health)
                        snapshot = self.core.snapshot()
                    except Exception:
                        outcome = "CLOCK_FAILURE"
                        self.core.communication_failed(
                            motor_id, CommunicationFailure.CLOCK_FAILURE
                        )
                        aborted = True
                    else:
                        joint = snapshot.joints[index]
                        feedback_received = joint.valid
                        feedback_ts = joint.received_at if joint.valid else None
                        tx_feedback_age = (
                            snapshot.feedback_ages_s[index] if joint.valid else None
                        )
            except WriteCancelledError:
                outcome = "WRITE_CANCELLED"
                aborted = True
            except InvalidFeedbackError:
                outcome = "INVALID_FEEDBACK"
                aborted = True
                self.core.communication_failed(
                    motor_id, CommunicationFailure.INVALID_FEEDBACK
                )
            except TransactionTimeoutError:
                if write_result_holder[0] is WriteResult.PREWRITE_DEADLINE:
                    outcome = "PREWRITE_DEADLINE"
                elif write_result_holder[0] in (WriteResult.PARTIAL, WriteResult.FAILED):
                    outcome = "DRIVER_FAILURE"
                else:
                    outcome = "TIMEOUT"
                    self.core.communication_failed(motor_id, CommunicationFailure.TIMEOUT)
                aborted = True
            except Exception:
                if claim_clock_failure[0]:
                    outcome = "CLOCK_FAILURE"
                    self.core.communication_failed(
                        motor_id, CommunicationFailure.CLOCK_FAILURE
                    )
                elif write_result_holder[0] is WriteResult.PREWRITE_DEADLINE:
                    outcome = "PREWRITE_DEADLINE"
                elif write_result_holder[0] in (WriteResult.PARTIAL, WriteResult.FAILED):
                    outcome = "DRIVER_FAILURE"
                    if dispatch_decision_holder[0] is None:
                        self.core.communication_failed(
                            motor_id, CommunicationFailure.DRIVER_FAILURE
                        )
                elif (
                    write_result_holder[0] is WriteResult.COMPLETE
                    and dispatch_decision_holder[0] is not None
                    and not dispatch_decision_holder[0].accepted
                ):
                    outcome = "CLOCK_FAILURE"
                else:
                    outcome = "DRIVER_FAILURE"
                    self.core.communication_failed(
                        motor_id, CommunicationFailure.DRIVER_FAILURE
                    )
                aborted = True

            if outcome != "OK":
                self.core.stop()

            tx_end_s = self._now()
            tx_duration = tx_end_s - tx_start_s

            tx = JointTransactionRecord(
                cycle_index=cycle_idx,
                joint_index=index,
                joint_name=joint_name,
                motor_id=motor_id,
                plan_id=plan_id,
                sequence=sequence,
                owner=owner,
                write_result=write_result_holder[0],
                outcome=outcome,
                started_s=tx_start_s,
                ended_s=tx_end_s,
                duration_s=tx_duration,
                feedback_received=feedback_received,
                feedback_timestamp_s=feedback_ts,
                feedback_age_s=tx_feedback_age,
            )
            self.timing.record_transaction(tx)
            tx_records.append(tx)

        cycle_end_s = self._now()
        snap = self.core.snapshot()
        feedback_ages = snap.feedback_ages_s
        feedback_timestamps = tuple(
            tx.feedback_timestamp_s
            for tx in tx_records
            if tx.feedback_received and tx.feedback_timestamp_s is not None
        )

        return self.timing.end_cycle(
            cycle_end_s,
            feedback_ages=feedback_ages,
            feedback_timestamps=feedback_timestamps,
            transactions=tuple(tx_records),
            missed_slots=missed_slots,
        )

    def check_step(self, *, deadline_s: float | None = None) -> tuple[JointTransactionRecord, ...]:
        """Execute one round of Stop feedback queries to check all configured motors."""
        deadline = self.deadline_s if deadline_s is None else validate_finite_time(deadline_s, "deadline_s")
        tx_records: list[JointTransactionRecord] = []
        cycle_idx = self.timing.snapshot().counters.cycles

        for index, spec in enumerate(self.core.joint_specs):
            motor_id = spec.motor_id
            stop_packet = command(motor_id, mode=0)
            t_start = self._now()
            outcome = "OK"
            feedback_received = False
            feedback_ts = None
            tx_feedback_age = None
            write_result: WriteResult | None = None

            def on_write(result: WriteResult) -> None:
                nonlocal write_result
                write_result = result

            try:
                reply = exchange(
                    self.bus,
                    stop_packet,
                    motor_id,
                    deadline_s=deadline,
                    on_write=on_write,
                )
                sample = mapped_sample(spec.mapping, reply)
                health = mapped_health(reply)
                try:
                    self.core.receive(motor_id, sample, health)
                    snapshot = self.core.snapshot()
                except Exception:
                    outcome = "CLOCK_FAILURE"
                    self.core.communication_failed(
                        motor_id, CommunicationFailure.CLOCK_FAILURE
                    )
                else:
                    joint = snapshot.joints[index]
                    feedback_received = joint.valid
                    feedback_ts = joint.received_at if joint.valid else None
                    tx_feedback_age = (
                        snapshot.feedback_ages_s[index] if joint.valid else None
                    )
            except InvalidFeedbackError:
                outcome = "INVALID_FEEDBACK"
                self.core.communication_failed(
                    motor_id, CommunicationFailure.INVALID_FEEDBACK
                )
            except TransactionTimeoutError:
                if write_result is WriteResult.PREWRITE_DEADLINE:
                    outcome = "PREWRITE_DEADLINE"
                    self.core.communication_failed(
                        motor_id, CommunicationFailure.PREWRITE_DEADLINE
                    )
                elif write_result in (WriteResult.PARTIAL, WriteResult.FAILED):
                    outcome = "DRIVER_FAILURE"
                    self.core.communication_failed(
                        motor_id, CommunicationFailure.DRIVER_FAILURE
                    )
                else:
                    outcome = "TIMEOUT"
                    self.core.communication_failed(motor_id, CommunicationFailure.TIMEOUT)
            except Exception:
                outcome = "DRIVER_FAILURE"
                self.core.communication_failed(
                    motor_id, CommunicationFailure.DRIVER_FAILURE
                )

            t_end = self._now()
            tx = JointTransactionRecord(
                cycle_index=cycle_idx,
                joint_index=index,
                joint_name=spec.name,
                motor_id=motor_id,
                plan_id=None,
                sequence=None,
                owner=None,
                write_result=write_result,
                outcome=outcome,
                started_s=t_start,
                ended_s=t_end,
                duration_s=t_end - t_start,
                feedback_received=feedback_received,
                feedback_timestamp_s=feedback_ts,
                feedback_age_s=tx_feedback_age,
            )
            self.timing.record_transaction(tx)
            tx_records.append(tx)

        return tuple(tx_records)

    def run_steps(
        self,
        count: int,
        *,
        sleep_fn: Callable[[float], None] | None = None,
    ) -> list[LoopStepRecord]:
        """Run count station steps pacing by nominal period and skipping missed slots.

        Never bursts or executes back-to-back iterations to catch up on missed slots.
        """
        if type(count) is not int or count < 1:
            raise ValueError("count must be a positive integer")

        records: list[LoopStepRecord] = []
        nominal = self.timing.config.nominal_period_s
        next_slot = self._now()
        sleep = time.sleep if sleep_fn is None else sleep_fn

        for _ in range(count):
            missed = 0
            while True:
                t_current = self._now()
                if t_current < next_slot:
                    sleep(next_slot - t_current)
                    continue
                if t_current > next_slot:
                    missed, _ = self.timing.calculate_slot_skip(t_current, next_slot)
                break

            record = self.step(missed_slots=missed)
            records.append(record)
            next_slot = record.started_s + nominal
            if not math.isfinite(next_slot) or next_slot <= record.started_s:
                raise ValueError("next cycle start is not representable as a future timestamp")

        return records

```

### station_timing.py SHA256 7bcf73ce9257ffbcfade2ae96a3bc3443708570bbcd7e9aa66795b2732c191a8
```python
"""Station timing instrumentation and bounded measurement tracking.

Tracks actual loop start-to-start period, nominal configuration separately,
per-joint transaction start/end duration/result, completion overrun, missed
slots skipped (never burst), and per-joint observed feedback age and sampling skew.

Exact finite monotonic checks; no rounded nominal numbers reported as actuals;
fixed counter saturation behavior.
"""

from collections import deque
from collections.abc import Iterable
from dataclasses import dataclass, field
from fractions import Fraction
import math
import time

from joint_contract import OwnerToken, WriteResult

__all__ = (
    "DEFAULT_CAPACITY",
    "UINT64_MAX",
    "VALID_OUTCOMES",
    "JointTransactionRecord",
    "LoopStepRecord",
    "StationTimingConfig",
    "StationTimingTracker",
    "TimingCounters",
    "TimingSnapshot",
    "saturate_add",
    "validate_finite_time",
    "validate_monotonic_time",
)

UINT64_MAX = (1 << 64) - 1
DEFAULT_CAPACITY = 256

VALID_OUTCOMES = frozenset((
    "OK",
    "TIMEOUT",
    "INVALID_FEEDBACK",
    "WRITE_CANCELLED",
    "PREWRITE_DEADLINE",
    "DRIVER_FAILURE",
    "SKIPPED",
    "CLOCK_FAILURE",
))


def saturate_add(current: int, delta: int) -> int:
    """Add delta to current saturating at UINT64_MAX without wrapping."""
    if type(current) is not int or current < 0:
        raise ValueError("current counter must be a non-negative integer")
    if type(delta) is not int or delta < 0:
        raise ValueError("counter delta must be a non-negative integer")
    if current >= UINT64_MAX or delta == 0:
        return UINT64_MAX if current >= UINT64_MAX else current
    result = current + delta
    return UINT64_MAX if result > UINT64_MAX else result


def validate_finite_time(value: object, name: str = "time") -> float:
    """Validate that value is a finite, non-negative real int or float."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a finite real number")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a finite real number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be a finite real number")
    if result < 0.0:
        raise ValueError(f"{name} must be non-negative")
    return result


def validate_monotonic_time(value: object, last_time: float | None = None, name: str = "time") -> float:
    """Validate finite non-negative time and monotonic advance against last_time."""
    result = validate_finite_time(value, name)
    if last_time is not None:
        if result < last_time:
            raise ValueError(f"{name} regressed from {last_time} to {result}")
    return result


@dataclass(frozen=True)
class StationTimingConfig:
    """Nominal station timing configuration, kept separate from actual measurements."""

    nominal_period_s: float
    capacity: int = DEFAULT_CAPACITY

    def __post_init__(self) -> None:
        if isinstance(self.nominal_period_s, bool) or not isinstance(self.nominal_period_s, (int, float)):
            raise ValueError("nominal_period_s must be a finite positive number")
        try:
            period = float(self.nominal_period_s)
        except (OverflowError, TypeError, ValueError) as exc:
            raise ValueError("nominal_period_s must be finite and positive") from exc
        if not math.isfinite(period) or period <= 0.0:
            raise ValueError("nominal_period_s must be finite and positive")
        object.__setattr__(self, "nominal_period_s", period)

        if type(self.capacity) is not int or not (1 <= self.capacity <= 65536):
            raise ValueError("capacity must be an integer between 1 and 65536")


@dataclass(frozen=True)
class JointTransactionRecord:
    """Per-joint transaction start/end duration and outcome correlation."""

    cycle_index: int
    joint_index: int
    joint_name: str
    motor_id: int
    plan_id: int | None
    sequence: int | None
    owner: OwnerToken | None
    write_result: WriteResult | None
    outcome: str
    started_s: float
    ended_s: float
    duration_s: float
    feedback_received: bool
    feedback_timestamp_s: float | None = None
    feedback_age_s: float | None = None

    def __post_init__(self) -> None:
        if type(self.cycle_index) is not int or self.cycle_index < 0:
            raise ValueError("cycle_index must be a non-negative integer")
        if type(self.joint_index) is not int or self.joint_index < 0:
            raise ValueError("joint_index must be a non-negative integer")
        if type(self.joint_name) is not str or not self.joint_name.strip():
            raise ValueError("joint_name must be a non-empty string")
        if type(self.motor_id) is not int or not (0 <= self.motor_id <= 14):
            raise ValueError("motor_id must be an integer from 0 to 14")
        if self.plan_id is not None and (type(self.plan_id) is not int or self.plan_id < 0):
            raise ValueError("plan_id must be None or a non-negative integer")
        if self.sequence is not None and (type(self.sequence) is not int or self.sequence < 0):
            raise ValueError("sequence must be None or a non-negative integer")
        if self.owner is not None and not isinstance(self.owner, OwnerToken):
            raise ValueError("owner must be None or an OwnerToken")
        if self.write_result is not None and not isinstance(self.write_result, WriteResult):
            raise ValueError("write_result must be None or a WriteResult")
        if type(self.outcome) is not str or not self.outcome.strip():
            raise ValueError("outcome must be a non-empty string")
        if self.outcome not in VALID_OUTCOMES:
            raise ValueError(f"outcome {self.outcome!r} is not in VALID_OUTCOMES")

        started = validate_finite_time(self.started_s, "started_s")
        ended = validate_finite_time(self.ended_s, "ended_s")
        if ended < started:
            raise ValueError("ended_s must be greater than or equal to started_s")
        object.__setattr__(self, "started_s", started)
        object.__setattr__(self, "ended_s", ended)

        duration = validate_finite_time(self.duration_s, "duration_s")
        expected_duration = ended - started
        if not math.isclose(duration, expected_duration, rel_tol=1e-9, abs_tol=1e-9):
            raise ValueError(f"duration_s {duration} does not match ended_s - started_s {expected_duration}")
        object.__setattr__(self, "duration_s", duration)

        if type(self.feedback_received) is not bool:
            raise ValueError("feedback_received must be a bool")

        if self.feedback_timestamp_s is not None:
            fb_ts = validate_finite_time(self.feedback_timestamp_s, "feedback_timestamp_s")
            object.__setattr__(self, "feedback_timestamp_s", fb_ts)

        if self.feedback_age_s is not None:
            fb_age = validate_finite_time(self.feedback_age_s, "feedback_age_s")
            object.__setattr__(self, "feedback_age_s", fb_age)


@dataclass(frozen=True)
class LoopStepRecord:
    """Actual loop iteration start-to-start timing, overrun, and joint records."""

    cycle_index: int
    started_s: float
    ended_s: float
    execution_duration_s: float
    actual_period_s: float | None
    overrun: bool
    overrun_s: float
    overrun_joints: tuple[str, ...]
    missed_slots_skipped: int
    feedback_ages_s: tuple[float | None, ...]
    sampling_skew_s: float | None
    transactions: tuple[JointTransactionRecord, ...]

    def __post_init__(self) -> None:
        if type(self.cycle_index) is not int or self.cycle_index < 0:
            raise ValueError("cycle_index must be a non-negative integer")

        started = validate_finite_time(self.started_s, "started_s")
        ended = validate_finite_time(self.ended_s, "ended_s")
        if ended < started:
            raise ValueError("ended_s must be greater than or equal to started_s")
        object.__setattr__(self, "started_s", started)
        object.__setattr__(self, "ended_s", ended)

        exec_dur = validate_finite_time(self.execution_duration_s, "execution_duration_s")
        expected_dur = ended - started
        if not math.isclose(exec_dur, expected_dur, rel_tol=1e-9, abs_tol=1e-9):
            raise ValueError("execution_duration_s must equal ended_s - started_s")
        object.__setattr__(self, "execution_duration_s", exec_dur)

        if self.actual_period_s is not None:
            period = validate_finite_time(self.actual_period_s, "actual_period_s")
            object.__setattr__(self, "actual_period_s", period)

        if type(self.overrun) is not bool:
            raise ValueError("overrun must be a bool")

        overrun_dur = validate_finite_time(self.overrun_s, "overrun_s")
        object.__setattr__(self, "overrun_s", overrun_dur)

        if type(self.overrun_joints) is not tuple or any(type(j) is not str for j in self.overrun_joints):
            raise ValueError("overrun_joints must be a tuple of joint name strings")

        if type(self.missed_slots_skipped) is not int or self.missed_slots_skipped < 0:
            raise ValueError("missed_slots_skipped must be a non-negative integer")

        if type(self.feedback_ages_s) is not tuple:
            raise ValueError("feedback_ages_s must be a tuple")
        for age in self.feedback_ages_s:
            if age is not None:
                validate_finite_time(age, "feedback_age")

        if self.sampling_skew_s is not None:
            skew = validate_finite_time(self.sampling_skew_s, "sampling_skew_s")
            object.__setattr__(self, "sampling_skew_s", skew)

        if type(self.transactions) is not tuple or any(not isinstance(t, JointTransactionRecord) for t in self.transactions):
            raise ValueError("transactions must be a tuple of JointTransactionRecord")


@dataclass(frozen=True)
class TimingCounters:
    """Fixed-capacity saturated cumulative event counters."""

    cycles: int
    transactions: int
    successful_transactions: int
    failed_transactions: int
    timeout_transactions: int
    invalid_feedback_transactions: int
    write_cancelled_transactions: int
    prewrite_deadline_transactions: int
    driver_failure_transactions: int
    skipped_transactions: int
    clock_failure_transactions: int
    overruns: int
    missed_slots_skipped: int

    def __post_init__(self) -> None:
        for name in (
            "cycles",
            "transactions",
            "successful_transactions",
            "failed_transactions",
            "timeout_transactions",
            "invalid_feedback_transactions",
            "write_cancelled_transactions",
            "prewrite_deadline_transactions",
            "driver_failure_transactions",
            "skipped_transactions",
            "clock_failure_transactions",
            "overruns",
            "missed_slots_skipped",
        ):
            val = getattr(self, name)
            if type(val) is not int or not (0 <= val <= UINT64_MAX):
                raise ValueError(f"{name} must be a uint64 integer")


@dataclass(frozen=True)
class TimingSnapshot:
    """Immutable copy-out snapshot of timing configuration, counters, and statistics."""

    config: StationTimingConfig
    counters: TimingCounters
    total_overrun_s: float
    last_cycle: LoopStepRecord | None
    recent_cycles: tuple[LoopStepRecord, ...]
    recent_transactions: tuple[JointTransactionRecord, ...]
    min_actual_period_s: float | None
    max_actual_period_s: float | None
    mean_actual_period_s: float | None
    min_execution_duration_s: float | None
    max_execution_duration_s: float | None
    mean_execution_duration_s: float | None
    min_transaction_duration_s: float | None
    max_transaction_duration_s: float | None
    mean_transaction_duration_s: float | None
    latest_feedback_ages_s: tuple[float | None, ...]
    latest_sampling_skew_s: float | None


class StationTimingTracker:
    """Thread-confined timing tracker with bounded records and exact monotonicity.

    Calculates actual start-to-start loop period, separate nominal configuration,
    transaction start/end duration, completion overrun attribution, missed slot
    skipping without bursting, feedback age and sampling skew.
    """

    def __init__(self, config: StationTimingConfig | float, capacity: int = DEFAULT_CAPACITY) -> None:
        if isinstance(config, (int, float)) and not isinstance(config, bool):
            self._config = StationTimingConfig(nominal_period_s=float(config), capacity=capacity)
        elif isinstance(config, StationTimingConfig):
            self._config = config
        else:
            raise ValueError("config must be StationTimingConfig or nominal period float")

        self._recent_cycles: deque[LoopStepRecord] = deque(maxlen=self._config.capacity)
        self._recent_transactions: deque[JointTransactionRecord] = deque(maxlen=self._config.capacity)

        # High-water mark of monotonic time
        self._high_water_s: float | None = None
        self._last_cycle_start_s: float | None = None
        self._current_cycle_start_s: float | None = None
        self._current_cycle_index: int = 0
        self._cycle_in_progress: bool = False

        # Cumulative counters saturating at UINT64_MAX
        self._counter_cycles: int = 0
        self._counter_transactions: int = 0
        self._counter_successful: int = 0
        self._counter_failed: int = 0
        self._counter_timeout: int = 0
        self._counter_invalid_feedback: int = 0
        self._counter_write_cancelled: int = 0
        self._counter_prewrite_deadline: int = 0
        self._counter_driver_failure: int = 0
        self._counter_skipped: int = 0
        self._counter_clock_failure: int = 0
        self._counter_overruns: int = 0
        self._counter_missed_slots: int = 0

        self._total_overrun_s: float = 0.0

        # Cached statistics over history
        self._actual_periods: list[float] = []
        self._execution_durations: list[float] = []
        self._transaction_durations: list[float] = []
        self._latest_feedback_ages: tuple[float | None, ...] = ()
        self._latest_sampling_skew: float | None = None

    @property
    def config(self) -> StationTimingConfig:
        return self._config

    def start_cycle(self, now_s: float) -> int:
        """Start a new loop cycle iteration, verifying clock monotonicity.

        Returns the assigned cycle_index.
        """
        if self._cycle_in_progress:
            raise RuntimeError("start_cycle called before the active cycle ended")
        now = validate_monotonic_time(now_s, self._high_water_s, "loop cycle start")
        self._high_water_s = now
        self._current_cycle_start_s = now
        self._cycle_in_progress = True
        return self._current_cycle_index

    def record_transaction(self, record: JointTransactionRecord) -> None:
        """Record one per-joint transaction outcome and duration."""
        if not isinstance(record, JointTransactionRecord):
            raise ValueError("record must be a JointTransactionRecord")

        started = validate_monotonic_time(
            record.started_s, self._high_water_s, "transaction start"
        )
        ended = validate_monotonic_time(record.ended_s, started, "transaction end")

        # Validate both timestamps before changing counters, history, or the clock mark.
        self._high_water_s = ended

        self._counter_transactions = saturate_add(self._counter_transactions, 1)

        outcome = record.outcome
        if outcome == "OK":
            self._counter_successful = saturate_add(self._counter_successful, 1)
        else:
            self._counter_failed = saturate_add(self._counter_failed, 1)

        if outcome == "TIMEOUT":
            self._counter_timeout = saturate_add(self._counter_timeout, 1)
        elif outcome == "INVALID_FEEDBACK":
            self._counter_invalid_feedback = saturate_add(self._counter_invalid_feedback, 1)
        elif outcome == "WRITE_CANCELLED":
            self._counter_write_cancelled = saturate_add(self._counter_write_cancelled, 1)
        elif outcome == "PREWRITE_DEADLINE":
            self._counter_prewrite_deadline = saturate_add(self._counter_prewrite_deadline, 1)
        elif outcome == "DRIVER_FAILURE":
            self._counter_driver_failure = saturate_add(self._counter_driver_failure, 1)
        elif outcome == "SKIPPED":
            self._counter_skipped = saturate_add(self._counter_skipped, 1)
        elif outcome == "CLOCK_FAILURE":
            self._counter_clock_failure = saturate_add(self._counter_clock_failure, 1)

        self._transaction_durations.append(record.duration_s)
        if len(self._transaction_durations) > self._config.capacity:
            self._transaction_durations.pop(0)

        self._recent_transactions.append(record)

    def calculate_overrun_attribution(
        self,
        transactions: tuple[JointTransactionRecord, ...],
        duration_s: float | Fraction,
    ) -> tuple[str, ...]:
        """Attribute completion overrun to the joints exceeding their nominal time slice."""
        duration = (
            duration_s
            if isinstance(duration_s, Fraction)
            else Fraction.from_float(validate_finite_time(duration_s, "duration_s"))
        )
        period = Fraction.from_float(self._config.nominal_period_s)
        if duration <= period or not transactions:
            return ()
        fair_share = period / len(transactions)
        durations = tuple(
            Fraction.from_float(tx.ended_s) - Fraction.from_float(tx.started_s)
            for tx in transactions
        )
        exceeded = [
            tx.joint_name
            for tx, tx_duration in zip(transactions, durations)
            if tx_duration > fair_share
        ]
        if exceeded:
            return tuple(exceeded)
        max_duration = max(durations)
        return tuple(
            tx.joint_name
            for tx, tx_duration in zip(transactions, durations)
            if tx_duration == max_duration
        )

    def calculate_sampling_skew(self, timestamps: Iterable[float | None]) -> float | None:
        """Calculate sampling skew (max - min) across joints with valid feedback timestamps."""
        valid = [validate_finite_time(ts, "feedback timestamp") for ts in timestamps if ts is not None]
        if len(valid) < 2:
            return None
        return max(valid) - min(valid)

    def calculate_slot_skip(self, current_time_s: float, next_slot_s: float) -> tuple[int, float]:
        """Compute integer missed slots to skip and advance next_slot boundary forward.

        Never bursts or executes missed iterations.
        """
        now = validate_finite_time(current_time_s, "current_time_s")
        slot = validate_finite_time(next_slot_s, "next_slot_s")
        if now <= slot:
            return (0, slot)
        now_exact = Fraction.from_float(now)
        slot_exact = Fraction.from_float(slot)
        period_exact = Fraction.from_float(self._config.nominal_period_s)
        missed_exact = (now_exact - slot_exact) // period_exact + 1
        new_slot_exact = slot_exact + missed_exact * period_exact
        if new_slot_exact <= now_exact:
            raise ValueError("next slot cannot be represented as a future timestamp")
        try:
            new_slot = float(new_slot_exact)
        except (OverflowError, ValueError) as exc:
            raise ValueError("next slot is outside the finite timestamp range") from exc
        if not math.isfinite(new_slot) or new_slot <= now:
            raise ValueError("next slot cannot be represented as a finite future timestamp")
        return (min(missed_exact, UINT64_MAX), new_slot)

    def end_cycle(
        self,
        now_s: float,
        feedback_ages: tuple[float | None, ...] = (),
        feedback_timestamps: tuple[float | None, ...] = (),
        transactions: tuple[JointTransactionRecord, ...] = (),
        missed_slots: int = 0,
    ) -> LoopStepRecord:
        """Complete the current cycle, update counters, and record actual timing."""
        if not self._cycle_in_progress or self._current_cycle_start_s is None:
            raise RuntimeError("end_cycle called without active start_cycle")

        started_s = self._current_cycle_start_s
        if type(transactions) is not tuple or any(
            not isinstance(transaction, JointTransactionRecord)
            for transaction in transactions
        ):
            raise ValueError("transactions must be a tuple of JointTransactionRecord")
        if type(feedback_ages) is not tuple or type(feedback_timestamps) is not tuple:
            raise ValueError("feedback ages and timestamps must be tuples")
        if type(missed_slots) is not int or missed_slots < 0:
            raise ValueError("missed_slots must be a non-negative integer")

        observed_high_water = self._high_water_s
        for transaction in transactions:
            if observed_high_water is None or transaction.ended_s > observed_high_water:
                observed_high_water = transaction.ended_s
        now = validate_monotonic_time(now_s, observed_high_water, "loop cycle end")

        started_exact = Fraction.from_float(started_s)
        now_exact = Fraction.from_float(now)
        exact_duration = now_exact - started_exact
        exec_duration = float(exact_duration)

        actual_period_s = None
        if self._last_cycle_start_s is not None:
            actual_period_s = float(
                started_exact - Fraction.from_float(self._last_cycle_start_s)
            )

        period_exact = Fraction.from_float(self._config.nominal_period_s)
        overrun = exact_duration > period_exact
        overrun_s = float(exact_duration - period_exact) if overrun else 0.0
        overrun_joints = self.calculate_overrun_attribution(transactions, exact_duration)

        saturated_missed_slots = min(missed_slots, UINT64_MAX)
        skew = self.calculate_sampling_skew(feedback_timestamps)
        record = LoopStepRecord(
            cycle_index=self._current_cycle_index,
            started_s=started_s,
            ended_s=now,
            execution_duration_s=exec_duration,
            actual_period_s=actual_period_s,
            overrun=overrun,
            overrun_s=overrun_s,
            overrun_joints=overrun_joints,
            missed_slots_skipped=saturated_missed_slots,
            feedback_ages_s=feedback_ages,
            sampling_skew_s=skew,
            transactions=transactions,
        )

        total_overrun_s = self._total_overrun_s
        if overrun:
            total_overrun_s += overrun_s
            if not math.isfinite(total_overrun_s):
                raise ValueError("total overrun is outside the finite range")

        if overrun:
            self._counter_overruns = saturate_add(self._counter_overruns, 1)
            self._total_overrun_s = total_overrun_s

        if actual_period_s is not None:
            self._actual_periods.append(actual_period_s)
            if len(self._actual_periods) > self._config.capacity:
                self._actual_periods.pop(0)

        self._execution_durations.append(exec_duration)
        if len(self._execution_durations) > self._config.capacity:
            self._execution_durations.pop(0)

        if saturated_missed_slots > 0:
            self._counter_missed_slots = saturate_add(
                self._counter_missed_slots, saturated_missed_slots
            )

        self._latest_feedback_ages = feedback_ages
        self._latest_sampling_skew = skew

        self._recent_cycles.append(record)
        self._counter_cycles = saturate_add(self._counter_cycles, 1)

        self._high_water_s = now
        self._last_cycle_start_s = started_s
        self._current_cycle_start_s = None
        self._cycle_in_progress = False
        self._current_cycle_index = saturate_add(self._current_cycle_index, 1)

        return record

    def snapshot(self) -> TimingSnapshot:
        """Produce an immutable snapshot of all counters and bounded metrics."""
        counters = TimingCounters(
            cycles=self._counter_cycles,
            transactions=self._counter_transactions,
            successful_transactions=self._counter_successful,
            failed_transactions=self._counter_failed,
            timeout_transactions=self._counter_timeout,
            invalid_feedback_transactions=self._counter_invalid_feedback,
            write_cancelled_transactions=self._counter_write_cancelled,
            prewrite_deadline_transactions=self._counter_prewrite_deadline,
            driver_failure_transactions=self._counter_driver_failure,
            skipped_transactions=self._counter_skipped,
            clock_failure_transactions=self._counter_clock_failure,
            overruns=self._counter_overruns,
            missed_slots_skipped=self._counter_missed_slots,
        )

        min_p = min(self._actual_periods) if self._actual_periods else None
        max_p = max(self._actual_periods) if self._actual_periods else None
        mean_p = (sum(self._actual_periods) / len(self._actual_periods)) if self._actual_periods else None

        min_e = min(self._execution_durations) if self._execution_durations else None
        max_e = max(self._execution_durations) if self._execution_durations else None
        mean_e = (sum(self._execution_durations) / len(self._execution_durations)) if self._execution_durations else None

        min_t = min(self._transaction_durations) if self._transaction_durations else None
        max_t = max(self._transaction_durations) if self._transaction_durations else None
        mean_t = (sum(self._transaction_durations) / len(self._transaction_durations)) if self._transaction_durations else None

        last_cycle = self._recent_cycles[-1] if self._recent_cycles else None

        return TimingSnapshot(
            config=self._config,
            counters=counters,
            total_overrun_s=self._total_overrun_s,
            last_cycle=last_cycle,
            recent_cycles=tuple(self._recent_cycles),
            recent_transactions=tuple(self._recent_transactions),
            min_actual_period_s=min_p,
            max_actual_period_s=max_p,
            mean_actual_period_s=mean_p,
            min_execution_duration_s=min_e,
            max_execution_duration_s=max_e,
            mean_execution_duration_s=mean_e,
            min_transaction_duration_s=min_t,
            max_transaction_duration_s=max_t,
            mean_transaction_duration_s=mean_t,
            latest_feedback_ages_s=self._latest_feedback_ages,
            latest_sampling_skew_s=self._latest_sampling_skew,
        )

    def reset(self) -> None:
        """Reset all counters and stored history."""
        self._recent_cycles.clear()
        self._recent_transactions.clear()
        self._high_water_s = None
        self._last_cycle_start_s = None
        self._current_cycle_start_s = None
        self._current_cycle_index = 0
        self._cycle_in_progress = False

        self._counter_cycles = 0
        self._counter_transactions = 0
        self._counter_successful = 0
        self._counter_failed = 0
        self._counter_timeout = 0
        self._counter_invalid_feedback = 0
        self._counter_write_cancelled = 0
        self._counter_prewrite_deadline = 0
        self._counter_driver_failure = 0
        self._counter_skipped = 0
        self._counter_clock_failure = 0
        self._counter_overruns = 0
        self._counter_missed_slots = 0
        self._total_overrun_s = 0.0

        self._actual_periods.clear()
        self._execution_durations.clear()
        self._transaction_durations.clear()
        self._latest_feedback_ages = ()
        self._latest_sampling_skew = None

```

### im6014_serial.py SHA256 395599d9aea6c737fd15e7722ec5f346616af08207f0c5aa04019db9afec37d2
```python
from collections import deque
from dataclasses import dataclass
import math
import threading
import time

from im6014_codec import feedback
from joint_contract import WriteResult

_monotonic = time.monotonic

_REQUEST_BYTES = 20
_REPLY_BYTES = 26
_CAPTURE_CAPACITY = 256
_IDENTITY_CHARS = 96
_PORT_CHARS = 160
_TAIL_BYTES = 25
_OUTCOMES = frozenset(('OK', 'TIMEOUT', 'INVALID_FEEDBACK', 'DRIVER_FAILURE'))
_DECODED_INTEGER_LIMITS = {
    'id': (0, 14), 'mode': (0, 1), 'timeout': (0, 1),
    'driver_c': (-128, 127), 'winding_c': (0, 255),
    'errors': (0, 0xFFFFFFFF), 'warnings': (0, 7),
}
_DECODED_FLOAT_FIELDS = ('voltage', 'torque_nm', 'rpm', 'position_rad')


def _bounded_count(value):
    if type(value) is not int or value < 0:
        return 0
    return min(value, 0x7FFFFFFF)


def _bounded_tail(value):
    if isinstance(value, bytes):
        return value[-_TAIL_BYTES:]
    if isinstance(value, bytearray):
        return bytes(value[-_TAIL_BYTES:])
    if isinstance(value, memoryview):
        try:
            return value.cast('B')[-_TAIL_BYTES:].tobytes()
        except (TypeError, ValueError):
            return b''
    return b''


class TransactionTimeoutError(RuntimeError):
    """The bounded transaction expired; diagnostics contain no exception text."""

    def __init__(self, message, *, rejected=0, crc_rejected=0, tail=b''):
        super().__init__(message)
        self.rejected_frames = _bounded_count(rejected)
        self.crc_rejected_frames = min(_bounded_count(crc_rejected), self.rejected_frames)
        self.tail = _bounded_tail(tail)


class InvalidFeedbackError(TransactionTimeoutError):
    """The transaction expired after rejecting one or more candidate frames."""


class WriteCancelledError(RuntimeError):
    """The serial write was cancelled before transmission by the pre-write hook."""


@dataclass(frozen=True)
class _PacketRecord:
    source: str
    identity: str
    connection: int
    port: str
    baud: int
    requested_motor_id: int
    started_s: float
    ended_s: float | None
    request_hex: str
    reply_hex: str
    decoded_fields: tuple
    outcome: str
    rejected_frames: int
    crc_rejected_frames: int
    tail_hex: str


class PacketCapture:
    """A copy-out, fixed-capacity ring of allowlisted packet diagnostics."""

    def __init__(self, capacity=_CAPTURE_CAPACITY, *, clock=None):
        if type(capacity) is not int or not 1 <= capacity <= _CAPTURE_CAPACITY:
            raise ValueError('Capture capacity must be an integer from 1 to 256')
        if clock is not None and not callable(clock):
            raise ValueError('Capture clock must be callable')
        self.capacity = capacity
        self._clock = time.monotonic if clock is None else clock
        self._records = deque(maxlen=capacity)
        self._dropped = 0
        self._lock = threading.Lock()

    def _now(self):
        value = self._clock()
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError('Capture clock must return a finite monotonic number')
        try:
            value = float(value)
        except (OverflowError, TypeError, ValueError) as error:
            raise ValueError('Capture clock must return a finite monotonic number') from error
        if not math.isfinite(value) or not 0 <= value <= 1e12:
            raise ValueError('Capture clock must return a finite monotonic number')
        return value

    def _append(self, record):
        with self._lock:
            if len(self._records) == self.capacity:
                self._dropped = min(self._dropped + 1, 0x7FFFFFFFFFFFFFFF)
            self._records.append(record)

    def snapshot(self):
        with self._lock:
            records = self._records.copy()
            dropped = self._dropped
        return {
            'capacity': self.capacity,
            'dropped': dropped,
            'records': [
                {
                    'source': item.source,
                    'identity': item.identity,
                    'connection': item.connection,
                    'port': item.port,
                    'baud': item.baud,
                    'requested_motor_id': item.requested_motor_id,
                    'started_s': item.started_s,
                    'ended_s': item.ended_s,
                    'request_hex': item.request_hex,
                    'reply_hex': item.reply_hex,
                    'decoded_fields': dict(item.decoded_fields),
                    'outcome': item.outcome,
                    'rejected_frames': item.rejected_frames,
                    'crc_rejected_frames': item.crc_rejected_frames,
                    'tail_hex': item.tail_hex,
                }
                for item in records
            ],
        }


def _capture_metadata(source, identity, connection, port, baud, motor_id):
    if type(source) is not str or source not in ('physical', 'demo', 'fixture'):
        raise ValueError('Capture source must be physical, demo, or fixture')
    if type(identity) is not str or not identity:
        raise ValueError('Capture identity must be a nonempty string')
    if type(port) is not str:
        raise ValueError('Capture port must be a string')
    if source == 'physical' and not port:
        raise ValueError('Physical capture requires an explicit port')
    if type(connection) is not int or not 0 <= connection <= 0x7FFFFFFF:
        raise ValueError('Capture connection must be a nonnegative integer')
    if type(baud) is not int or baud not in (4000000, 6000000):
        raise ValueError('Capture baud must be 4000000 or 6000000')
    if type(motor_id) is not int or not 0 <= motor_id <= 14:
        raise ValueError('Capture motor ID must be an integer from 0 to 14')
    return source, identity[:_IDENTITY_CHARS], connection, port[:_PORT_CHARS], baud, motor_id


def _packet_prefix(value, limit):
    if isinstance(value, bytes):
        return value[:limit]
    if isinstance(value, bytearray):
        return bytes(value[:limit])
    if isinstance(value, memoryview):
        try:
            return value.cast('B')[:limit].tobytes()
        except (TypeError, ValueError):
            return b''
    return b''


def _reply_prefix(result):
    if type(result) is not dict:
        return b''
    raw = result.get('raw')
    if isinstance(raw, bytes):
        return raw[:_REPLY_BYTES]
    if isinstance(raw, bytearray):
        return bytes(raw[:_REPLY_BYTES])
    if isinstance(raw, memoryview):
        try:
            return raw.cast('B')[:_REPLY_BYTES].tobytes()
        except (TypeError, ValueError):
            return b''
    if type(raw) is str:
        raw = raw[:_REPLY_BYTES * 2]
        raw = raw[:len(raw) - len(raw) % 2]
        try:
            return bytes.fromhex(raw)[:_REPLY_BYTES]
        except ValueError:
            return b''
    return b''


def _decoded_fields(result):
    if type(result) is not dict:
        return ()
    fields = []
    for name, (minimum, maximum) in _DECODED_INTEGER_LIMITS.items():
        value = result.get(name)
        if type(value) is int and minimum <= value <= maximum:
            fields.append((name, value))
    for name in _DECODED_FLOAT_FIELDS:
        value = result.get(name)
        if type(value) in (int, float):
            try:
                value = float(value)
            except (OverflowError, TypeError, ValueError):
                continue
            if math.isfinite(value) and abs(value) <= 1e6:
                fields.append((name, value))
    return tuple(fields)


def _outcome(error):
    if isinstance(error, InvalidFeedbackError):
        return 'INVALID_FEEDBACK'
    if isinstance(error, (TransactionTimeoutError, TimeoutError)):
        return 'TIMEOUT'
    return 'DRIVER_FAILURE'


def capture_exchange(capture, exchange_fn, bus, packet, motor_id, *,
                     source, identity, connection, port, baud,
                     before_write=None, on_write=None):
    """Call the current caller's three-argument exchange and retain one safe record."""
    if not isinstance(capture, PacketCapture):
        raise ValueError('Capture must be a PacketCapture')
    if not callable(exchange_fn):
        raise ValueError('Capture exchange function must be callable')
    context = _capture_metadata(source, identity, connection, port, baud, motor_id)
    source, identity, connection, port, baud, motor_id = context
    request = _packet_prefix(packet, _REQUEST_BYTES)
    started = capture._now()
    reply = b''
    decoded = ()
    outcome = 'DRIVER_FAILURE'
    rejected = 0
    crc_rejected = 0
    tail = b''
    kwargs = {}
    if before_write is not None:
        kwargs['before_write'] = before_write
    if on_write is not None:
        kwargs['on_write'] = on_write
    try:
        if kwargs:
            result = exchange_fn(bus, packet, motor_id, **kwargs)
        else:
            result = exchange_fn(bus, packet, motor_id)
        reply = _reply_prefix(result)
        decoded = _decoded_fields(result)
        outcome = 'OK'
        return result
    except Exception as error:
        outcome = _outcome(error)
        if isinstance(error, TransactionTimeoutError):
            rejected = _bounded_count(error.rejected_frames)
            crc_rejected = min(_bounded_count(error.crc_rejected_frames), rejected)
            tail = _bounded_tail(error.tail)
        raise
    finally:
        try:
            ended = capture._now()
        except Exception:
            ended = None
        if ended is not None and ended < started:
            ended = None
        if outcome not in _OUTCOMES:
            outcome = 'DRIVER_FAILURE'
        capture._append(_PacketRecord(
            source, identity, connection, port, baud, motor_id, started, ended,
            request.hex(), reply.hex(), decoded, outcome, rejected, crc_rejected, tail.hex(),
        ))


def _remaining(deadline):
    remaining = deadline - _monotonic()
    if remaining <= 0:
        raise TransactionTimeoutError('No validated motor feedback within deadline')
    return remaining


def _bounded_timeout(original, remaining, writing=False):
    if original is None or writing and original == 0:
        return remaining
    return min(original, remaining)


def _receive(bus, motor_id, deadline, original_timeout):
    data = bytearray()
    rejected = 0
    crc_rejected = 0
    last_error = ''
    try:
        while True:
            bus.timeout = _bounded_timeout(original_timeout, _remaining(deadline))
            _remaining(deadline)
            size = min(26, max(1, bus.in_waiting))
            _remaining(deadline)
            data.extend(bus.read(size))
            _remaining(deadline)
            while True:
                _remaining(deadline)
                start = data.find(b'\xfc\xee')
                if start < 0:
                    data[:] = b'\xfc' if data.endswith(b'\xfc') else b''
                    break
                del data[:start]
                if len(data) < 26:
                    break
                try:
                    result = feedback(bytes(data[:26]), motor_id)
                except RuntimeError as error:
                    rejected += 1
                    last_error = str(error)
                    crc_rejected += int("CRC" in last_error)
                    del data[:1]
                else:
                    _remaining(deadline)
                    return result
    except TransactionTimeoutError as error:
        crc_detail = f'CRC rejected {crc_rejected}; ' if crc_rejected else ''
        message = (f'No validated motor feedback within deadline; rejected {rejected}; '
                   f'{crc_detail}{last_error}; tail {data[-25:].hex()}')
        error_type = InvalidFeedbackError if rejected else TransactionTimeoutError
        raise error_type(message, rejected=rejected, crc_rejected=crc_rejected,
                         tail=data[-25:]) from error


def exchange(bus, packet, motor_id, deadline_s=0.05, *, before_write=None, on_write=None):
    """Reset once, write once, and return requested feedback before expiry.

    The bus has one owner. Its timeout setters, reset and I/O must obey their
    driver contract. Objects without write_timeout must write immediately.
    Synchronous driver calls and cleanup cannot be forcibly interrupted.
    Read/write settings are restored before any validated result is returned.
    If the final deadline check expires after before_write allows dispatch,
    on_write receives PREWRITE_DEADLINE even though bus.write was never called.
    """
    if type(motor_id) is not int or not 0 <= motor_id <= 14:
        raise ValueError('Expected motor ID must be an integer from 0 to 14')
    if isinstance(deadline_s, bool) or not isinstance(deadline_s, (int, float)):
        raise ValueError('Transaction deadline must be a finite positive int or float')
    try:
        deadline_s = float(deadline_s)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError('Transaction deadline must be finite and positive') from error
    if not math.isfinite(deadline_s) or deadline_s <= 0:
        raise ValueError('Transaction deadline must be finite and positive')
    if before_write is not None and not callable(before_write):
        raise ValueError('before_write hook must be callable')
    if on_write is not None and not callable(on_write):
        raise ValueError('on_write hook must be callable')
    deadline = _monotonic() + deadline_s
    if not math.isfinite(deadline):
        raise ValueError('Transaction deadline is not representable')
    original_timeout = bus.timeout
    has_write_timeout = hasattr(bus, 'write_timeout')
    original_write_timeout = bus.write_timeout if has_write_timeout else None
    failure = None
    try:
        _remaining(deadline)
        bus.reset_input_buffer()
        _remaining(deadline)
        if has_write_timeout:
            bus.write_timeout = _bounded_timeout(original_write_timeout, _remaining(deadline), writing=True)
        _remaining(deadline)
        if before_write is not None:
            allowed = before_write()
            if not allowed:
                raise WriteCancelledError('Serial write cancelled by pre-write hook')
        try:
            _remaining(deadline)
        except TransactionTimeoutError:
            if on_write is not None:
                on_write(WriteResult.PREWRITE_DEADLINE)
            raise
        try:
            written = bus.write(packet)
        except Exception:
            if on_write is not None:
                try:
                    on_write(WriteResult.FAILED)
                except Exception:
                    pass
            raise
        if type(written) is int and written == len(packet):
            write_result = WriteResult.COMPLETE
        elif type(written) is int and 0 < written < len(packet):
            write_result = WriteResult.PARTIAL
        else:
            write_result = WriteResult.FAILED
        if on_write is not None:
            on_write(write_result)
        _remaining(deadline)
        if write_result is not WriteResult.COMPLETE:
            raise RuntimeError('Incomplete serial write')
        result = _receive(bus, motor_id, deadline, original_timeout)
    except ValueError as error:
        failure = error
        raise RuntimeError('Serial timeout configuration failed') from error
    except Exception as error:
        failure = error
        raise
    finally:
        restore_errors = []
        for name, value in [('timeout', original_timeout), *(
                [('write_timeout', original_write_timeout)] if has_write_timeout else [])]:
            try:
                setattr(bus, name, value)
            except Exception as error:
                restore_errors.append((name, error))
        if restore_errors:
            names = ', '.join(name for name, _ in restore_errors)
            detail = f'; transaction also failed: {failure}' if failure else ''
            raise RuntimeError(f'Cannot restore serial timeout settings: {names}{detail}') from restore_errors[0][1]
    _remaining(deadline)
    return result

```

### im6014_codec.py SHA256 82aed0838cc0a9d8d63ab2065aea786893ade405f55e5a0b7c895eacf2197af9
```python
import math
import struct
from collections.abc import Callable

RATIO = 38 / 3
RPM_MIN = -32768 / 64 / RATIO * 60
RPM_MAX = 32767 / 64 / RATIO * 60
POSITION_MIN = -2147483648 / 32768 / RATIO * math.tau
POSITION_MAX = 2147483647 / 32768 / RATIO * math.tau
RAW_POSITION_MIN = -2147483648
RAW_POSITION_MAX = 2147483647
RAW_RPM_MIN = -32768
RAW_RPM_MAX = 32767


def raw_to_position(raw_position):
    if type(raw_position) is not int or not RAW_POSITION_MIN <= raw_position <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return raw_position / 32768 / RATIO * math.tau


def position_to_raw(position):
    position = _finite_control(position, 'Position')
    return _signed_raw(position / math.tau * RATIO * 32768,
                       RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')


def raw_to_rpm(raw_rpm):
    if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
        raise ValueError('raw_rpm must be a signed 16-bit integer')
    return raw_rpm / 64 / RATIO * 60


def rpm_to_raw(rpm):
    rpm = _finite_control(rpm, 'Speed')
    return _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')


def _motor_id(value, name='Individual ID'):
    if type(value) is not int or not 0 <= value <= 14:
        raise ValueError(f'{name} must be an integer from 0 to 14')
    return value


def _finite_control(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f'{name} must be a finite int or float')
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as error:
        raise ValueError(f'{name} must be finite') from error
    if not math.isfinite(result):
        raise ValueError(f'{name} must be finite')
    return result


def _signed_raw(value, minimum, maximum, name):
    raw = round(value)
    if not minimum <= raw <= maximum:
        raise ValueError(f'{name} cannot be represented by the motor protocol')
    return raw


def _torque_raw(value):
    return _signed_raw(value / RATIO * 2560, -32768, 32767, 'Feedforward torque')


def _kp_raw(value):
    return _signed_raw(value / RATIO ** 2 * 12800, -32768, 32767, 'Kp')


def _kd_raw(value):
    return _signed_raw(value / RATIO ** 2 * 51200, -32768, 32767, 'Kd')


def _raw_position(value):
    if type(value) is not int or not RAW_POSITION_MIN <= value <= RAW_POSITION_MAX:
        raise ValueError('raw_position must be a signed 32-bit integer')
    return value


def crc32(data):
    if len(data) % 4:
        raise ValueError('CRC input must contain complete four-byte words')
    crc = 0xFFFFFFFF
    for start in range(0, len(data), 4):
        for byte in data[start:start + 4][::-1]:
            crc ^= byte << 24
            for _ in range(8):
                crc = ((crc << 1) ^ (0x04C11DB7 if crc & 0x80000000 else 0)) & 0xFFFFFFFF
    return crc


def command(motor_id, mode=0, rpm=0, kd=0, torque=0, watchdog=True, position=0, kp=0):
    position = _finite_control(position, 'Position')
    if not POSITION_MIN <= position <= POSITION_MAX:
        raise ValueError('Position cannot be encoded in the motor protocol')
    if mode == 0 and position != 0.0:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    position_raw = _signed_raw(position / math.tau * RATIO * 32768,
                               RAW_POSITION_MIN, RAW_POSITION_MAX, 'Position')
    return command_with_raw_position(
        motor_id,
        position_raw,
        mode=mode,
        rpm=rpm,
        kd=kd,
        torque=torque,
        watchdog=watchdog,
        kp=kp,
    )


def command_with_raw_position(
    motor_id, raw_position, mode=0, rpm=0, kd=0, torque=0, watchdog=True, kp=0, raw_rpm=None
):
    """Encode a command while preserving an already selected position grid code."""
    motor_id = _motor_id(motor_id)
    raw_position = _raw_position(raw_position)
    if type(mode) is not int or mode not in (0, 1):
        raise ValueError('Individual ID 0–14 and Stop/FOC modes only')
    if type(watchdog) is not bool:
        raise ValueError('Watchdog must be a bool')
    rpm, kd, torque, kp = (
        _finite_control(value, name) for value, name in
        ((rpm, 'Speed'), (kd, 'Kd'), (torque, 'Feedforward torque'),
         (kp, 'Kp'))
    )
    if not RPM_MIN <= rpm <= RPM_MAX:
        raise ValueError('Speed cannot be encoded in the motor protocol; this is not a rated-speed limit')
    if not 0 <= kd <= 6 or not 0 <= kp <= 30 or not -3.5 <= torque <= 3.5:
        raise ValueError('Bench limits: Kd 0–6, Kp 0–30, feedforward torque ±3.5 Nm')
    torque_raw = _torque_raw(torque)
    if raw_rpm is not None:
        if type(raw_rpm) is not int or not RAW_RPM_MIN <= raw_rpm <= RAW_RPM_MAX:
            raise ValueError('raw_rpm must be a signed 16-bit integer')
        rpm_raw = raw_rpm
    else:
        rpm_raw = _signed_raw(rpm / 60 * RATIO * 64, RAW_RPM_MIN, RAW_RPM_MAX, 'Speed')
    kp_raw = _kp_raw(kp)
    kd_raw = _kd_raw(kd)
    if mode == 0 and (rpm or kd or torque or raw_position or kp or (raw_rpm is not None and raw_rpm != 0)) or mode == 1 and not watchdog:
        raise ValueError('Stop must have zero targets; FOC requires watchdog')
    raw = b'\xfe\xee' + bytes([motor_id | mode << 4 | int(watchdog) << 7, 0])
    raw += struct.pack('<hhihh', torque_raw, rpm_raw, raw_position, kp_raw, kd_raw)
    return raw + struct.pack('<I', crc32(raw))


def project_position_raw(
    wanted_q,
    q_min,
    q_max,
    map_decoded_position: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw position whose mapped decoded value is in bounds.

    ``map_decoded_position`` maps decoded actuator radians to the caller's
    position domain. ``direction`` declares whether that mapping increases or
    decreases as the raw position code increases. Bounds are closed.
    """
    wanted_q = _finite_control(wanted_q, 'Wanted position')
    q_min = _finite_control(q_min, 'Minimum position')
    q_max = _finite_control(q_max, 'Maximum position')
    if q_min > q_max:
        raise ValueError('Minimum position must not exceed maximum position')
    if not callable(map_decoded_position):
        raise ValueError('Position mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Position mapping direction must be -1 or 1')

    ordered_min = direction * (q_min if direction == 1 else q_max)
    ordered_max = direction * (q_max if direction == 1 else q_min)
    ordered_wanted = direction * wanted_q

    def mapped(raw_position):
        decoded = raw_to_position(raw_position)
        try:
            result = map_decoded_position(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Position mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped position')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_POSITION_MIN
        right = RAW_POSITION_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_POSITION_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def project_speed_raw(
    wanted_dq,
    v_min,
    v_max,
    map_decoded_speed: Callable[[float], float],
    direction: int,
) -> int | None:
    """Choose the nearest raw speed whose mapped decoded value is in bounds.

    ``map_decoded_speed`` maps decoded actuator RPM to the caller's
    speed domain. ``direction`` declares whether that mapping increases or
    decreases as the raw speed code increases. Bounds are closed.
    """
    wanted_dq = _finite_control(wanted_dq, 'Wanted speed')
    v_min = _finite_control(v_min, 'Minimum speed')
    v_max = _finite_control(v_max, 'Maximum speed')
    if v_min > v_max:
        raise ValueError('Minimum speed must not exceed maximum speed')
    if not callable(map_decoded_speed):
        raise ValueError('Speed mapping must be callable')
    if type(direction) is not int or direction not in (-1, 1):
        raise ValueError('Speed mapping direction must be -1 or 1')

    ordered_min = direction * (v_min if direction == 1 else v_max)
    ordered_max = direction * (v_max if direction == 1 else v_min)
    ordered_wanted = direction * wanted_dq

    def mapped(raw_speed):
        decoded = raw_to_rpm(raw_speed)
        try:
            result = map_decoded_speed(decoded)
        except (ArithmeticError, TypeError, ValueError) as error:
            raise ValueError('Speed mapping is not representable') from error
        return direction * _finite_control(result, 'Mapped speed')

    def first_raw_satisfying(bound, *, strict):
        left = RAW_RPM_MIN
        right = RAW_RPM_MAX + 1
        while left < right:
            mid = (left + right) // 2
            value = mapped(mid)
            matches = value > bound if strict else value >= bound
            if matches:
                right = mid
            else:
                left = mid + 1
        return left

    first = first_raw_satisfying(ordered_min, strict=False)
    last = first_raw_satisfying(ordered_max, strict=True) - 1
    if first > RAW_RPM_MAX or last < first:
        return None

    candidate = first_raw_satisfying(ordered_wanted, strict=False)
    if candidate < first:
        return first
    if candidate > last:
        return last
    if candidate == first:
        return candidate

    current_delta = abs(mapped(candidate) - ordered_wanted)
    prior_delta = abs(mapped(candidate - 1) - ordered_wanted)
    return candidate - 1 if prior_delta <= current_delta else candidate


def feedback(raw, motor_id):
    motor_id = _motor_id(motor_id, 'Expected motor ID')
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Feedback frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Feedback frame must be a bytes-like buffer') from error
    if len(raw) != 26 or raw[:2] != b'\xfc\xee':
        raise RuntimeError('Invalid feedback length/header')
    if struct.unpack('<I', raw[22:])[0] != crc32(raw[2:22]):
        raise RuntimeError('Feedback CRC mismatch')
    m, td, tw, v, tq, sp, pos, err, flags, _, _ = struct.unpack('<BbBBhhiIHBB', raw[2:22])
    if m & 15 != motor_id or (m >> 4) & 7 not in (0, 1):
        raise RuntimeError('Feedback ID/mode mismatch')
    return dict(id=m & 15, mode=(m >> 4) & 7, timeout=m >> 7,
                driver_c=td, winding_c=tw, voltage=v / 2,
                torque_nm=tq / 2560 * RATIO, rpm=sp / 64 / RATIO * 60,
                position_rad=pos / 32768 / RATIO * math.tau,
                errors=err, warnings=(flags >> 13) & 7, raw=raw.hex())


def decode_command(raw):
    if not isinstance(raw, (bytes, bytearray, memoryview)):
        raise ValueError('Command frame must be a bytes-like buffer')
    try:
        raw = bytes(raw)
    except (TypeError, ValueError) as error:
        raise ValueError('Command frame must be a bytes-like buffer') from error
    if len(raw) != 20 or raw[:2] != b'\xfe\xee':
        raise ValueError('Invalid command length/header')
    if struct.unpack('<I', raw[16:])[0] != crc32(raw[:16]):
        raise ValueError('Command CRC mismatch')
    m = raw[2]
    motor_id = m & 0x0F
    mode = (m >> 4) & 0x07
    watchdog = bool(m & 0x80)
    if motor_id > 14 or mode not in (0, 1) or raw[3] != 0:
        raise ValueError('Invalid command ID, mode, or reserved byte')
    if mode == 1 and not watchdog:
        raise ValueError('FOC command requires watchdog')
    tq, sp, pos, kp, kd = struct.unpack('<hhihh', raw[4:16])
    if mode == 0 and (tq or sp or pos or kp or kd):
        raise ValueError('Stop command must have zero targets')
    decoded = dict(
        motor_id=motor_id,
        mode=mode,
        watchdog=watchdog,
        raw_torque=tq,
        raw_rpm=sp,
        raw_position=pos,
        raw_kp=kp,
        raw_kd=kd,
        torque_nm=tq / 2560 * RATIO,
        rpm=sp / 64 / RATIO * 60,
        position_rad=pos / 32768 / RATIO * math.tau,
        kp=kp * (RATIO ** 2) / 12800,
        kd=kd * (RATIO ** 2) / 51200,
        raw=raw.hex(),
    )
    if not _torque_raw(-3.5) <= tq <= _torque_raw(3.5):
        raise ValueError('Feedforward torque is outside the canonical command range')
    if not 0 <= kp <= _kp_raw(30.0) or not 0 <= kd <= _kd_raw(6.0):
        raise ValueError('Gain is outside the canonical command range')
    return decoded

```

### A02-luna-files.json
{
  "baseHead": "16017843f3058fb42df3e137fe9288df172598f9",
  "files": [
    {
      "path": "arm_station.py",
      "sha256": "1cc27ade39d244a85bce49eb5ed31fc1de256e25bb39e707cfff4baaed6f83b4",
      "bytes": 76893
    },
    {
      "path": "arm_fixture.py",
      "sha256": "36aa5dba2448c6ffdd7e5515760571c8ce4386fdd8a3579e7815f169f5abfd97",
      "bytes": 10655
    },
    {
      "path": "test_arm_station.py",
      "sha256": "3e5fdf8d76607b0dacfa16496cba6dc47e38f44f26d1ea9b7f80f9643b33f273",
      "bytes": 28000
    }
  ]
}

### A02-luna-independent.json
{
  "testsRun": 8,
  "failures": [],
  "errors": [],
  "success": true,
  "hardwareIO": false,
  "scope": "Independent parent regressions on frozen selected source"
}

### result.json
{
  "baseHead": "16017843f3058fb42df3e137fe9288df172598f9",
  "sourceHashes": [
    {
      "path": "arm_station.py",
      "sha256": "1cc27ade39d244a85bce49eb5ed31fc1de256e25bb39e707cfff4baaed6f83b4",
      "bytes": 76893
    },
    {
      "path": "arm_fixture.py",
      "sha256": "36aa5dba2448c6ffdd7e5515760571c8ce4386fdd8a3579e7815f169f5abfd97",
      "bytes": 10655
    },
    {
      "path": "test_arm_station.py",
      "sha256": "3e5fdf8d76607b0dacfa16496cba6dc47e38f44f26d1ea9b7f80f9643b33f273",
      "bytes": 28000
    }
  ],
  "checks": [
    {
      "name": "focused",
      "argv": [
        "/home/sid/Documents/code/im6014Workbench/.venv/bin/python",
        "-B",
        "-c",
        "\nimport serial, unittest\ndef no_physical_port(*args, **kwargs):\n    raise AssertionError('Physical serial acquisition is outside this verification scope')\nserial.Serial = no_physical_port\nimport im6014_port\nim6014_port.open_managed_port = no_physical_port\nsuite = unittest.defaultTestLoader.loadTestsFromName('test_arm_station')\nresult = unittest.TextTestRunner(verbosity=2).run(suite)\nraise SystemExit(not result.wasSuccessful())\n"
      ],
      "exitCode": 0,
      "log": "/home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/arm-parent-checks/20261009T125753368981Z/focused.log"
    },
    {
      "name": "accepted-regression",
      "argv": [
        "/home/sid/Documents/code/im6014Workbench/.venv/bin/python",
        "-B",
        "-m",
        "unittest",
        "-v",
        "test_joint_mapping",
        "test_numerical_inputs",
        "test_port_config",
        "test_diagnostic_capture",
        "test_bus_owner",
        "test_controller",
        "test_controller_targets",
        "test_controller_expiry",
        "test_controller_owner",
        "test_controller_limits",
        "test_controller_lead",
        "test_controller_effort",
        "test_controller_thermal",
        "test_station_timing"
      ],
      "exitCode": 0,
      "log": "/home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/arm-parent-checks/20261009T125753368981Z/accepted-regression.log"
    }
  ],
  "sourceUnchanged": true,
  "passedChecks": true,
  "hardwareIO": "none; focused tests deny physical port acquisition"
}

### A02-review-triage.json
{
  "artifact": "original retained A02-workbench draft",
  "accepted": false,
  "rows": [
    {
      "seat": "muse",
      "finding": 1,
      "status": "accepted reproduced",
      "parentReason": "Original20 startup errors; unsupported tracker clock keyword. Constructor-only correction exposes9further failures.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 2,
      "status": "accepted reproduced",
      "parentReason": "A02-parent-repros: caller extends expired canonical ticket and request is accepted. Canonical record owns all fields.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 3,
      "status": "accepted reproduced",
      "parentReason": "A02-parent-repros:1000 pending tickets retained. Bounded canonical ingress repair assigned.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 4,
      "status": "accepted reproduced",
      "parentReason": "A02-parent-repros: Stop request waits behind blocked executor exchange. Remove lock across Core/I/O.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 5,
      "status": "accepted reproduced",
      "parentReason": "A02-parent-repros: Core.snapshot runs on caller thread, clock high-water is mutable. Publish immutable view only.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 6,
      "status": "accepted source grounded",
      "parentReason": "Disconnect/close leaves owner,tickets,epoch,intent. Successful release invalidates authority; failed transport close retains lease. Keep Core protection/fault history.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 7,
      "status": "accepted source grounded",
      "parentReason": "Ingress reservation must distinguish queued/active ownership and unwind failed Connect. Ignored begin_connect/connected decisions must be checked.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 8,
      "status": "accepted source grounded",
      "parentReason": "issue_ticket allows pre-connect generation1. Require active current ownership.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 9,
      "status": "accepted source grounded",
      "parentReason": "Expiry/Stop must invalidate stale mailbox, pending Arm and neutral state. No implicit rearm.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 10,
      "status": "accepted reproduced",
      "parentReason": "Ignored submit results and zero-elapsed faults leave ARMED/hold flags false to reality; A02-zero-elapsed-parent-repro. Retain Core strict time authority.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 11,
      "status": "partly accepted",
      "parentReason": "Fresh mode0 confirmation independent of FAULT and updated for each Stop/disconnect attempt. READY after an actual mode0 Check may truthfully show mode0 confirmation; reject premise that Check packet is not a Stop.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 12,
      "status": "partly accepted",
      "parentReason": "close uses caller Core context, hides failures and drops live thread handle. Fix executor ownership and report transport close separately from per-joint Stop. Do not redefine confirmed transport close as impossible unless all feedback succeeded.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 13,
      "status": "accepted reproduced",
      "parentReason": "Valid physical Connect is false success; A02 explicit commissioning refusal until A03. A02-draft-parent-repros proves nonfinite/type/J1 reference-shift validation defects. No live acquisition authorized.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 14,
      "status": "partly accepted",
      "parentReason": "Synthetic gains cannot serve physical profile, and fictitious dt0.001 is wrong. Reject claim accepted Core limiter is bypassed by a bounded goal: it remains sole speed/acceleration/lead/effort authority. No duplicate reference limiter.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 15,
      "status": "accepted source grounded",
      "parentReason": "Original callback runs once at index0 under ingress lock. Final hook belongs at each existing exchange before_write in A03. Original unit cannot claim per-joint race protection.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 16,
      "status": "rejected source contradiction",
      "parentReason": "CheckAction explicitly rejects states other than CONNECTED/STOPPED/FAULT before claim_owner. Reviewer ARMED/MOVING ownership rotation claim is false.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 17,
      "status": "partly accepted",
      "parentReason": "compute_zero_output nonfinite acceptance reproduced. Raw mode0 commissioning sampling needs truthful health/freshness record in A03; canonical exchange already validates requested motor ID/CRC/deadline, so corrupt CRC does not return an angle.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "muse",
      "finding": 18,
      "status": "partly accepted",
      "parentReason": "Remove unused authority imports and swallowed executor exceptions. Requested/admitted/dispatched/measured immutable views intentionally expose observation, not callable Core/window capability. Frozen clock tests must use deterministic manual executor or explicit coupled pacing; no false timing claims.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "1",
      "status": "accepted reproduced",
      "parentReason": "20actual constructor errors;9subsequent failures in constructor-only copy.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "2.1",
      "status": "accepted reproduced",
      "parentReason": "Fake exchange blocks Stop ingress under mailboxlock; no claim already-started exchange can be interrupted.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "2.2",
      "status": "accepted reproduced",
      "parentReason": "Public snapshot invokes mutable Core in caller thread.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "2.3",
      "status": "accepted reproduced",
      "parentReason": "Authored test fails (True,True,True) versus desired(True,False,True); inspect health.mode0/currentStop round. Clear prior mode0 confirmation on mode1dispatch.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "2.4",
      "status": "rejected reproduced contrary",
      "parentReason": "A02-gemini-parent-repros: positive20ms neutral/repress J1 jog staysMOVING; exact derivative~0.1rad/s is limited by accepted Core. Original failures originate zero elapsed fixtures, not claimed25rad/s2 bypass. No duplicate limiter.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "2.5",
      "status": "accepted reproduced",
      "parentReason": "A02-gemini-parent-repros READY idle550ms faults stale without mode0polling. Keep Core freshness; paced nonenergizing telemetry and explicit Arm freshStop/referencecheck needed.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "3.1",
      "status": "accepted source grounded",
      "parentReason": "FailedConnect leaves ingressowner captured. Reservation/activeownership must be separate and failures unwind.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "3.2",
      "status": "accepted source grounded",
      "parentReason": "SuccessfulDisconnect releases clientauthority; preserve Core history/faults and any failed transportlease.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "3.3",
      "status": "partly accepted",
      "parentReason": "Expiryforgery/unboundedtickets already reproduced. Other registered session deletion claim rejected: parent observed NOT_OWNER and original ticket intact.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "3.4",
      "status": "accepted source grounded",
      "parentReason": "Physicalvaliddraft returnsCONNECTED without acquisition; explicit commissioning refusalA02, full physicalphaseA03.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "3.5",
      "status": "accepted source grounded",
      "parentReason": "Original guard prepares oneplan,coordinator preparesanother and callbackonlyindex0. A03hook at driverfinalbefore_write mandatory.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "4.1",
      "status": "accepted test exposes defect",
      "parentReason": "Mode1reply falselyStopconfirmed; authorednegativeassertion is correct, not testfallacy.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "4.2",
      "status": "accepted fixture correction",
      "parentReason": "Check rotates owner with latchedfault movesCoreFAULT; expectationCONNECTED conflicts actualCore contract. Preservefault/protection.",
      "repairVerification": "pending fresh A02-fix checks"
    },
    {
      "seat": "gemini",
      "finding": "4.3",
      "status": "accepted conditional fixture correction",
      "parentReason": "Failure must preserve actual lastconfirmedreference. Positiveelapsedhold packet remains; original zeroelapsedholdfault meant this authoredtest happenedtopass without prior emission. Compare exact priorrecord rather than universalNone.",
      "repairVerification": "pending fresh A02-fix checks"
    }
  ],
  "at": "2026-10-09T12:38:55.659519+00:00"
}

### A03-source-grounded-contract.md
# A03 source-grounded design notes

Parent HEAD remains16017843 while A02 repair/review runs. This is a design record, no accepted control implementation.

## Final write guard

Accepted `im6014_serial.exchange` calls `before_write` after input reset and timeout setup, immediately before its final deadline check and single `bus.write`. Use that existing boundary, once per motor. Never run the guard only at cycle/index0 or after `JointCore.claim_dispatch`.

`StationStepCoordinator` gets an optional typed callback that returns allow, replace-hold, or revoke for the frozen plan and joint index. With no callback every existing coordinator behavior stays identical. The callback executes in the station executor; it briefly inspects bounded mailbox/latches under the ingress lock, then releases it before any Core/I/O. Actual serial writes remain synchronous and cannot be forcibly interrupted. Treat the final gate/claim as the start boundary and document that already-claimed work can finish; do not promise instantaneous hardware stop from HTTP acknowledgment.

For ordinary release, the station builds a complete stationary goal from the latest actually confirmed per-joint references, issues a live Core window and submits it through accepted `submit_target`. Its accepted submission already invalidates the old prepared plan (`_invalidate_plan`); no new public Core cancellation authority or private-field mutation is needed. Return replace-hold only after accepted replacement, with a persistent release generation so a later pressed input cannot erase release before capture. A failed replacement becomes revoke. The coordinator cancels the old exchange before claim and records explicit `PLAN_SUPERSEDED`, skips remaining old packets, and does not call `core.stop` for this one typed successful replacement. No synthetic on_write result or optimistic joint reference is recorded. The next ordinary paced slot prepares bounded settling toward the stationary goal. Every other cancellation retains existing Stop/fault behavior.

Stop/focus/device change/expiry revoke Core before the next final gate, cancel old packet, then attempt mode0 every motor in executor. Per-joint confirmation needs actual complete mode0 request plus fresh current-attempt CRC-valid reply mode0, not merely any valid feedback. Keep previous write history exactly, including one earlier joint that completed before release/Stop and all skipped later joints. Reset confirmation for every fresh Stop attempt.

## Required parent reproductions

Inject release/Stop after each joint write and during next input-reset immediately before `before_write`; assert no later old packet, exact per-joint history, no Stop for successful ordinary release, no invented on_write cancellation result, settling stays capped by Core. Test unchanged no-hook path, malformed/throwing guard fail-closed, rejected hold replacement, ticket/owner expiry while exchange is blocked, clock/deadline failure, partial write, mode1 reply to mode0, stale/replayed feedback, failed port close and retained lease. Run original full controller/timing tests plus exact768reference+768cache certificates and fake/PTy baseline.

## Physical commissioning remains a separate explicit phase

A02 repair truthfully rejects physical Connect pending commissioning. A03 must implement the full draft/raw-mode0/reference/mapping/ManagedPort ownership path with injected acquisition and isolated PTYs; merely changing that receipt to CONNECTED is unacceptable. Unknown gains/limits/timeouts remain operator-required fields. Acquire only after full draft and explicit user opt-in; raw mode0 display does not instantiate mapped Core until supported reference, directions, J1 provisional intended bound and finite confirmed J2/J3 travel are approved. Freeze one physical Core/config per process; reconnect preserves protection/fault state and requires same reference and fresh Stop check. No repeated Core reset/hot rebinding, saved absolute pose or automatic rearm. No assembled-arm I/O permission is inferred from implementing this code.

### A04-control-contract.md
# A04 control and verification notes

Design preparation only; implement after A02 and A03 actual acceptance. Default dashboard is an explicitly labeled fake three-motor fixture; physical mode needs CLI opt-in and full commissioning. Keep lifecycle controls, keyboard/Xbox input, three measured joint angles, logical/per-joint Stop and the verified 3D model prominent. Show stationary energized hold separately from Stop. Do not enable impedance/gravity on placeholder inertials.

## Input contract

Use pure input normalization/state reducer separate from DOM/fetch. Keyboard A/D:J1, W/S:J2, Q/E:J3, Space held:deadman, Escape:Stop; label signed directions on-screen. Ignore jogging keys while editing fields and clear keys on blur/hidden. Device selection changes Stop and invalidate epoch; neutral/released then new deadman edge required after arm, reconnection, focus restore or device switch. Escape remains available from form fields. Never arm from controller buttons or reconnect events.

For browser-recognized standard Xbox mapping, use axes0 for J1, negative axes1 for J2, negative axes3 for J3; top-right shoulder button5 (RB) deadman, right face button1 (B) Stop. Validate standard mapping, connected device, complete finite bounded axis/button arrays; unknown mapping refuses jogging and explains keyboard fallback. Deadzone and remaining range rescaling are explicit, finite and pure. Read current pad every frame; unplug, missing pad, mapping change or replacement increments a connection nonce/device epoch and sends Stop. Index/id alone cannot distinguish a replacement at the same index.

The exact standard indices/axis signs are grounded in W3C Gamepad working draft: https://www.w3.org/TR/gamepad/#remapping (observed2026-10-09). This spec defines axis range[-1,1], button range[0,1], standard mapping and polling; it does not establish an actual Xbox/browser connection on this host. Use actual browser behavior and preserve hardware-vs-fixture distinction.

Browser sends only normalized axes/deadman/focus/device epoch/monotonic sequence with opaque server-issued ticket. Server owns expiry, owner generation, physical goals/gains/zeros/windows. At most one ordinary request in flight, retain only newest unsent input; no accumulated fetch queue. Stop uses separate priority request and invalidates local pending input; do not wait behind a blocked ordinary fetch. Delayed input does not become fresh on receipt. Network error/hidden/blur/unplug cause best-effort Stop plus server lease expiry; no automatic Check/Arm recovery.

Snapshot serialization uses an explicit observational field allowlist, not recursive dataclasses.asdict. Never expose another session's opaque handle, owner token, window or pending ticket. A public owner label can be mine/another client/none; raw owner_session_id may itself be a session capability. HTTP identity comes from the server-issued bound session, never a payload SessionHandle.

## HTTP and commissioning

Loopback-only binding by default; strict Host/origin on mutations, reject cross-origin content and unsupported methods, body/request/session/connection caps, socket timeouts and bounded request queues. Static file allowlist and canonical packaged resource paths; no directory traversal or raw private source exposure. Parse external payload once to typed actions. HTTP threads call only bounded ingress and published snapshot; never Core or serial. Don't invent another safety/motion controller.

Commissioning UI must match actual A03 typed physical phase. Operator-required IDs0/1/2 provisional, stable adapter identity, directions, finite real travel/gains/protection/timeout facts and supported reference. Display raw mode0 positions and health truthfully before mapped Core creation. J1 bound from generated model, J2/J3 unknown until operator confirmation. Explicit known reference establishes zero_output=measured_output-direction*reference_joint. No saved absolute pose auto restore or physical timeout bypass.

## Verification

Parent actual HTTP fixture lifecycle, emitted canonical packets/goal histories, keyboard event reducer and held/release/repress semantics, gamepad standard/unknown/NaN/truncated/unplug/replacement, in-flight request replacement/expiry/Stop priority, focus/hidden/network failure, stale ticket/sequence/owner, Stop perjoint/wrongmode/partialwrite/close cases. Node tests may execute pure reducer functions with synthetic pads; they are not real browser/Xbox tests.

Drive actual browser lifecycle and keyboard controls via supported CUA operations, inspect resulting live fixture joint state and wire history and no writes after loss. If physical Xbox unavailable, label that limitation. A fixture-only virtual gamepad exercise may call the SAME input reducer via clearly labeled simulation controls; make it structurally unavailable in physical mode and never mutate navigator/Gamepad API to claim hardware input. Actual UI captures are required where screenshot surface works; retain unavailable screenshot errors and do not fabricate visual inspection. Test installed resources outside checkout after package migration.

### arm-design-synthesis.md
# Manual arm dashboard design

## Problem and usage
User wants simple keyboard/Xbox joint jogging ready for assembly testing. Three IM6014, no external reduction, IDs planned0base/1shoulder/2elbow. Latest v3 export is authoritative. Default launch ./start_arm_dashboard.sh uses three-motor fake fixture and loopback dashboard. Explicit real opt-in plus commissioning gates precedes hardware control. Existing bench launcher stays functional.

## Shape
Select Sol browser+accepted Core candidate. One station execution context owns Core/coordinator/ManagedPort and all serial operations. Bounded HTTP ingress holds latest jog intent, bounded lifecycle requests, persistent release latch and priority Stop. HTTP threads never mutate Core. Browser sends axes/deadman/focus/device epoch/sequence, not physical target/gains/time/owner fields. Server issues bounded freshness tickets; delayed requests cannot become fresh merely when received. One request in flight and latest unsent replacement; no unbounded backlog. Same-origin/Host checks, body limits, request deadlines, connection/session caps.
Public station methods request, snapshot, close hide ownership/windows/targets/wire. Immutable views distinguish requested/admitted/dispatched/measured and logical vs physically confirmed Stop/close.
Default20ms nominal station slots,150ms input lease,50ms exchange deadline are software policies, not observed hardware rates. Actual timing/missed slots displayed; no catch-up bursts.

## Motion and operator semantics
Core.checked seeds measured references; Core.arm alone sends nothing. Arm admits measured-position hold and requires neutral/released input then new deadman edge. Ordinary deadman release captures last actual complete references as a stationary goal while fresh explicit owner input continues. This remains energized and can require bounded settling. Stop, hidden/focusloss, unplug/devicechange, stale owner/intent or disconnect revoke before the next unstarted mode1 write, then attempt mode0 on every motor; only valid fresh mode0 feedback confirms Stop. No promise of interrupting an already-started write.
Jog requests anchor per joint to last confirmed reference and actual elapsed time. Core remains sole limiter with exact Fraction derivative/encoded speed, lead/combined effort/protection/cache invariants. No optimistic all-vector history.
Add narrow optional coordinator dispatch guard with explicit typed allow/replace-hold/revoke outcome. Release replacement cancels superseded prepared plan without fabricating write history or revoking fresh hold authority; all other cancellations preserve current safety behavior. Parent reproductions must verify per-joint release/Stop races and historical exact certificates.

## Commissioning
Physical draft has IDs/gains/protection/port identity/support/timeout facts before open, no usable mapping. Bounded mode0 raw reads display output coordinates without testing uncalibrated angles against URDF limits. Operator aligns known supported reference and confirms directions/reference/travel/gains/timeout. zero_output = measured_output - direction*reference_joint. Instantiate physical Core once after validated mapping. Freeze configuration for process lifetime; no hot rebind/repeated Core reconstruction. Disconnect keeps protection/fault history; reconnect requires explicit same-reference confirmation and fresh Stop check. Changed zero/config requires deliberate new process and commissioning; no automatic saved absolute pose restoration. No automatic timeout clearing/recovery/rearm.

## Model contract and provenance
Generator tools/build_manual_arm.py produces arm_assets/arm.urdf, arm_assets/model.json, arm_assets/meshes portable STL plus four rendering body sets. Latest source archive SHA ebb0777628e318e27eca25686adefed16dabc92daec44229f51913b915d6cd72; URDF SHA8c3b60f2bc8c19b6843143f491b92fe4365a9ce9928f39e3566ae3903b05666c. Preserve raw input outside shipping source. Active order revolute_2/revolute_1/revolute_3. Weld passive revolute_4 at exported transform. Retain fixed base motor none_2; remove duplicate moving none_1 visual only and record source/transform discrepancy; preserve topology. No old tool links, analytic IK, contact limits/calibration.
Model JSON schema1: source hashes and cleanup provenance; units mm; bodies base/j1/j2/j3 keyed material with file/vertices/triangles/SHA; joints ordered with name/base-shoulder-elbow role, urdf,motor_id,origin[3],axis[3],limits_deg(default J1[-90,90], others null),limit_provenance; cad_to_world matrix/origin; cleanedURDF and all portable STL file hashes; flags placeholder_inertials true, dynamics_validated false, collision_validated false. J1 cap shared runtime/UI from this model. J2/J3 finite real limits required commissioning; no guessed full-turn clearance. Clean J1 URDF revolute with lower/upper +-pi/2; effort/velocity zero means kinematic artifact supplies no live command authority. Other active joints retain continuous type; real profile limits independent and mandatory. URDF assets resolve relatively. Pure visualization mesh LOD may simplify dense surfaces; exact joint frames retained and raw source hashes/provenance distinguish approximations from collision/mechanical proof.

## Synthesis decision and red flag screen
Sol base keeps one accepted motion authority and browser-native Xbox input without a new native-controller dependency. Adopt Gemini alternative's fixed-base visual ownership and explicit telemetry status separation. Gemini Qt-only control+read-only browser is structurally distinct but loses because native input backend unspecified, candidate contains wrong PortConfig/package calls and unsupported synchronous Stop/6ms claims. Its self-selected winning synthesis did not inspect sibling and is rejected. Browser timer loss explicitly expires authority; Qt does not remove all controller/liveness/Stop risks. Reject raw ArmSession authority and duplicate safety middleware. Reject initial hot mapping bind/revisioned history rewrite. Keep one limits source and no hand-synced UI/controller cap.

## Serialized units and next implementation
M01 model generator/artifact+parent source/frame/asset/URDF tests and visual inspect. A02 station fixture lifecycle/commissioning/goals/views. A03 final dispatch guard/physical Stop and PTy failure paths. A04 browser manual inputs/transport/actual fixture interaction. Each isolated Gemini writer hands to parent checks; reproduced bugs go configured LunaMax; configured reviewer panel before handoff. Final no-comments/deslop/decision-trail audit/fresh nonwriter Sol verify and private PR/exact-head guarded merge remain required. No C16 rejected code integration and no new hardware I/O authorization.


## Review Rubric

# Review Rubric

Review through whichever lenses are relevant. Not every lens applies to every change. Use judgment.

## Correctness

Does the code actually do what the intent says it should?

- Edge cases: empty inputs, nil/undefined, boundary values, concurrent access
- Error handling: are errors caught, propagated, or silently swallowed?
- Off-by-one, type coercion, integer overflow, string encoding
- State management: race conditions, stale closures, dangling references
- Does the happy path work? Does the sad path work?
- Idempotency: what happens if this operation runs twice, or if a previous run crashed halfway? If the answer is "it depends on what state was left behind," there's a missing reconciliation step.
- Concurrency: if multiple actors can touch the same mutable state (files, branches, shared data), is access serialized structurally (locks, sequential phases, exclusive ownership), or by conventions that won't hold?

When you find a potential bug, trace the execution path. Don't just flag "this could be nil". Show the call chain that makes it nil.

## Root Causes vs. Symptoms

Is the code fixing the actual problem or papering over a symptom?

Answering this often requires looking beyond the changed files. Read the surrounding code (callers, callees, type definitions, sibling modules) and understand the architecture the change lives in. Use the tools available to you (Read, Grep, Glob) to explore. Follow the call chain. Read the types. Understand why the code exists before judging whether the change addresses the right layer.

- Guard clauses that mask a deeper invariant violation
- Retry logic that hides a broken contract
- Type casts that silence a modeling error
- If you see a workaround, ask: why is the workaround needed? What would a proper fix look like?
- A fix in module A that should really be a fix in module B's contract
- Instructions where structure would be better: if the fix is a comment saying "don't do X" or a convention someone has to remember, ask whether it could instead be a type constraint, a lint rule, or a runtime check that makes the wrong thing impossible

## Structural Integrity

Does the code fit well into the system it's part of?

- Boundary discipline: is validation at system boundaries, or scattered through business logic? Validate data once where it enters the system, then trust it internally.
- Abstraction level: is the code mixing high-level orchestration with low-level detail?
- Coupling: does this change introduce dependencies that will make future changes harder?
- Data model fit: do the data structures match the actual access patterns? The right structure makes downstream code obvious. The wrong one fights you at every turn.
- Bolted-on vs. integrated: was the change patched onto the existing design, or does it read as if the design always accounted for it? If the new requirement had been known from the start, would the code look like this?
- Legacy dual-paths: does the change introduce a new API while keeping the old one alive? If there are no external consumers, migrate callers and delete the old path in the same wave. Don't leave compatibility layers that will become permanent.

Don't penalize simple code for lacking abstraction. Premature abstraction is worse than duplication.

## Verification

Can you tell that this code works from reading it?

- Are there tests? Do they test behavior or implementation details?
- Are there assertions/invariants that would catch regressions?
- If this is a bug fix: is there a test for the bug?
- If this touches an integration boundary: is the full path tested?
- Check the real thing, not a proxy. If the code checks liveness via file mtime or cached state instead of reading the actual value, that's a verification gap.
- For delegated or async work: does the code verify actual output artifacts, or does it trust self-reports and summaries?

## Complexity Budget

Is the complexity justified by what the code accomplishes?

- Code that could be simpler without losing correctness or clarity
- Abstractions that serve only one call site
- Configuration or parameterization for cases that don't exist yet
- Dead code, unused imports, vestigial parameters
- Over-engineering: "just in case" code paths with no current callers
- Obsolete compatibility paths kept alive for transitional stability that's no longer needed. If the migration is done, delete the scaffolding
- Does the user experience justify the complexity? Every feature, control, and option should earn its place. Half-finished features are worse than missing ones.

Simpler is better unless simpler is wrong. Three lines of duplication beat a premature abstraction.

## Security

For each security finding, trace the input path through the code and show it.

- User input flowing to dangerous sinks (SQL, shell, eval, innerHTML) without sanitization
- Authentication/authorization gaps in new endpoints
- Secrets in code, logs, or error messages
- TOCTOU (time-of-check-time-of-use) in security-critical paths


## Code Quality Lens

# Code Quality Review

Each reviewer applies this code-quality lens in addition to the rubric. It is a strict standard focused on implementation quality, maintainability, abstraction quality, and codebase health.

Above all, be ambitious about code structure. Do not merely identify local cleanup. Actively search for "code judo" moves, restructurings that preserve behavior while making the implementation dramatically simpler, smaller, more direct, and more elegant.

## Core Prompt

Start from this baseline:

> Perform a deep code quality audit of the current branch's changes.
> Rethink how to structure / implement the changes to meaningfully improve code quality without impacting behavior.
> Work to improve abstractions, modularity, reduce Spaghetti code, improve succinctness and legibility.
> Be ambitious, if there is a clear path to improving the implementation that involves restructuring some of the codebase, go for it.
> Be extremely thorough and rigorous. Measure twice, cut once.

## Dimensions

Each dimension is stated once. Apply the ones that are relevant.

0. **Be ambitious about structural simplification.** Do not stop at "this could be a bit cleaner." Look for reframings that make whole branches, helpers, modes, conditionals, or layers disappear. Assume a "code judo" move is often available. It uses the existing architecture more effectively and makes the change dramatically simpler. If you can delete complexity rather than rearrange it, push hard for that.

1. **Do not let a PR push a file from under 1k lines to over 1k lines without a very strong reason.** Treat this as a strong smell. Prefer extracting helpers, subcomponents, or modules. If the diff crosses that threshold, ask whether the code should be decomposed first. Waive only for a compelling structural reason where the resulting file stays clearly organized.

2. **Do not allow spaghetti growth in existing code.** Be suspicious of new ad-hoc conditionals, scattered special cases, or one-off branches inserted into unrelated flows. Treat "weird if statements in random places" as a design problem, not a style nit. Prefer pushing the logic into a dedicated helper, state machine, or module instead of tangling an existing path.

3. **Bias toward cleaning the design, not just accepting working code.** If behavior can stay the same while the structure becomes meaningfully cleaner, push for the cleaner version. Prefer simplifications that remove moving pieces over refactors that spread the same complexity around.

4. **Prefer direct, boring, maintainable code over hacky or magical code.** Treat brittle, ad-hoc, or "magic" behavior as a problem. Be skeptical of generic mechanisms that hide simple data-shape assumptions. Flag thin abstractions, identity wrappers, or pass-through helpers that add indirection without buying clarity.

5. **Push on type and boundary cleanliness when it affects maintainability.** Question unnecessary optionality, `unknown`, `any`, or cast-heavy code when a clearer type boundary could exist. Prefer explicit typed models over loosely-shaped ad-hoc objects. If a branch leans on a silent fallback to paper over an unclear invariant, ask whether the boundary should be made explicit.

6. **Keep logic in the canonical layer and reuse existing helpers.** Call out feature logic leaking into shared paths or implementation details leaking through APIs. Prefer existing canonical utilities over bespoke one-offs. Push code toward the right package, service, or module instead of normalizing drift.

7. **Treat unnecessary sequential orchestration and non-atomic updates as design smells when the cleaner structure is obvious.** If independent work is serialized for no reason, ask whether it should run in parallel. If related updates can leave state half-applied, push for a more atomic structure. Do not over-index on micro-optimizations, but do flag avoidable orchestration complexity that makes the code more brittle.

## Output Expectations

Prioritize structural code-quality regressions and missed simplifications first, then spaghetti and branching complexity, then boundary, type, and file-size concerns, then smaller modularity and legibility issues.

## Approval Bar

Do not approve merely because behavior seems correct. Treat these as presumptive blockers unless the author can justify them: the PR keeps a lot of incidental complexity when a code-judo move would delete it. Pushes a file from below 1000 lines to above 1000 lines. Adds ad-hoc branching that tangles an existing flow. Scatters feature checks across shared code. Adds an unnecessary abstraction, wrapper, or cast-heavy contract, or duplicates an existing helper or puts logic in the wrong layer when there is a clear canonical home. If those conditions are not met, leave explicit, actionable feedback and push for a cleaner decomposition.

## Review Tone

Be direct, serious, and demanding about quality. Do not be rude, but do not soften major maintainability issues into mild suggestions. If the code is making the codebase messier, say so. If the implementation missed an obvious dramatic simplification, say that too. Do not be satisfied with "maybe rename this" when the real issue is structural.


## Instructions

Review the code through every lens in the rubric and the code-quality lens above that you find relevant. Do not force lenses that don't apply. A simple bug fix does not need paragraphs about architectural integrity.

For each finding, provide:

1. **Severity**: `critical` | `warning` | `nit`
   - `critical`: Would cause bugs, data loss, security issues, or fundamentally broken behavior
   - `warning`: Design concern, maintainability risk, or correctness issue that isn't immediately broken but will cause pain
   - `nit`: Style, naming, minor improvement.
2. **Finding**: What the problem is, in concrete terms. Reference specific lines/functions.
3. **Evidence**: Why you believe this is a problem. Show your reasoning. Don't just assert.
4. **Suggestion** (optional): What you'd do instead, if you have a concrete alternative. Skip this if you don't have a clear fix.

## What Makes a Good Finding

- It references specific code, not vague concerns ("this could be better")
- It explains WHY something is a problem, not just THAT it is
- It distinguishes between "this is broken" and "I would have done this differently"
- It considers the stated intent. A finding that ignores the context of what's being built is a bad finding

## What to Avoid

- Restating what the code does without identifying a problem
- Praising the code. You're an adversary, not a cheerleader. If you find nothing wrong, say "no findings" and stop.

## Output

Return your findings as a structured list. If you have zero findings, say so. An empty review is a valid outcome.

```
## Findings

### 1. [Severity] Short title
**Location**: file:line or function name
**Finding**: What's wrong
**Evidence**: Why this matters
**Suggestion**: (optional) What to do instead

### 2. [Severity] Short title
...
```
