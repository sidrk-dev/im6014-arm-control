## Findings

### 1. [critical] `ArmStation.__init__` calls accepted timing API with wrong keyword
**Location**: `arm_station.py:ArmStation.__init__`
**Finding**: Passes `clock=self._clock` to `StationTimingTracker`, whose accepted `__init__` is `(config, capacity)` with no `clock`. Construction raises `TypeError`.
**Evidence**: Accepted `station_timing.py:StationTimingTracker.__init__` takes no clock. Draft does `StationTimingTracker(StationTimingConfig(...), clock=self._clock)`. Expected: station constructs. Actual: every construction fails before any lifecycle. This is the retained 20-error startup failure; fixing only this exposes behavioral failures below.
**Suggestion**: Do not patch call-site only; decide single timing-clock authority.

### 2. [critical] Ticket validation trusts caller-supplied ticket copy
**Location**: `arm_station.py:ArmStation.request` JogIntent branch
**Finding**: Checks `ticket.ticket_id in _active_tickets`, deletes entry, then validates `ticket.session_id`, `ticket.owner_generation`, `ticket.expires_at_s`, `ticket.bound_sequence` from the caller object, not the stored ticket.
**Evidence**: Expected: expired ticket rejected even if caller rewrites `expires_at_s`. Actual per parent repro: issue ticket, advance past `input_lease_s`, submit `JogIntent` with same `ticket_id` but caller-modified far-future `expires_at_s` and matching `bound_sequence` -> `accepted/ACCEPTED`. Same hole forges `session_id`/`owner_generation`/`bound_sequence`. Stored values are never compared.
**Suggestion**: Look up stored ticket by ID and validate stored copy; bind sequence/expiry/generation/session from store.

### 3. [critical] Unbounded pending tickets
**Location**: `arm_station.py:issue_ticket`, `_active_tickets`
**Finding**: No cap, no expiry sweep, no consumption deadline on `_active_tickets`.
**Evidence**: Expected: bounded pending tickets. Actual per parent repro: 1000 `issue_ticket` calls retain 1000 entries. `MAX_SESSIONS` bounds sessions only; lifecycle queue is bounded to 16 but tickets are not. Leak + DoS + stale-ticket amplification for finding 2.
**Suggestion**: Bound per-session outstanding tickets and prune expired tickets on issue/request/step.

### 4. [critical] Mailbox lock held across transport I/O blocks Stop ingress
**Location**: `arm_station.py:ArmStation.step`
**Finding**: `step` holds `_mailbox_lock` while running `coordinator.check_step()` and `coordinator.step()`, both of which do synchronous `exchange` with `deadline_s`.
**Evidence**: Expected: Stop ingress admitted independently of serial I/O. Actual per parent repro: while executor exchange blocked, `request(StopAction)` cannot acquire lock and is not admitted before exchange release. Design requires Stop/focus-loss/unplug revoke before next unstarted mode-1 write and mode-0 on every motor; blocking ingress behind the write being revoked defeats it. Same lock also blocks `snapshot` and `register_session`.
**Suggestion**: Separate ingress mailbox from execution; never hold ingress lock across `exchange`.

### 5. [critical] `snapshot` mutates thread-confined Core on caller thread
**Location**: `arm_station.py:ArmStation.snapshot`
**Finding**: Takes `_mailbox_lock` then calls `self.core.snapshot()` and `self.timing.snapshot()` on whatever thread called `snapshot`.
**Evidence**: Expected: immutable published view only; `JointCore` header states all methods belong to one calling thread and HTTP threads never mutate Core. Actual per parent repro: caller thread ID observed inside Core path. Worse, `JointCore.snapshot()` calls `_now()` which writes `_now_high_water_s` and validates regression, so a “read-only” snapshot is a Core mutation and races the loop thread’s `prepare/claim/dispatch/receive`.
**Suggestion**: Publish copy-out state from executor thread only; make snapshot lock-free read of last published record.

### 6. [critical] Station ownership never released on Disconnect/close
**Location**: `arm_station.py:request`, `_handle_lifecycle_action:DisconnectAction`, `close`
**Finding**: First `ConnectAction` sets `_owner_session_id/_owner_generation` at `request` time. `DisconnectAction` and `close` never clear `_owner_session_id`, `_owner_generation`, `_sessions`, `_active_tickets`, `_device_epoch`, `_latest_intent`.
**Evidence**: Expected: disconnect relinquishes station ownership so a new session can own; reconnect requires fresh confirmation. Actual: owner stuck for process lifetime. Second session `ConnectAction` always `NOT_OWNER`. Failed-close test passes only because ownership is sticky, but successful disconnect also sticks. Tickets/intents/device-epoch survive disconnect, violating freshness.
**Suggestion**: Define explicit ownership release; clear tickets/intent/epoch on disconnect/close/fault per spec.

### 7. [critical] Owner granted before transport/connect succeeds
**Location**: `arm_station.py:request` Connect branch vs `_handle_lifecycle_action` Connect
**Finding**: `request` assigns `_owner_session_id` immediately when `_owner_session_id is None`, queues work, returns `queued`. Core `begin_connect/connected` runs later in `step`.
**Evidence**: Expected: ownership reflects admitted connection. Actual: snapshot `owner_session_id` set while Core still `disconnected`; if `begin_connect/connected` rejected or physical draft invalid, owner remains captured and blocks all others. Return values of `begin_connect/connected` are also ignored.
**Suggestion**: Assign ownership at execution success, not ingress.

### 8. [critical] Pre-owner tickets match post-owner generation
**Location**: `arm_station.py:issue_ticket`
**Finding**: Allows issue when `_owner_session_id is None` and synthesizes `owner_generation=max(1,_owner_generation)` = 1. After first connect `_owner_generation` becomes 1.
**Evidence**: Expected: tickets bound to active owner generation; pre-connect tickets unusable. Actual: ticket issued before any owner has generation 1 and will pass later `ticket.owner_generation != _owner_generation` check. Combined with finding 2, delayed pre-owner input can become fresh.
**Suggestion**: Refuse ticket issue with no active owner.

### 9. [warning] Lease expiry and priority Stop retain stale intent/latch
**Location**: `arm_station.py:step` lease-expired and priority-stop paths
**Finding**: Lease path calls `core.stop()`, sets `lease_expired`, but leaves `_latest_intent`, `_persistent_release_latch`, `_last_intent_server_time_s` intact. Priority-stop path clears `_latest_intent` but leaves `_persistent_release_latch`, `_needs_deadman_fresh_edge`/`_observed_released_neutral` inconsistent.
**Evidence**: Expected: stale owner/intent revoked; re-arm requires neutral + fresh deadman edge. Actual reproduction: arm -> jog accepted -> advance past `input_lease_s` -> step stops -> `snapshot.requested_axes` still shows old axes; after Check+Arm without new intent, old `_latest_intent` can immediately drive `_capture` or jog logic. After focus-loss Stop, latch state can permit motion without required repress.
**Suggestion**: Clear intent, timestamps, and release latch on every revoke path; require explicit fresh neutral edge.

### 10. [critical] Arm/hold submit results ignored — misleading success
**Location**: `arm_station.py:_handle_lifecycle_action:ArmAction`, `_capture_and_submit_stationary_hold`
**Finding**: Builds `window` + `Target` and calls `core.submit_target(target)` without checking `Decision`. Still sets `_holding_position/_hold_energized=True`, `input_phase=holding`, receipt `ARMED`.
**Evidence**: Expected: armed only with measured hold actually admitted by Core sole limiter. Actual: if Core rejects (`STALE_FEEDBACK`, `UNHEALTHY`, `EXPIRED`, `DUPLICATE_OR_OLDER`, limit violation), station still reports `ARMED/holding/hold_energized`. Same for every `_capture_and_submit_stationary_hold` caller (release, guard REPLACE_HOLD). Tests asserting `hold_energized` therefore prove nothing about Core admission.
**Suggestion**: Check `submit_target.accepted`; on reject do not set hold flags and return reject receipt.

### 11. [warning] Per-joint Stop truthfulness lost
**Location**: `arm_station.py:step`, `_handle_lifecycle_action`, `snapshot`
**Finding**: `_per_joint_stop_confirmed` updated only in priority-stop, lease-expiry, guard-REVOKE, and Check paths. Disconnect’s `check_step` records discarded. `snapshot.stop_confirmed = all(per_joint) and state in (STOPPED,READY)`.
**Evidence**: Expected: logical vs physically confirmed Stop distinguished per joint; only valid fresh mode-0 feedback confirms. Actual: (a) Disconnect reports `DISCONNECTED` success without per-joint confirmation. (b) After `Check`, state `READY` + check mode-0 OK makes `stop_confirmed=True` though no Stop occurred — check masquerades as stop. (c) `FAULT` with all mode-0 OK still `stop_confirmed=False` because `FAULT` excluded, conflating logical and confirmed.
**Suggestion**: Update per-joint map on every mode-0 round including Disconnect/close; separate check-confirmed from stop-confirmed.

### 12. [critical] `close` claims settle+stop without verifying confirmation
**Location**: `arm_station.py:close`
**Finding**: Sets latch, one `step()` in try/except pass, stops loop, closes `managed_port` or `bus`, returns `closed` based only on `is_open is False`.
**Evidence**: Expected: stop motors, bounded settle, then close lease; unconfirmed close reported distinctly without losing stop evidence. Actual reproduction: inject single-motor stop failure, `close()` still closes transport and can return `True` while `_per_joint_stop_confirmed=(True,False,True)`. Exception from `step` swallowed, so failed stop still proceeds to close. `stop_loop(join timeout 1.0)` drops thread handle on timeout, leaking loop. `managed_port` never assigned (always `None`), so physical lease never closed via owned port path.
**Suggestion**: Verify all-joint mode-0 confirmation before transport close; do not swallow step errors; join with verification.

### 13. [critical] Physical draft valid path is no-op misleading success
**Location**: `arm_station.py:_handle_lifecycle_action:physical`, `validate_physical_draft`
**Finding**: Valid draft only writes receipt `CONNECTED/Physical draft validated`; never opens port, never builds physical `JointMap`/specs/Core, never freezes config. Invalid path sets `_commissioning_blocked=True` sticky and never clears on later valid draft.
**Evidence**: Expected: instantiate physical Core once after validated mapping, freeze for lifetime; blocked flag reflects current draft. Actual: station stays on fixture Core/specs after “physical connect”; snapshot still fixture-owned. Once blocked, always blocked. Validation also misses `reference_joint_rad` finiteness, `name` non-empty, `q/v/a/lead/effort/kp/kd` finiteness (inf passes `>0`), `limits_provenance` length bound, per-joint gain/protection consistency.
**Suggestion**: Either implement single physical instantiation + freeze or return explicit unimplemented commissioning refusal; make blocked flag per-request and validate finite fields.

### 14. [critical] Jog synthesis bypasses Core limiter assumptions + ignores physical gains
**Location**: `arm_station.py:step` jogging branch
**Finding**: Anchors `goal_q = ref.q + axis*selected_speed*max(0.001, now-ref.sample_time)`, clamps only to `q_min/q_max`, always `dq=0,tau=0,kp=SYNTHETIC_KP,kd=SYNTHETIC_KD`.
**Evidence**: Expected: Core sole limiter with exact Fraction derivative/encoded speed, lead/combined effort/protection/cache invariants; physical per-joint `kp/kd/v_max` honored. Actual: elapsed-time scaling grows after missed dispatches causing jumps; position-only clamp can still violate lead/speed/effort and force Core fault instead of graceful limit; hardcoded synthetic gains ignore validated physical draft gains; `SetSpeed` upper bound hardcoded `2.0` ignores spec `v_max` (physical `v_max=1.0` still accepts `2.0`).
**Suggestion**: Derive goals through accepted reference API; use per-spec limits/gains; validate speed against active specs.

### 15. [warning] Dispatch guard seam hardcodes joint index and risks deadlock
**Location**: `arm_station.py:step` guard block
**Finding**: Calls `guard(plan.plan_id, 0, plan)` always with `0`; user callback runs while holding `_mailbox_lock`.
**Evidence**: Expected: narrow per-joint allow/replace-hold/revoke without fabricating history. Actual: guard never sees joints 1..2, cannot make per-joint truthful decision. If guard calls `request/snapshot/step`, non-reentrant `Lock` deadlocks loop thread. `REPLACE_HOLD` invalidates prepared plan via new `submit_target` then falls through to fresh `coordinator.step`, obscuring which plan was actually dispatched.
**Suggestion**: Pass actual joint index/vector; document non-reentrancy or invoke guard outside lock.

### 16. [warning] Lifecycle Check claims owner without Stop transport
**Location**: `arm_station.py:_handle_lifecycle_action:CheckAction`
**Finding**: Pops lifecycle queue even in `ARMED/MOVING`, calls `core.claim_owner()` which can flip `ARMED/MOVING→STOPPED` internally with no mode-0 exchange, then `begin_check/check_step/checked`.
**Evidence**: Expected: Stop attempts mode-0 on every motor with per-joint confirmation. Actual: ownership rotation silently stops Core logically without wire evidence; subsequent `check_step` is attributed to check, not to the implicit stop. Overwrites `_current_core_owner` even when `begin_check` later rejects.
**Suggestion**: Forbid Check while armed/moving or route through explicit Stop with confirmation first.

### 17. [warning] `read_uncalibrated_raw_angles` returns unqualified angles
**Location**: `arm_station.py:read_uncalibrated_raw_angles`
**Finding**: Sends mode-0 `command`, `exchange`, returns `float(reply[position_rad])` with no `mode/timeout/errors/warnings` check, no bus/deadline/motor-id validation, unbounded total time (`deadline` per motor).
**Evidence**: Expected: bounded mode-0 raw reads in output coordinates, faulty feedback never presented as angle. Actual: timeout/error/corrupt feedback still yields number if `exchange` returns; caller cannot distinguish faulty vs fresh. `compute_zero_output` similarly lacks finite checks and can return `inf/nan` (`float(inf)-direction*float(ref)`).
**Suggestion**: Validate reply health/timeout, bound total deadline and ID set, require finite inputs/outputs.

### 18. [warning] Wrong codec/API assumptions and dead code
**Location**: `arm_station.py` imports, `station_step.py`, `arm_fixture.py` vs `im6014_codec.py`
**Finding**: `arm_station` imports `decode_command` never used; `JointMap` imported but physical mapping never built. `snapshot` exposes `admitted_goal/dispatched_reference/confirmed_reference/owner_session_id/owner_generation` despite design “public methods hide ownership/windows/targets/wire”. Loop worker mixes deterministic `clock` with real `time.sleep` and `timing.calculate_slot_skip`, so frozen test clock causes real 20 ms sleeps and skewed `actual_period_s`. `_loop_worker` swallows all `step` exceptions, hiding protection/transport faults from timing/history.
**Evidence**: Reproduction logic: valid physical connect still leaves `admitted_goal` with synthetic gains visible; `start_loop` with `DeterministicClock` sleeps real time while clock frozen; fault during loop never surfaces except via missing transactions.
**Suggestion**: Remove unused imports; publish only requested/admitted/dispatched/measured views as specified; drive loop pacing from injected clock/sleep; do not swallow executor errors.
