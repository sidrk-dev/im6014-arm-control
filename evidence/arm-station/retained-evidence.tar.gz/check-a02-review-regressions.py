from pathlib import Path
import json,sys,time,threading,unittest
sys.path.insert(0,sys.argv[1])
import serial
def deny(*args,**kwargs):raise AssertionError('No physical serial acquisition')
serial.Serial=deny
import im6014_port
im6014_port.open_managed_port=deny
from arm_station import ArmStation,ConnectAction,CheckAction,ArmAction,DisconnectAction,JogIntent,StopAction
from arm_fixture import ArmPacketFixture
from im6014_codec import decode_command
class Clock:
 def __init__(self):self.value=10.
 def __call__(self):return self.value
 def advance(self):self.value+=.02
class ReviewRegressions(unittest.TestCase):
 def setup_manual(self,ready=False,armed=False):
  c=Clock();f=ArmPacketFixture(clock=c);s=ArmStation(clock=c,fixture=f);a=s.register_session()
  def step():c.advance();return s.step()
  for action in [ConnectAction()]+([CheckAction()] if ready or armed else [])+([ArmAction()] if armed else []):s.request(action,a);step()
  return c,f,s,a,step
 def wait(self,predicate):
  until=time.monotonic()+2
  while not predicate() and time.monotonic()<until:time.sleep(.005)
  self.assertTrue(predicate())
 def setup_background(self):
  f=ArmPacketFixture();s=ArmStation(fixture=f);a=s.register_session();s.start_loop();s.request(ConnectAction(),a);self.wait(lambda:s.snapshot().lifecycle_state=='connected');return f,s,a
 def test_successful_disconnect_allows_new_client(self):
  c,f,s,a,step=self.setup_manual();s.request(DisconnectAction(),a);step();self.assertIsNone(s.snapshot().owner_session_id);b=s.register_session();receipt=s.request(ConnectAction(),b);self.assertNotEqual(receipt.code,'NOT_OWNER');step();self.assertEqual(s.snapshot().lifecycle_state,'connected');self.assertEqual(s.snapshot().owner_session_id,b.session_id)
 def test_failed_initial_physical_connect_does_not_claim_station(self):
  c=Clock();f=ArmPacketFixture(clock=c);s=ArmStation(clock=c,fixture=f);a=s.register_session();s.request(ConnectAction(source_kind='physical'),a);c.advance();s.step();self.assertIsNone(s.snapshot().owner_session_id);b=s.register_session();r=s.request(ConnectAction(),b);self.assertNotEqual(r.code,'NOT_OWNER');c.advance();s.step();self.assertEqual(s.snapshot().lifecycle_state,'connected');self.assertEqual(f.writes,())
 def test_arm_exception_clears_transition_and_revokes(self):
  c,f,s,a,step=self.setup_manual(ready=True)
  def fail(*args,**kwargs):raise ValueError('injected arm failure')
  s._core.arm=fail;s.request(ArmAction(),a)
  try:step()
  except ValueError:pass
  self.assertFalse(s._arm_transition);self.assertFalse(s._lifecycle_in_progress)
  with self.assertRaises((ValueError,RuntimeError)):s.issue_ticket(a,1)
 def test_background_executor_failure_attempts_all_mode0(self):
  f,s,a=self.setup_background();before=len(f.writes)
  def fail(*args,**kwargs):raise RuntimeError('injected failure')
  s._step_once=fail;self.wait(lambda:s.snapshot().executor_failed);s._loop_thread.join(1);self.assertEqual([decode_command(p)['motor_id'] for p in f.writes[before:] if decode_command(p)['mode']==0],[0,1,2]);self.assertTrue(s.snapshot().stop_logical);self.assertTrue(s.snapshot().close_attempted)
 def test_invalid_core_clock_cannot_suppress_stop_wire_attempts(self):
  c,f,s,a,step=self.setup_manual();before=len(f.writes);c.value=float('nan');s._record_executor_failure();self.assertEqual([decode_command(p)['motor_id'] for p in f.writes[before:] if decode_command(p)['mode']==0],[0,1,2]);self.assertTrue(s.snapshot().executor_failed);self.assertFalse(s.snapshot().stop_confirmed)
 def test_stop_loop_then_close_uses_same_executor_and_closes(self):
  f,s,a=self.setup_background();s.stop_loop();self.assertTrue(s.close());self.assertFalse(f.is_open);self.assertFalse(s._loop_thread.is_alive())
 def test_unconfirmed_disconnect_retains_owner(self):
  c,f,s,a,step=self.setup_manual(armed=True);f.inject_stop_failure_ids={1};s.request(DisconnectAction(),a);step();self.assertFalse(s.snapshot().stop_confirmed);self.assertEqual(s.snapshot().owner_session_id,a.session_id);b=s.register_session();self.assertEqual(s.request(ConnectAction(),b).code,'NOT_OWNER')
 def test_pending_jog_stop_has_terminal_rejected_receipt(self):
  c,f,s,a,step=self.setup_manual(armed=True);ticket=s.issue_ticket(a,1);r=s.request(JogIntent(1,(0,0,0),False,True,'keys',ticket),a);s.request(StopAction(),a);step();self.assertEqual(s._receipts[r.request_id].code,'STOP_PREEMPTED')
 def test_lifecycle_completion_survives_unrelated_request_flood(self):
  f,s,a=self.setup_background();entered=threading.Event();release=threading.Event();orig=f.write;first=[True]
  def blocked(packet):
   if first[0]:first[0]=False;entered.set();release.wait(2)
   return orig(packet)
  f.write=blocked;r=s.request(CheckAction(),a);self.assertTrue(entered.wait(1))
  try:
   for i in range(1000):s.request(object(),a)
  finally:release.set()
  self.wait(lambda:s.snapshot().lifecycle_state=='ready')
  try:
   lookup=s.receipt(r.request_id);self.assertEqual(lookup.status,'present');observed=lookup.receipt;self.assertIsNotNone(observed);self.assertEqual(observed.code,'READY');self.assertEqual(observed.status,'accepted')
  finally:s.close()
out=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ReviewRegressions))
Path(sys.argv[2]).write_text(json.dumps({'testsRun':out.testsRun,'success':out.wasSuccessful(),'failures':[str(t) for t,_ in out.failures],'errors':[str(t) for t,_ in out.errors],'hardwareIO':False,'source':sys.argv[1]},indent=2)+'\n')
raise SystemExit(not out.wasSuccessful())
