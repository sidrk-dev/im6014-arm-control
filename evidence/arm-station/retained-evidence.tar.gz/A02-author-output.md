### Summary of Changes

1. **`arm_fixture.py`**:
   - Implemented `ArmPacketFixture`, a pyserial-shaped, in-memory three-motor (IDs 0, 1, 2) packet fixture that uses existing `decode_command`, `crc32`, and canonical 26-byte feedback framing (`make_feedback_packet`). Never imports or opens physical serial devices.
   - Preserves output/internal 38/3 semantics and ideal command-following dynamics, with testable injection controls for mode 0 failures, motor faults, timeouts, corrupted CRCs/feedback frames, partial writes, driver errors, and close failures.
   - Defined conservative synthetic joint limits (`J1` bounded to $\pm\pi/2$, `J2` and `J3` bounded to finite synthetic limits $\pm 2.356\text{ rad}$), synthetic protection policy, and `create_synthetic_arm_specs()`.

2. **`arm_station.py`**:
   - Implemented `ArmStation` providing single authority over one `JointCore`, one `StationStepCoordinator`, one `StationTimingTracker`, and packet transport.
   - Implemented bounded session registration (cap of 16), short-lived session-scoped input tickets (binding owner generation, 150 ms lease, sequence, single-use consumption), and request handling for agreed actions: `ConnectAction`, `CheckAction`, `ArmAction`, `JogIntent`, `StopAction`, `DisconnectAction`, and `SetSpeedAction`.
   - Guaranteed authority and stop priorities:
     - Stop requests may be submitted by any registered session and latch with priority.
     - Release latches persist so that newer active intents never drop an admitted release.
     - Mode 0 Stop commands are attempted across all three motors, distinguishing logical stop from physical stop confirmation (`stop_confirmed` and `per_joint_stop_confirmed`).
     - Arm requires neutral axes and released deadman, and transitions immediately to a measured-position hold Target.
     - Deadman repress gate enforces an observed neutral/released state before a fresh deadman edge can trigger jog movement.
     - Jog goals are derived from last confirmed reference and actual elapsed server time with zero velocity/torque feedforward.
     - Ordinary deadman release captures last confirmed reference as stationary goal and holds energized position.
     - Focus loss, device epoch changes, lease timeouts, and close requests revoke authority and trigger mode 0 commands to all motors.
     - Station close failure retains ownership and reports `close_unconfirmed`.
     - Preserves `JointCore` latched protection and fault history across reconnects.
     - Exposed narrow internal dispatch guard seam (`DispatchGuardOutcome.ALLOW`, `REPLACE_HOLD`, `REVOKE`).
   - Implemented physical commissioning draft structures (`PhysicalDraft`, `PhysicalJointDraft`, `validate_physical_draft`, `compute_zero_output`, `read_uncalibrated_raw_angles`) that strictly reject uncommissioned physical connections before any port opening.

3. **`test_arm_station.py`**:
   - Authored unit test suite covering:
     - Disconnected startup state and unavailable measurements (no fake zeros).
     - Bounded sessions (16 max) and rejection of unknown handles.
     - Third-party stop allowance without ownership overwrite.
     - Complete lifecycle (`Connect` -> `Check` -> `Arm` -> `Jog` -> `Hold` -> `Stop` -> `Disconnect`).
     - Single-use ticket rejection, expired tickets, older sequence rejection, and foreign session ticket rejection.
     - Delayed input expiry and input lease loss stop.
     - Neutral input and fresh deadman edge gate.
     - Verification with `decode_command` that mode 1 is never sent before Arm.
     - Measured-position hold verification.
     - Independent jog directions across J1, J2, and J3 verified against wire writes.
     - Ordinary release hold persistence.
     - Focus loss and device epoch change revocation.
     - Stale owner stop.
     - Partial/failed writes and truthful history preservation.
     - One-motor stop failure with attempts on others, confirming logical vs. confirmed stop separation.
     - Close failure retaining ownership and preventing second owners.
     - Fault and protection persistence across reconnect.
     - Incomplete physical draft rejection before opening.
     - Canonical packet decoding of actual writes with `decode_command`.
     - Dispatch guard seam replacement and revocation.
     - Lifecycle queue overflow rejection (`QUEUE_FULL`).

### Observed Verification

Local command execution tools were unavailable on this provider surface (file tools only); no local shell commands or tests were executed. All checks are requested from the parent runner.

```pstack-handoff
{"task":"A02-author","checkpoint":"A02-draft","operation":"run-checks","files":["arm_station.py","arm_fixture.py","test_arm_station.py"],"checks":["A02-fixture-lifecycle","A02-station-boundary","A02-offline-regression"],"summary":"Verify three-joint arm station, packet fixture, and test suite across lifecycle, session boundaries, and offline baseline."}
```