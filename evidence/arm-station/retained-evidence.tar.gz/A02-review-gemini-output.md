# Adversarial Code Review: Retained Original Gemini A02 Arm Station Draft

This review evaluates the retained original Gemini A02 station draft ([`arm_station.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py), [`arm_fixture.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_fixture.py), and [`test_arm_station.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/test_arm_station.py)) against the accepted Core, transport, and timing contracts ([`joint_contract.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_contract.py), [`joint_controller.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py), [`station_step.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py), and [`station_timing.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_timing.py)).

The draft fails at construction across all 20 test cases due to an invalid timing tracker invocation. Resolving the constructor reveals 9 behavioral failures and fundamental violations of single-thread confinement, stop ingress, feedback freshness, per-joint truthfulness, and lifecycle ownership.

---

## 1. Startup Blocker: `StationTimingTracker` Constructor API Mismatch

### Finding
In [`arm_station.py` line 235](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L235):
```python
self.timing = StationTimingTracker(
    StationTimingConfig(nominal_period_s=self.slot_period_s),
    clock=self._clock,
)
```
[`StationTimingTracker.__init__`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_timing.py#L340) accepts `(config: StationTimingConfig | float, capacity: int = DEFAULT_CAPACITY)`. It does not accept a `clock` keyword argument.

* **Expected**: [`ArmStation`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L210) initializes [`StationTimingTracker`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_timing.py#L340) conforming to its defined constructor signature.
* **Actual**: Every instantiation of [`ArmStation`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L210) raises `TypeError: StationTimingTracker.__init__() got an unexpected keyword argument 'clock'`, failing all 20 tests at startup.
* **Reproduction**: Instantiate `ArmStation(clock=lambda: 0.0)`.

---

## 2. Critical Safety & Architectural Deficiencies

### 2.1 Stop Ingress Blocked by In-Flight Bus Exchange Lock
* **Location**: [`arm_station.py` lines 248–266, 461–558](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L248-L266)
* **Defect**: [`ArmStation.step`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L461) holds `with self._mailbox_lock:` across the entire execution of [`StationStepCoordinator.step`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py#L107). This step coordinates sequential, synchronous serial port exchanges (`exchange`) across all joints. If a motor stalls, times out, or experiences I/O delay (up to `3 * deadline_s`, or 150ms+), `_mailbox_lock` is held continuously.
* **Impact**: [`ArmStation.request`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L248) also requires `with self._mailbox_lock:`. An operator or external supervisor submitting [`StopAction`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L119) is blocked on the caller thread until the multi-joint bus exchange finishes or times out. Emergency stop cannot preempt or interrupt in-flight exchanges.
* **Reproduction**: While `bus.write()` or `bus.read()` blocks inside `exchange()`, invoke `station.request(StopAction(), handle)` from another thread; observe caller thread blocked on `_mailbox_lock`.

### 2.2 Caller-Thread Core Snapshot Violates Thread Confinement
* **Location**: [`arm_station.py` lines 650–689](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L650-L689)
* **Defect**: [`ArmStation.snapshot`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L650) directly executes [`self.core.snapshot()`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L594). [`JointCore`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L65) is thread-confined: *"All methods on a JointCore belong to one calling thread."* In addition, [`JointCore.snapshot`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L594) mutates internal high-water state via [`_now()`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L297):
  ```python
  self._now_high_water_s = result
  ```
* **Impact**: Calling `snapshot()` from a UI or HTTP endpoint thread while `_loop_thread` runs `step()` executes `JointCore` methods concurrently across threads. If clock reads between the threads interleave or diverge, `_now()` raises `ValueError("clock regressed...")`, crashing the core.

### 2.3 Per-Joint Stop Confirmation Falsified on Running Motor
* **Location**: [`arm_station.py` lines 470–474, 608–612](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L470-L474) and [`station_step.py` lines 275–305](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py#L275-L305)
* **Defect**: In [`StationStepCoordinator.check_step`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py#L254), each transaction record receives `outcome = "OK"` and `feedback_received = True` whenever `exchange()` completes without an exception. [`ArmStation.step`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L461) sets:
  ```python
  self._per_joint_stop_confirmed[r.motor_id] = (
      r.outcome == "OK" and r.feedback_received
  )
  ```
  Neither [`check_step`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py#L254) nor [`ArmStation`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L210) inspects `reply["mode"]` or `health.mode == 0`.
* **Impact**: If a motor fails to stop and reports `mode == 1`, the station records `_per_joint_stop_confirmed = True`. Furthermore, once initialized during [`CheckAction`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L101), `_per_joint_stop_confirmed` is never cleared during motion; while the arm is actively moving, [`ArmStationSnapshot.per_joint_stop_confirmed`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L218) continues to report `(True, True, True)`.
* **Reproduction**: Configure `fixture.inject_stop_failure_ids = {1}`. Submit `StopAction()`, step, and inspect `snapshot().per_joint_stop_confirmed[1]`; it evaluates to `True` instead of `False`.

### 2.4 Instantaneous Step Velocity Trips Core Acceleration Limit Fault
* **Location**: [`arm_station.py` lines 504–530](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L504-L530)
* **Defect**: In `step()`, jog goals are calculated as:
  ```python
  goal_q = ref.q_rad + float(axis) * self._selected_speed_rad_s * dt
  ```
  and submitted with `dq_rad_s = 0.0`. In the subsequent refresh cycle, [`prepare_complete_reference`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L450) computes derivative velocity `(goal_q - ref.q_rad) / dt = 0.5 rad/s`. The transition from stationary hold ($0.0 \text{ rad/s}$) to $0.5 \text{ rad/s}$ in a $0.020\text{s}$ slot produces an acceleration of $a = 0.5 / 0.02 = 25.0 \text{ rad/s}^2$. The synthetic specification limit [`SYNTHETIC_A_MAX`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_fixture.py#L38) is $5.0 \text{ rad/s}^2$.
* **Impact**: [`JointCore.prepare_refresh`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L466) rejects the target with a constraint violation, latches a joint fault, and calls `self.stop()`. Instantaneous jog motion cannot start without tripping an acceleration fault.
* **Reproduction**: In armed hold, submit `JogIntent(sequence=1, axes=(1.0, 0.0, 0.0), ...)`, step, and inspect `core.snapshot().state`; it transitions to `State.FAULT`.

### 2.5 Stale Feedback Starvation in `State.READY` Latches Spurious Fault
* **Location**: [`arm_station.py` lines 480–558](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L480-L558) and [`station_step.py` lines 115–135](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py#L115-L135)
* **Defect**: When the station is in `State.READY`, [`JointCore.prepare_refresh`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L416) returns `None`. [`StationStepCoordinator.step`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py#L107) executes `self.core.tick()`, exchanging zero packets with the bus.
* **Impact**: [`JointCore._housekeeping`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L318) monitors feedback age against `feedback_max_age_s` (0.500s). If the arm remains in `State.READY` for longer than 500ms, `_housekeeping` latches `stale = True` on all joints and forces the core into `State.FAULT`. If `ArmAction` is submitted after 500ms, [`JointCore.arm`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L400) rejects with `STALE_FEEDBACK`.
* **Reproduction**: Transition to `State.READY`, advance clock by 0.550s, call `step()`; observe `core.snapshot().state == State.FAULT`.

---

## 3. Authority, Ownership & Commissioning Violations

### 3.1 Premature Ownership Mutation on Unvalidated Connect
* **Location**: [`arm_station.py` lines 267–275](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L267-L275)
* **Defect**: In `request()`, when `self._owner_session_id is None`:
  ```python
  if isinstance(action, ConnectAction):
      self._owner_session_id = session_handle.session_id
      self._owner_generation += 1
  ```
  This mutation occurs during request ingress, before the action is validated or executed.
* **Impact**: If `ConnectAction` is rejected in `step()` (e.g. invalid physical draft or core error), `_owner_session_id` is never rolled back. The rejected session permanently retains station ownership, locking out all other sessions while the station remains disconnected.
* **Reproduction**: Submit `ConnectAction(source_kind="physical", draft=None)` from session A; step. Attempt `ConnectAction()` from session B; observe rejection with `NOT_OWNER`.

### 3.2 `DisconnectAction` Fails to Relinquish Ownership Authority
* **Location**: [`arm_station.py` lines 734–747](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L734-L747)
* **Defect**: Handling `DisconnectAction` does not reset `_owner_session_id`, `_current_core_owner`, `_active_tickets`, or `_device_epoch`.
* **Impact**: After a session explicitly disconnects, no subsequent session can connect because `self._owner_session_id` remains bound to the disconnected session.
* **Reproduction**: Session A connects, steps, and disconnects. Session B attempts `ConnectAction()`; rejected with `NOT_OWNER`.

### 3.3 Ticket Expiry Forgery & Blind Ticket Invalidation
* **Location**: [`arm_station.py` lines 288–320](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L288-L320)
* **Defect 1 (Expiry Forgery)**: In `request()`, the server evaluates `now > ticket.expires_at_s` using the caller-supplied `action.ticket` dataclass instead of the canonical record stored in `self._active_tickets`. A client can submit an expired ticket with a forged future `expires_at_s`.
* **Defect 2 (Unauthorized Deletion)**: `del self._active_tickets[ticket.ticket_id]` is executed before verifying `ticket.session_id == self._owner_session_id`. Any registered session can invalidate an active owner's ticket by submitting its ID.
* **Defect 3 (Unbounded Accumulation)**: Unused tickets in `_active_tickets` are never pruned, leaking memory on high ticket volume.

### 3.4 Physical Commissioning Returns False Connection Receipt
* **Location**: [`arm_station.py` lines 573–587](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L573-L587)
* **Defect**: When `action.source_kind == "physical"` and `validate_physical_draft` succeeds:
  ```python
  self._receipts[req_id] = RequestReceipt(
      req_id, "Connect", "accepted", "CONNECTED", "Physical draft validated", now,
  )
  ```
  The station never creates a [`ManagedPort`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/im6014_port.py#L18), never calls `core.begin_connect()`, and never calls `core.connected()`.
* **Impact**: The caller receives a receipt stating `CONNECTED`, but the core remains in `State.DISCONNECTED`. Subsequent `CheckAction` or `ArmAction` calls fail immediately.

### 3.5 Broken Dispatch Guard Seam
* **Location**: [`arm_station.py` lines 545–557](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L545-L557)
* **Defect**: The dispatch guard seam:
  1. Hardcodes joint index to `0`: `self._dispatch_guard(plan.plan_id, 0, plan)`, ignoring joints 1 and 2.
  2. If the guard allows the plan, `ArmStation` calls `coordinator.step()`, which invokes `self.core.prepare_refresh()` a second time. This generates a new plan with `plan_id + 1` that was never validated by `_dispatch_guard`.
  3. [`StationStepCoordinator`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py#L65) does not possess or invoke `_dispatch_guard`.

---

## 4. Test Suite Fallacies in `test_arm_station.py`

### 4.1 Falsified Stop Confirmation in `test_one_motor_stop_failure...`
In [`test_arm_station.py` line 398](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/test_arm_station.py#L398):
```python
self.fixture.inject_stop_failure_ids = {1}
self.station.request(StopAction(), session)
self.station.step()
...
self.assertEqual(snap.per_joint_stop_confirmed, (True, False, True))
```
Because `check_step()` ignores `reply["mode"] == 1`, `per_joint_stop_confirmed` evaluates to `(True, True, True)`, failing the test.

### 4.2 State Mutation Flaw in `test_reconnect_protection_preserved`
In [`test_arm_station.py` line 449](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/test_arm_station.py#L449):
```python
rc_no_ack = self.station.request(CheckAction(acknowledge_fault=False), session)
self.station.step()
self.assertEqual(self.station.snapshot().lifecycle_state, "connected")
```
When `CheckAction` runs, [`arm_station.py` line 605](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L605) executes `self.core.claim_owner(self._owner_session_id)`. When latched faults exist, [`JointCore.claim_owner`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/joint_controller.py#L221) mutates state to `State.FAULT`. The snapshot lifecycle state becomes `"fault"`, failing the assertion for `"connected"`.

### 4.3 Confirmed Packet Assumption in `test_partial_failed_writes...`
In [`test_arm_station.py` line 377](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/test_arm_station.py#L377):
```python
self.assertIsNone(self.station.core.snapshot().confirmed_references[0].packet)
```
In `JointCore`, a failed dispatch record does not nullify the last confirmed reference; it preserves the previous reference confirmed during arming. `confirmed_references[0].packet` contains the earlier emitted hold packet, failing the assertion.

---

## 5. Summary Matrix

| ID | Category | Severity | Root Cause Location | Consequence |
|---|---|---|---|---|
| 1 | API Mismatch | Blocker | [`arm_station.py#L235`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L235) | Unexpected keyword argument `clock`; fails all 20 tests at startup |
| 2.1 | Concurrency | Critical | [`arm_station.py#L248-L266`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L248-L266) | Stop request blocked on caller thread during multi-joint bus I/O |
| 2.2 | Concurrency | Critical | [`arm_station.py#L650`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L650) | `JointCore` thread confinement violated; clock race causes crash |
| 2.3 | Truthfulness | High | [`arm_station.py#L470`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L470) | Mode 1 feedback accepted as confirmed stop; truthfulness lost |
| 2.4 | Dynamics | High | [`arm_station.py#L504`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L504) | Instantaneous step velocity demands 25 rad/s² against 5 rad/s² limit |
| 2.5 | Freshness | High | [`station_step.py#L115`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/station_step.py#L115) | Core starves without exchanges in `READY`; latches stale fault after 0.5s |
| 3.1 | Authority | High | [`arm_station.py#L267`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L267) | Ownership assigned prior to draft validation; locks station on failure |
| 3.2 | Authority | High | [`arm_station.py#L734`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L734) | `DisconnectAction` retains ownership; locks out subsequent sessions |
| 3.3 | Security | Medium | [`arm_station.py#L288`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L288) | Ticket expiry validated against untrusted client object |
| 3.4 | Truthfulness | Medium | [`arm_station.py#L573`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L573) | Physical `ConnectAction` returns `CONNECTED` without opening transport |
| 3.5 | Architecture | Medium | [`arm_station.py#L545`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-workbench/arm_station.py#L545) | `_dispatch_guard` hardcodes joint 0 and is bypassed during execution |