"""Three-joint manual arm station managing single authority, timing, and lifecycle.

Coordinates one JointCore, StationStepCoordinator, and packet transport.
Exposes bounded session registration, short-lived input tickets, lifecycle requests,
and immutable telemetry snapshots.
"""

from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
import math
import secrets
import threading
import time

from arm_fixture import (
    ArmPacketFixture,
    SYNTHETIC_KD,
    SYNTHETIC_KP,
    create_synthetic_arm_specs,
)
from im6014_codec import command, decode_command
from im6014_port import ManagedPort, PortConfig
from im6014_serial import exchange
from joint_contract import (
    DecisionCode,
    JointFault,
    JointSpec,
    JointStatus,
    JointTrajectoryReference,
    MotorHealth,
    OwnerToken,
    RefreshPlan,
    Snapshot as CoreSnapshot,
    SourceIdentity,
    State,
    Target,
)
from joint_controller import JointCore
from joint_mapping import JointMap, JointSample, JointTarget
from joint_protection import ProtectionPolicy
from station_step import StationStepCoordinator
from station_timing import (
    LoopStepRecord,
    StationTimingConfig,
    StationTimingTracker,
    TimingCounters,
    TimingSnapshot,
    validate_finite_time,
)

__all__ = (
    "DEFAULT_EXCHANGE_DEADLINE_S",
    "DEFAULT_FEEDBACK_MAX_AGE_S",
    "DEFAULT_INPUT_LEASE_S",
    "DEFAULT_MAX_REFERENCE_GAP_S",
    "DEFAULT_MAX_WINDOW_S",
    "DEFAULT_SLOT_PERIOD_S",
    "DEFAULT_SPEED_LIMIT_RAD_S",
    "MAX_SESSIONS",
    "ArmAction",
    "ArmStation",
    "ArmStationSnapshot",
    "CheckAction",
    "ConnectAction",
    "DisconnectAction",
    "DispatchGuardOutcome",
    "InputTicket",
    "JogIntent",
    "PhysicalDraft",
    "PhysicalJointDraft",
    "RequestReceipt",
    "SessionHandle",
    "SetSpeedAction",
    "StopAction",
    "compute_zero_output",
    "read_uncalibrated_raw_angles",
    "validate_physical_draft",
)

DEFAULT_SLOT_PERIOD_S = 0.020
DEFAULT_INPUT_LEASE_S = 0.150
DEFAULT_EXCHANGE_DEADLINE_S = 0.050
DEFAULT_MAX_WINDOW_S = 0.200
DEFAULT_MAX_REFERENCE_GAP_S = 0.500
DEFAULT_FEEDBACK_MAX_AGE_S = 0.500
DEFAULT_SPEED_LIMIT_RAD_S = 0.500
MAX_SESSIONS = 16


class DispatchGuardOutcome(str, Enum):
    """Outcomes from the narrow coordinator dispatch guard seam."""

    ALLOW = "allow"
    REPLACE_HOLD = "replace_hold"
    REVOKE = "revoke"


@dataclass(frozen=True)
class SessionHandle:
    """Opaque capability identifying a registered client session."""

    session_id: str
    created_at_s: float

    def __post_init__(self) -> None:
        if type(self.session_id) is not str or not self.session_id:
            raise ValueError("session_id must be a non-empty string")
        validate_finite_time(self.created_at_s, "created_at_s")


@dataclass(frozen=True)
class InputTicket:
    """Session-scoped short-lived ticket binding owner generation and sequence."""

    ticket_id: str
    session_id: str
    owner_generation: int
    created_at_s: float
    expires_at_s: float
    bound_sequence: int

    def __post_init__(self) -> None:
        if type(self.ticket_id) is not str or not self.ticket_id:
            raise ValueError("ticket_id must be a non-empty string")
        if type(self.session_id) is not str or not self.session_id:
            raise ValueError("session_id must be a non-empty string")
        if type(self.owner_generation) is not int or self.owner_generation < 1:
            raise ValueError("owner_generation must be a positive integer")
        validate_finite_time(self.created_at_s, "created_at_s")
        validate_finite_time(self.expires_at_s, "expires_at_s")
        if self.expires_at_s <= self.created_at_s:
            raise ValueError("expires_at_s must follow created_at_s")
        if type(self.bound_sequence) is not int or self.bound_sequence < 0:
            raise ValueError("bound_sequence must be a non-negative integer")


@dataclass(frozen=True)
class ConnectAction:
    source_kind: str = "fixture"
    draft: "PhysicalDraft | None" = None


@dataclass(frozen=True)
class CheckAction:
    acknowledge_fault: bool = False


@dataclass(frozen=True)
class ArmAction:
    support_acknowledgment: bool = True


@dataclass(frozen=True)
class JogIntent:
    sequence: int
    axes: tuple[float, float, float]
    deadman: bool
    focus: bool
    device_epoch: str
    ticket: InputTicket

    def __post_init__(self) -> None:
        if type(self.sequence) is not int or self.sequence < 0:
            raise ValueError("sequence must be a non-negative integer")
        if type(self.axes) is not tuple or len(self.axes) != 3:
            raise ValueError("axes must be a 3-element tuple")
        for val in self.axes:
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                raise ValueError("each axis must be a finite real number")
            v = float(val)
            if not math.isfinite(v) or v < -1.0 or v > 1.0:
                raise ValueError("each axis must be in [-1.0, 1.0]")
        if type(self.deadman) is not bool:
            raise ValueError("deadman must be a bool")
        if type(self.focus) is not bool:
            raise ValueError("focus must be a bool")
        if type(self.device_epoch) is not str or not self.device_epoch:
            raise ValueError("device_epoch must be a non-empty string")
        if not isinstance(self.ticket, InputTicket):
            raise ValueError("ticket must be an InputTicket")


@dataclass(frozen=True)
class StopAction:
    reason: str = "operator_stop"


@dataclass(frozen=True)
class DisconnectAction:
    pass


@dataclass(frozen=True)
class SetSpeedAction:
    speed_rad_s: float

    def __post_init__(self) -> None:
        validate_finite_time(self.speed_rad_s, "speed_rad_s")
        if self.speed_rad_s <= 0.0:
            raise ValueError("speed_rad_s must be positive")


@dataclass(frozen=True)
class RequestReceipt:
    request_id: int
    action_name: str
    status: str
    code: str
    message: str
    timestamp_s: float


@dataclass(frozen=True)
class PhysicalJointDraft:
    motor_id: int
    name: str
    direction: int
    reference_joint_rad: float
    zero_output_rad: float | None = None
    q_min_rad: float | None = None
    q_max_rad: float | None = None
    v_max_rad_s: float | None = None
    a_max_rad_s2: float | None = None
    max_lead_rad: float | None = None
    max_effort_nm: float | None = None
    kp: float | None = None
    kd: float | None = None
    protection: ProtectionPolicy | None = None
    limits_provenance: str = ""


@dataclass(frozen=True)
class PhysicalDraft:
    port_config: PortConfig | None = None
    joints: tuple[PhysicalJointDraft, ...] = ()
    support_acknowledged: bool = False
    timeout_facts_acknowledged: bool = False
    allow_hardware_opt_in: bool = False


def validate_physical_draft(draft: PhysicalDraft | None) -> tuple[bool, list[str]]:
    """Validate completeness and safety of a physical arm commissioning draft."""
    if draft is None:
        return False, ["Physical draft is missing"]
    if not isinstance(draft, PhysicalDraft):
        return False, ["Draft must be an instance of PhysicalDraft"]

    errors: list[str] = []

    if not draft.allow_hardware_opt_in:
        errors.append("Hardware opening is not opted in (runtime opt-in required)")
    if draft.port_config is None or not isinstance(draft.port_config, PortConfig):
        errors.append("Valid PortConfig is required")
    if not draft.support_acknowledged:
        errors.append("Support acknowledgment is required before hardware connection")
    if not draft.timeout_facts_acknowledged:
        errors.append("Timeout facts acknowledgment is required (timeout unresolved)")

    if len(draft.joints) != 3:
        errors.append(f"Physical arm requires exactly 3 joints, found {len(draft.joints)}")
    else:
        ids = [j.motor_id for j in draft.joints]
        if ids != [0, 1, 2]:
            errors.append(f"Joint motor IDs must be [0, 1, 2], found {ids}")

        for j in draft.joints:
            if j.direction not in (-1, 1):
                errors.append(f"Joint {j.name} direction must be -1 or 1")
            if j.zero_output_rad is None or not math.isfinite(j.zero_output_rad):
                errors.append(f"Joint {j.name} zero_output_rad must be confirmed and finite")
            if j.q_min_rad is None or j.q_max_rad is None:
                errors.append(f"Joint {j.name} requires explicit finite position limits")
            elif j.q_min_rad >= j.q_max_rad:
                errors.append(f"Joint {j.name} q_min_rad must be strictly less than q_max_rad")
            elif j.motor_id in (1, 2) and (j.q_max_rad - j.q_min_rad) >= 2 * math.pi:
                errors.append(
                    f"Joint {j.name} full-turn travel assumption prohibited; finite operator clearance required"
                )
            elif j.motor_id == 0:
                ref = j.reference_joint_rad
                if j.q_min_rad < ref - math.pi / 2.0 or j.q_max_rad > ref + math.pi / 2.0:
                    errors.append(
                        f"Joint {j.name} position limits must be within +/- pi/2 about reference"
                    )

            if j.v_max_rad_s is None or j.v_max_rad_s <= 0.0:
                errors.append(f"Joint {j.name} requires positive finite v_max_rad_s")
            if j.a_max_rad_s2 is None or j.a_max_rad_s2 <= 0.0:
                errors.append(f"Joint {j.name} requires positive finite a_max_rad_s2")
            if j.max_lead_rad is None or j.max_lead_rad <= 0.0:
                errors.append(f"Joint {j.name} requires positive finite max_lead_rad")
            if j.max_effort_nm is None or j.max_effort_nm <= 0.0:
                errors.append(f"Joint {j.name} requires positive finite max_effort_nm")
            if j.kp is None or j.kp < 0.0:
                errors.append(f"Joint {j.name} requires non-negative finite kp")
            if j.kd is None or j.kd < 0.0:
                errors.append(f"Joint {j.name} requires non-negative finite kd")
            if j.protection is None or not isinstance(j.protection, ProtectionPolicy):
                errors.append(f"Joint {j.name} requires ProtectionPolicy")
            if not j.limits_provenance or not j.limits_provenance.strip():
                errors.append(f"Joint {j.name} requires non-empty limits_provenance")

    return (len(errors) == 0), errors


def compute_zero_output(
    measured_output_rad: float,
    direction: int,
    reference_joint_rad: float,
) -> float:
    """Compute zero_output = measured_output - direction * reference_joint."""
    if direction not in (-1, 1):
        raise ValueError("direction must be -1 or 1")
    return float(measured_output_rad) - float(direction) * float(reference_joint_rad)


def read_uncalibrated_raw_angles(
    bus: object,
    motor_ids: tuple[int, ...] = (0, 1, 2),
    *,
    deadline_s: float = 0.05,
) -> dict[int, float]:
    """Execute bounded mode 0 queries to read raw output encoder angles without bounds checks."""
    angles: dict[int, float] = {}
    for motor_id in motor_ids:
        stop_pkt = command(motor_id, mode=0)
        reply = exchange(bus, stop_pkt, motor_id, deadline_s=deadline_s)
        angles[motor_id] = float(reply["position_rad"])
    return angles


@dataclass(frozen=True)
class ArmStationSnapshot:
    """Immutable snapshot of station status, telemetry, and execution state."""

    lifecycle_state: str
    source: SourceIdentity | None
    requested_axes: tuple[float, float, float] | None
    admitted_goal: tuple[JointTarget, ...] | None
    dispatched_reference: tuple[JointTarget | None, ...] | None
    confirmed_reference: tuple[JointTrajectoryReference | None, ...] | None
    measured_sample: tuple[JointSample | None, ...]
    measured_health: tuple[MotorHealth | None, ...]
    feedback_ages_s: tuple[float | None, ...]
    faults: tuple[JointFault, ...]
    fault_latched: bool
    owner_session_id: str | None
    owner_generation: int | None
    input_phase: str
    hold_energized: bool
    stop_logical: bool
    stop_confirmed: bool
    per_joint_stop_confirmed: tuple[bool, ...]
    close_attempted: bool
    close_confirmed: bool
    close_unconfirmed: bool
    timing_counters: TimingCounters | None
    timing_snapshot: TimingSnapshot | None
    latest_receipt: RequestReceipt | None
    device_epoch: str | None
    selected_speed_rad_s: float
    commissioning_blocked: bool
    commissioning_reasons: tuple[str, ...]


class ArmStation:
    """Single execution station owning JointCore, coordinator, and transport."""

    def __init__(
        self,
        *,
        clock: Callable[[], float] | None = None,
        fixture: ArmPacketFixture | None = None,
        slot_period_s: float = DEFAULT_SLOT_PERIOD_S,
        input_lease_s: float = DEFAULT_INPUT_LEASE_S,
        exchange_deadline_s: float = DEFAULT_EXCHANGE_DEADLINE_S,
        max_reference_gap_s: float = DEFAULT_MAX_REFERENCE_GAP_S,
        feedback_max_age_s: float = DEFAULT_FEEDBACK_MAX_AGE_S,
        max_window_s: float = DEFAULT_MAX_WINDOW_S,
        jog_speed_rad_s: float = DEFAULT_SPEED_LIMIT_RAD_S,
        dispatch_guard: (
            Callable[[int, int, RefreshPlan], DispatchGuardOutcome] | None
        ) = None,
    ) -> None:
        self._clock = time.monotonic if clock is None else clock
        self.slot_period_s = validate_finite_time(slot_period_s, "slot_period_s")
        self.input_lease_s = validate_finite_time(input_lease_s, "input_lease_s")
        self.exchange_deadline_s = validate_finite_time(
            exchange_deadline_s, "exchange_deadline_s"
        )
        self.max_reference_gap_s = validate_finite_time(
            max_reference_gap_s, "max_reference_gap_s"
        )
        self.feedback_max_age_s = validate_finite_time(
            feedback_max_age_s, "feedback_max_age_s"
        )
        self.max_window_s = validate_finite_time(max_window_s, "max_window_s")
        self._selected_speed_rad_s = validate_finite_time(
            jog_speed_rad_s, "jog_speed_rad_s"
        )

        self.specs = create_synthetic_arm_specs()
        self.core = JointCore(
            self.specs,
            max_reference_gap_s=self.max_reference_gap_s,
            feedback_max_age_s=self.feedback_max_age_s,
            max_window_s=self.max_window_s,
            clock=self._clock,
        )

        self.bus = fixture if fixture is not None else ArmPacketFixture(clock=self._clock)
        self.managed_port: ManagedPort | None = None
        self.timing = StationTimingTracker(
            StationTimingConfig(nominal_period_s=self.slot_period_s),
        )
        self.coordinator = StationStepCoordinator(
            self.core,
            self.bus,
            self.timing,
            clock=self._clock,
            deadline_s=self.exchange_deadline_s,
        )

        self._mailbox_lock = threading.Lock()
        self._latest_intent: JogIntent | None = None
        self._lifecycle_queue: deque[tuple[int, object]] = deque(maxlen=16)
        self._persistent_release_latch: bool = False
        self._priority_stop_latch: bool = False
        self._priority_stop_reason: str | None = None

        self._sessions: dict[str, SessionHandle] = {}
        self._owner_session_id: str | None = None
        self._owner_generation: int = 0
        self._active_tickets: dict[str, InputTicket] = {}
        self._current_core_owner: OwnerToken | None = None
        self._last_accepted_intent_sequence: int = -1
        self._last_intent_server_time_s: float | None = None
        self._device_epoch: str | None = None

        self._needs_deadman_fresh_edge: bool = True
        self._observed_released_neutral: bool = False
        self._holding_position: bool = False
        self._hold_stationary_targets: tuple[JointTarget, ...] | None = None
        self._hold_energized: bool = False
        self._input_phase: str = "disconnected"
        self._next_core_sequence: int = 0

        self._per_joint_stop_confirmed: dict[int, bool] = {0: False, 1: False, 2: False}
        self._close_attempted: bool = False
        self._close_confirmed: bool = False
        self._close_unconfirmed: bool = False

        self._commissioning_blocked: bool = False
        self._commissioning_reasons: tuple[str, ...] = ()

        self._dispatch_guard = dispatch_guard
        self._receipts: dict[int, RequestReceipt] = {}
        self._next_request_id: int = 1

        self._loop_thread: threading.Thread | None = None
        self._loop_running = threading.Event()

    def _now(self) -> float:
        return validate_finite_time(self._clock(), "clock")

    def register_session(self, client_info: str = "") -> SessionHandle:
        """Issue a bounded session handle capability."""
        with self._mailbox_lock:
            if len(self._sessions) >= MAX_SESSIONS:
                raise RuntimeError("Maximum registered sessions exceeded")
            token = secrets.token_hex(16)
            handle = SessionHandle(session_id=token, created_at_s=self._now())
            self._sessions[token] = handle
            return handle

    def issue_ticket(self, session_handle: SessionHandle, sequence: int) -> InputTicket:
        """Issue a session-scoped single-use input ticket."""
        with self._mailbox_lock:
            if not isinstance(session_handle, SessionHandle):
                raise ValueError("session_handle must be a SessionHandle")
            if session_handle.session_id not in self._sessions:
                raise ValueError("Session handle is not registered")
            if (
                self._owner_session_id is not None
                and self._owner_session_id != session_handle.session_id
            ):
                raise ValueError("Session is not the current station owner")

            now = self._now()
            ticket_id = secrets.token_hex(16)
            ticket = InputTicket(
                ticket_id=ticket_id,
                session_id=session_handle.session_id,
                owner_generation=max(1, self._owner_generation),
                created_at_s=now,
                expires_at_s=now + self.input_lease_s,
                bound_sequence=sequence,
            )
            self._active_tickets[ticket_id] = ticket
            return ticket

    def request(self, action: object, session_handle: SessionHandle) -> RequestReceipt:
        """Submit a lifecycle action or jog intent."""
        now = self._now()
        with self._mailbox_lock:
            req_id = self._next_request_id
            self._next_request_id += 1

            if (
                not isinstance(session_handle, SessionHandle)
                or session_handle.session_id not in self._sessions
            ):
                receipt = RequestReceipt(
                    req_id,
                    type(action).__name__,
                    "rejected",
                    "UNKNOWN_SESSION",
                    "Session handle is not registered",
                    now,
                )
                self._receipts[req_id] = receipt
                return receipt

            if isinstance(action, StopAction):
                self._priority_stop_latch = True
                self._priority_stop_reason = action.reason
                receipt = RequestReceipt(
                    req_id, "Stop", "accepted", "STOP_QUEUED", "Priority stop queued", now
                )
                self._receipts[req_id] = receipt
                return receipt

            if self._owner_session_id is None:
                if isinstance(action, ConnectAction):
                    self._owner_session_id = session_handle.session_id
                    self._owner_generation += 1
                else:
                    receipt = RequestReceipt(
                        req_id,
                        type(action).__name__,
                        "rejected",
                        "NOT_OWNER",
                        "Action requires active station owner",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt
            elif self._owner_session_id != session_handle.session_id:
                receipt = RequestReceipt(
                    req_id,
                    type(action).__name__,
                    "rejected",
                    "NOT_OWNER",
                    "Another session owns the station",
                    now,
                )
                self._receipts[req_id] = receipt
                return receipt

            if isinstance(action, JogIntent):
                ticket = action.ticket
                if ticket.ticket_id not in self._active_tickets:
                    receipt = RequestReceipt(
                        req_id,
                        "JogIntent",
                        "rejected",
                        "INVALID_TICKET",
                        "Ticket not found or already consumed",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt

                del self._active_tickets[ticket.ticket_id]

                if ticket.session_id != self._owner_session_id:
                    receipt = RequestReceipt(
                        req_id,
                        "JogIntent",
                        "rejected",
                        "INVALID_TICKET",
                        "Ticket belongs to different session",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt

                if ticket.owner_generation != self._owner_generation:
                    receipt = RequestReceipt(
                        req_id,
                        "JogIntent",
                        "rejected",
                        "EXPIRED_OWNER_GENERATION",
                        "Ticket from expired owner generation",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt

                if now > ticket.expires_at_s:
                    receipt = RequestReceipt(
                        req_id,
                        "JogIntent",
                        "rejected",
                        "TICKET_EXPIRED",
                        "Ticket has expired",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt

                if action.sequence != ticket.bound_sequence:
                    receipt = RequestReceipt(
                        req_id,
                        "JogIntent",
                        "rejected",
                        "SEQUENCE_MISMATCH",
                        "Sequence does not match ticket bound sequence",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt

                if action.sequence <= self._last_accepted_intent_sequence:
                    receipt = RequestReceipt(
                        req_id,
                        "JogIntent",
                        "rejected",
                        "DUPLICATE_OR_OLDER",
                        "Sequence out of order or duplicate",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt

                if action.focus is False:
                    self._priority_stop_latch = True
                    self._priority_stop_reason = "focus_lost"
                    self._needs_deadman_fresh_edge = True
                    self._observed_released_neutral = False
                    receipt = RequestReceipt(
                        req_id,
                        "JogIntent",
                        "rejected",
                        "FOCUS_LOST",
                        "Focus lost; authority revoked",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt

                if self._device_epoch is None:
                    self._device_epoch = action.device_epoch
                elif self._device_epoch != action.device_epoch:
                    self._priority_stop_latch = True
                    self._priority_stop_reason = "device_epoch_changed"
                    self._device_epoch = action.device_epoch
                    self._needs_deadman_fresh_edge = True
                    self._observed_released_neutral = False
                    receipt = RequestReceipt(
                        req_id,
                        "JogIntent",
                        "rejected",
                        "DEVICE_EPOCH_CHANGED",
                        "Device epoch changed; authority revoked",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt

                self._last_accepted_intent_sequence = action.sequence
                self._last_intent_server_time_s = now
                if not action.deadman:
                    self._persistent_release_latch = True
                self._latest_intent = action

                receipt = RequestReceipt(
                    req_id,
                    "JogIntent",
                    "accepted",
                    "ACCEPTED",
                    "Jog intent admitted",
                    now,
                )
                self._receipts[req_id] = receipt
                return receipt

            if isinstance(action, SetSpeedAction):
                if action.speed_rad_s <= 0.0 or action.speed_rad_s > 2.0:
                    receipt = RequestReceipt(
                        req_id,
                        "SetSpeed",
                        "rejected",
                        "INVALID_SPEED",
                        "Requested speed out of bounds",
                        now,
                    )
                else:
                    self._selected_speed_rad_s = action.speed_rad_s
                    receipt = RequestReceipt(
                        req_id,
                        "SetSpeed",
                        "accepted",
                        "ACCEPTED",
                        "Selected speed updated",
                        now,
                    )
                self._receipts[req_id] = receipt
                return receipt

            if isinstance(action, (ConnectAction, CheckAction, ArmAction, DisconnectAction)):
                if len(self._lifecycle_queue) >= 16:
                    receipt = RequestReceipt(
                        req_id,
                        type(action).__name__,
                        "rejected",
                        "QUEUE_FULL",
                        "Lifecycle queue is full",
                        now,
                    )
                    self._receipts[req_id] = receipt
                    return receipt
                self._lifecycle_queue.append((req_id, action))
                receipt = RequestReceipt(
                    req_id,
                    type(action).__name__,
                    "queued",
                    "QUEUED",
                    "Lifecycle action queued",
                    now,
                )
                self._receipts[req_id] = receipt
                return receipt

            receipt = RequestReceipt(
                req_id,
                type(action).__name__,
                "rejected",
                "INVALID_ACTION",
                "Unrecognized action type",
                now,
            )
            self._receipts[req_id] = receipt
            return receipt

    def step(self, *, missed_slots: int = 0) -> LoopStepRecord:
        """Execute one complete station refresh cycle."""
        with self._mailbox_lock:
            if self._priority_stop_latch:
                self._priority_stop_latch = False
                self._priority_stop_reason = None
                self._holding_position = False
                self._hold_energized = False
                self._latest_intent = None
                self._input_phase = "stopped"
                self.core.stop()
                records = self.coordinator.check_step()
                for r in records:
                    self._per_joint_stop_confirmed[r.motor_id] = (
                        r.outcome == "OK" and r.feedback_received
                    )
                return self.coordinator.step(missed_slots=missed_slots)

            if self._lifecycle_queue:
                req_id, action = self._lifecycle_queue.popleft()
                self._handle_lifecycle_action(req_id, action)

            now = self._now()
            core_state = self.core.snapshot().state

            if core_state in (State.ARMED, State.MOVING):
                if self._last_intent_server_time_s is not None and (
                    now - self._last_intent_server_time_s > self.input_lease_s
                ):
                    self.core.stop()
                    records = self.coordinator.check_step()
                    for r in records:
                        self._per_joint_stop_confirmed[r.motor_id] = (
                            r.outcome == "OK" and r.feedback_received
                        )
                    self._holding_position = False
                    self._hold_energized = False
                    self._input_phase = "lease_expired"
                    return self.coordinator.step(missed_slots=missed_slots)

                intent = self._latest_intent

                if intent is not None and (
                    not intent.deadman or self._persistent_release_latch
                ):
                    self._persistent_release_latch = False
                    self._capture_and_submit_stationary_hold()
                    self._needs_deadman_fresh_edge = True
                    if all(a == 0.0 for a in intent.axes):
                        self._observed_released_neutral = True

                elif intent is not None and intent.deadman:
                    if self._needs_deadman_fresh_edge:
                        if self._observed_released_neutral:
                            self._needs_deadman_fresh_edge = False

                    if not self._needs_deadman_fresh_edge:
                        core_snap = self.core.snapshot()
                        if all(r is not None for r in core_snap.confirmed_references):
                            joint_goals = []
                            any_motion = any(a != 0.0 for a in intent.axes)
                            for spec, ref, axis in zip(
                                self.core.joint_specs,
                                core_snap.confirmed_references,
                                intent.axes,
                            ):
                                dt = max(0.001, now - ref.sample_time_s)
                                goal_q = (
                                    ref.q_rad + float(axis) * self._selected_speed_rad_s * dt
                                )
                                goal_q = max(spec.q_min_rad, min(spec.q_max_rad, goal_q))
                                joint_goals.append(
                                    JointTarget(
                                        q_rad=goal_q,
                                        dq_rad_s=0.0,
                                        tau_nm=0.0,
                                        kp=SYNTHETIC_KP,
                                        kd=SYNTHETIC_KD,
                                    )
                                )
                            window = self.core.issue_window(valid_for_s=self.max_window_s)
                            self._next_core_sequence += 1
                            target = Target(
                                sequence=self._next_core_sequence,
                                joints=tuple(joint_goals),
                                window=window,
                                owner=self._current_core_owner,
                            )
                            sub_dec = self.core.submit_target(target)
                            if sub_dec.accepted:
                                self._input_phase = "jogging" if any_motion else "holding"
                                self._holding_position = not any_motion
                                self._hold_energized = True

                if self._dispatch_guard is not None:
                    plan = self.core.prepare_refresh()
                    if plan is not None:
                        outcome = self._dispatch_guard(plan.plan_id, 0, plan)
                        if outcome is DispatchGuardOutcome.REPLACE_HOLD:
                            self._capture_and_submit_stationary_hold()
                        elif outcome is DispatchGuardOutcome.REVOKE:
                            self.core.stop()
                            records = self.coordinator.check_step()
                            for r in records:
                                self._per_joint_stop_confirmed[r.motor_id] = (
                                    r.outcome == "OK" and r.feedback_received
                                )
                            return self.coordinator.step(missed_slots=missed_slots)

            return self.coordinator.step(missed_slots=missed_slots)

    def _handle_lifecycle_action(self, req_id: int, action: object) -> None:
        now = self._now()
        if isinstance(action, ConnectAction):
            if action.source_kind == "fixture":
                if self.core.snapshot().state == State.DISCONNECTED:
                    self.core.begin_connect()
                    self.core.connected(SourceIdentity("fixture", "arm-fixture", 1))
                    self._input_phase = "connected"
                    self._receipts[req_id] = RequestReceipt(
                        req_id,
                        "Connect",
                        "accepted",
                        "CONNECTED",
                        "Connected to fixture",
                        now,
                    )
                else:
                    self._receipts[req_id] = RequestReceipt(
                        req_id,
                        "Connect",
                        "rejected",
                        "INVALID_STATE",
                        "Core already connected",
                        now,
                    )
            elif action.source_kind == "physical":
                is_valid, errors = validate_physical_draft(action.draft)
                if not is_valid:
                    self._commissioning_blocked = True
                    self._commissioning_reasons = tuple(errors)
                    self._receipts[req_id] = RequestReceipt(
                        req_id,
                        "Connect",
                        "rejected",
                        "COMMISSIONING_BLOCKED",
                        "; ".join(errors),
                        now,
                    )
                else:
                    self._receipts[req_id] = RequestReceipt(
                        req_id,
                        "Connect",
                        "accepted",
                        "CONNECTED",
                        "Physical draft validated",
                        now,
                    )

        elif isinstance(action, CheckAction):
            if self.core.snapshot().state not in (
                State.CONNECTED,
                State.STOPPED,
                State.FAULT,
            ):
                self._receipts[req_id] = RequestReceipt(
                    req_id,
                    "Check",
                    "rejected",
                    "INVALID_STATE",
                    "Core not in checkable state",
                    now,
                )
            else:
                if self._owner_session_id is not None:
                    self._current_core_owner = self.core.claim_owner(self._owner_session_id)
                dec = self.core.begin_check(acknowledge_fault=action.acknowledge_fault)
                if not dec.accepted:
                    self._receipts[req_id] = RequestReceipt(
                        req_id,
                        "Check",
                        "rejected",
                        dec.code.value,
                        "begin_check rejected",
                        now,
                    )
                else:
                    records = self.coordinator.check_step()
                    for r in records:
                        self._per_joint_stop_confirmed[r.motor_id] = (
                            r.outcome == "OK" and r.feedback_received
                        )
                    check_dec = self.core.checked()
                    if check_dec.accepted:
                        self._input_phase = "ready"
                        self._receipts[req_id] = RequestReceipt(
                            req_id,
                            "Check",
                            "accepted",
                            "READY",
                            "Check completed successfully",
                            now,
                        )
                    else:
                        self._input_phase = "check_failed"
                        self._receipts[req_id] = RequestReceipt(
                            req_id,
                            "Check",
                            "rejected",
                            check_dec.code.value,
                            "checked rejected",
                            now,
                        )

        elif isinstance(action, ArmAction):
            core_snap = self.core.snapshot()
            if core_snap.state != State.READY:
                self._receipts[req_id] = RequestReceipt(
                    req_id,
                    "Arm",
                    "rejected",
                    "NOT_READY",
                    "Arm requires READY state",
                    now,
                )
            elif not action.support_acknowledgment:
                self._receipts[req_id] = RequestReceipt(
                    req_id,
                    "Arm",
                    "rejected",
                    "SUPPORT_ACK_REQUIRED",
                    "Arm requires support acknowledgment",
                    now,
                )
            elif self._latest_intent is not None and (
                self._latest_intent.deadman
                or any(a != 0.0 for a in self._latest_intent.axes)
            ):
                self._receipts[req_id] = RequestReceipt(
                    req_id,
                    "Arm",
                    "rejected",
                    "INPUT_NOT_NEUTRAL",
                    "Arm requires released deadman and neutral axes",
                    now,
                )
            elif any(not j.healthy for j in core_snap.joints):
                self._receipts[req_id] = RequestReceipt(
                    req_id,
                    "Arm",
                    "rejected",
                    "UNHEALTHY",
                    "Arm requires healthy feedback",
                    now,
                )
            else:
                arm_dec = self.core.arm(self._current_core_owner)
                if not arm_dec.accepted:
                    self._receipts[req_id] = RequestReceipt(
                        req_id,
                        "Arm",
                        "rejected",
                        arm_dec.code.value,
                        "arm rejected",
                        now,
                    )
                else:
                    window = self.core.issue_window(valid_for_s=self.max_window_s)
                    hold_targets = tuple(
                        JointTarget(
                            q_rad=joint.sample.q_rad,
                            dq_rad_s=0.0,
                            tau_nm=0.0,
                            kp=SYNTHETIC_KP,
                            kd=SYNTHETIC_KD,
                        )
                        for joint in self.core.snapshot().joints
                    )
                    self._next_core_sequence += 1
                    target = Target(
                        sequence=self._next_core_sequence,
                        joints=hold_targets,
                        window=window,
                        owner=self._current_core_owner,
                    )
                    self.core.submit_target(target)
                    self._holding_position = True
                    self._hold_stationary_targets = hold_targets
                    self._hold_energized = True
                    self._input_phase = "holding"
                    self._needs_deadman_fresh_edge = True
                    self._observed_released_neutral = True
                    self._receipts[req_id] = RequestReceipt(
                        req_id,
                        "Arm",
                        "accepted",
                        "ARMED",
                        "Armed with measured hold",
                        now,
                    )

        elif isinstance(action, DisconnectAction):
            self.core.stop()
            self.coordinator.check_step()
            self.core.disconnect()
            self._holding_position = False
            self._hold_energized = False
            self._input_phase = "disconnected"
            self._receipts[req_id] = RequestReceipt(
                req_id,
                "Disconnect",
                "accepted",
                "DISCONNECTED",
                "Disconnected",
                now,
            )

    def _capture_and_submit_stationary_hold(self) -> None:
        core_snap = self.core.snapshot()
        if core_snap.confirmed_references and all(
            r is not None for r in core_snap.confirmed_references
        ):
            stationary_targets = tuple(
                JointTarget(
                    q_rad=ref.q_rad,
                    dq_rad_s=0.0,
                    tau_nm=0.0,
                    kp=SYNTHETIC_KP,
                    kd=SYNTHETIC_KD,
                )
                for ref in core_snap.confirmed_references
            )
        else:
            stationary_targets = tuple(
                JointTarget(
                    q_rad=j.sample.q_rad,
                    dq_rad_s=0.0,
                    tau_nm=0.0,
                    kp=SYNTHETIC_KP,
                    kd=SYNTHETIC_KD,
                )
                for j in core_snap.joints
            )
        window = self.core.issue_window(valid_for_s=self.max_window_s)
        self._next_core_sequence += 1
        target = Target(
            sequence=self._next_core_sequence,
            joints=stationary_targets,
            window=window,
            owner=self._current_core_owner,
        )
        self.core.submit_target(target)
        self._holding_position = True
        self._hold_stationary_targets = stationary_targets
        self._hold_energized = True
        self._input_phase = "holding"

    def run_steps(self, count: int) -> list[LoopStepRecord]:
        """Run a count of station steps sequentially."""
        if type(count) is not int or count < 1:
            raise ValueError("count must be a positive integer")
        return [self.step() for _ in range(count)]

    def start_loop(self) -> None:
        """Start background execution loop."""
        if self._loop_running.is_set():
            return
        self._loop_running.set()
        self._loop_thread = threading.Thread(target=self._loop_worker, daemon=True)
        self._loop_thread.start()

    def stop_loop(self) -> None:
        """Stop background execution loop."""
        if not self._loop_running.is_set():
            return
        self._loop_running.clear()
        if self._loop_thread is not None:
            self._loop_thread.join(timeout=1.0)
            self._loop_thread = None

    def _loop_worker(self) -> None:
        nominal = self.timing.config.nominal_period_s
        next_slot = self._now()
        while self._loop_running.is_set():
            missed = 0
            t_current = self._now()
            if t_current < next_slot:
                time.sleep(max(0.0, next_slot - t_current))
                t_current = self._now()
            if t_current > next_slot:
                missed, _ = self.timing.calculate_slot_skip(t_current, next_slot)
            try:
                record = self.step(missed_slots=missed)
                next_slot = record.started_s + nominal
            except Exception:
                next_slot = self._now() + nominal

    def close(self) -> bool:
        """Close station, stopping motors, settling executor, and closing transport lease."""
        if self._close_confirmed:
            return True
        self._close_attempted = True

        self._priority_stop_latch = True
        self._priority_stop_reason = "station_close"
        try:
            self.step()
        except Exception:
            pass

        if self._loop_running.is_set():
            self.stop_loop()

        closed = False
        if self.managed_port is not None:
            try:
                closed = bool(self.managed_port.close())
            except Exception:
                closed = False
        elif self.bus is not None:
            try:
                if hasattr(self.bus, "close"):
                    self.bus.close()
                closed = getattr(self.bus, "is_open", False) is False
            except Exception:
                closed = False
        else:
            closed = True

        if closed:
            self._close_confirmed = True
            self._close_unconfirmed = False
            return True

        self._close_confirmed = False
        self._close_unconfirmed = True
        return False

    def snapshot(self) -> ArmStationSnapshot:
        """Capture an immutable telemetry snapshot of the station."""
        with self._mailbox_lock:
            core_snap = self.core.snapshot()
            timing_snap = self.timing.snapshot() if self.timing is not None else None

            if core_snap.state == State.DISCONNECTED:
                samples = (None, None, None)
                healths = (None, None, None)
                ages = (None, None, None)
            else:
                samples = tuple(j.sample for j in core_snap.joints)
                healths = tuple(j.health for j in core_snap.joints)
                ages = core_snap.feedback_ages_s

            admitted_goal = (
                core_snap.admitted_target.joints
                if core_snap.admitted_target is not None
                else None
            )
            dispatched = tuple(
                r.target if r is not None else None for r in core_snap.dispatched_records
            )
            confirmed = core_snap.confirmed_references

            axes = self._latest_intent.axes if self._latest_intent is not None else None

            stop_logical = core_snap.state in (
                State.STOPPED,
                State.FAULT,
                State.DISCONNECTED,
            )
            all_stops_confirmed = (
                all(self._per_joint_stop_confirmed.values())
                and (core_snap.state in (State.STOPPED, State.READY))
            )

            return ArmStationSnapshot(
                lifecycle_state=core_snap.state.value,
                source=core_snap.source,
                requested_axes=axes,
                admitted_goal=admitted_goal,
                dispatched_reference=dispatched,
                confirmed_reference=confirmed,
                measured_sample=samples,
                measured_health=healths,
                feedback_ages_s=ages,
                faults=core_snap.faults,
                fault_latched=core_snap.fault_latched,
                owner_session_id=self._owner_session_id,
                owner_generation=self._owner_generation,
                input_phase=self._input_phase,
                hold_energized=self._hold_energized,
                stop_logical=stop_logical,
                stop_confirmed=all_stops_confirmed,
                per_joint_stop_confirmed=tuple(
                    self._per_joint_stop_confirmed[i] for i in (0, 1, 2)
                ),
                close_attempted=self._close_attempted,
                close_confirmed=self._close_confirmed,
                close_unconfirmed=self._close_unconfirmed,
                timing_counters=timing_snap.counters if timing_snap is not None else None,
                timing_snapshot=timing_snap,
                latest_receipt=self._receipts.get(self._next_request_id - 1),
                device_epoch=self._device_epoch,
                selected_speed_rad_s=self._selected_speed_rad_s,
                commissioning_blocked=self._commissioning_blocked,
                commissioning_reasons=self._commissioning_reasons,
            )
