An adversarial code review of the frozen Luna-repaired A02 station (`arm_station.py`), fixture (`arm_fixture.py`), and test contracts (`test_arm_station.py`) was conducted.

---

### Finding 1: Sticky `_neutral_seen` Allows High-Speed Jumps on Deadman Press Without Neutral at Input Time

**Severity:** High (Safety & Ingress Interlock Violation)  
**Location:** [`arm_station.py` L435–L445](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L435-L445), [L625–L630](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L625-L630), [L757–L773](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L757-L773)

#### Vulnerability
`self._neutral_seen` is set to `True` whenever a neutral intent (`axes == (0, 0, 0)` with `deadman == False`) is received. Once set, `_neutral_seen` is **never reset to `False`** when the operator subsequently moves the joystick away from neutral while deadman is released:

```python
# L757-L766
if not intent.deadman:
    if all(axis == 0.0 for axis in intent.axes):
        self._neutral_seen = True
    # If axes != 0, _neutral_seen is NOT cleared!
```

#### Exploit / Reproduction Logic
1. Station arms; `self._needs_neutral_and_edge = True` and `self._neutral_seen = False`.
2. Operator sends `Intent 1`: `axes = (0.0, 0.0, 0.0), deadman = False`. Station steps; `self._neutral_seen` transitions to `True`.
3. Operator deflects joystick to full stroke without pressing deadman: `Intent 2`: `axes = (1.0, 0.0, 0.0), deadman = False`. Station steps; `_neutral_seen` remains `True`.
4. Operator presses deadman while stick is already deflected at `1.0`: `Intent 3`: `axes = (1.0, 0.0, 0.0), deadman = True`.
5. In `_apply_intent`:
   ```python
   if self._needs_neutral_and_edge:
       if not (self._neutral_seen and fresh_edge): # Both evaluate to True!
           ...
       self._needs_neutral_and_edge = False
       self._neutral_seen = False
   ```
   Because `_neutral_seen` remained latched from step 2 and `fresh_edge` is `True`, `NEUTRAL_REQUIRED` is **bypassed**.
6. The arm immediately jumps into full velocity motion upon deadman press from a deflected stick.

---

### Finding 2: `DisconnectAction` and Station Close Leak Ownership Permanently Denying Service to Subsequent Sessions

**Severity:** High (Denial of Service / Authority Leak)  
**Location:** [`arm_station.py` L490–L505](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L490-L505), [L579–L612](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L579-L612), [L800–L820](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L800-L820)

#### Vulnerability
`self._owner_session_id` is bound when a session first issues a lifecycle request (such as `ConnectAction`). However, when `DisconnectAction` or `close()` completes, `self._owner_session_id` is **never cleared**:

```python
# L799 in _handle_lifecycle_action (DisconnectAction)
with self._condition:
    self._owner_generation += 1
    self._revoke_ingress_locked(disconnected_at, "DISCONNECTED", ...)
self._current_core_owner = None
# self._owner_session_id remains set to the old session!
```

In `request()`:
```python
# L492-L498
elif self._owner_session_id is not None and (
    self._owner_session_id != session_handle.session_id
):
    receipt = self._new_receipt_locked(
        request_id, name, "rejected", "NOT_OWNER",
        "Another session owns the station", now
    )
```

#### Exploit / Reproduction Logic
1. `session_1 = station.register_session("s1")`.
2. `station.request(ConnectAction(), session_1)`. Station steps (`_owner_session_id = session_1.session_id`).
3. `station.request(DisconnectAction(), session_1)`. Station steps (`DISCONNECTED`).
4. `session_2 = station.register_session("s2")`.
5. `receipt = station.request(ConnectAction(), session_2)`.
6. Receipt is immediately rejected with `"NOT_OWNER"` (`"Another session owns the station"`). No subsequent session can ever connect or acquire station authority for the lifetime of the process.

---

### Finding 3: `stop_loop()` Kills Background Worker but Leaves Station in `"background"` Mode, Hanging Subsequent `close()`

**Severity:** Medium (Deadlock / Resource Leak)  
**Location:** [`arm_station.py` L970–L980](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L970-L980), [L982–L1015](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L982-L1015)

#### Vulnerability
`stop_loop()` sets `self._loop_stop_requested = True`, notifies the condition variable, and joins `self._loop_thread`. The thread terminates. However, `self._execution_mode` is left as `"background"`:

```python
# In close()
if mode == "background":
    if thread is None:
        return False
    with self._condition:
        self._condition.wait_for(
            lambda: self._close_completed_id >= request_id,
            timeout=BACKGROUND_CLOSE_WAIT_S,
        )
        return self._close_completed_id >= request_id and self._close_confirmed
```

#### Reproduction Logic
1. `station.start_loop()`.
2. `station.stop_loop()`. (Worker thread joins and exits).
3. Call `station.close()`.
4. `close()` inspects `mode == "background"`. It enters `wait_for(lambda: self._close_completed_id >= request_id, timeout=1.0)`.
5. Because the worker thread is dead, `_close_completed_id` is never advanced.
6. `station.close()` hangs for the full 1.0s timeout and returns `False`. The station can never confirm close after `stop_loop()`.

---

### Finding 4: Background Executor Failure Drops Hardware Stop Command

**Severity:** High (Safety / Actuator Runaway Protection)  
**Location:** [`arm_station.py` L921–L968](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L921-L968) (`_record_executor_failure`)

#### Vulnerability
When an unexpected exception occurs inside `_loop_worker` (e.g., timing jitter error, unhandled coordinate math, or port fault), execution drops to `_record_executor_failure()`.
This method invokes:
```python
if self._core is not None:
    stop_accepted = self._core.stop().accepted
```
`JointCore.stop()` is purely an in-memory state transition. It **never transmits Mode 0 Stop packets** to `ArmPacketFixture` or physical motors. `self._coordinator.check_step()` is never called.

#### Consequence
If the station was actively jogging in Mode 1 when the executor exception occurred, the actuators are never actively commanded to stop. Motors will continue executing their last command until their hardware timeout fires. Furthermore, because the loop worker terminates, `stop_pending` remains `True` with no executor alive to ever service it.

---

### Finding 5: `ArmAction` "INPUT_NOT_NEUTRAL" Safety Check is Dead Code

**Severity:** Low (Dead Code / False Claim of Ingress Validation)  
**Location:** [`arm_station.py` L744–L747](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L744-L747)

#### Vulnerability
In `_handle_lifecycle_action` for `ArmAction`:
```python
if not code and latest is not None and (expiry is None or now < expiry) and (
    latest.deadman or any(axis != 0.0 for axis in latest.axes)
):
    code, message = "INPUT_NOT_NEUTRAL", "Arm requires released neutral input"
```
`latest` is `self._latest_intent`.
However:
1. `issue_ticket()` enforces:
   ```python
   if not self._input_enabled ...:
       raise RuntimeError("Input tickets require an armed station with live authority")
   ```
2. `self._input_enabled` is only set to `True` *after* `ArmAction` succeeds.
3. In `State.READY`, `self._input_enabled` is always `False`, making ticket generation impossible.
4. Any `JogIntent` submitted without a valid ticket is rejected with `INVALID_TICKET` and never populates `_latest_intent`.
5. `_execute_stop` and `_revoke_ingress_locked` explicitly set `self._latest_intent = None`.

Therefore, whenever `ArmAction` runs from `State.READY`, `latest` is **guaranteed to be `None`**. The `INPUT_NOT_NEUTRAL` rejection code path can never execute under any circumstances.

---

### Finding 6: Jog Trajectory `dt` Computed Asynchronously Per-Joint Breaks Kinematic Coordination

**Severity:** Medium (Trajectory Skew & Distorted Motion)  
**Location:** [`arm_station.py` L791–L812](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L791-L812)

#### Vulnerability
In `_apply_intent`:
```python
for ref, axis in zip(refs, intent.axes):
    dt = now - ref.sample_time_s
    ...
    goals.append(
        JointTarget(
            q_rad=ref.q_rad + float(axis) * speed_rad_s * dt,
            dq_rad_s=0.0,
            tau_nm=0.0,
            kp=SYNTHETIC_KP,
            kd=SYNTHETIC_KD,
        )
    )
```
`dt` is evaluated against each joint's individual `ref.sample_time_s`.
If joint feedback timestamps differ (e.g., J1 was confirmed at $T$, while J2 had a delayed transaction or was confirmed during re-anchor at $T - \Delta t$), J1 and J2 will compute different $dt$ intervals ($dt_1 \neq dt_2$).
A diagonal jog command (`axes = (1.0, 1.0, 0.0)`) will command uneven displacements to J1 and J2 proportional to their timestamp skew, distorting the intended Cartesian or joint-space trajectory.

---

### Finding 7: Receipt Queue Eviction Silently Drops Terminal Lifecycle Receipts

**Severity:** Medium (Contract Breach & Client Deadlock)  
**Location:** [`arm_station.py` L320–L336](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L320-L336), [L348–L355](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L348-L355)

#### Vulnerability
`self._receipts` is an `OrderedDict` bounded by `MAX_RECEIPTS = 64`.
In `_finish_receipt`:
```python
with self._condition:
    if request_id not in self._receipts:
        return
```
In a 50 Hz jog stream, 64 receipts represent ~1.28 seconds of history. If a lifecycle action (e.g., `ArmAction` or `CheckAction`) is queued and 64 jog requests are submitted before or while the lifecycle transition completes on the executor:
1. The lifecycle `request_id` is evicted from `self._receipts`.
2. When `_handle_lifecycle_action` completes and calls `_finish_receipt(request_id, ...)`, the check `if request_id not in self._receipts: return` silently aborts.
3. The terminal status (`accepted` or `rejected`) is discarded and never published in `latest_receipt`. Clients waiting on the receipt will poll until timeout.

---

### Finding 8: `_loop_worker` Uses Uninterruptible `time.sleep` Instead of Condition Variable

**Severity:** Low (Latency & Ineffective Stop Signaling)  
**Location:** [`arm_station.py` L887–L890](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py#L887-L890)

#### Vulnerability
```python
if now < next_slot:
    time.sleep(next_slot - now)
    now = self._now()
```
`request(StopAction)` executes `self._condition.notify_all()`. However, `_loop_worker` sleeps with OS `time.sleep` rather than `self._condition.wait(timeout=...)`. The background executor thread is deaf to condition notifications while sleeping, delaying Priority Stop execution by up to the remainder of the slot period.

---

### Summary of Verification and Changes

- **Inspected Files:**
  - [`arm_station.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_station.py)
  - [`arm_fixture.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/arm_fixture.py)
  - [`test_arm_station.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/test_arm_station.py)
  - [`joint_contract.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/joint_contract.py)
  - [`joint_controller.py`](file:///home/sid/Documents/code/im6014Workbench-runs/arm-priority-20261009/A02-luna-workbench/joint_controller.py)
- **Modifications:** None. Read-only inspection in compliance with the subordinate worker contract.