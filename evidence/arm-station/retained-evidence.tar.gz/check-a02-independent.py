from pathlib import Path
import dataclasses, importlib, json, sys, threading, unittest
workspace=Path(sys.argv[1]);report=Path(sys.argv[2]);sys.path.insert(0,str(workspace))
import serial
def deny_physical(*args,**kwargs):raise AssertionError('Physical acquisition excluded')
serial.Serial=deny_physical
import im6014_port
im6014_port.open_managed_port=deny_physical
from arm_station import ArmStation,ConnectAction,CheckAction,ArmAction,JogIntent,StopAction
from arm_fixture import ArmPacketFixture
from im6014_codec import decode_command
class Clock:
 def __init__(self):self.value=10.0
 def __call__(self):return self.value
 def advance(self,dt=.02):self.value+=dt
class ParentArmChecks(unittest.TestCase):
 def setUp(self):
  self.clock=Clock();self.fixture=ArmPacketFixture(clock=self.clock);self.station=ArmStation(clock=self.clock,fixture=self.fixture);self.owner=self.station.register_session()
 def step(self):self.clock.advance();return self.station.step()
 def ready(self):
  self.station.request(ConnectAction(),self.owner);self.step();self.station.request(CheckAction(),self.owner);self.step();self.assertEqual(self.station.snapshot().lifecycle_state,'ready')
 def armed(self):
  self.ready();self.station.request(ArmAction(support_acknowledgment=True),self.owner);self.step();self.step();self.assertIn(self.station.snapshot().lifecycle_state,('armed','moving'))
 def intent(self,n,axes=(0,0,0),held=False):
  ticket=self.station.issue_ticket(self.owner,n);return self.station.request(JogIntent(n,axes,held,True,'parent-keyboard',ticket),self.owner)
 def test_zero_elapsed_does_not_invent_time_or_report_faulted_hold(self):
  self.station.request(ConnectAction(),self.owner);self.station.step();self.station.request(CheckAction(),self.owner);self.station.step();self.station.request(ArmAction(),self.owner);self.station.step();view=self.station.snapshot();self.assertNotEqual(view.lifecycle_state,'fault');self.assertEqual(sum(decode_command(p)['mode']==1 for p in self.fixture.writes),0)
 def test_ready_remains_fresh_then_explicit_arm_after_seconds(self):
  self.ready()
  for _ in range(150):self.step()
  self.assertEqual(self.station.snapshot().lifecycle_state,'ready');self.station.request(ArmAction(),self.owner);self.step();self.step();self.assertIn(self.station.snapshot().lifecycle_state,('armed','moving'))
 def test_original_expired_ticket_forgery_is_rejected(self):
  self.armed();ticket=self.station.issue_ticket(self.owner,1);self.clock.advance(.16);forged=dataclasses.replace(ticket,expires_at_s=self.clock()+100);receipt=self.station.request(JogIntent(1,(0,0,0),False,True,'parent-keyboard',forged),self.owner);self.assertEqual(receipt.status,'rejected');self.station.step();self.assertNotIn(self.station.snapshot().lifecycle_state,('armed','moving'))
 def test_thousand_unused_tickets_do_not_leave_old_authority(self):
  self.armed();tickets=[self.station.issue_ticket(self.owner,n) for n in range(1000)];receipt=self.station.request(JogIntent(0,(0,0,0),False,True,'parent-keyboard',tickets[0]),self.owner);self.assertEqual(receipt.status,'rejected');pending=[value for value in vars(self.station).values() if isinstance(value,dict) and any(type(item).__name__=='InputTicket' for item in value.values())];self.assertLessEqual(sum(len(d) for d in pending),16)
 def test_public_snapshot_does_not_call_core_on_reader_threads(self):
  self.armed();module=importlib.import_module('arm_station');original=module.JointCore.snapshot;calls=[]
  def observe(core):calls.append(threading.get_ident());return original(core)
  module.JointCore.snapshot=observe
  try:
   readers=[threading.Thread(target=lambda:[self.station.snapshot() for _ in range(100)]) for _ in range(4)]
   for reader in readers:reader.start()
   for reader in readers:reader.join(2)
   self.assertTrue(all(not reader.is_alive() for reader in readers));self.assertEqual(calls,[])
  finally:module.JointCore.snapshot=original
 def test_stop_ingress_during_blocked_fake_exchange(self):
  self.fixture=ArmPacketFixture();self.station=ArmStation(fixture=self.fixture);self.owner=self.station.register_session()
  self.station.request(ConnectAction(),self.owner);entered=threading.Event();release=threading.Event();stopped=threading.Event();original=self.fixture.write
  def blocked(packet):entered.set();assert release.wait(2);return original(packet)
  self.fixture.write=blocked
  self.station.start_loop()
  import time
  until=time.monotonic()+2
  while self.station.snapshot().lifecycle_state!='connected' and time.monotonic()<until:time.sleep(.005)
  self.station.request(CheckAction(),self.owner);self.assertTrue(entered.wait(2))
  def stop():self.station.request(StopAction(),self.owner);stopped.set()
  reader=threading.Thread(target=stop);reader.start()
  try:self.assertTrue(stopped.wait(.2),'Stop ingress blocked behind fake serial I/O')
  finally:release.set();reader.join(2);self.station.close()
 def test_positive_elapsed_neutral_repress_jog_preserves_core_limits(self):
  self.armed();self.intent(1);self.step();self.intent(2,(1,0,0),True);self.step();view=self.station.snapshot();self.assertIn(view.lifecycle_state,('armed','moving'));self.assertFalse(view.fault_latched);reference=view.confirmed_reference[0];self.assertGreater(reference.q_rad,0);self.assertLessEqual(float(reference.position_step_velocity_rad_s),.5)
 def test_wrong_mode_cannot_confirm_stop(self):
  self.armed();self.fixture.inject_stop_failure_ids={1};self.station.request(StopAction(),self.owner);self.step();self.assertEqual(self.station.snapshot().per_joint_stop_confirmed,(True,False,True));self.assertFalse(self.station.snapshot().stop_confirmed);self.assertEqual([decode_command(p)['motor_id'] for p in self.fixture.writes[-3:]],[0,1,2])
 def tearDown(self):
  self.fixture.write=getattr(self,'original_write',self.fixture.write)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(ParentArmChecks)
outcome=unittest.TextTestRunner(verbosity=2).run(suite)
report.write_text(json.dumps({'testsRun':outcome.testsRun,'failures':[str(t) for t,_ in outcome.failures],'errors':[str(t) for t,_ in outcome.errors],'success':outcome.wasSuccessful(),'hardwareIO':False,'scope':'Independent parent regressions on frozen selected source'},indent=2)+'\n')
raise SystemExit(not outcome.wasSuccessful())
